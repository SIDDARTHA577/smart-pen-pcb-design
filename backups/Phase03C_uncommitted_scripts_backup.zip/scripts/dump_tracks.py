import pcbnew
from pathlib import Path

pcb_path = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb")
board = pcbnew.LoadBoard(str(pcb_path))

tracks = board.GetTracks()
print(f"Index, Type, Net, Layer, Start(x, y), End(x, y), Width, UUID")
for i, t in enumerate(tracks):
    t_type = "VIA" if "VIA" in t.GetClass() else "TRACK"
    net = t.GetNetname()
    layer = t.GetLayerName() if t_type == "TRACK" else f"{board.GetLayerName(t.TopLayer())}-{board.GetLayerName(t.BottomLayer())}"
    sx, sy = t.GetStart().x / 1e6, t.GetStart().y / 1e6
    ex, ey = t.GetEnd().x / 1e6, t.GetEnd().y / 1e6
    w = t.GetWidth() / 1e6
    uuid = str(t.m_Uuid.AsString())
    print(f"[{i:3d}] {t_type:5s} {net:20s} {layer:10s} ({sx:6.2f}, {sy:5.2f}) -> ({ex:6.2f}, {ey:5.2f}) w={w:.2f} uuid={uuid}")

