import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
d4 = b.FindFootprintByReference('D4')
d4.SetPosition(pcbnew.VECTOR2I(int(59.0*1e6), int(3.5*1e6)))

geom = BoardGeometry(b)
for vy in [1.0, 1.2, 1.5, 2.0, 2.5, 2.8, 3.0, 3.2]:
    for vx in [59.150, 59.300, 59.400]:
        v, rv = geom.is_via_legal(vx, vy, '/SD_MISO')
        if v:
            print(f"SD_MISO via legal at ({vx:.3f}, {vy:.2f})")
