import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

board_path = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb'
b = pcbnew.LoadBoard(board_path)

gnd_net = b.FindNet('/GND')
vbat_net = b.FindNet('/VBAT_SW')
dm_net = b.FindNet('/USB_DM_CORE')

tracks = [t for t in b.Tracks()]
# 1. Remove the shorting via at (30.753, 4.400) and any track to it
for t in tracks:
    if isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/VBAT_SW':
        pos = t.GetPosition()
        px, py = pos.x / 1e6, pos.y / 1e6
        if abs(px - 30.753) < 0.2 and abs(py - 4.400) < 0.2:
            b.Remove(t)
    elif not isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/VBAT_SW':
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = s.x / 1e6, s.y / 1e6
        ex, ey = e.x / 1e6, e.y / 1e6
        if (abs(sx - 30.753) < 0.2 and abs(sy - 4.400) < 0.2) or (abs(ex - 30.753) < 0.2 and abs(ey - 4.400) < 0.2):
            b.Remove(t)

# 2. Fix thermal vias: move from 5.8 down to 5.2
for t in tracks:
    if isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/GND':
        pos = t.GetPosition()
        px, py = pos.x / 1e6, pos.y / 1e6
        if 42.0 <= px <= 44.0 and 5.5 <= py <= 6.0:
            b.Remove(t)

# Ensure the 4 clean corner thermal vias exist at Y=3.8 and Y=5.2
existing_vias = []
for t in tracks:
    if isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/GND':
        pos = t.GetPosition()
        existing_vias.append((round(pos.x / 1e6, 2), round(pos.y / 1e6, 2)))

for vx, vy in [(42.2, 3.8), (43.5, 3.8), (42.2, 5.2), (43.5, 5.2)]:
    if (vx, vy) not in existing_vias:
        v = pcbnew.PCB_VIA(b)
        v.SetNet(gnd_net)
        v.SetPosition(pcbnew.VECTOR2I(int(vx * 1e6), int(vy * 1e6)))
        v.SetWidth(int(0.50 * 1e6))
        v.SetDrill(int(0.30 * 1e6))
        v.SetViaType(pcbnew.VIATYPE_THROUGH)
        b.Add(v)

# 3. Clean up DM crossing on In2.Cu:
# Remove the long In2.Cu track at Y=5.800
for t in tracks:
    if t.GetNetname() == '/USB_DM_CORE' and t.GetLayerName() == 'In2.Cu':
        b.Remove(t)
    elif isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/USB_DM_CORE':
        pos = t.GetPosition()
        px, py = pos.x / 1e6, pos.y / 1e6
        if abs(px - 73.0) < 0.2 and abs(py - 7.0) < 0.2:
            b.Remove(t)
        elif abs(px - 52.0) < 0.2 and abs(py - 7.0) < 0.2:
            b.Remove(t)
    elif t.GetNetname() == '/USB_DM_CORE' and t.GetLayerName() == 'F.Cu':
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = s.x / 1e6, s.y / 1e6
        ex, ey = e.x / 1e6, e.y / 1e6
        if max(sx, ex) >= 72.0:
            b.Remove(t)

filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
b.Save(board_path)
print("Cleanup executed successfully!")
sys.exit(0)
