import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
bcu_id = b.GetLayerID('B.Cu')
in2_id = b.GetLayerID('In2.Cu')

# Adjust VBAT_SW
to_remove = []
for t in b.Tracks():
    if not isinstance(t, pcbnew.PCB_VIA) and t.GetLayer() == bcu_id and t.GetNetname() == '/VBAT_SW':
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (x1 == 38.0 and x2 == 40.5) or (x1 == 40.5 and x2 == 52.0):
            to_remove.append(t)
for t in to_remove:
    b.Remove(t)

def add_track(x1, y1, x2, y2, layer_id, net_name, width=0.25):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(x1*1e6), int(y1*1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2*1e6), int(y2*1e6)))
    t.SetLayer(layer_id)
    t.SetWidth(int(width*1e6))
    t.SetNet(b.FindNet(net_name))
    b.Add(t)

add_track(38.000, 4.050, 41.200, 4.050, bcu_id, '/VBAT_SW', 0.25)
add_track(41.200, 4.050, 41.650, 4.500, bcu_id, '/VBAT_SW', 0.25)
add_track(41.650, 4.500, 52.000, 4.500, bcu_id, '/VBAT_SW', 0.25)

geom = BoardGeometry(b)

# Via is at (24.250, 7.150) -> already connected to U3.1.
# Can we run from (24.250, 7.150) on In2.Cu or B.Cu?
print("Testing In2.Cu from (24.250, 7.150) -> ... -> (38.800, 4.585)")
# Let's check segments on In2.Cu:
# Say (24.250, 7.150) -> (38.800, 7.150) -> (38.800, 4.585)
s1, r1 = geom.is_segment_legal(24.250, 7.150, 38.800, 7.150, 'In2.Cu', '/I2C_SCL')
s2, r2 = geom.is_segment_legal(38.800, 7.150, 38.800, 4.585, 'In2.Cu', '/I2C_SCL')
print(f"In2.Cu straight: s1={s1} ({r1}), s2={s2} ({r2})")

# Also test B.Cu:
# What about (24.250, 7.150) -> (25.000, 7.150) -> (25.000, 5.600) -> (38.800, 5.600) -> (38.800, 4.585)
s_b1, rb1 = geom.is_segment_legal(24.250, 7.150, 25.000, 7.150, 'B.Cu', '/I2C_SCL')
s_b2, rb2 = geom.is_segment_legal(25.000, 7.150, 25.000, 5.600, 'B.Cu', '/I2C_SCL')
s_b3, rb3 = geom.is_segment_legal(25.000, 5.600, 38.800, 5.600, 'B.Cu', '/I2C_SCL')
s_b4, rb4 = geom.is_segment_legal(38.800, 5.600, 38.800, 4.585, 'B.Cu', '/I2C_SCL')
print(f"B.Cu route: s1={s_b1}({rb1}), s2={s_b2}({rb2}), s3={s_b3}({rb3}), s4={s_b4}({rb4})")
