import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print("PADS on F.Cu between X=44 and 55, Y=6.0..8.5:")
for p in b.GetPads():
    pos = p.GetPosition()
    px, py = pos.x / 1e6, pos.y / 1e6
    if 44.0 <= px <= 55.0 and 6.0 <= py <= 8.5:
        fp = p.GetParentFootprint()
        ref = fp.GetReference() if fp else '?'
        print(f"  {ref}.{p.GetNumber()} [{p.GetNetname()}] at ({px:.3f}, {py:.3f})")

print("\nTRACKS on F.Cu between X=44 and 55, Y=6.0..8.5:")
for t in b.GetTracks():
    if not isinstance(t, pcbnew.PCB_VIA) and t.GetLayerName() == 'F.Cu':
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = s.x / 1e6, s.y / 1e6
        ex, ey = e.x / 1e6, e.y / 1e6
        if ((44.0 <= sx <= 55.0 and 6.0 <= sy <= 8.5) or 
            (44.0 <= ex <= 55.0 and 6.0 <= ey <= 8.5)):
            print(f"  TRACK F.Cu [{t.GetNetname()}] ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})")

sys.exit(0)
