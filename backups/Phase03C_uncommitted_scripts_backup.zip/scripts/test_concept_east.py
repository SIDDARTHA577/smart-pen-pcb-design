import os, sys, math, json, subprocess
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try: import wx; wx.DisableAsserts()
except: pass
import pcbnew, shutil

# Test candidate:
# SCK via at (58.150, 3.450) to In2.Cu!
# Pad 4 (MOSI) via at (57.650, 2.500) to B.Cu!
# Pad 5 (MISO) via at (59.800, 2.500) or around east!
print("Testing concept...")
