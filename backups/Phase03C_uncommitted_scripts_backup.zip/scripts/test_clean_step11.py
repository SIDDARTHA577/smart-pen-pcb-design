import os, sys, math, json
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try: import wx; wx.DisableAsserts()
except: pass
import pcbnew, shutil

src_pcb = 'scratch_test_clean_step10.kicad_pcb'
dst_pcb = 'scratch_test_clean_step11.kicad_pcb'
shutil.copy(src_pcb, dst_pcb)
shutil.copy(src_pcb.replace('.kicad_pcb', '.kicad_pro'), dst_pcb.replace('.kicad_pcb', '.kicad_pro'))

b = pcbnew.LoadBoard(dst_pcb)
bcu = b.GetLayerID('B.Cu')
net_3v3 = b.FindNet('/3V3')

def add_trk(netname, layer_id, x1, y1, x2, y2, w=0.20):
    net = b.FindNet(netname)
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(round(x1 * 1e6)), int(round(y1 * 1e6))))
    t.SetEnd(pcbnew.VECTOR2I(int(round(x2 * 1e6)), int(round(y2 * 1e6))))
    t.SetWidth(int(round(w * 1e6)))
    t.SetLayer(layer_id)
    t.SetNet(net)
    b.Add(t)
    return t

# 3V3 Bridge on B.Cu from (56.945, 3.636) to (60.146, 7.807)
add_trk('/3V3', bcu, 56.945, 3.636, 56.945, 7.807, 0.20)
add_trk('/3V3', bcu, 56.945, 7.807, 60.146, 7.807, 0.20)

filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
b.Save(dst_pcb)
print("Saved clean step 11.")