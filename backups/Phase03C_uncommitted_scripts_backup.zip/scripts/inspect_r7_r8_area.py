import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print("PADS near R7/R8 (X: 70..74, Y: 5.0..8.5):")
for p in b.GetPads():
    pos = p.GetPosition()
    px, py = pos.x / 1e6, pos.y / 1e6
    if 70.0 <= px <= 74.0 and 5.0 <= py <= 8.5:
        fp = p.GetParentFootprint()
        ref = fp.GetReference() if fp else '?'
        print(f"  {ref}.{p.GetNumber()} [{p.GetNetname()}] at ({px:.3f}, {py:.3f})")

print("\nTRACKS near R7/R8 (X: 70..74, Y: 5.0..8.5):")
for t in b.GetTracks():
    if not isinstance(t, pcbnew.PCB_VIA):
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = s.x / 1e6, s.y / 1e6
        ex, ey = e.x / 1e6, e.y / 1e6
        if ((70.0 <= sx <= 74.0 and 5.0 <= sy <= 8.5) or 
            (70.0 <= ex <= 74.0 and 5.0 <= ey <= 8.5)):
            print(f"  TRACK {t.GetLayerName()} [{t.GetNetname()}] ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})")

sys.exit(0)
