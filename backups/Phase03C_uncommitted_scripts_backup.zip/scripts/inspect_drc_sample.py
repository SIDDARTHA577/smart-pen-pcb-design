import json
from pathlib import Path

drc_path = Path("reports/RevG/Phase03C/raw/baseline/Main_SmartPen_drc.json")
with open(drc_path, "r", encoding="utf-8") as f:
    drc = json.load(f)

print("Violation 0:")
print(json.dumps(drc["violations"][0], indent=2))

print("\nUnconnected 0:")
print(json.dumps(drc["unconnected_items"][0], indent=2))

