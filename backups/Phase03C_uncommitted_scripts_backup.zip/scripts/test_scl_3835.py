import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

s1, r1 = geom.is_segment_legal(38.000, 5.600, 38.350, 5.600, 'F.Cu', '/I2C_SCL')
s2, r2 = geom.is_segment_legal(38.350, 5.600, 38.800, 4.585, 'F.Cu', '/I2C_SCL')
s3, r3 = geom.is_segment_legal(38.800, 4.585, 40.480, 4.585, 'F.Cu', '/I2C_SCL')

print(f"s1: {s1} ({r1})")
print(f"s2: {s2} ({r2})")
print(f"s3: {s3} ({r3})")
