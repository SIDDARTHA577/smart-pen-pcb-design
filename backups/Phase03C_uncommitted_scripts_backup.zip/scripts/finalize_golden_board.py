import os
import sys
import pcbnew

def build_golden_board():
    src_path = 'scratch_test_vip.kicad_pcb'
    dst_path = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb'
    
    print(f"Loading base board from {src_path}...")
    b = pcbnew.LoadBoard(src_path)
    
    # 1. Delete freestanding GND via at (55.00, 1.20)
    for t in list(b.GetTracks()):
        if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 55.00 and round(t.GetPosition().y/1e6, 2) == 1.20:
            b.Delete(t)
            print("Deleted freestanding GND via at (55.00, 1.20)")
            
    # 2. Relocate VSYS_RAW via from (59.50, 2.40) to D4.1 pad (59.00, 2.40)
    for t in list(b.GetTracks()):
        if t.GetNetname() == '/VSYS_RAW':
            if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().y/1e6, 1) in [2.4, 1.2]:
                b.Delete(t)
            elif t.GetClass() != 'PCB_VIA' and round(t.GetStart().x/1e6, 1) == 59.5:
                b.Delete(t)
    
    v_vsys = pcbnew.PCB_VIA(b)
    v_vsys.SetPosition(pcbnew.VECTOR2I(int(59.000*1e6), int(2.400*1e6)))
    v_vsys.SetWidth(int(0.500*1e6))
    v_vsys.SetDrill(int(0.300*1e6))
    v_vsys.SetNet(b.FindNet('/VSYS_RAW'))
    b.Add(v_vsys)
    print("Placed VSYS_RAW via on D4.1 pad at (59.00, 2.40)")

    # 3. Rotate R27 180 degrees at (44.00, 1.00)
    r27 = b.FindFootprintByReference('R27')
    r27.SetPosition(pcbnew.VECTOR2I(int(44.000*1e6), int(1.000*1e6)))
    r27.SetOrientationDegrees(180)
    print("Rotated R27 180 deg at (44.00, 1.00)")
    
    # Delete old GPIO8_STRAP and 3V3 tracks near R27
    for t in list(b.GetTracks()):
        if t.GetNetname() == '/GPIO8_STRAP':
            b.Delete(t)
        elif t.GetNetname() == '/3V3' and (round(t.GetPosition().x/1e6, 1) == 42.0 or (t.GetClass() != 'PCB_VIA' and round(t.GetStart().x/1e6, 1) == 42.0)):
            b.Delete(t)
            
    def trk(sx, sy, ex, ey, layer, netname, w=0.15):
        t = pcbnew.PCB_TRACK(b)
        t.SetStart(pcbnew.VECTOR2I(int(sx*1e6), int(sy*1e6)))
        t.SetEnd(pcbnew.VECTOR2I(int(ex*1e6), int(ey*1e6)))
        t.SetWidth(int(w*1e6))
        t.SetLayer(b.GetLayerID(layer))
        t.SetNet(b.FindNet(netname))
        b.Add(t)
        return t

    def via(x, y, netname, dia=0.5, drill=0.3):
        v = pcbnew.PCB_VIA(b)
        v.SetPosition(pcbnew.VECTOR2I(int(x*1e6), int(y*1e6)))
        v.SetWidth(int(dia*1e6))
        v.SetDrill(int(drill*1e6))
        v.SetNet(b.FindNet(netname))
        b.Add(v)
        return v

    # 4. Connect R27.2 (/GPIO8_STRAP at 43.525, 1.000) to U1.14 (43.630, 2.435)
    trk(43.630, 2.435, 43.525, 2.330, 'F.Cu', '/GPIO8_STRAP')
    trk(43.525, 2.330, 43.525, 1.000, 'F.Cu', '/GPIO8_STRAP')
    
    # Connect R27.1 (/3V3 at 44.475, 1.000) to 3V3 plane via
    trk(44.475, 1.000, 44.475, 0.500, 'F.Cu', '/3V3')
    via(44.475, 0.500, '/3V3')
    print("Connected R27 pads cleanly")

    # 5. Route /SD_CS
    # U1.13 (43.130, 2.435) escape
    trk(43.130, 2.435, 43.000, 2.305, 'F.Cu', '/SD_CS')
    trk(43.000, 2.305, 43.000, 1.700, 'F.Cu', '/SD_CS')
    via(43.000, 1.700, '/SD_CS')
    # In2.Cu ribbon at Y=1.150
    trk(43.000, 1.700, 43.000, 1.150, 'In2.Cu', '/SD_CS')
    trk(43.000, 1.150, 59.300, 1.150, 'In2.Cu', '/SD_CS')
    # Tap to R18.2 at (56.975, 2.000)
    via(56.975, 1.150, '/SD_CS')
    trk(56.975, 1.150, 56.975, 2.000, 'F.Cu', '/SD_CS')
    # Fanout to J_SD.6 at (59.650, 4.200)
    trk(59.300, 1.150, 59.300, 0.700, 'In2.Cu', '/SD_CS')
    via(59.300, 0.700, '/SD_CS')
    trk(59.300, 0.700, 59.300, 0.850, 'F.Cu', '/SD_CS')
    trk(59.300, 0.850, 59.800, 0.850, 'F.Cu', '/SD_CS')
    trk(59.800, 0.850, 59.800, 3.600, 'F.Cu', '/SD_CS')
    trk(59.800, 3.600, 59.650, 3.600, 'F.Cu', '/SD_CS')
    trk(59.650, 3.600, 59.650, 4.200, 'F.Cu', '/SD_CS')
    print("Routed /SD_CS")

    # 6. Route /SD_SCK
    # U1.12 (42.630, 2.435) escape
    trk(42.630, 2.435, 42.630, 0.500, 'F.Cu', '/SD_SCK')
    via(42.630, 0.500, '/SD_SCK')
    # In2.Cu ribbon at Y=1.450
    trk(42.630, 0.500, 42.630, 1.450, 'In2.Cu', '/SD_SCK')
    trk(42.630, 1.450, 58.000, 1.450, 'In2.Cu', '/SD_SCK')
    trk(58.000, 1.450, 58.000, 5.500, 'In2.Cu', '/SD_SCK')
    via(58.000, 5.500, '/SD_SCK')
    # Fanout to J_SD.3 at (58.150, 4.200)
    trk(58.000, 5.500, 58.150, 5.500, 'F.Cu', '/SD_SCK')
    trk(58.150, 5.500, 58.150, 4.200, 'F.Cu', '/SD_SCK')
    print("Routed /SD_SCK")

    # 7. Route /SD_MOSI
    # U1.9 (41.130, 2.435) escape
    trk(41.130, 2.435, 41.130, 0.500, 'F.Cu', '/SD_MOSI')
    via(41.130, 0.500, '/SD_MOSI')
    # In2.Cu bypass south of 3V3_RTC via at (42.13, 1.8)
    trk(41.130, 0.500, 42.800, 0.500, 'In2.Cu', '/SD_MOSI')
    trk(42.800, 0.500, 42.800, 1.750, 'In2.Cu', '/SD_MOSI')
    trk(42.800, 1.750, 57.400, 1.750, 'In2.Cu', '/SD_MOSI')
    trk(57.400, 1.750, 57.400, 2.800, 'In2.Cu', '/SD_MOSI')
    via(57.400, 2.800, '/SD_MOSI')
    # Fanout to J_SD.4 at (58.650, 4.200)
    trk(57.400, 2.800, 57.400, 3.250, 'F.Cu', '/SD_MOSI')
    trk(57.400, 3.250, 58.650, 3.250, 'F.Cu', '/SD_MOSI')
    trk(58.650, 3.250, 58.650, 4.200, 'F.Cu', '/SD_MOSI')
    print("Routed /SD_MOSI")

    # 8. Route /SD_MISO
    # U1.10 (41.630, 2.435) escape
    trk(41.630, 2.435, 41.630, 2.050, 'F.Cu', '/SD_MISO')
    trk(41.630, 2.050, 41.400, 1.820, 'F.Cu', '/SD_MISO')
    trk(41.400, 1.820, 41.400, 1.600, 'F.Cu', '/SD_MISO')
    via(41.400, 1.600, '/SD_MISO')
    # In2.Cu bypass north of 3V3_RTC via at (42.13, 1.8)
    trk(41.400, 1.600, 41.400, 2.320, 'In2.Cu', '/SD_MISO')
    trk(41.400, 2.320, 42.700, 2.320, 'In2.Cu', '/SD_MISO')
    trk(42.700, 2.320, 42.700, 2.050, 'In2.Cu', '/SD_MISO')
    trk(42.700, 2.050, 57.800, 2.050, 'In2.Cu', '/SD_MISO')
    # In2.Cu bypass under D4 (X=59.0, Y=2.4)
    trk(57.800, 2.050, 57.800, 1.300, 'In2.Cu', '/SD_MISO')
    trk(57.800, 1.300, 59.650, 1.300, 'In2.Cu', '/SD_MISO')
    via(59.650, 1.300, '/SD_MISO')
    # Fanout to J_SD.5 at (59.150, 4.200)
    trk(59.650, 1.300, 59.800, 1.300, 'F.Cu', '/SD_MISO')
    trk(59.800, 1.300, 59.800, 3.250, 'F.Cu', '/SD_MISO')
    trk(59.800, 3.250, 59.150, 3.250, 'F.Cu', '/SD_MISO')
    trk(59.150, 3.250, 59.150, 4.200, 'F.Cu', '/SD_MISO')
    print("Routed /SD_MISO")

    # 9. Refill all copper zones
    print("Refilling all copper zones...")
    filler = pcbnew.ZONE_FILLER(b)
    filler.Fill(b.Zones())
    print("Zone fill complete.")

    # 10. Save to destination
    os.makedirs(os.path.dirname(dst_path), exist_ok=True)
    b.Save(dst_path)
    print(f"Successfully generated golden 4-layer board: {dst_path}")

if __name__ == '__main__':
    build_golden_board()
