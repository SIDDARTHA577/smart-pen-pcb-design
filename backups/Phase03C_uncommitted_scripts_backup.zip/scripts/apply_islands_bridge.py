import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
bcu = b.GetLayerID('B.Cu')
gnd_net = b.FindNet('/GND')
net_3v3 = b.FindNet('/3V3')

def add_via(x, y, net, width=0.500, drill=0.300):
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(int(x*1e6), int(y*1e6)))
    v.SetWidth(int(width*1e6))
    v.SetDrill(int(drill*1e6))
    v.SetNet(net)
    b.Add(v)

def add_track(x1, y1, x2, y2, layer_id, net, width=0.20):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(x1*1e6), int(y1*1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2*1e6), int(y2*1e6)))
    t.SetLayer(layer_id)
    t.SetWidth(int(width*1e6))
    t.SetNet(net)
    b.Add(t)

# 1. GND stitching via in Outline 3 at (34.800, 6.800):
add_via(34.800, 6.800, gnd_net)

# 2. GND stitching via in Outline 4 at (18.000, 6.000):
add_via(18.000, 6.000, gnd_net)

# 3. 3V3 bridge on B.Cu connecting via (60.146, 7.807) to via (68.714, 6.563):
add_track(60.146, 7.807, 68.714, 7.807, bcu, net_3v3, 0.20)
add_track(68.714, 7.807, 68.714, 6.563, bcu, net_3v3, 0.20)

candidate_pcb = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb'
b.Save(candidate_pcb)
print("Saved GND stitching and 3V3 bridge to candidate PCB!")
