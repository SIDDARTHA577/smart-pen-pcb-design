import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# Test In2.Cu jogged path for DM:
# Via at (52.0, 7.0)
# (52.0, 7.0) -> (52.0, 5.8) on In2.Cu
# (52.0, 5.8) -> (73.0, 5.8) on In2.Cu
# (73.0, 5.8) -> (73.0, 7.0) on In2.Cu
# Via at (73.0, 7.0)
# (73.0, 7.0) -> (72.5, 7.025) on F.Cu

print("DM In2.Cu jogged path:")
print("via_w (52.0, 7.0):", geom.is_via_legal(52.0, 7.0, '/USB_DM_CORE'))
print("via_e (73.0, 7.0):", geom.is_via_legal(73.0, 7.0, '/USB_DM_CORE'))
print("In2 jog down:", geom.is_segment_legal(52.0, 7.0, 52.0, 5.8, 'In2.Cu', '/USB_DM_CORE'))
print("In2 main run:", geom.is_segment_legal(52.0, 5.8, 73.0, 5.8, 'In2.Cu', '/USB_DM_CORE'))
print("In2 jog up:", geom.is_segment_legal(73.0, 5.8, 73.0, 7.0, 'In2.Cu', '/USB_DM_CORE'))
print("F.Cu to R7.2:", geom.is_segment_legal(73.0, 7.0, 72.5, 7.025, 'F.Cu', '/USB_DM_CORE'))

sys.exit(0)
