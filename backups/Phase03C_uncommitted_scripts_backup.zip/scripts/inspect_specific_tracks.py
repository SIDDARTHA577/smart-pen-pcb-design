import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

nets_to_inspect = [
    '/USB_DP_CORE', '/USB_DM_CORE', '/USB_DP_PORT', '/USB_DM_PORT',
    '/SD_CS', '/TOUCH_OUT', '/RF_LNA', '/3V3_RF', '/VBAT',
    '/CHG_PROG', '/LED_RED_SINK', '/MCU_EN', '/UART_RX'
]

for t in board.GetTracks():
    net = t.GetNetname()
    if net in nets_to_inspect:
        if isinstance(t, pcbnew.PCB_VIA):
            pos = t.GetPosition()
            print(f'VIA {net}: pos=({pos.x/1e6:.3f}, {pos.y/1e6:.3f}), drill={t.GetDrill()/1e6:.3f}, width={t.GetWidth(pcbnew.F_Cu)/1e6:.3f}')
        else:
            s = t.GetStart()
            e = t.GetEnd()
            l = t.GetLength()
            layer = board.GetLayerName(t.GetLayer())
            print(f'TRACK {net} [{layer}]: start=({s.x/1e6:.3f}, {s.y/1e6:.3f}), end=({e.x/1e6:.3f}, {e.y/1e6:.3f}), len={l/1e6:.3f}')

