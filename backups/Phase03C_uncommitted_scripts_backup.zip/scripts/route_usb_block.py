import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

def trk(board, netname, layer_name, x1, y1, x2, y2, w=0.18):
    net = board.FindNet(netname)
    layer = board.GetLayerID(layer_name)
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    t.SetWidth(int(w * 1e6))
    t.SetLayer(layer)
    t.SetNet(net)
    board.Add(t)
    return t

def via(board, netname, x, y, drill=0.30, dia=0.50):
    net = board.FindNet(netname)
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    v.SetWidth(int(dia * 1e6))
    v.SetDrill(int(drill * 1e6))
    v.SetNet(net)
    board.Add(v)
    return v

# --- 1. USB_CC1 ---
trk(board, '/USB_CC1', 'F.Cu', 77.150, 3.100, 77.150, 2.000)
via(board, '/USB_CC1', 77.150, 2.000)
trk(board, '/USB_CC1', 'B.Cu', 77.150, 2.000, 77.600, 2.000)
trk(board, '/USB_CC1', 'B.Cu', 77.600, 2.000, 77.600, 5.400)
via(board, '/USB_CC1', 77.600, 5.400)
trk(board, '/USB_CC1', 'F.Cu', 77.600, 5.400, 77.600, 6.225)

# --- 2. USB_CC2 ---
trk(board, '/USB_CC2', 'F.Cu', 79.650, 3.100, 79.650, 2.000)
via(board, '/USB_CC2', 79.650, 2.000)
trk(board, '/USB_CC2', 'B.Cu', 79.650, 2.000, 79.200, 2.000)
trk(board, '/USB_CC2', 'B.Cu', 79.200, 2.000, 79.200, 5.400)
via(board, '/USB_CC2', 79.200, 5.400)
trk(board, '/USB_CC2', 'F.Cu', 79.200, 5.400, 79.200, 6.225)

# --- 3. USB_DM_PORT ---
# J_USB.5 to J_USB.7 via
trk(board, '/USB_DM_PORT', 'F.Cu', 77.650, 3.100, 77.650, 2.200)
via(board, '/USB_DM_PORT', 77.650, 2.200)
trk(board, '/USB_DM_PORT', 'B.Cu', 77.650, 2.200, 78.650, 2.200)
trk(board, '/USB_DM_PORT', 'B.Cu', 78.650, 2.200, 78.650, 0.550)

# U_ESD.2 to R7.1
via(board, '/USB_DM_PORT', 72.500, 8.500)
trk(board, '/USB_DM_PORT', 'F.Cu', 72.500, 7.975, 72.500, 8.500)
trk(board, '/USB_DM_PORT', 'B.Cu', 72.000, 0.550, 69.600, 0.550)
trk(board, '/USB_DM_PORT', 'B.Cu', 69.600, 0.550, 69.600, 8.500)
trk(board, '/USB_DM_PORT', 'B.Cu', 69.600, 8.500, 72.500, 8.500)

# --- 4. USB_DP_PORT ---
# J_USB.8 to J_USB.6 via
trk(board, '/USB_DP_PORT', 'F.Cu', 79.150, 3.100, 79.150, 2.200)
via(board, '/USB_DP_PORT', 79.150, 2.200)
trk(board, '/USB_DP_PORT', 'B.Cu', 79.150, 2.200, 78.150, 2.200)
trk(board, '/USB_DP_PORT', 'B.Cu', 78.150, 2.200, 78.150, 1.200)

# U_ESD.1 to R8.1
via(board, '/USB_DP_PORT', 71.600, 8.500)
trk(board, '/USB_DP_PORT', 'F.Cu', 71.600, 7.975, 71.600, 8.500)
trk(board, '/USB_DP_PORT', 'B.Cu', 71.050, 1.200, 70.300, 1.200)
trk(board, '/USB_DP_PORT', 'B.Cu', 70.300, 1.200, 70.300, 8.500)
trk(board, '/USB_DP_PORT', 'B.Cu', 70.300, 8.500, 71.600, 8.500)

# --- 5. USB_DP_CORE ---
trk(board, '/USB_DP_CORE', 'F.Cu', 44.130, 7.235, 44.130, 8.400)
trk(board, '/USB_DP_CORE', 'F.Cu', 44.130, 8.400, 54.000, 8.400)
trk(board, '/USB_DP_CORE', 'F.Cu', 54.000, 8.400, 54.000, 7.300)
via(board, '/USB_DP_CORE', 54.000, 7.300)
trk(board, '/USB_DP_CORE', 'B.Cu', 54.000, 7.300, 70.800, 7.300)
trk(board, '/USB_DP_CORE', 'B.Cu', 70.800, 7.300, 70.800, 7.025)
via(board, '/USB_DP_CORE', 70.800, 7.025)
trk(board, '/USB_DP_CORE', 'F.Cu', 70.800, 7.025, 71.600, 7.025)

# --- 6. USB_DM_CORE ---
trk(board, '/USB_DM_CORE', 'F.Cu', 44.630, 7.235, 44.630, 8.000)
trk(board, '/USB_DM_CORE', 'F.Cu', 44.630, 8.000, 53.000, 8.000)
trk(board, '/USB_DM_CORE', 'F.Cu', 53.000, 8.000, 53.000, 7.300)
via(board, '/USB_DM_CORE', 53.000, 7.300)
trk(board, '/USB_DM_CORE', 'B.Cu', 53.000, 7.300, 53.000, 6.700)
trk(board, '/USB_DM_CORE', 'B.Cu', 53.000, 6.700, 73.300, 6.700)
trk(board, '/USB_DM_CORE', 'B.Cu', 73.300, 6.700, 73.300, 7.025)
via(board, '/USB_DM_CORE', 73.300, 7.025)
trk(board, '/USB_DM_CORE', 'F.Cu', 73.300, 7.025, 72.500, 7.025)

filler = pcbnew.ZONE_FILLER(board)
filler.Fill(board.Zones())
board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('Routed USB Block successfully!')

