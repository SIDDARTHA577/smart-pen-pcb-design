import pcbnew
import math

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

# Define 3V3 via locations
via_locations = {
    'J_SD.1': (57.150, 3.200),
    'U3.6': (20.650, 5.650),
    'U3.18': (25.999, 5.499),
    'U1.17': (46.200, 2.500),
    'R15.1': (20.175, 4.400),
    'R14.1': (20.175, 2.200),
    'C3.1': (50.253, 8.400),
    'J_IMU.1': (1.700, 5.300),
    'C14.1': (69.314, 2.750),
    'R1.1': (37.975, 3.060),
    'R27.1': (41.325, 1.000),
    'U4.5': (68.814, 6.563),
    'R18.1': (56.025, 2.700),
    'R4.1': (35.407, 3.301),
    'C15.1': (5.725, 2.700),
    'R3.1': (37.025, 4.785),
    'R2.1': (51.275, 2.950),
    'FB1.1': (45.480, 8.250),
    'J_TOUCH.1': (8.000, 3.100),
    'R11.1': (5.725, 7.900),
    'C13.1': (25.525, 8.200),
    'R12.1': (14.025, 7.700),
    'R13.1': (20.025, 7.700),
    'J_UART.4': (59.760, 8.047),
    'R10.1': (5.725, 5.300)
}

net_3v3 = board.FindNet('/3V3')
layer_fcu = board.GetLayerID('F.Cu')
layer_in2 = board.GetLayerID('In2.Cu')

def trk(board, net, layer, x1, y1, x2, y2, w=0.18):
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    t.SetWidth(int(w * 1e6))
    t.SetLayer(layer)
    t.SetNet(net)
    board.Add(t)
    return t

def via(board, net, x, y, drill=0.30, dia=0.50):
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    v.SetWidth(int(dia * 1e6))
    v.SetDrill(int(drill * 1e6))
    v.SetNet(net)
    board.Add(v)
    return v

# Place vias and connection tracks
for fp in board.Footprints():
    ref = fp.GetReference()
    for p in fp.Pads():
        if p.GetNetname() == '/3V3':
            key = f'{ref}.{p.GetNumber()}'
            if key in via_locations:
                vx, vy = via_locations[key]
                v = via(board, net_3v3, vx, vy)
                pos = p.GetPosition()
                px, py = pos.x / 1e6, pos.y / 1e6
                t = trk(board, net_3v3, layer_fcu, px, py, vx, vy)
                print(f'Connected {key} at ({px:.3f}, {py:.3f}) to via at ({vx:.3f}, {vy:.3f})')

# Create In2.Cu zone for /3V3
zone = pcbnew.ZONE(board)
zone.SetNet(net_3v3)
zone.SetLayer(layer_in2)
poly = pcbnew.SHAPE_POLY_SET()
poly.NewOutline()
poly.Append(int(0.25 * 1e6), int(0.25 * 1e6))
poly.Append(int(83.75 * 1e6), int(0.25 * 1e6))
poly.Append(int(83.75 * 1e6), int(8.95 * 1e6))
poly.Append(int(0.25 * 1e6), int(8.95 * 1e6))
zone.SetOutline(poly)
zone.SetMinThickness(int(0.127 * 1e6))
zone.SetThermalReliefGap(int(0.15 * 1e6))
zone.SetThermalReliefSpokeWidth(int(0.18 * 1e6))
zone.SetIslandRemovalMode(2) # Never remove islands
board.Add(zone)

filler = pcbnew.ZONE_FILLER(board)
filler.Fill(board.Zones())
board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('Successfully placed 3V3 distribution and zone!')
