import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

board_path = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb'
b = pcbnew.LoadBoard(board_path)

fcu = b.GetLayerID('F.Cu')
in1 = b.GetLayerID('In1.Cu')
in2 = b.GetLayerID('In2.Cu')
bcu = b.GetLayerID('B.Cu')

def add_track(net, layer, x1, y1, x2, y2, w=0.18):
    t = pcbnew.PCB_TRACK(b)
    t.SetNet(net)
    t.SetLayer(layer)
    t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    t.SetWidth(int(w * 1e6))
    b.Add(t)
    return t

def add_via(net, x, y, dia=0.50, drill=0.30):
    v = pcbnew.PCB_VIA(b)
    v.SetNet(net)
    v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    v.SetWidth(int(dia * 1e6))
    v.SetDrill(int(drill * 1e6))
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    b.Add(v)
    return v

print("Starting final Phase 3C master routing...")

# 1. Fix VBAT_SW continuity:
vbat_net = b.FindNet('/VBAT_SW')
# Connect (28.090, 4.400) to (34.000, 4.400) on B.Cu
add_track(vbat_net, bcu, 28.090, 4.400, 34.000, 4.400)

# 2. Complete /I2C_SCL West:
scl_net = b.FindNet('/I2C_SCL')
# J_IMU.4 (4.700, 4.600) -> (4.700, 7.150) on F.Cu
add_track(scl_net, fcu, 4.700, 4.600, 4.700, 7.150)
add_via(scl_net, 4.700, 7.150)
# R11.2 (6.675, 7.200) -> (7.500, 7.200) -> (7.500, 7.150) on F.Cu
add_track(scl_net, fcu, 6.675, 7.200, 7.500, 7.200)
add_track(scl_net, fcu, 7.500, 7.200, 7.500, 7.150)
add_via(scl_net, 7.500, 7.150)
# Connect on B.Cu: (4.700, 7.150) -> (7.500, 7.150) -> (24.250, 7.150)
add_track(scl_net, bcu, 4.700, 7.150, 7.500, 7.150)
add_track(scl_net, bcu, 7.500, 7.150, 24.250, 7.150)

# 3. Complete /I2C_SCL East:
# Run on In2.Cu from (24.250, 7.150) -> (24.250, 4.585) -> (40.480, 4.585)
add_track(scl_net, in2, 24.250, 7.150, 24.250, 4.585)
add_track(scl_net, in2, 24.250, 4.585, 38.500, 4.585)
add_via(scl_net, 38.500, 4.585)
add_track(scl_net, fcu, 38.500, 4.585, 40.480, 4.585)

# 4. Complete /USB_DM_CORE:
dm_net = b.FindNet('/USB_DM_CORE')
# F.Cu: U1.25 (44.630, 7.235) -> (44.630, 8.350) -> (52.000, 8.350) -> (52.000, 7.000)
# (Already exists from previous step, let's verify if via exists)
dm_vias = [t for t in b.Tracks() if isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/USB_DM_CORE']
if not any(abs(t.GetPosition().x/1e6 - 52.0) < 0.2 for t in dm_vias):
    add_via(dm_net, 52.000, 7.000)
# Run on In2.Cu: (52.000, 7.000) -> (70.500, 7.000) -> (70.500, 7.025)
add_track(dm_net, in2, 52.000, 7.000, 70.500, 7.000)
add_track(dm_net, in2, 70.500, 7.000, 70.500, 7.025)
add_via(dm_net, 70.500, 7.025)
add_track(dm_net, fcu, 70.500, 7.025, 72.500, 7.025)

# 5. Complete /VSYS_RAW:
vsys_net = b.FindNet('/VSYS_RAW')
# SW3.1 (60.963, 6.824) -> (60.500, 6.500) -> via to B.Cu -> (59.500, 6.500) -> (59.500, 2.400) -> via to F.Cu -> D4.1 (59.000, 2.400)
add_track(vsys_net, fcu, 60.963, 6.824, 60.500, 6.500)
add_via(vsys_net, 60.500, 6.500)
add_track(vsys_net, bcu, 60.500, 6.500, 59.500, 6.500)
add_track(vsys_net, bcu, 59.500, 6.500, 59.500, 2.400)
add_via(vsys_net, 59.500, 2.400)
add_track(vsys_net, fcu, 59.500, 2.400, 59.000, 2.400)
# Tap on B.Cu to Q2.2 (61.700, 3.450):
add_track(vsys_net, bcu, 59.500, 3.450, 61.700, 3.450)
add_via(vsys_net, 61.700, 3.450)

# 6. Complete /VBAT:
vbat_p_net = b.FindNet('/VBAT')
add_track(vbat_p_net, fcu, 62.300, 1.720, 62.300, 1.000)
add_via(vbat_p_net, 62.300, 1.000)
add_track(vbat_p_net, bcu, 62.300, 1.000, 67.400, 1.000)
add_via(vbat_p_net, 67.400, 1.000)
add_track(vbat_p_net, fcu, 67.400, 1.000, 67.400, 1.400) # C12.1
add_track(vbat_p_net, fcu, 67.400, 1.400, 67.950, 1.400)
add_track(vbat_p_net, fcu, 67.950, 1.400, 67.950, 2.770) # U2.3
# Tap to Q2.3 (63.900, 4.400):
add_track(vbat_p_net, bcu, 63.900, 1.000, 63.900, 4.400)
add_via(vbat_p_net, 63.900, 4.400)

# 7. Complete /USB_VBUS:
vbus_net = b.FindNet('/USB_VBUS')
# Cluster 1: Q2.1 (61.700, 5.350) -> R26.1 (60.500, 4.875) -> D4.2 (59.000, 5.600)
add_track(vbus_net, fcu, 61.700, 5.350, 60.500, 4.875)
add_track(vbus_net, fcu, 60.500, 4.875, 59.000, 5.600)
# Connect Q2.1 to U2.4 (67.950, 5.370) via B.Cu:
add_via(vbus_net, 61.700, 5.350)
add_track(vbus_net, bcu, 61.700, 5.350, 67.950, 5.350)
add_via(vbus_net, 67.950, 5.350)
add_track(vbus_net, fcu, 67.950, 5.350, 67.950, 5.370) # U2.4
# U2.4 to C11.1 (67.250, 7.750):
add_track(vbus_net, fcu, 67.950, 5.370, 67.250, 5.370)
add_track(vbus_net, fcu, 67.250, 5.370, 67.250, 7.750)
# U2.4 to C10.1 (73.750, 1.500) and J_USB (76.0..80.8, 3.100) via north run on F.Cu:
add_track(vbus_net, fcu, 73.750, 1.500, 73.750, 0.700)
add_track(vbus_net, fcu, 73.750, 0.700, 80.800, 0.700)
add_track(vbus_net, fcu, 76.000, 0.700, 76.000, 3.100) # J_USB.2
add_track(vbus_net, fcu, 80.800, 0.700, 80.800, 3.100) # J_USB.11
# Connect C10.1 to U2.4 on B.Cu:
add_via(vbus_net, 73.750, 1.500)
add_track(vbus_net, bcu, 67.950, 5.350, 67.950, 1.500)
add_track(vbus_net, bcu, 67.950, 1.500, 73.750, 1.500)

# 8. Complete MicroSD Bus:
mosi_net = b.FindNet('/SD_MOSI')
miso_net = b.FindNet('/SD_MISO')
sck_net  = b.FindNet('/SD_SCK')
cs_net   = b.FindNet('/SD_CS')

# MOSI: U1.9 (41.130, 2.435) -> (41.130, 0.450) -> via -> B.Cu -> (58.650, 0.450) -> via -> J_SD.4 (58.650, 4.200)
add_track(mosi_net, fcu, 41.130, 2.435, 41.130, 0.450)
add_via(mosi_net, 41.130, 0.450)
add_track(mosi_net, bcu, 41.130, 0.450, 58.650, 0.450)
add_via(mosi_net, 58.650, 0.450)
add_track(mosi_net, fcu, 58.650, 0.450, 58.650, 4.200)

# MISO: U1.10 (41.630, 2.435) -> (41.630, 1.150) -> via -> In2.Cu -> (59.150, 1.150) -> via -> J_SD.5 (59.150, 4.200)
add_track(miso_net, fcu, 41.630, 2.435, 41.630, 1.150)
add_via(miso_net, 41.630, 1.150)
add_track(miso_net, in2, 41.630, 1.150, 59.150, 1.150)
add_via(miso_net, 59.150, 1.150)
add_track(miso_net, fcu, 59.150, 1.150, 59.150, 4.200)

# SCK: U1.12 (42.630, 2.435) -> (42.630, 1.750) -> via -> In2.Cu -> (58.150, 1.750) -> via -> J_SD.3 (58.150, 4.200)
add_track(sck_net, fcu, 42.630, 2.435, 42.630, 1.750)
add_via(sck_net, 42.630, 1.750)
add_track(sck_net, in2, 42.630, 1.750, 58.150, 1.750)
add_via(sck_net, 58.150, 1.750)
add_track(sck_net, fcu, 58.150, 1.750, 58.150, 4.200)

# CS: U1.13 (43.130, 2.435) -> (43.130, 0.850) -> via -> In2.Cu -> (59.650, 0.850) -> via -> J_SD.6 (59.650, 4.200)
# And connect to R18.2 (56.975, 2.000)
add_track(cs_net, fcu, 43.130, 2.435, 43.130, 0.850)
add_via(cs_net, 43.130, 0.850)
add_track(cs_net, in2, 43.130, 0.850, 59.650, 0.850)
add_via(cs_net, 59.650, 0.850)
add_track(cs_net, fcu, 59.650, 0.850, 59.650, 4.200)
add_track(cs_net, in2, 56.975, 0.850, 56.975, 2.000)
add_via(cs_net, 56.975, 2.000)
add_track(cs_net, fcu, 56.975, 2.000, 56.975, 2.000)

# 9. 3V3 island tap:
v3_net = b.FindNet('/3V3')
add_via(v3_net, 52.000, 2.800) # tap In2.Cu 3V3 plane to F.Cu 3V3 track

# Refill all zones
filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
b.Save(board_path)
print("Phase 3C master routing applied!")
sys.exit(0)
