import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

print("--- Testing Pad 4 North exits ---")
for y in [4.800, 4.850, 4.900, 4.950, 5.000]:
    s1, r1 = geom.is_segment_legal(58.650, 4.200, 58.650, y, 'F.Cu', '/SD_MOSI')
    if s1:
        for x in [58.4, 58.2, 58.0, 57.8, 57.5]:
            s2, r2 = geom.is_segment_legal(58.650, y, x, y, 'F.Cu', '/SD_MOSI')
            if s2:
                print(f"North exit legal at Y={y} to X={x}!")
