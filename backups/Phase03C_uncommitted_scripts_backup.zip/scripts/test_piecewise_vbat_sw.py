import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

# Update thermal vias under U1 to clean 4-corner pattern
gnd_net = b.FindNet('/GND')
to_remove = []
for t in b.GetTracks():
    if isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/GND':
        pos = t.GetPosition()
        px, py = pos.x / 1e6, pos.y / 1e6
        if 42.0 <= px <= 44.0 and 4.0 <= py <= 5.5:
            to_remove.append(t)

for t in to_remove:
    b.Remove(t)

for vx, vy in [(42.2, 3.8), (43.5, 3.8), (42.2, 5.8), (43.5, 5.8)]:
    v = pcbnew.PCB_VIA(b)
    v.SetNet(gnd_net)
    v.SetPosition(pcbnew.VECTOR2I(int(vx * 1e6), int(vy * 1e6)))
    v.SetWidth(int(0.50 * 1e6))
    v.SetDrill(int(0.30 * 1e6))
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    b.Add(v)

geom = BoardGeometry(b)

# Piecewise VBAT_SW route:
# (28.090, 4.400) -> (34.000, 4.400)
# (34.000, 4.400) -> (35.000, 4.050)
# (35.000, 4.050) -> (38.000, 4.050)
# (38.000, 4.050) -> (40.500, 4.800)
# (40.500, 4.800) -> (52.000, 4.800)
# (52.000, 4.800) -> (54.000, 4.400)
# (54.000, 4.400) -> (62.963, 4.400)

segs = [
    (28.090, 4.400, 34.000, 4.400),
    (34.000, 4.400, 35.000, 4.050),
    (35.000, 4.050, 38.000, 4.050),
    (38.000, 4.050, 40.500, 4.800),
    (40.500, 4.800, 52.000, 4.800),
    (52.000, 4.800, 54.000, 4.400),
    (54.000, 4.400, 62.963, 4.400)
]

print("Testing piecewise VBAT_SW route on B.Cu:")
all_ok = True
for i, (x1, y1, x2, y2) in enumerate(segs):
    leg, r = geom.is_segment_legal(x1, y1, x2, y2, 'B.Cu', '/VBAT_SW')
    print(f"  seg {i+1} ({x1},{y1})->({x2},{y2}): {leg} ({r})")
    if not leg:
        all_ok = False

print("All segments legal:", all_ok)

sys.exit(0)
