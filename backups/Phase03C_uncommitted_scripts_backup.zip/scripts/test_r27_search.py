import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
r27 = b.FindFootprintByReference('R27')

# Test R27 at various X positions
for rx in [43.8, 44.0, 44.2, 44.5]:
    r27.SetPosition(pcbnew.VECTOR2I(int(rx*1e6), int(1.0*1e6)))
    # Delete old tracks
    for t in list(b.GetTracks()):
        if t.GetNetname() == '/GPIO8_STRAP':
            b.Delete(t)
    geom = BoardGeometry(b)
    p1 = r27.FindPadByNumber('1')
    p2 = r27.FindPadByNumber('2')
    p1x, p1y = p1.GetPosition().x/1e6, p1.GetPosition().y/1e6
    p2x, p2y = p2.GetPosition().x/1e6, p2.GetPosition().y/1e6
    
    # Check if R27 pads collide with anything
    pad1_ok, r1 = geom.is_segment_legal(p1x, p1y, p1x, p1y, 'F.Cu', '/3V3')
    pad2_ok, r2 = geom.is_segment_legal(p2x, p2y, p2x, p2y, 'F.Cu', '/GPIO8_STRAP')
    
    # Check if SD_SCK segment along X=42.630 is legal
    sck_seg_ok, rsck = geom.is_segment_legal(42.630, 2.435, 42.630, 0.500, 'F.Cu', '/SD_SCK')
    sck_via_ok, rsvia = geom.is_via_legal(42.630, 0.500, '/SD_SCK')
    
    print(f"rx={rx}: pad1={pad1_ok}, pad2={pad2_ok}, sck_seg={sck_seg_ok}, sck_via={sck_via_ok} ({rsvia})")
