import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

for t in board.GetTracks():
    if t.GetNetname() == '/RF_OUT':
        s, e = t.GetStart(), t.GetEnd()
        print(f'RF_OUT track [{board.GetLayerName(t.GetLayer())}]: ({s.x/1e6:.3f}, {s.y/1e6:.3f}) -> ({e.x/1e6:.3f}, {e.y/1e6:.3f})')

