import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# Test DP to R8.2 (71.600, 7.025):
# Via at (70.5, 7.5) -> F.Cu track to (71.600, 7.025)
v_dp, r_dp = geom.is_via_legal(70.5, 7.5, '/USB_DP_CORE')
s_dp_fcu, rs_dp_fcu = geom.is_segment_legal(70.5, 7.5, 71.6, 7.025, 'F.Cu', '/USB_DP_CORE')
print(f"DP via at (70.5, 7.5): {v_dp}({r_dp}), F.Cu track: {s_dp_fcu}({rs_dp_fcu})")

# Test DM to R7.2 (72.500, 7.025):
# Via at (73.2, 7.025) -> F.Cu track to (72.500, 7.025)
v_dm, r_dm = geom.is_via_legal(73.2, 7.025, '/USB_DM_CORE')
s_dm_fcu, rs_dm_fcu = geom.is_segment_legal(73.2, 7.025, 72.5, 7.025, 'F.Cu', '/USB_DM_CORE')
print(f"DM via at (73.2, 7.025): {v_dm}({r_dm}), F.Cu track: {s_dm_fcu}({rs_dm_fcu})")

sys.exit(0)
