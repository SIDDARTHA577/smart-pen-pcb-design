import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- F.Cu items in X: 44..55, Y: 7.8..8.8 ---')
for p in board.GetPads():
    pos = p.GetPosition()
    x, y = pos.x / 1e6, pos.y / 1e6
    if 44.0 <= x <= 55.0 and 7.8 <= y <= 8.8:
        fp = p.GetParentFootprint()
        ref = fp.GetReference() if fp else '?'
        print(f'Pad {ref}.{p.GetNumber()} [{p.GetNetname()}] at ({x:.3f}, {y:.3f})')

for t in board.GetTracks():
    if t.GetLayerName() == 'F.Cu':
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = s.x/1e6, s.y/1e6
        ex, ey = e.x/1e6, e.y/1e6
        if (44.0 <= sx <= 55.0 and 7.8 <= sy <= 8.8) or (44.0 <= ex <= 55.0 and 7.8 <= ey <= 8.8):
            print(f'Track F.Cu [{t.GetNetname()}] ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})')

print('\n--- PADS/TRACKS near X=53, Y=6.5..7.5 ---')
for p in board.GetPads():
    pos = p.GetPosition()
    x, y = pos.x / 1e6, pos.y / 1e6
    if 51.5 <= x <= 54.5 and 6.0 <= y <= 8.0:
        fp = p.GetParentFootprint()
        ref = fp.GetReference() if fp else '?'
        print(f'Pad {ref}.{p.GetNumber()} [{p.GetNetname()}] at ({x:.3f}, {y:.3f}) layer {p.GetLayerName()}')

for t in board.GetTracks():
    s, e = t.GetStart(), t.GetEnd()
    sx, sy = s.x/1e6, s.y/1e6
    ex, ey = e.x/1e6, e.y/1e6
    if (51.5 <= sx <= 54.5 and 6.0 <= sy <= 8.0) or (51.5 <= ex <= 54.5 and 6.0 <= ey <= 8.0):
        print(f'{t.GetClass()} [{t.GetNetname()}] {t.GetLayerName()} ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})')

