with open('output/RevG/SmartPen.kicad_sch', 'r') as f:
    text = f.read()

pos = text.find('342.90 203.20')
if pos != -1:
    print('--- Area 1 ---')
    print(text[pos-200:pos+800])

pos2 = text.find('38.10 381.00')
if pos2 != -1:
    print('--- Area 2 ---')
    print(text[pos2-200:pos2+800])
