import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print("--- TRACKS between X=43 and 58, Y=2.4 and 4.2 ---")
for t in b.Tracks():
    if not isinstance(t, pcbnew.PCB_VIA):
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if max(x1, x2) >= 43 and min(x1, x2) <= 58 and max(y1, y2) >= 2.4 and min(y1, y2) <= 4.2:
            print(f"Track: {t.GetNetname()} [{b.GetLayerName(t.GetLayer())}] ({x1:.3f},{y1:.3f}) -> ({x2:.3f},{y2:.3f})")

print("\n--- VIAS between X=43 and 58, Y=2.4 and 4.2 ---")
for t in b.Tracks():
    if isinstance(t, pcbnew.PCB_VIA):
        p = t.GetPosition()
        x, y = p.x/1e6, p.y/1e6
        if 43 <= x <= 58 and 2.4 <= y <= 4.2:
            print(f"Via: {t.GetNetname()} at ({x:.3f},{y:.3f})")
