import sys
sys.path.append('scripts')
import pcbnew

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
print("=== Items in X in [59.7, 60.5], Y in [0.5, 4.0] ===")
for fp in b.GetFootprints():
    for p in fp.Pads():
        pos = p.GetPosition()
        px, py = pos.x/1e6, pos.y/1e6
        if 59.7 <= px <= 60.6 and 0.5 <= py <= 4.0:
            print(f"FP Pad: {fp.GetReference()}.{p.GetNumber()} ({p.GetNetname()}): ({px:.3f}, {py:.3f}) sz=({p.GetSize().x/1e6:.3f}, {p.GetSize().y/1e6:.3f}) layer={b.GetLayerName(p.GetLayer())}")

for t in b.GetTracks():
    s, e = t.GetStart(), t.GetEnd()
    sx, sy, ex, ey = s.x/1e6, s.y/1e6, e.x/1e6, e.y/1e6
    if (59.7 <= sx <= 60.6 or 59.7 <= ex <= 60.6) and (0.5 <= sy <= 4.0 or 0.5 <= ey <= 4.0):
        print(f"Track: {t.GetClass()} net={t.GetNetname()} layer={b.GetLayerName(t.GetLayer())}: ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})")
