import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- Tracks on B.Cu with X in [44, 73] ---')
for t in board.GetTracks():
    if t.GetLayer() == pcbnew.B_Cu:
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = s.x/1e6, s.y/1e6
        ex, ey = e.x/1e6, e.y/1e6
        if max(sx, ex) >= 44 and min(sx, ex) <= 73:
            print(f'B.Cu {t.GetNetname()}: ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})')

