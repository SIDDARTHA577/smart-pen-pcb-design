import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
for t in list(b.GetTracks()):
    if t.GetNetname() == '/3V3_RTC':
        b.Delete(t)

geom = BoardGeometry(b)
for vy in [1.9, 1.95, 2.0, 2.05, 2.1, 2.15]:
    v, rv = geom.is_via_legal(42.130, vy, '/3V3_RTC')
    print(f"3V3_RTC via at (42.13, {vy}): {v} ({rv})")
