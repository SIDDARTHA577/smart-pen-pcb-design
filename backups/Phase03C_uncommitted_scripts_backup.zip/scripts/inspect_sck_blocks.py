import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

v_ok, rv = geom.is_via_legal(42.63, 0.50, '/SD_SCK')
print(f"Via (42.63, 0.50): {v_ok}, {rv}")
v_ok, rv = geom.is_via_legal(42.63, 1.60, '/SD_SCK')
print(f"Via (42.63, 1.60): {v_ok}, {rv}")
v_ok, rv = geom.is_via_legal(42.63, 3.20, '/SD_SCK')
print(f"Via (42.63, 3.20): {v_ok}, {rv}")
