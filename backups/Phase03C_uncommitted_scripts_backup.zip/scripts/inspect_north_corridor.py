import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print("TRACKS in north corridor (X: 41..60, Y: 0.5..2.5):")
for t in b.GetTracks():
    if not isinstance(t, pcbnew.PCB_VIA):
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = s.x / 1e6, s.y / 1e6
        ex, ey = e.x / 1e6, e.y / 1e6
        if ((41.0 <= sx <= 60.0 and 0.5 <= sy <= 2.5) or 
            (41.0 <= ex <= 60.0 and 0.5 <= ey <= 2.5)):
            print(f"  TRACK {t.GetLayerName()} [{t.GetNetname()}] ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})")

print("\nVIAS in north corridor (X: 41..60, Y: 0.5..2.5):")
for t in b.GetTracks():
    if isinstance(t, pcbnew.PCB_VIA):
        pos = t.GetPosition()
        px, py = pos.x / 1e6, pos.y / 1e6
        if 41.0 <= px <= 60.0 and 0.5 <= py <= 2.5:
            print(f"  VIA [{t.GetNetname()}] at ({px:.3f}, {py:.3f})")

sys.exit(0)
