import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

s, r = geom.is_segment_legal(59.850, 3.250, 59.850, 1.300, 'F.Cu', '/SD_MISO')
print("s3:", s, r)
for x in [59.75, 59.80, 59.85, 59.90, 59.95, 60.00]:
    s_x, r_x = geom.is_segment_legal(x, 3.250, x, 1.300, 'F.Cu', '/SD_MISO')
    print(f"X={x:.2f}: {s_x} ({r_x})")
