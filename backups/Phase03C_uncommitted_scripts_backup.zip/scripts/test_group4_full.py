import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

dm_net = b.FindNet('/USB_DM_CORE')
dp_net = b.FindNet('/USB_DP_CORE')
fcu = b.GetLayerID('F.Cu')
in2 = b.GetLayerID('In2.Cu')

def add_track(b, net, layer, x1, y1, x2, y2, w=0.18):
    t = pcbnew.PCB_TRACK(b)
    t.SetNet(net)
    t.SetLayer(layer)
    t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    t.SetWidth(int(w * 1e6))
    b.Add(t)

def add_via(b, net, x, y, dia=0.50, drill=0.30):
    v = pcbnew.PCB_VIA(b)
    v.SetNet(net)
    v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    v.SetWidth(int(dia * 1e6))
    v.SetDrill(int(drill * 1e6))
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    b.Add(v)

# DM: U1.25 (44.630, 7.235) -> (44.630, 8.350) -> (53.000, 8.350) -> (53.000, 6.900)
# Via at (53.000, 6.900)
# In2.Cu: (53.000, 6.900) -> (73.000, 6.900)
# Via at (73.000, 6.900)
# F.Cu: (73.000, 6.900) -> (72.500, 7.025)

# DP: U1.26 (44.130, 7.235) -> (44.130, 8.750) -> (54.000, 8.750) -> (54.000, 7.300)
# Via at (54.000, 7.300)
# In2.Cu: (54.000, 7.300) -> (70.500, 7.300)
# Via at (70.500, 7.300)
# F.Cu: (70.500, 7.300) -> (71.600, 7.025)

# Let's verify legality of all segments:
dm_segs = [
    (44.630, 7.235, 44.630, 8.350, 'F.Cu'),
    (44.630, 8.350, 53.000, 8.350, 'F.Cu'),
    (53.000, 8.350, 53.000, 6.900, 'F.Cu'),
    (53.000, 6.900, 73.000, 6.900, 'In2.Cu'),
    (73.000, 6.900, 72.500, 7.025, 'F.Cu')
]
for x1, y1, x2, y2, lyr in dm_segs:
    leg, r = geom.is_segment_legal(x1, y1, x2, y2, lyr, '/USB_DM_CORE')
    print(f"DM seg {lyr} ({x1},{y1})->({x2},{y2}): {leg} ({r})")

dp_segs = [
    (44.130, 7.235, 44.130, 8.750, 'F.Cu'),
    (44.130, 8.750, 54.000, 8.750, 'F.Cu'),
    (54.000, 8.750, 54.000, 7.300, 'F.Cu'),
    (54.000, 7.300, 70.500, 7.300, 'In2.Cu'),
    (70.500, 7.300, 71.600, 7.025, 'F.Cu')
]
for x1, y1, x2, y2, lyr in dp_segs:
    leg, r = geom.is_segment_legal(x1, y1, x2, y2, lyr, '/USB_DP_CORE')
    print(f"DP seg {lyr} ({x1},{y1})->({x2},{y2}): {leg} ({r})")

print("Checking vias:")
for vx, vy, net in [(53.0, 6.9, '/USB_DM_CORE'), (73.0, 6.9, '/USB_DM_CORE'),
                    (54.0, 7.3, '/USB_DP_CORE'), (70.5, 7.3, '/USB_DP_CORE')]:
    leg, r = geom.is_via_legal(vx, vy, net)
    print(f"Via {net} at ({vx}, {vy}): {leg} ({r})")

sys.exit(0)
