try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- PADS near U3 (X: 20..27, Y: 3.5..8.5) ---')
for p in board.GetPads():
    pos = p.GetPosition()
    x, y = pos.x / 1e6, pos.y / 1e6
    if 20.0 <= x <= 27.0 and 3.5 <= y <= 8.5:
        fp = p.GetParentFootprint()
        ref = fp.GetReference() if fp else '?'
        print(f'{ref}.{p.GetNumber()} [{p.GetNetname()}] at ({x:.3f}, {y:.3f}) layer {p.GetLayerName()}')

print('--- TRACKS on F.Cu near U3 ---')
for t in board.GetTracks():
    if t.GetLayerName() == 'F.Cu':
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = s.x/1e6, s.y/1e6
        ex, ey = e.x/1e6, e.y/1e6
        if (20.0 <= sx <= 27.0 and 3.5 <= sy <= 8.5) or (20.0 <= ex <= 27.0 and 3.5 <= ey <= 8.5):
            print(f'{t.GetClass()} [{t.GetNetname()}] ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})')

