import os, sys, math
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx; wx.DisableAsserts()
except: pass
import pcbnew

b = pcbnew.LoadBoard('scratch_test_restore_vsys.kicad_pcb')

# Proposed U1 escape vias:
# Pin 9  (MOSI): (41.130, 1.600)
# Pin 10 (MISO): (41.630, 0.500)
# Pin 12 (SCK):  (42.630, 0.500)
# Pin 13 (CS):   (43.000, 1.600)

proposed_vias = [
    ('/SD_MOSI', 41.130, 1.600),
    ('/SD_MISO', 41.630, 0.500),
    ('/SD_SCK',  42.630, 0.500),
    ('/SD_CS',   43.000, 1.600),
]

print("--- Check via-to-via distances among proposed vias ---")
for i in range(len(proposed_vias)):
    for j in range(i+1, len(proposed_vias)):
        n1, x1, y1 = proposed_vias[i]
        n2, x2, y2 = proposed_vias[j]
        d = math.hypot(x1 - x2, y1 - y2)
        print(f'{n1} vs {n2}: dist = {d:.3f} mm (clearance = {d - 0.50:.3f} mm)')

print("\n--- Check proposed vias against all existing board items ---")
for netname, vx, vy in proposed_vias:
    v_pt = pcbnew.VECTOR2I(int(vx * 1e6), int(vy * 1e6))
    for t in b.GetTracks():
        if t.GetNetname() == netname: continue
        if t.GetClass() == 'PCB_VIA':
            p = t.GetPosition()
            d = math.hypot(p.x/1e6 - vx, p.y/1e6 - vy)
            if d < 1.0:
                clr = d - 0.50
                print(f'{netname} via at ({vx}, {vy}) vs existing VIA {t.GetNetname()} at ({p.x/1e6:.3f}, {p.y/1e6:.3f}): dist={d:.3f} mm clr={clr:.3f} mm')
        else:
            # Check clearance to track
            # Distance from point to segment
            s, e = t.GetStart(), t.GetEnd()
            sx, sy, ex, ey = s.x/1e6, s.y/1e6, e.x/1e6, e.y/1e6
            # bounding box quick check
            if min(sx, ex) - 0.5 <= vx <= max(sx, ex) + 0.5 and min(sy, ey) - 0.5 <= vy <= max(sy, ey) + 0.5:
                # Segment distance
                dx, dy = ex - sx, ey - sy
                L2 = dx*dx + dy*dy
                if L2 == 0:
                    d = math.hypot(vx - sx, vy - sy)
                else:
                    u = max(0.0, min(1.0, ((vx - sx)*dx + (vy - sy)*dy) / L2))
                    proj_x = sx + u * dx
                    proj_y = sy + u * dy
                    d = math.hypot(vx - proj_x, vy - proj_y)
                track_w = t.GetWidth() / 1e6
                clr = d - 0.25 - track_w / 2.0
                if clr < 0.25:
                    print(f'{netname} via at ({vx}, {vy}) vs track on {t.GetLayerName()} {t.GetNetname()} ({sx:.3f},{sy:.3f})->({ex:.3f},{ey:.3f}): clr={clr:.3f} mm')
