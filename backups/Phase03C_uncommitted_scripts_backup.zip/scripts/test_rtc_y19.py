import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
for t in list(b.GetTracks()):
    if t.GetNetname() == '/3V3_RTC':
        b.Delete(t)

geom = BoardGeometry(b)
s, r = geom.is_segment_legal(36.000, 1.900, 42.130, 1.900, 'In2.Cu', '/3V3_RTC')
print(f"3V3_RTC at Y=1.9 on In2.Cu: {s} ({r})")
v1, rv1 = geom.is_via_legal(36.000, 1.900, '/3V3_RTC')
v2, rv2 = geom.is_via_legal(42.130, 1.900, '/3V3_RTC')
print(f"v1 (36.0, 1.9): {v1} ({rv1}), v2 (42.13, 1.9): {v2} ({rv2})")
