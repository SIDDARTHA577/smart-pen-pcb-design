import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

print("Checking vias for Pad 6 (SD_CS at 59.650, 4.200):")
for vx in [59.4, 59.5, 59.65, 59.8, 60.0]:
    for vy in [0.85, 1.0, 1.2, 1.5, 2.0, 2.5, 3.0, 3.25, 3.6, 4.8, 5.0, 5.5]:
        v, rv = geom.is_via_legal(vx, vy, '/SD_CS')
        if v:
            print(f"  SD_CS via OK at ({vx:.2f}, {vy:.2f})")
