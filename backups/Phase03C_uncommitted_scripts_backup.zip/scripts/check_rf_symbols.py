from pathlib import Path
import re

sch_text = Path("output/RevG/SmartPen.kicad_sch").read_text(encoding="utf-8")
print("=== Symbols in SmartPen.kicad_sch with RF ===")
for m in re.finditer(r'\(symbol\s+\(lib_id\s+"([^"]+)"\).*?\(property\s+"Reference"\s+"([^"]+)".*?\(property\s+"Value"\s+"([^"]+)"', sch_text, re.DOTALL):
    lib_id, ref, val = m.group(1), m.group(2), m.group(3)
    if "RF" in ref or "RF" in lib_id or "AE" in ref or "ANT" in ref:
        print(f"Ref: {ref}, Value: {val}, Lib: {lib_id}")

