import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
# Delete freestanding GND via at (55.00, 1.20)
for t in list(b.GetTracks()):
    if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 55.00 and round(t.GetPosition().y/1e6, 2) == 1.20:
        b.Delete(t)

geom = BoardGeometry(b)
print("Testing In2.Cu boundaries from X=43.0 to 57.0:")
for y in [0.80, 0.85, 0.90, 0.95, 1.00, 1.05, 1.10, 2.00, 2.05, 2.10, 2.15, 2.20]:
    s, r = geom.is_segment_legal(43.000, y, 57.000, y, 'In2.Cu', '/SD_MOSI')
    print(f"Y={y:.2f}: {s} ({r})")
