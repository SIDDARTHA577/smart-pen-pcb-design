import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
for t in b.Tracks():
    if isinstance(t, pcbnew.PCB_VIA):
        print(f"Via at ({t.GetPosition().x/1e6:.3f}, {t.GetPosition().y/1e6:.3f}) - Width: {t.GetWidth(pcbnew.F_Cu)/1e6:.3f}, Drill: {t.GetDrill()/1e6:.3f}")
        break
