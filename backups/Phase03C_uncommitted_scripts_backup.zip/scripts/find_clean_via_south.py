import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')

# Let's delete GPIO8_STRAP temporarily to find pure geometry possibilities
for t in list(b.GetTracks()):
    if t.GetNetname() == '/GPIO8_STRAP':
        b.Delete(t)

geom = BoardGeometry(b)

print("Finding legal via positions for SD_CS (X in 42.9 - 43.3, Y in 0.4 - 2.0):")
for vx in [43.0, 43.13, 43.2]:
    for vy in [0.5, 0.7, 0.9, 1.1, 1.3, 1.5, 1.7, 1.75, 1.9]:
        v_ok, rv = geom.is_via_legal(vx, vy, '/SD_CS')
        if v_ok:
            print(f"  SD_CS via OK at ({vx}, {vy})")

print("Finding legal via positions for SD_SCK (X in 42.4 - 42.8, Y in 0.4 - 2.0):")
for vx in [42.5, 42.63, 42.7]:
    for vy in [0.5, 0.7, 0.9, 1.1, 1.3, 1.5, 1.7, 1.75, 1.9]:
        v_ok, rv = geom.is_via_legal(vx, vy, '/SD_SCK')
        if v_ok:
            print(f"  SD_SCK via OK at ({vx}, {vy})")
