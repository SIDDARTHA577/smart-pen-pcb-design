import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Checking horizontal tracks at Y=2.0 on F.Cu:")
print("MOSI west (41.13, 2.0) -> (40.0, 2.0):", geom.is_segment_legal(41.13, 2.0, 40.0, 2.0, 'F.Cu', '/SD_MOSI'))
print("MISO west (41.63, 2.0) -> (40.5, 2.0):", geom.is_segment_legal(41.63, 2.0, 40.5, 2.0, 'F.Cu', '/SD_MISO'))
print("SCK east (42.63, 2.0) -> (45.0, 2.0):", geom.is_segment_legal(42.63, 2.0, 45.0, 2.0, 'F.Cu', '/SD_SCK'))
print("CS east (43.13, 2.0) -> (45.0, 2.0):", geom.is_segment_legal(43.13, 2.0, 45.0, 2.0, 'F.Cu', '/SD_CS'))

# What about straight north to Y=0.5 on F.Cu?
print("\nChecking if pins can reach Y=0.5:")
print("MOSI (41.13, 2.435) -> (41.13, 0.5):", geom.is_segment_legal(41.13, 2.435, 41.13, 0.5, 'F.Cu', '/SD_MOSI'))
print("MISO (41.63, 2.435) -> (41.63, 0.5):", geom.is_segment_legal(41.63, 2.435, 41.63, 0.5, 'F.Cu', '/SD_MISO'))
print("SCK (42.63, 2.435) -> (42.63, 0.5):", geom.is_segment_legal(42.63, 2.435, 42.63, 0.5, 'F.Cu', '/SD_SCK'))
print("CS (43.13, 2.435) -> (43.13, 0.5):", geom.is_segment_legal(43.13, 2.435, 43.13, 0.5, 'F.Cu', '/SD_CS'))

sys.exit(0)
