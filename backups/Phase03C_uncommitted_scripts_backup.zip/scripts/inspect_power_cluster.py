import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
power_fps = ['SW3', 'Q2', 'U2', 'C10', 'C11', 'C12', 'U4', 'D4', 'R26', 'J_BAT', 'J_USB']
print("Power Components and Pads:")
for ref in power_fps:
    fp = b.FindFootprintByReference(ref)
    if fp:
        print(f"\n{ref} at ({fp.GetPosition().x/1e6:.3f}, {fp.GetPosition().y/1e6:.3f}):")
        for p in fp.Pads():
            pos = p.GetPosition()
            sz = p.GetSize()
            print(f"  Pad {p.GetNumber()} [{p.GetNetname()}] at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f}) sz=({sz.x/1e6:.3f}, {sz.y/1e6:.3f})")

sys.exit(0)
