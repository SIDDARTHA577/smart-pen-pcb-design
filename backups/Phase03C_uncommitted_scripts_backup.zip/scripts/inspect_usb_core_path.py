import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- PADS near U1 pins 24..28 ---')
for p in board.GetPads():
    pos = p.GetPosition()
    x, y = pos.x / 1e6, pos.y / 1e6
    if 43.0 <= x <= 46.0 and 6.0 <= y <= 8.8:
        fp = p.GetParentFootprint()
        ref = fp.GetReference() if fp else '?'
        print(f'{ref}.{p.GetNumber()} [{p.GetNetname()}] at ({x:.3f}, {y:.3f})')

print('\n--- TRACKS on B.Cu near X: 43..73, Y: 5.5..7.5 ---')
for t in board.GetTracks():
    if t.GetLayerName() == 'B.Cu':
        s, e = t.GetStart(), t.GetEnd()
        if (43.0 <= s.x/1e6 <= 73.0 and 5.5 <= s.y/1e6 <= 7.5) or (43.0 <= e.x/1e6 <= 73.0 and 5.5 <= e.y/1e6 <= 7.5):
            print(f'{t.GetClass()} [{t.GetNetname()}] ({s.x/1e6:.3f}, {s.y/1e6:.3f}) -> ({e.x/1e6:.3f}, {e.y/1e6:.3f})')

