import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
in2_id = b.GetLayerID('In2.Cu')
bcu_id = b.GetLayerID('B.Cu')
fcu_id = b.GetLayerID('F.Cu')

print("--- ITEMS on In2.Cu between X=20 and 42 ---")
for t in b.Tracks():
    if t.GetLayer() == in2_id:
        p1 = t.GetStart()
        p2 = t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if max(x1, x2) >= 20 and min(x1, x2) <= 42:
            print(f"Track: {t.GetNetname()} In2.Cu ({x1:.3f},{y1:.3f}) -> ({x2:.3f},{y2:.3f})")

print("\n--- VIAS between X=20 and 42 ---")
for t in b.Tracks():
    if isinstance(t, pcbnew.PCB_VIA):
        p = t.GetPosition()
        x, y = p.x/1e6, p.y/1e6
        if 20 <= x <= 42 and 3 <= y <= 8:
            print(f"Via: {t.GetNetname()} at ({x:.3f}, {y:.3f})")
