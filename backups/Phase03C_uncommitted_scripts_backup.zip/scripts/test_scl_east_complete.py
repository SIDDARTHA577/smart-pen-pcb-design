import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
bcu_id = b.GetLayerID('B.Cu')

# Adjust VBAT_SW jog
to_remove = []
for t in b.Tracks():
    if not isinstance(t, pcbnew.PCB_VIA) and t.GetLayer() == bcu_id and t.GetNetname() == '/VBAT_SW':
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (x1 == 38.0 and x2 == 40.5) or (x1 == 40.5 and x2 == 52.0):
            to_remove.append(t)
for t in to_remove:
    b.Remove(t)

def add_track(x1, y1, x2, y2, layer_id, net_name, width=0.25):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(x1*1e6), int(y1*1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2*1e6), int(y2*1e6)))
    t.SetLayer(layer_id)
    t.SetWidth(int(width*1e6))
    t.SetNet(b.FindNet(net_name))
    b.Add(t)

add_track(38.000, 4.050, 41.200, 4.050, bcu_id, '/VBAT_SW', 0.25)
add_track(41.200, 4.050, 41.650, 4.500, bcu_id, '/VBAT_SW', 0.25)
add_track(41.650, 4.500, 52.000, 4.500, bcu_id, '/VBAT_SW', 0.25)

geom = BoardGeometry(b)

print("Checking full East SCL route on B.Cu:")
# 1. From (24.250, 7.150) to (25.000, 7.150)
s1, r1 = geom.is_segment_legal(24.250, 7.150, 25.000, 7.150, 'B.Cu', '/I2C_SCL')
# 2. From (25.000, 7.150) jog down to (25.000, 4.585) -- wait, does (25.000, y) cross anything?
s2, r2 = geom.is_segment_legal(25.000, 7.150, 25.000, 4.585, 'B.Cu', '/I2C_SCL')
# 3. From (25.000, 4.585) straight east to (38.800, 4.585)
s3, r3 = geom.is_segment_legal(25.000, 4.585, 38.800, 4.585, 'B.Cu', '/I2C_SCL')
# 4. Via at (38.800, 4.585)
v4, rv4 = geom.is_via_legal(38.800, 4.585, '/I2C_SCL')
# 5. F.Cu from (38.800, 4.585) to U1.5 (40.480, 4.585)
s5, r5 = geom.is_segment_legal(38.800, 4.585, 40.480, 4.585, 'F.Cu', '/I2C_SCL')

print(f"s1 (24.25->25.0 @ 7.15): {s1} ({r1})")
print(f"s2 (25.0 @ 7.15->4.585): {s2} ({r2})")
print(f"s3 (25.0->38.8 @ 4.585): {s3} ({r3})")
print(f"v4 via at (38.8, 4.585): {v4} ({rv4})")
print(f"s5 F.Cu to U1.5: {s5} ({r5})")
