import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- PADS in X: 70..80, Y: 2..8 ---')
for p in board.GetPads():
    pos = p.GetPosition()
    x, y = pos.x / 1e6, pos.y / 1e6
    if 70.0 <= x <= 80.0 and 2.0 <= y <= 8.5:
        fp = p.GetParentFootprint()
        ref = fp.GetReference() if fp else '?'
        print(f'{ref}.{p.GetNumber()} [{p.GetNetname()}] at ({x:.3f}, {y:.3f}) layer {p.GetLayerName()}')

print('\n--- TRACKS on B.Cu in X: 70..80 ---')
for t in board.GetTracks():
    if t.GetLayerName() == 'B.Cu':
        s, e = t.GetStart(), t.GetEnd()
        if (70.0 <= s.x/1e6 <= 80.0) or (70.0 <= e.x/1e6 <= 80.0):
            print(f'{t.GetClass()} [{t.GetNetname()}] ({s.x/1e6:.3f}, {s.y/1e6:.3f}) -> ({e.x/1e6:.3f}, {e.y/1e6:.3f})')

