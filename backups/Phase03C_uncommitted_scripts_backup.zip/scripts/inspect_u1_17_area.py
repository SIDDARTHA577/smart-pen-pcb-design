import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- PADS near U1.17 (X: 44.5..47.5, Y: 2.0..4.0) ---')
for p in board.GetPads():
    pos = p.GetPosition()
    x, y = pos.x / 1e6, pos.y / 1e6
    if 44.5 <= x <= 47.5 and 2.0 <= y <= 4.0:
        fp = p.GetParentFootprint()
        ref = fp.GetReference() if fp else '?'
        print(f'{ref}.{p.GetNumber()} [{p.GetNetname()}] at ({x:.3f}, {y:.3f}) layer {p.GetLayerName()}')

print('--- TRACKS near U1.17 ---')
for t in board.GetTracks():
    s, e = t.GetStart(), t.GetEnd()
    sx, sy = s.x/1e6, s.y/1e6
    ex, ey = e.x/1e6, e.y/1e6
    if (44.5 <= sx <= 47.5 and 2.0 <= sy <= 4.0) or (44.5 <= ex <= 47.5 and 2.0 <= ey <= 4.0):
        print(f'{t.GetClass()} [{t.GetNetname()}] {t.GetLayerName()} ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})')

