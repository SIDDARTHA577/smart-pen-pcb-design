import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

def add_via(board, x, y, netname, drill=0.30, width=0.50):
    net = board.FindNet(netname)
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    v.SetWidth(int(width * 1e6))
    v.SetDrill(int(drill * 1e6))
    v.SetNet(net)
    board.Add(v)
    return v

def add_track(board, x1, y1, x2, y2, netname, layer_name='F.Cu', width=0.18):
    net = board.FindNet(netname)
    layer = board.GetLayerID(layer_name)
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    t.SetWidth(int(width * 1e6))
    t.SetLayer(layer)
    t.SetNet(net)
    board.Add(t)
    return t

# 1. 3V3 Vias to In2.Cu plane:
v33_coords = [
    (1.7, 4.6), (5.725, 4.6), (5.725, 2.0), (5.725, 7.2), (8.0, 2.4),
    (14.025, 7.0), (19.475, 4.4), (19.475, 2.2), (20.025, 7.0),
    (21.35, 5.65), (25.15, 4.65), (25.525, 7.5), (35.407, 2.601),
    (37.975, 2.36), (43.025, 1.0), (45.28, 3.085), (45.48, 7.55),
    (47.825, 2.8), (50.253, 7.7), (51.275, 2.25), (56.025, 2.0),
    (57.15, 4.2), (59.76, 7.347), (68.114, 6.563), (70.014, 2.75)
]

for x, y in v33_coords:
    add_via(board, x, y, '/3V3')
print('Added 3V3 vias')

# 2. USB_VBUS connections:
# J_USB.11 (80.8, 3.1) -> track at (76.0, 0.7)
add_track(board, 80.8, 3.1, 78.4, 0.7, '/USB_VBUS', 'F.Cu', 0.25)
add_track(board, 78.4, 0.7, 76.0, 0.7, '/USB_VBUS', 'F.Cu', 0.25)
# U2.4 (67.95, 5.37) -> track at (73.75, 1.5)
add_track(board, 73.75, 1.5, 70.0, 1.5, '/USB_VBUS', 'F.Cu', 0.25)
add_track(board, 70.0, 1.5, 70.0, 5.37, '/USB_VBUS', 'F.Cu', 0.25)
add_track(board, 70.0, 5.37, 67.95, 5.37, '/USB_VBUS', 'F.Cu', 0.25)
# Track at (67.45, 5.373) -> Q2.1 at (61.7, 5.35)
add_track(board, 67.45, 5.373, 61.7, 5.35, '/USB_VBUS', 'F.Cu', 0.25)
# Q2.1 (61.7, 5.35) -> R26.1 (60.5, 4.875) -> D4.2 (59.0, 5.6)
add_track(board, 61.7, 5.35, 60.5, 4.875, '/USB_VBUS', 'F.Cu', 0.25)
add_track(board, 60.5, 4.875, 59.0, 5.6, '/USB_VBUS', 'F.Cu', 0.25)
print('Connected USB_VBUS')

# 3. VBAT connections:
# J_BAT.1 (66.5, 4.0) -> track at (67.95, 1.4)
add_track(board, 66.5, 4.0, 67.95, 1.4, '/VBAT', 'F.Cu', 0.25)
# Track at (67.95, 1.4) -> Q2.3 at (63.9, 4.4)
add_track(board, 67.95, 1.4, 63.9, 4.4, '/VBAT', 'F.Cu', 0.25)
# Q2.3 (63.9, 4.4) -> track at (62.3, 1.72)
add_track(board, 63.9, 4.4, 62.3, 1.72, '/VBAT', 'F.Cu', 0.25)
print('Connected VBAT')

# 4. VSYS_RAW connections:
# D4.1 (59.0, 2.4) -> Q2.2 (61.7, 3.45)
add_track(board, 59.0, 2.4, 61.7, 3.45, '/VSYS_RAW', 'F.Cu', 0.25)
# Q2.2 (61.7, 3.45) -> SW3.1 (60.963, 6.824)
add_track(board, 61.7, 3.45, 60.963, 6.824, '/VSYS_RAW', 'F.Cu', 0.25)
print('Connected VSYS_RAW')

# 5. VBAT_SW connections:
# SW3.2 (62.963, 6.824) -> track at (62.963, 6.824)
# U4.3 (70.014, 3.963) -> track at (68.114, 3.963)
add_track(board, 70.014, 3.963, 68.114, 3.963, '/VBAT_SW', 'F.Cu', 0.25)
# J_MOT.1 (30.753, 6.285) -> (62.963, 6.824)
add_track(board, 30.753, 6.285, 30.753, 4.4, '/VBAT_SW', 'F.Cu', 0.25)
add_track(board, 30.753, 4.4, 62.963, 4.4, '/VBAT_SW', 'B.Cu', 0.25)
add_via(board, 30.753, 4.4, '/VBAT_SW')
print('Connected VBAT_SW')

# 6. USB_CC1 and USB_CC2:
# J_USB.4 (77.15, 3.1) -> R5.1 (77.6, 6.225)
add_track(board, 77.15, 3.1, 77.6, 6.225, '/USB_CC1', 'F.Cu', 0.18)
# J_USB.9 (79.65, 3.1) -> R6.1 (79.2, 6.225)
add_track(board, 79.65, 3.1, 79.2, 6.225, '/USB_CC2', 'F.Cu', 0.18)
print('Connected USB_CC1 and USB_CC2')

# 7. USB_DP_PORT and USB_DM_PORT:
# J_USB.8 (79.15, 3.1) -> track at (78.15, 3.1)
add_track(board, 79.15, 3.1, 78.15, 3.1, '/USB_DP_PORT', 'F.Cu', 0.18)
# Track at (71.05, 1.2) -> R8.1 (71.6, 7.975)
add_track(board, 71.05, 3.19, 71.6, 7.975, '/USB_DP_PORT', 'F.Cu', 0.18)
# J_USB.5 (77.65, 3.1) -> track at (78.65, 3.1)
add_track(board, 77.65, 3.1, 78.65, 3.1, '/USB_DM_PORT', 'F.Cu', 0.18)
# Track at (72.0, 0.55) -> R7.1 (72.5, 7.975)
add_track(board, 72.0, 3.19, 72.5, 7.975, '/USB_DM_PORT', 'F.Cu', 0.18)
print('Connected USB DP/DM Port')

board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('Board saved')

