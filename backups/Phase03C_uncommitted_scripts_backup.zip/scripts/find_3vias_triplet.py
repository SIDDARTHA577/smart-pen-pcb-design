import pcbnew, math

b = pcbnew.LoadBoard("scratch_test_fcu_cs_clean.kicad_pcb")

elements = []
for fp in b.GetFootprints():
    for p in fp.Pads():
        pos = p.GetPosition()
        x, y = pos.x/1e6, pos.y/1e6
        if 55.0 <= x <= 61.0 and 0.0 <= y <= 6.0:
            elements.append(('pad', fp.GetReference(), p.GetNetname(), x, y, p.GetSize().x/1e6, p.GetSize().y/1e6))

for t in b.GetTracks():
    if t.GetClass() == 'PCB_VIA':
        p = t.GetPosition()
        x, y = p.x/1e6, p.y/1e6
        if 55.0 <= x <= 61.0 and 0.0 <= y <= 6.0:
            elements.append(('via', 'VIA', t.GetNetname(), x, y, 0.50, 0.50))
    else:
        # Also avoid existing tracks on F.Cu
        if t.GetLayer() == b.GetLayerID('F.Cu'):
            p1, p2 = t.GetStart(), t.GetEnd()
            # approximate as segment
            elements.append(('trk', 'TRK_FCU', t.GetNetname(), (p1.x+p2.x)/2e6, (p1.y+p2.y)/2e6, abs(p1.x-p2.x)/1e6 + 0.15, abs(p1.y-p2.y)/1e6 + 0.15))

def is_via_valid(vx, vy, netname, dia=0.50):
    for etype, name, net, x, y, sx, sy in elements:
        if net == netname:
            continue
        dx = max(0, abs(vx - x) - sx/2)
        dy = max(0, abs(vy - y) - sy/2)
        d = math.hypot(dx, dy)
        if d < (dia/2 + 0.170): # 0.170 margin for safety
            return False
    return True

# Candidate positions for SCK, MOSI, MISO
# Let's search in steps of 0.05 mm
candidates = []
for xi in range(568, 600, 1):
    x = xi / 10.0
    for yi in range(12, 35, 1):
        y = yi / 10.0
        if is_via_valid(x, y, '/DUMMY'):
            candidates.append((x, y))

print(f"Candidates with strict 0.170 clearance: {len(candidates)}")

# We need:
# SCK via (vsck_x, vsck_y)
# MOSI via (vmosi_x, vmosi_y)
# MISO via (vmiso_x, vmiso_y)
# With:
# vsck_x <= vmosi_x <= vmiso_x  (or order that doesn't cross on F.Cu to J_SD.3 (58.15), J_SD.4 (58.65), J_SD.5 (59.15))
# and pairwise distance >= 0.65 mm

valid_triplets = []
for sck in candidates:
    for mosi in candidates:
        if math.hypot(sck[0]-mosi[0], sck[1]-mosi[1]) < 0.68:
            continue
        for miso in candidates:
            if math.hypot(sck[0]-miso[0], sck[1]-miso[1]) < 0.68:
                continue
            if math.hypot(mosi[0]-miso[0], mosi[1]-miso[1]) < 0.68:
                continue
            
            # Check non-crossing order to destinations:
            # Dest: SCK=58.150, MOSI=58.650, MISO=59.150 (all at Y=4.200)
            # If sck[0] <= mosi[0] <= miso[0], F.Cu tracks won't cross!
            if sck[0] <= mosi[0] <= miso[0] and sck[1] <= 3.4 and mosi[1] <= 3.4 and miso[1] <= 3.4:
                valid_triplets.append((sck, mosi, miso))
                if len(valid_triplets) >= 20:
                    break
        if len(valid_triplets) >= 20:
            break
    if len(valid_triplets) >= 20:
        break

print(f"Found {len(valid_triplets)} valid triplets!")
for i, (sck, mosi, miso) in enumerate(valid_triplets[:10]):
    print(f"[{i+1}] SCK: ({sck[0]:.2f}, {sck[1]:.2f}), MOSI: ({mosi[0]:.2f}, {mosi[1]:.2f}), MISO: ({miso[0]:.2f}, {miso[1]:.2f})")
