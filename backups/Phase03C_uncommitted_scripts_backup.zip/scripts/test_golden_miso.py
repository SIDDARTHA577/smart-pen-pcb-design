import pcbnew, shutil, subprocess, json, math, heapq

src_pcb = 'scratch_test_mosi_flawless.kicad_pcb'
dst_pcb = 'scratch_test_golden.kicad_pcb'

shutil.copyfile('scratch_test_mosi_flawless.kicad_pro', 'scratch_test_golden.kicad_pro')
shutil.copyfile('scratch_test_mosi_flawless.kicad_prl', 'scratch_test_golden.kicad_prl')

b = pcbnew.LoadBoard(src_pcb)
fcu = b.GetLayerID('F.Cu')
in1 = b.GetLayerID('In1.Cu')
in2 = b.GetLayerID('In2.Cu')
bcu = b.GetLayerID('B.Cu')

# 1. Update D4 footprint to standard SOD-123 pad size (0.800, 0.900) on board
# and set D4 position to (59.000, 4.050)
d4 = b.FindFootprintByReference('D4')
d4.SetPosition(pcbnew.VECTOR2I_MM(59.000, 4.050))
p1 = d4.FindPadByNumber('1')
p2 = d4.FindPadByNumber('2')
p1.SetSize(pcbnew.VECTOR2I_MM(0.800, 0.900))
p2.SetSize(pcbnew.VECTOR2I_MM(0.800, 0.900))

# D4.1 is at (59.000, 2.450)
# Update VSYS_RAW via on Pad 1 to (59.000, 2.450)
for t in b.GetTracks():
    if isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/VSYS_RAW':
        pos = t.GetPosition()
        if abs(pcbnew.ToMM(pos.x) - 59.0) < 0.05 and abs(pcbnew.ToMM(pos.y) - 2.4) < 0.05:
            t.SetPosition(pcbnew.VECTOR2I_MM(59.000, 2.450))
            print("Updated VSYS_RAW via to (59.0, 2.45)")
    elif not isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/VSYS_RAW':
        p1_t, p2_t = t.GetStart(), t.GetEnd()
        x1, y1 = pcbnew.ToMM(p1_t.x), pcbnew.ToMM(p1_t.y)
        x2, y2 = pcbnew.ToMM(p2_t.x), pcbnew.ToMM(p2_t.y)
        if abs(y1 - 2.4) < 0.05 and abs(y2 - 2.4) < 0.05:
            t.SetStart(pcbnew.VECTOR2I_MM(59.500, 2.450))
            t.SetEnd(pcbnew.VECTOR2I_MM(59.000, 2.450))
            print("Updated VSYS_RAW horizontal segment to Y=2.45")
        if abs(x1 - 59.5) < 0.05 and abs(x2 - 59.5) < 0.05 and abs(y2 - 2.4) < 0.05:
            t.SetEnd(pcbnew.VECTOR2I_MM(59.500, 2.450))
            print("Updated VSYS_RAW vertical trunk end to Y=2.45")

# Update USB_VBUS track to Pad 2 at (59.000, 5.650)
for t in b.GetTracks():
    if not isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/USB_VBUS' and t.GetLayer() == fcu:
        p1_t, p2_t = t.GetStart(), t.GetEnd()
        x2, y2 = pcbnew.ToMM(p2_t.x), pcbnew.ToMM(p2_t.y)
        if abs(x2 - 59.0) < 0.05 and abs(y2 - 5.6) < 0.05:
            t.SetEnd(pcbnew.VECTOR2I_MM(59.000, 5.650))
            print("Updated USB_VBUS track to (59.0, 5.65)")

def add_tr(netname, lid, x1, y1, x2, y2, w=0.150):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I_MM(x1, y1))
    t.SetEnd(pcbnew.VECTOR2I_MM(x2, y2))
    t.SetWidth(pcbnew.FromMM(w))
    t.SetLayer(lid)
    t.SetNet(b.FindNet(netname))
    b.Add(t)
    return t

def add_via(netname, x, y, drill=0.300, dia=0.500):
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I_MM(x, y))
    v.SetDrill(pcbnew.FromMM(drill))
    v.SetWidth(pcbnew.FromMM(dia))
    v.SetNet(b.FindNet(netname))
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    b.Add(v)
    return v

# 2. J_SD North Escape
# Pad 5 (59.150, 4.200) -> (59.150, 5.025) -> (57.300, 5.025) -> (57.300, 5.500)
add_tr('/SD_MISO', fcu, 59.150, 4.200, 59.150, 5.025)
add_tr('/SD_MISO', fcu, 59.150, 5.025, 57.300, 5.025)
add_tr('/SD_MISO', fcu, 57.300, 5.025, 57.300, 5.500)
add_via('/SD_MISO', 57.300, 5.500)

# 3. U1 South Escape
# Pad 10 (41.630, 2.435) -> (41.630, 0.600)
add_tr('/SD_MISO', fcu, 41.630, 2.435, 41.630, 0.600)
add_via('/SD_MISO', 41.630, 0.600)

# 4. A* path on In1.Cu:
pts = [
  (41.630, 0.600),
  (41.500, 0.600),
  (41.000, 1.100),
  (40.900, 1.100),
  (40.700, 1.300),
  (40.700, 1.400),
  (40.600, 1.500),
  (40.600, 1.800),
  (40.700, 1.900),
  (40.700, 2.000),
  (41.400, 2.700),
  (41.900, 2.700),
  (42.300, 3.100),
  (45.000, 3.100),
  (46.000, 4.100),
  (54.300, 4.100),
  (54.400, 4.200),
  (54.500, 4.200),
  (54.600, 4.300),
  (54.700, 4.300),
  (54.800, 4.400),
  (54.900, 4.400),
  (55.000, 4.500),
  (55.200, 4.500),
  (55.300, 4.600),
  (55.400, 4.600),
  (55.500, 4.700),
  (55.600, 4.700),
  (55.700, 4.800),
  (55.800, 4.800),
  (55.900, 4.900),
  (56.000, 4.900),
  (56.100, 5.000),
  (56.300, 5.000),
  (56.400, 5.100),
  (56.500, 5.100),
  (56.600, 5.200),
  (56.700, 5.200),
  (56.800, 5.300),
  (56.900, 5.300),
  (57.000, 5.400),
  (57.200, 5.400),
  (57.300, 5.500)
]

for i in range(len(pts) - 1):
    add_tr('/SD_MISO', in1, pts[i][0], pts[i][1], pts[i+1][0], pts[i+1][1])

# Refill all zones
filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())

b.Save(dst_pcb)
print(f"Saved {dst_pcb} successfully!")
