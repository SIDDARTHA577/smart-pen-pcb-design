import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# Check U1.25 escape on F.Cu:
# U1.25 is at (44.630, 7.235)
print("Checking U1.25 escape:")
for y_esc in [8.30, 8.35, 8.40, 8.95, 9.00, 9.05]:
    s1, r1 = geom.is_segment_legal(44.630, 7.235, 44.630, y_esc, 'F.Cu', '/USB_DM_CORE')
    print(f"F.Cu (44.630, 7.235) -> (44.630, {y_esc:.2f}): {s1} ({r1})")
