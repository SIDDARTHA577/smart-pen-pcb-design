import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
# Remove test group 4 tracks
dm_net = b.FindNet('/USB_DM_CORE')
dp_net = b.FindNet('/USB_DP_CORE')
to_remove = [t for t in b.Tracks() if t.GetNetCode() in [dm_net.GetNetCode(), dp_net.GetNetCode()]]
for t in to_remove:
    b.Remove(t)

geom = BoardGeometry(b)

print("Checking F.Cu corridor north of R7/R8 (Y=6.4):")
for y in [6.3, 6.4, 6.5, 6.6]:
    s_fcu, r = geom.is_segment_legal(70.0, y, 72.5, y, 'F.Cu', '/USB_DM_CORE')
    print(f"  F.Cu (70.0, {y}) -> (72.5, {y}): {s_fcu} ({r})")

# And from (72.5, 6.4) down to R7.2 (72.5, 7.025)
s_drop, r_drop = geom.is_segment_legal(72.5, 6.4, 72.5, 7.025, 'F.Cu', '/USB_DM_CORE')
print(f"  F.Cu drop (72.5, 6.4) -> (72.5, 7.025): {s_drop} ({r_drop})")

sys.exit(0)
