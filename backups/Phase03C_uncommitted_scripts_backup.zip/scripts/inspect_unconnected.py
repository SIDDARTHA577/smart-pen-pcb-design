import json

with open('reports/RevG/Phase03C/raw/Candidate_FourLayer_drc.json') as f:
    d = json.load(f)

unconnected = d.get('unconnected_items', [])
print(f'Total unconnected: {len(unconnected)}')

by_net = {}
for u in unconnected:
    # Look for net name in description or items
    desc = u.get('description', '')
    items = u.get('items', [])
    item_descs = [it.get('description', '') for it in items]
    
    # Extract net from item description e.g. Pad X [/NET]
    nets = set()
    for s in item_descs:
        import re
        m = re.search(r'\[([^\]]+)\]', s)
        if m:
            nets.add(m.group(1))
    net_name = ', '.join(nets) if nets else 'Unknown'
    by_net.setdefault(net_name, []).append((desc, item_descs))

for net, items in sorted(by_net.items(), key=lambda x: -len(x[1])):
    print(f'\nNet "{net}": {len(items)} unconnected items')
    for desc, it_list in items:
        print(f'  - {desc}')
        for it in it_list:
            print(f'      {it}')

