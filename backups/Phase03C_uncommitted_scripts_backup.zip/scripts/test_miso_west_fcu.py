import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

s1, r1 = geom.is_segment_legal(41.630, 2.435, 41.630, 2.000, 'F.Cu', '/SD_MISO')
s2, r2 = geom.is_segment_legal(41.630, 2.000, 39.500, 2.000, 'F.Cu', '/SD_MISO')
print("SD_MISO s1:", s1, r1)
print("SD_MISO s2:", s2, r2)
