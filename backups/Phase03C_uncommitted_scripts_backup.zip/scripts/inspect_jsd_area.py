import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    app = wx.App()
    wx.DisableAsserts()
except:
    pass
import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")

print("--- PADS between X=55 and 61 ---")
for fp in b.GetFootprints():
    for p in fp.Pads():
        pos = p.GetPosition()
        x, y = pos.x/1e6, pos.y/1e6
        if 55.0 <= x <= 61.0 and 0.0 <= y <= 6.0:
            print(f"FP: {fp.GetReference()} Pad: {p.GetNumber()} Net: {p.GetNetname()} Pos: ({x:.3f}, {y:.3f})")

print("\n--- TRACKS and VIAS between X=55 and 61 ---")
for t in b.GetTracks():
    p1 = t.GetStart()
    p2 = t.GetEnd()
    x1, y1 = p1.x/1e6, p1.y/1e6
    x2, y2 = p2.x/1e6, p2.y/1e6
    layer = b.GetLayerName(t.GetLayer())
    if (55.0 <= x1 <= 61.0 or 55.0 <= x2 <= 61.0) and (0.0 <= y1 <= 6.0 or 0.0 <= y2 <= 6.0):
        if t.GetClass() == 'PCB_VIA':
            print(f"VIA Net: {t.GetNetname()} Pos: ({x1:.3f}, {y1:.3f})")
        else:
            print(f"TRK Layer: {layer} Net: {t.GetNetname()} Start: ({x1:.3f}, {y1:.3f}) End: ({x2:.3f}, {y2:.3f})")
