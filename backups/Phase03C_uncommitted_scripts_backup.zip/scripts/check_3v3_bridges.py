import pcbnew

b = pcbnew.LoadBoard("scratch_test_clean_step8.kicad_pcb")
bcu = b.GetLayerID('B.Cu')
net_3v3 = b.FindNet('/3V3')

# Check B.Cu paths for 3V3 bridges:
# Bridge 1: (44.475, 0.500) to (45.666, 2.625)
print("Checking Bridge 1 path on B.Cu:")
for t in b.GetTracks():
    if t.GetLayer() == bcu and t.GetNet() != net_3v3:
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if 44.0 <= max(x1, x2) and min(x1, x2) <= 46.0 and 0.0 <= max(y1, y2) and min(y1, y2) <= 3.0:
            print(f"TRK {t.GetNetname()} on B.Cu: ({x1:.3f}, {y1:.3f}) -> ({x2:.3f}, {y2:.3f})")

# Bridge 2: J_SD.1 via at (56.945, 3.636)
print("\nChecking around J_SD.1 3V3 via at (56.945, 3.636):")
for t in b.GetTracks():
    if t.GetNet() == net_3v3:
        if t.GetClass() == 'PCB_VIA':
            p = t.GetPosition()
            print(f"3V3 VIA: ({p.x/1e6:.3f}, {p.y/1e6:.3f})")
