import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

# Remove the test Group 4 tracks first
dm_net = b.FindNet('/USB_DM_CORE')
dp_net = b.FindNet('/USB_DP_CORE')

to_remove = []
for t in b.Tracks():
    if t.GetNetCode() in [dm_net.GetNetCode(), dp_net.GetNetCode()]:
        to_remove.append(t)

for t in to_remove:
    b.Remove(t)

geom = BoardGeometry(b)

print("Checking DM on B.Cu:")
# DM: U1.25 (44.630, 7.235) -> F.Cu (44.630, 8.350) -> F.Cu (52.000, 8.350) -> F.Cu (52.000, 7.000)
# Via DM at (52.000, 7.000)
# B.Cu: (52.000, 7.000) -> (52.000, 5.800) -> (73.000, 5.800) -> (73.000, 7.000)
# Via DM at (73.000, 7.000)
# F.Cu: (73.000, 7.000) -> (72.500, 7.025)

print("DM via west (52.0, 7.0):", geom.is_via_legal(52.0, 7.0, '/USB_DM_CORE'))
print("DM via east (73.0, 7.0):", geom.is_via_legal(73.0, 7.0, '/USB_DM_CORE'))
print("DM B.Cu jog down:", geom.is_segment_legal(52.0, 7.0, 52.0, 5.8, 'B.Cu', '/USB_DM_CORE'))
print("DM B.Cu main run:", geom.is_segment_legal(52.0, 5.8, 73.0, 5.8, 'B.Cu', '/USB_DM_CORE'))
print("DM B.Cu jog up:", geom.is_segment_legal(73.0, 5.8, 73.0, 7.0, 'B.Cu', '/USB_DM_CORE'))
print("DM F.Cu to R7.2:", geom.is_segment_legal(73.0, 7.0, 72.5, 7.025, 'F.Cu', '/USB_DM_CORE'))

print("\nChecking DP on In2.Cu:")
print("DP via west (54.0, 7.2):", geom.is_via_legal(54.0, 7.2, '/USB_DP_CORE'))
print("DP via east (70.5, 7.8):", geom.is_via_legal(70.5, 7.8, '/USB_DP_CORE'))
print("DP In2.Cu main run:", geom.is_segment_legal(54.0, 7.2, 70.5, 7.2, 'In2.Cu', '/USB_DP_CORE'))
print("DP In2.Cu jog up:", geom.is_segment_legal(70.5, 7.2, 70.5, 7.8, 'In2.Cu', '/USB_DP_CORE'))
print("DP F.Cu to R8.2:", geom.is_segment_legal(70.5, 7.8, 71.6, 7.025, 'F.Cu', '/USB_DP_CORE'))

sys.exit(0)
