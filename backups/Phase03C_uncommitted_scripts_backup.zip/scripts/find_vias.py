import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Grid search for vias near U1 south/east (X: 44..55, Y: 6.0..8.5):")
found_vias = []
for xi in range(440, 550, 2):
    x = xi / 10.0
    for yi in range(60, 88, 2):
        y = yi / 10.0
        ok_dm, _ = geom.is_via_legal(x, y, '/USB_DM_CORE')
        ok_dp, _ = geom.is_via_legal(x, y, '/USB_DP_CORE')
        if ok_dm or ok_dp:
            found_vias.append((x, y, ok_dm, ok_dp))

print(f"Found {len(found_vias)} legal via locations:")
for f in found_vias[:25]:
    print(f"  ({f[0]:.1f}, {f[1]:.1f}): DM={f[2]}, DP={f[3]}")

sys.exit(0)
