import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# 1. F.Cu from U1.25 (44.630, 7.235) to via at (53.000, 7.500):
s1, r1 = geom.is_segment_legal(44.630, 7.235, 44.630, 8.400, 'F.Cu', '/USB_DM_CORE')
s2, r2 = geom.is_segment_legal(44.630, 8.400, 53.000, 8.400, 'F.Cu', '/USB_DM_CORE')
s3, r3 = geom.is_segment_legal(53.000, 8.400, 53.000, 7.500, 'F.Cu', '/USB_DM_CORE')
v1, rv1 = geom.is_via_legal(53.000, 7.500, '/USB_DM_CORE')
print(f"F.Cu escape: s1={s1}, s2={s2}, s3={s3}, via1={v1}")

# 2. Run on B.Cu from (53.0, 7.5) to (70.0, 7.5):
# Wait, between 53 and 57.22, is B.Cu at 7.5 clear of UART_RX (which is at 8.05)?
# 8.05 - 7.50 = 0.55 mm > 0.495 mm!
s_bcu1, rb1 = geom.is_segment_legal(53.000, 7.500, 70.000, 7.500, 'B.Cu', '/USB_DM_CORE')
print(f"B.Cu run 53->70: {s_bcu1} ({rb1})")

# 3. Via at (70.000, 7.500) to In2.Cu to cross X=71.050 (where USB_DP_PORT is on B.Cu):
v2, rv2 = geom.is_via_legal(70.000, 7.500, '/USB_DM_CORE')
s_in2, rin = geom.is_segment_legal(70.000, 7.500, 71.800, 7.500, 'In2.Cu', '/USB_DM_CORE')
v3, rv3 = geom.is_via_legal(71.800, 7.500, '/USB_DM_CORE')
print(f"Via2={v2}, In2 cross={s_in2}, Via3={v3}")

# 4. On B.Cu from (71.8, 7.5) across X=72.500 to (73.0, 7.100):
s_bcu2, rb2 = geom.is_segment_legal(71.800, 7.500, 73.000, 7.100, 'B.Cu', '/USB_DM_CORE')
v4, rv4 = geom.is_via_legal(73.000, 7.100, '/USB_DM_CORE')
s_fcu_r7, rf_r7 = geom.is_segment_legal(73.000, 7.100, 72.500, 7.025, 'F.Cu', '/USB_DM_CORE')
print(f"B.Cu to east via: {s_bcu2}, Via4={v4}, F.Cu to R7.2: {s_fcu_r7}")
