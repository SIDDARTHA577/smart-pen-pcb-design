import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
r27 = b.FindFootprintByReference('R27')
# Rotate R27 180 degrees and place at (44.0, 1.0)
r27.SetOrientationDegrees(180.0)
r27.SetPosition(pcbnew.VECTOR2I(int(44.0*1e6), int(1.0*1e6)))

# Remove old GPIO8_STRAP and 3V3 via at (42.0, 0.5)
for t in list(b.GetTracks()):
    if t.GetNetname() == '/GPIO8_STRAP':
        b.Delete(t)
    elif t.GetNetname() == '/3V3' and (round(t.GetPosition().x/1e6, 1) == 42.0 or (t.GetClass() != 'PCB_VIA' and round(t.GetStart().x/1e6, 1) == 42.0)):
        b.Delete(t)

# Pad 2 of R27 is now at (43.525, 1.000)
# Pad 1 of R27 is now at (44.475, 1.000)
net_strap = b.FindNet('/GPIO8_STRAP')
net_3v3 = b.FindNet('/3V3')

def add_trk(layer, sx, sy, ex, ey, net, w=0.15):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(sx*1e6), int(sy*1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(ex*1e6), int(ey*1e6)))
    t.SetWidth(int(w*1e6))
    t.SetLayer(b.GetLayerID(layer))
    t.SetNet(net)
    b.Add(t)
    return t

def add_via(x, y, net, dia=0.50, drill=0.30):
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(int(x*1e6), int(y*1e6)))
    v.SetWidth(int(dia*1e6))
    v.SetDrill(int(drill*1e6))
    v.SetTopLayer(b.GetLayerID('F.Cu'))
    v.SetBottomLayer(b.GetLayerID('B.Cu'))
    v.SetNet(net)
    b.Add(v)
    return v

# Connect U1.14 (43.630, 2.435) to R27.2 (43.525, 1.000)
# (43.630, 2.435) -> (43.525, 2.000) -> (43.525, 1.000)
add_trk('F.Cu', 43.630, 2.435, 43.525, 2.000, net_strap)
add_trk('F.Cu', 43.525, 2.000, 43.525, 1.000, net_strap)

# Connect R27.1 (44.475, 1.000) to 3V3 via at (44.475, 0.450)
add_trk('F.Cu', 44.475, 1.000, 44.475, 0.450, net_3v3)
add_via(44.475, 0.450, net_3v3)

geom = BoardGeometry(b)
print("GPIO8_STRAP s1:", geom.is_segment_legal(43.630, 2.435, 43.525, 2.000, 'F.Cu', '/GPIO8_STRAP'))
print("GPIO8_STRAP s2:", geom.is_segment_legal(43.525, 2.000, 43.525, 1.000, 'F.Cu', '/GPIO8_STRAP'))
print("R27.1 3V3 seg:", geom.is_segment_legal(44.475, 1.000, 44.475, 0.450, 'F.Cu', '/3V3'))

# Now test SD_SCK via at (42.630, 0.500) and segment from U1.12 (42.630, 2.435)
print("SD_SCK seg:", geom.is_segment_legal(42.630, 2.435, 42.630, 0.500, 'F.Cu', '/SD_SCK'))
print("SD_SCK via:", geom.is_via_legal(42.630, 0.500, '/SD_SCK'))

# Now test SD_CS via at (43.130, 1.750) and segment from U1.13 (43.130, 2.435)
print("SD_CS seg:", geom.is_segment_legal(43.130, 2.435, 43.130, 1.750, 'F.Cu', '/SD_CS'))
print("SD_CS via:", geom.is_via_legal(43.130, 1.750, '/SD_CS'))
