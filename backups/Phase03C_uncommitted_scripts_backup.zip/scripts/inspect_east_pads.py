import os, sys, math
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try: import wx; wx.DisableAsserts()
except: pass
import pcbnew

b = pcbnew.LoadBoard('scratch_test_restore_vsys.kicad_pcb')

# Let's inspect J_SD pads exact bounding boxes:
jsd = b.FindFootprintByReference('J_SD')
print(f"J_SD reference position: ({jsd.GetPosition().x/1e6:.3f}, {jsd.GetPosition().y/1e6:.3f})")
for p in jsd.Pads():
    pos = p.GetPosition()
    print(f"Pad {p.GetNumber()} ({p.GetNetname()}): pos=({pos.x/1e6:.3f}, {pos.y/1e6:.3f}) size=({p.GetSize().x/1e6:.3f}, {p.GetSize().y/1e6:.3f})")

r18 = b.FindFootprintByReference('R18')
print(f"R18 reference position: ({r18.GetPosition().x/1e6:.3f}, {r18.GetPosition().y/1e6:.3f})")
for p in r18.Pads():
    pos = p.GetPosition()
    print(f"Pad {p.GetNumber()} ({p.GetNetname()}): pos=({pos.x/1e6:.3f}, {pos.y/1e6:.3f}) size=({p.GetSize().x/1e6:.3f}, {p.GetSize().y/1e6:.3f})")

d4 = b.FindFootprintByReference('D4')
print(f"D4 reference position: ({d4.GetPosition().x/1e6:.3f}, {d4.GetPosition().y/1e6:.3f})")
for p in d4.Pads():
    pos = p.GetPosition()
    print(f"Pad {p.GetNumber()} ({p.GetNetname()}): pos=({pos.x/1e6:.3f}, {pos.y/1e6:.3f}) size=({p.GetSize().x/1e6:.3f}, {p.GetSize().y/1e6:.3f})")
