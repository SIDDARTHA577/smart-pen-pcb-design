import json

with open('scratch_baseline_drc.json') as f:
    d = json.load(f)
    print("Baseline violations count:", len(d.get('violations', [])))
    for v in d.get('violations', []):
        desc = v.get('description', '')
        text = json.dumps(v)
        if 'D4' in text or 'J_SD' in text:
            print("VIOLATION:", desc)
            for it in v.get('items', []):
                print("  ", it.get('description'))
