import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Checking complete USB_VBUS routing:")
# 1. F.Cu around Q2, R26, D4
s1, r1 = geom.is_segment_legal(61.700, 5.350, 60.500, 4.875, 'F.Cu', '/USB_VBUS')
s2, r2 = geom.is_segment_legal(60.500, 4.875, 59.000, 5.600, 'F.Cu', '/USB_VBUS')
print(f"Q2.1 -> R26.1: {s1}, R26.1 -> D4.2: {s2}")

# 2. Q2.1 to U2.4 on B.Cu
v_q2, rv_q = geom.is_via_legal(61.700, 5.350, '/USB_VBUS')
s_q2_u2, r_qu = geom.is_segment_legal(61.700, 5.350, 67.450, 5.350, 'B.Cu', '/USB_VBUS')
print(f"Via at Q2.1: {v_q2}, B.Cu to U2.4: {s_q2_u2}")

# 3. U2.4 to C11.1 on F.Cu
s_u2_c11, r_uc = geom.is_segment_legal(67.950, 5.370, 67.450, 5.370, 'F.Cu', '/USB_VBUS')
s_c11_a, r_ca = geom.is_segment_legal(67.450, 5.370, 67.450, 7.750, 'F.Cu', '/USB_VBUS')
s_c11_b, r_cb = geom.is_segment_legal(67.450, 7.750, 67.250, 7.750, 'F.Cu', '/USB_VBUS')
print(f"U2.4 -> C11.1: s_u2={s_u2_c11}, s_a={s_c11_a}, s_b={s_c11_b}")

# 4. Via at (67.450, 5.100) or (67.450, 5.350)
v_u2, rv_u = geom.is_via_legal(67.450, 5.100, '/USB_VBUS')
print(f"Via U2 at (67.45, 5.10): {v_u2} ({rv_u})")

# 5. B.Cu run from 67.450 to 80.800 at Y=5.100
s_bcu, r_bcu = geom.is_segment_legal(67.450, 5.100, 80.800, 5.100, 'B.Cu', '/USB_VBUS')
print(f"B.Cu run at Y=5.10: {s_bcu} ({r_bcu})")

# 6. Vias and drops to J_USB.2 and J_USB.11
v_j2, rv_j2 = geom.is_via_legal(76.000, 5.100, '/USB_VBUS')
s_j2, r_j2 = geom.is_segment_legal(76.000, 3.100, 76.000, 5.100, 'F.Cu', '/USB_VBUS')
v_j11, rv_j11 = geom.is_via_legal(80.800, 5.100, '/USB_VBUS')
s_j11, r_j11 = geom.is_segment_legal(80.800, 3.100, 80.800, 5.100, 'F.Cu', '/USB_VBUS')
print(f"J_USB.2 via={v_j2}, F.Cu={s_j2} | J_USB.11 via={v_j11}, F.Cu={s_j11}")

# 7. C10.1 to J_USB.2 on F.Cu:
s_c10_1, r_c1 = geom.is_segment_legal(73.750, 1.500, 73.750, 2.200, 'F.Cu', '/USB_VBUS')
s_c10_2, r_c2 = geom.is_segment_legal(73.750, 2.200, 76.000, 2.200, 'F.Cu', '/USB_VBUS')
s_c10_3, r_c3 = geom.is_segment_legal(76.000, 2.200, 76.000, 3.100, 'F.Cu', '/USB_VBUS')
print(f"C10.1 -> J_USB.2: s1={s_c10_1}, s2={s_c10_2}, s3={s_c10_3}")
