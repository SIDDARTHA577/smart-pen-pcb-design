import pcbnew, math

b = pcbnew.LoadBoard("scratch_test_clean_step5.kicad_pcb")

# Test via at (vx, vy)
def test_via(vx, vy):
    print(f"\n--- Testing via at ({vx:.3f}, {vy:.3f}) ---")
    min_dist = 999.0
    closest = None
    for fp in b.GetFootprints():
        for p in fp.Pads():
            if p.GetNetname() == '/SD_CS': continue
            pos = p.GetPosition()
            dx = max(0, abs(vx - pos.x/1e6) - p.GetSize().x/2e6)
            dy = max(0, abs(vy - pos.y/1e6) - p.GetSize().y/2e6)
            d = math.hypot(dx, dy)
            if d < min_dist:
                min_dist = d
                closest = (fp.GetReference(), p.GetNumber(), p.GetNetname(), 'pad')
    for t in b.GetTracks():
        if t.GetNetname() == '/SD_CS': continue
        if t.GetClass() == 'PCB_VIA':
            pos = t.GetPosition()
            d = math.hypot(vx - pos.x/1e6, vy - pos.y/1e6) - 0.25
            if d < min_dist:
                min_dist = d
                closest = (t.GetNetname(), 'via', pos.x/1e6, pos.y/1e6)
        else:
            p1, p2 = t.GetStart(), t.GetEnd()
            # check point to segment distance
            x1, y1 = p1.x/1e6, p1.y/1e6
            x2, y2 = p2.x/1e6, p2.y/1e6
            l2 = (x2-x1)**2 + (y2-y1)**2
            if l2 == 0: t_proj = 0
            else: t_proj = max(0, min(1, ((vx-x1)*(x2-x1) + (vy-y1)*(y2-y1)) / l2))
            proj_x = x1 + t_proj*(x2-x1)
            proj_y = y1 + t_proj*(y2-y1)
            d = math.hypot(vx - proj_x, vy - proj_y) - t.GetWidth()/2e6
            if d < min_dist:
                min_dist = d
                closest = (t.GetNetname(), b.GetLayerName(t.GetLayer()), 'trk')
    print(f"Closest item: {closest}, clearance = {min_dist - 0.25:.3f} mm")

test_via(56.975, 1.450)
test_via(57.500, 1.450)
test_via(56.500, 1.450)
test_via(57.500, 2.500)
test_via(57.600, 2.700)
