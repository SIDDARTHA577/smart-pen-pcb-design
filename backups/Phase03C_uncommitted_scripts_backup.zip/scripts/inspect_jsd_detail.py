import sys
sys.path.append('scripts')
import pcbnew

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
jsd = b.FindFootprintByReference('J_SD')
print('J_SD pos:', jsd.GetPosition().x/1e6, jsd.GetPosition().y/1e6)
for p in jsd.Pads():
    pos = p.GetPosition()
    sz = p.GetSize()
    print(f"Pad {p.GetNumber()}: net={p.GetNetname()}, pos=({pos.x/1e6:.3f}, {pos.y/1e6:.3f}), size=({sz.x/1e6:.3f}, {sz.y/1e6:.3f})")
