import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
r27 = b.FindFootprintByReference('R27')
# Put R27 back to baseline position (43.5, 1.0)
r27.SetPosition(pcbnew.VECTOR2I(int(43.5*1e6), int(1.0*1e6)))

# Remove old GPIO8_STRAP tracks
for t in list(b.GetTracks()):
    if t.GetNetname() == '/GPIO8_STRAP':
        b.Delete(t)

# Route GPIO8_STRAP from U1.14 (43.630, 2.435) to R27.2 (43.975, 1.000)
# (43.630, 2.435) -> (43.630, 1.000) -> (43.975, 1.000)
net_strap = b.FindNet('/GPIO8_STRAP')
t1 = pcbnew.PCB_TRACK(b)
t1.SetStart(pcbnew.VECTOR2I(int(43.630*1e6), int(2.435*1e6)))
t1.SetEnd(pcbnew.VECTOR2I(int(43.630*1e6), int(1.000*1e6)))
t1.SetWidth(int(0.15*1e6))
t1.SetLayer(b.GetLayerID('F.Cu'))
t1.SetNet(net_strap)
b.Add(t1)

t2 = pcbnew.PCB_TRACK(b)
t2.SetStart(pcbnew.VECTOR2I(int(43.630*1e6), int(1.000*1e6)))
t2.SetEnd(pcbnew.VECTOR2I(int(43.975*1e6), int(1.000*1e6)))
t2.SetWidth(int(0.15*1e6))
t2.SetLayer(b.GetLayerID('F.Cu'))
t2.SetNet(net_strap)
b.Add(t2)

geom = BoardGeometry(b)
# Check GPIO8_STRAP legality
print("GPIO8_STRAP s1:", geom.is_segment_legal(43.630, 2.435, 43.630, 1.000, 'F.Cu', '/GPIO8_STRAP'))
print("GPIO8_STRAP s2:", geom.is_segment_legal(43.630, 1.000, 43.975, 1.000, 'F.Cu', '/GPIO8_STRAP'))

# Now test SD_CS escape at U1.13 (43.130, 2.435)
print("SD_CS s1:", geom.is_segment_legal(43.130, 2.435, 43.130, 1.750, 'F.Cu', '/SD_CS'))
print("SD_CS via:", geom.is_via_legal(43.130, 1.750, '/SD_CS'))

# Now test SD_SCK escape at U1.12 (42.630, 2.435)
# Check via for SD_SCK at (42.630, 1.750) or (42.630, 0.500)
for vx in [42.630, 42.500, 42.400, 42.700]:
    for vy in [1.750, 1.600, 0.500]:
        v_ok, rv = geom.is_via_legal(vx, vy, '/SD_SCK')
        if v_ok:
            print(f"SD_SCK via legal at ({vx}, {vy})")
