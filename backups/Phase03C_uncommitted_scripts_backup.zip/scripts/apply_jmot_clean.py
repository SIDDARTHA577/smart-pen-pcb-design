import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

board_path = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb'
b = pcbnew.LoadBoard(board_path)

vbat_net = b.FindNet('/VBAT_SW')
fcu = b.GetLayerID('F.Cu')
in2 = b.GetLayerID('In2.Cu')

# Remove the test tracks that shorted to J_MOT pad 3
tracks = [t for t in b.Tracks()]
for t in tracks:
    if t.GetNetname() == '/VBAT_SW':
        if t.GetLayerName() == 'F.Cu':
            s, e = t.GetStart(), t.GetEnd()
            sx, sy = s.x / 1e6, s.y / 1e6
            ex, ey = e.x / 1e6, e.y / 1e6
            if abs(sx - 29.0) < 0.1 or abs(ex - 29.0) < 0.1:
                b.Remove(t)
            elif abs(sy - 7.8) < 0.1 and abs(ey - 7.8) < 0.1:
                b.Remove(t)

# Add verified clean In2.Cu and F.Cu path
def add_track(net, layer, x1, y1, x2, y2, w=0.18):
    t = pcbnew.PCB_TRACK(b)
    t.SetNet(net)
    t.SetLayer(layer)
    t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    t.SetWidth(int(w * 1e6))
    b.Add(t)

def add_via(net, x, y, dia=0.50, drill=0.30):
    v = pcbnew.PCB_VIA(b)
    v.SetNet(net)
    v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    v.SetWidth(int(dia * 1e6))
    v.SetDrill(int(drill * 1e6))
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    b.Add(v)

add_track(vbat_net, in2, 28.090, 4.400, 30.753, 4.400)
add_track(vbat_net, in2, 30.753, 4.400, 30.753, 7.200)
add_via(vbat_net, 30.753, 7.200)
add_track(vbat_net, fcu, 30.753, 7.200, 30.753, 6.285)

filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
b.Save(board_path)
print("J_MOT connection cleanly applied!")
sys.exit(0)
