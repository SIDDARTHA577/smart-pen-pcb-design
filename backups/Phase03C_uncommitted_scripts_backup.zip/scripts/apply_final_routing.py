import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

def build_routed_board(source_pcb, dest_pcb):
    b = pcbnew.LoadBoard(source_pcb)
    fcu = b.GetLayerID('F.Cu')
    bcu = b.GetLayerID('B.Cu')
    in2 = b.GetLayerID('In2.Cu')

    def add_trk(netname, layer_id, x1, y1, x2, y2, width=0.15):
        net = b.FindNet(netname)
        t = pcbnew.PCB_TRACK(b)
        t.SetStart(pcbnew.VECTOR2I(int(round(x1 * 1e6)), int(round(y1 * 1e6))))
        t.SetEnd(pcbnew.VECTOR2I(int(round(x2 * 1e6)), int(round(y2 * 1e6))))
        t.SetLayer(layer_id)
        t.SetWidth(int(round(width * 1e6)))
        t.SetNet(net)
        b.Add(t)
        return t

    def add_via(netname, x, y, drill=0.30, dia=0.50):
        net = b.FindNet(netname)
        v = pcbnew.PCB_VIA(b)
        v.SetPosition(pcbnew.VECTOR2I(int(round(x * 1e6)), int(round(y * 1e6))))
        v.SetWidth(int(round(dia * 1e6)))
        v.SetDrill(int(round(drill * 1e6)))
        v.SetNet(net)
        v.SetViaType(pcbnew.VIATYPE_THROUGH)
        b.Add(v)
        return v

    # 1. Move R27 to (44.8, 1.0)
    r27 = b.FindFootprintByReference('R27')
    if r27:
        r27.SetPosition(pcbnew.VECTOR2I(int(44.8 * 1e6), int(1.0 * 1e6)))

    # 2. Delete interfering items:
    for t in list(b.GetTracks()):
        net = t.GetNetname()
        cls = t.GetClass()
        layer = b.GetLayerName(t.GetLayer())
        
        # Remove old GPIO8_STRAP
        if net == '/GPIO8_STRAP':
            b.Delete(t)
        # Remove old BOOT9
        elif net == '/BOOT9':
            b.Delete(t)
        # Remove old VSYS_RAW on In2.Cu
        elif net == '/VSYS_RAW' and layer == 'In2.Cu':
            b.Delete(t)
        # Remove redundant freestanding GND stitching via at (55.0, 1.2)
        elif cls == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 55.0 and round(t.GetPosition().y/1e6, 2) == 1.2:
            b.Delete(t)
        # Remove old 3V3 stub to former R27.1 position at (42.025, 1.0)
        elif net == '/3V3' and layer == 'F.Cu' and cls != 'PCB_VIA':
            s = t.GetStart()
            e = t.GetEnd()
            if (round(s.x/1e6, 2) in [42.02, 42.0] and round(s.y/1e6, 2) == 1.0) or \
               (round(e.x/1e6, 2) in [42.02, 42.0] and round(e.y/1e6, 2) == 1.0):
                b.Delete(t)
        # Remove old USB_DM_PORT via at (72.5, 8.5) and In2.Cu track at X=72.5
        elif net == '/USB_DM_PORT':
            if cls == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 72.5 and round(t.GetPosition().y/1e6, 2) == 8.5:
                b.Delete(t)
            elif layer == 'In2.Cu':
                b.Delete(t)
            elif layer == 'F.Cu' and cls != 'PCB_VIA':
                s, e = t.GetStart(), t.GetEnd()
                if round(s.x/1e6, 2) == 72.5 and round(s.y/1e6, 2) == 8.5:
                    b.Delete(t)
                elif round(e.x/1e6, 2) == 72.5 and round(e.y/1e6, 2) == 8.5:
                    b.Delete(t)
        # Update CHG_STAT jog on B.Cu to Y=2.30 between X=39 and 44
        elif net == '/CHG_STAT' and layer == 'B.Cu' and cls != 'PCB_VIA':
            s, e = t.GetStart(), t.GetEnd()
            x1, y1 = round(s.x/1e6, 2), round(s.y/1e6, 2)
            x2, y2 = round(e.x/1e6, 2), round(e.y/1e6, 2)
            if (x1 == 24.25 and x2 == 44.0 and y1 == 1.0 and y2 == 1.0) or \
               (x1 == 39.0 and x2 == 44.0):
                b.Delete(t)

    # Re-apply CHG_STAT clean jog
    add_trk('/CHG_STAT', bcu, 24.25, 1.00, 39.00, 1.00)
    add_trk('/CHG_STAT', bcu, 39.00, 1.00, 39.00, 2.30)
    add_trk('/CHG_STAT', bcu, 39.00, 2.30, 44.00, 2.30)
    add_trk('/CHG_STAT', bcu, 44.00, 2.30, 44.00, 1.80)

    # 3. Route GPIO8_STRAP to R27 at (44.8, 1.0):
    # R27.2 is at (45.275, 1.000). R27.1 (3V3) is at (44.325, 1.000).
    # Pin 14 is at (43.630, 2.435).
    add_trk('/GPIO8_STRAP', fcu, 43.630, 2.435, 43.630, 1.700)
    add_trk('/GPIO8_STRAP', fcu, 43.630, 1.700, 45.275, 1.700)
    add_trk('/GPIO8_STRAP', fcu, 45.275, 1.700, 45.275, 1.000)

    # Connect R27.1 (44.325, 1.000) to 3V3 plane via
    add_via('/3V3', 44.325, 0.500)
    add_trk('/3V3', fcu, 44.325, 1.000, 44.325, 0.500)

    # 4. Route BOOT9 cleanly at Y=2.00:
    # U1.15 (44.130, 2.435) to SW2.1 (45.704, 1.500):
    add_trk('/BOOT9', fcu, 44.130, 2.435, 44.130, 1.500)
    add_trk('/BOOT9', fcu, 44.130, 1.500, 45.704, 1.500)
    # Via to B.Cu at (46.50, 2.00)
    add_via('/BOOT9', 46.50, 2.00)
    add_trk('/BOOT9', fcu, 45.704, 1.500, 46.50, 2.00)
    add_trk('/BOOT9', bcu, 46.50, 2.00, 52.225, 2.00)
    add_via('/BOOT9', 52.225, 2.00)
    add_trk('/BOOT9', fcu, 52.225, 2.00, 52.225, 2.250)

    # 5. Route VSYS_RAW on B.Cu (replacing In2.Cu run):
    # SW3.1 is at (60.963, 6.824), via at (60.500, 6.500)
    # B.Cu run: (60.500, 6.500) -> (59.500, 6.500) -> (59.500, 2.400)
    add_trk('/VSYS_RAW', bcu, 60.500, 6.500, 59.500, 6.500, 0.20)
    add_trk('/VSYS_RAW', bcu, 59.500, 6.500, 59.500, 2.400, 0.20)
    # Q2.2 tap:
    add_trk('/VSYS_RAW', bcu, 59.500, 3.450, 61.500, 3.450, 0.20)
    # Note: vias at (60.5, 6.5), (59.5, 2.4), (61.5, 3.45) and F.Cu stubs already exist!

    # 6. Re-route USB_DM_PORT with shifted via at (73.2, 8.5):
    add_trk('/USB_DM_PORT', fcu, 72.500, 7.975, 73.200, 7.975)
    add_trk('/USB_DM_PORT', fcu, 73.200, 7.975, 73.200, 8.500)
    add_via('/USB_DM_PORT', 73.200, 8.500)
    add_trk('/USB_DM_PORT', in2, 73.200, 8.500, 73.200, 0.550)
    add_trk('/USB_DM_PORT', in2, 73.200, 0.550, 72.000, 0.550)

    # 7. Route /USB_DM_CORE:
    # F.Cu: U1.25 (44.630, 7.235) -> (44.630, 8.400) -> (52.000, 8.400) -> (52.000, 7.000)
    add_trk('/USB_DM_CORE', fcu, 44.630, 7.235, 44.630, 8.400)
    add_trk('/USB_DM_CORE', fcu, 44.630, 8.400, 52.000, 8.400)
    add_trk('/USB_DM_CORE', fcu, 52.000, 8.400, 52.000, 7.000)
    add_via('/USB_DM_CORE', 52.000, 7.000)
    # In2.Cu: (52.000, 7.000) -> (52.000, 6.000) -> (73.000, 6.000) -> (73.000, 7.100)
    add_trk('/USB_DM_CORE', in2, 52.000, 7.000, 52.000, 6.000)
    add_trk('/USB_DM_CORE', in2, 52.000, 6.000, 73.000, 6.000)
    add_trk('/USB_DM_CORE', in2, 73.000, 6.000, 73.000, 7.100)
    add_via('/USB_DM_CORE', 73.000, 7.100)
    # F.Cu: (73.000, 7.100) -> R7.2 (72.500, 7.025)
    add_trk('/USB_DM_CORE', fcu, 73.000, 7.100, 72.500, 7.025)

    # 8. Route MicroSD SPI Bus:
    # Net 1: /SD_MOSI
    add_trk('/SD_MOSI', fcu, 41.130, 2.435, 41.130, 2.050)
    add_trk('/SD_MOSI', fcu, 41.130, 2.050, 40.880, 2.050)
    add_trk('/SD_MOSI', fcu, 40.880, 2.050, 40.880, 0.550)
    add_via('/SD_MOSI', 40.880, 0.550)
    add_trk('/SD_MOSI', bcu, 40.880, 0.550, 40.880, 1.050)
    add_trk('/SD_MOSI', bcu, 40.880, 1.050, 42.500, 1.050)
    add_trk('/SD_MOSI', bcu, 42.500, 1.050, 42.500, 0.550)
    add_trk('/SD_MOSI', bcu, 42.500, 0.550, 58.650, 0.550)
    add_via('/SD_MOSI', 58.650, 0.550)
    add_trk('/SD_MOSI', fcu, 58.650, 0.550, 58.200, 1.500)
    add_trk('/SD_MOSI', fcu, 58.200, 1.500, 58.200, 3.150)
    add_trk('/SD_MOSI', fcu, 58.200, 3.150, 58.650, 3.500)
    add_trk('/SD_MOSI', fcu, 58.650, 3.500, 58.650, 4.200)

    # Net 2: /SD_MISO
    add_trk('/SD_MISO', fcu, 41.630, 2.435, 41.400, 1.600)
    add_via('/SD_MISO', 41.400, 1.600)
    add_trk('/SD_MISO', bcu, 41.400, 1.600, 41.400, 1.250)
    add_trk('/SD_MISO', bcu, 41.400, 1.250, 59.150, 1.250)
    add_trk('/SD_MISO', bcu, 59.150, 1.250, 59.150, 3.350)
    add_via('/SD_MISO', 59.150, 3.350)
    add_trk('/SD_MISO', fcu, 59.150, 3.350, 59.150, 4.200)

    # Net 3: /SD_SCK
    add_trk('/SD_SCK', fcu, 42.630, 2.435, 42.680, 0.550)
    add_via('/SD_SCK', 42.680, 0.550)
    add_trk('/SD_SCK', in2, 42.680, 0.550, 42.680, 1.650)
    add_trk('/SD_SCK', in2, 42.680, 1.650, 58.150, 1.650)
    add_trk('/SD_SCK', in2, 58.150, 1.650, 58.150, 1.300)
    add_via('/SD_SCK', 58.150, 1.300)
    add_trk('/SD_SCK', fcu, 58.150, 1.300, 58.150, 4.200)

    # Net 4: /SD_CS
    add_trk('/SD_CS', fcu, 43.130, 2.435, 43.350, 1.600)
    add_via('/SD_CS', 43.350, 1.600)
    add_trk('/SD_CS', in2, 43.350, 1.600, 43.350, 1.950)
    add_trk('/SD_CS', in2, 43.350, 1.950, 60.000, 1.950)
    add_trk('/SD_CS', in2, 60.000, 1.950, 60.000, 3.200)
    add_via('/SD_CS', 60.000, 3.200)
    add_trk('/SD_CS', fcu, 60.000, 3.200, 59.650, 4.200)
    # Tap to R18:
    add_trk('/SD_CS', in2, 56.975, 1.950, 56.975, 0.850)
    add_via('/SD_CS', 56.975, 0.850)
    add_trk('/SD_CS', fcu, 56.975, 0.850, 56.975, 2.000)

    b.Save(dest_pcb)
    print(f"Successfully saved cleanly routed board to: {dest_pcb}")

if __name__ == '__main__':
    src = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb'
    dest = 'scratch_final_candidate.kicad_pcb'
    build_routed_board(src, dest)
