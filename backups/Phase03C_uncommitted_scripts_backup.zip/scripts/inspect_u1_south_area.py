import sys
sys.path.append('scripts')
import pcbnew

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
u1 = b.FindFootprintByReference('U1')
for pin_num in [9, 10, 12, 13]:
    pad = u1.FindPadByNumber(str(pin_num))
    pos = pad.GetPosition()
    print(f"U1.{pin_num} ({pad.GetNetname()}): pos=({pos.x/1e6:.3f}, {pos.y/1e6:.3f})")

print("=== Footprints near U1 south/east: X in [40, 46], Y in [0, 3] ===")
for fp in b.GetFootprints():
    pos = fp.GetPosition()
    px, py = pos.x/1e6, pos.y/1e6
    if 40.0 <= px <= 46.0 and 0.0 <= py <= 3.0:
        print(f"FP: {fp.GetReference()} at ({px:.3f}, {py:.3f}), rot={fp.GetOrientation().AsDegrees()}")
        for p in fp.Pads():
            pp = p.GetPosition()
            print(f"  Pad {p.GetNumber()} ({p.GetNetname()}): pos=({pp.x/1e6:.3f}, {pp.y/1e6:.3f})")

print("=== Tracks in X in [40, 46], Y in [0, 3] ===")
for t in b.GetTracks():
    s, e = t.GetStart(), t.GetEnd()
    sx, sy, ex, ey = s.x/1e6, s.y/1e6, e.x/1e6, e.y/1e6
    if (40.0 <= sx <= 46.0 or 40.0 <= ex <= 46.0) and (0.0 <= sy <= 3.0 or 0.0 <= ey <= 3.0):
        print(f"{t.GetClass()} net={t.GetNetname()} layer={b.GetLayerName(t.GetLayer())}: ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})")
