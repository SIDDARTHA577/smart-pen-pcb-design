import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

s1, r1 = geom.is_segment_legal(52.500, 7.300, 52.500, 6.600, 'B.Cu', '/USB_DM_CORE')
s2, r2 = geom.is_segment_legal(52.500, 6.600, 68.000, 6.600, 'B.Cu', '/USB_DM_CORE')

print(f"s1 (jog down to 6.6): {s1} ({r1})")
print(f"s2 (horiz 52.5->68 @ 6.6): {s2} ({r2})")
