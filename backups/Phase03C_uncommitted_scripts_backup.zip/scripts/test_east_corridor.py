import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# R7.2 is at (72.500, 7.025)
# R8.2 is at (71.600, 7.025)
# Let's test vias near R7.2 and R8.2
print("Testing vias near R7/R8:")
for x in [70.5, 71.0, 71.6, 72.5, 73.0, 73.5]:
    for y in [6.5, 7.0, 7.5, 8.0, 8.5]:
        v_ok, r = geom.is_via_legal(x, y, '/USB_DM_CORE')
        if v_ok:
            print(f"  Legal via DM at ({x:.1f}, {y:.1f})")

# Test In2.Cu and B.Cu corridors from 53.0/54.0 to 71.0/73.0
print("\nTesting horizontal runs on In2.Cu:")
for y in [6.8, 7.0, 7.2, 7.4]:
    leg, r = geom.is_segment_legal(53.0, y, 71.0, y, 'In2.Cu', '/USB_DM_CORE')
    print(f"  In2.Cu (53.0, {y}) -> (71.0, {y}): {leg} ({r})")

print("\nTesting horizontal runs on B.Cu:")
for y in [5.0, 5.2, 5.4, 5.6, 5.8, 6.0]:
    leg, r = geom.is_segment_legal(53.0, y, 71.0, y, 'B.Cu', '/USB_DM_CORE')
    print(f"  B.Cu (53.0, {y}) -> (71.0, {y}): {leg} ({r})")

sys.exit(0)
