import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

v_jmot, rv = geom.is_via_legal(30.753, 7.200, '/VBAT_SW')
s_bcu1, rs1 = geom.is_segment_legal(28.090, 4.400, 30.753, 4.400, 'B.Cu', '/VBAT_SW')
s_bcu2, rs2 = geom.is_segment_legal(30.753, 4.400, 30.753, 7.200, 'B.Cu', '/VBAT_SW')
s_fcu, rsf = geom.is_segment_legal(30.753, 7.200, 30.753, 6.285, 'F.Cu', '/VBAT_SW')
print(f"J_MOT via B.Cu: v={v_jmot}({rv}), s1={s_bcu1}({rs1}), s2={s_bcu2}({rs2}), fcu={s_fcu}({rsf})")

sys.exit(0)
