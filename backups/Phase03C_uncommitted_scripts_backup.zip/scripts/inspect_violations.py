import json
with open('reports/RevG/Phase03C/raw/Candidate_FourLayer_drc.json') as f:
    d = json.load(f)

violations = d.get('violations', [])
by_type = {}
for v in violations:
    t = v.get('type')
    by_type[t] = by_type.get(t, 0) + 1
print('Violations by type:')
for t, count in sorted(by_type.items(), key=lambda x: -x[1]):
    print(f'  {t}: {count}')

for i, v in enumerate(violations):
    items = [it.get('description', '') for it in v.get('items', [])]
    print(f'[{i+1}] {v.get("type")}: {v.get("description")}')
    for it in items:
        print(f'    {it}')

