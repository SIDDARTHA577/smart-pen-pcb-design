import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

print("--- Testing Pad 4 (SD_MOSI at 58.650, 4.200) North ---")
for y in [4.5, 4.8, 5.0, 5.2, 5.5, 6.0]:
    s, r = geom.is_segment_legal(58.650, 4.200, 58.650, y, 'F.Cu', '/SD_MOSI')
    print(f"y={y}: {s} ({r})")
    if s:
        for vx in [58.650, 58.400, 58.000]:
            v, rv = geom.is_via_legal(vx, y, '/SD_MOSI')
            if v:
                print(f"  Via OK at ({vx}, {y})")
