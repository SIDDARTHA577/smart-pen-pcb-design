import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Checking Power Segments:")

# 1. /VSYS_RAW
# SW3.1 (60.963, 6.824) -> (60.963, 3.450) -> Q2.2 (61.700, 3.450)
s1, r1 = geom.is_segment_legal(60.963, 6.824, 60.963, 3.450, 'F.Cu', '/VSYS_RAW')
s2, r2 = geom.is_segment_legal(60.963, 3.450, 61.700, 3.450, 'F.Cu', '/VSYS_RAW')
# (60.963, 3.450) -> (59.000, 2.400) [D4.1]
s3, r3 = geom.is_segment_legal(60.963, 3.450, 59.000, 2.400, 'F.Cu', '/VSYS_RAW')
print(f"VSYS_RAW: s1={s1}({r1}), s2={s2}({r2}), s3={s3}({r3})")

# 2. /VBAT
# J_BAT.1 (62.300, 1.720) -> (67.400, 1.400) [C12.1]
b1, rb1 = geom.is_segment_legal(62.300, 1.720, 67.400, 1.400, 'F.Cu', '/VBAT')
# C12.1 (67.400, 1.400) -> U2.3 (67.950, 2.770)
b2, rb2 = geom.is_segment_legal(67.400, 1.400, 67.950, 2.770, 'F.Cu', '/VBAT')
# J_BAT.1 (62.300, 1.720) -> Q2.3 (63.900, 4.400)
b3, rb3 = geom.is_segment_legal(62.300, 1.720, 63.900, 4.400, 'F.Cu', '/VBAT')
print(f"VBAT: b1={b1}({rb1}), b2={b2}({rb2}), b3={b3}({rb3})")

# 3. /USB_VBUS
# U2.4 (67.950, 5.370) -> Q2.1 (61.700, 5.350)
u1, ru1 = geom.is_segment_legal(67.950, 5.370, 61.700, 5.350, 'F.Cu', '/USB_VBUS')
# Q2.1 (61.700, 5.350) -> R26.1 (60.500, 4.875)
u2, ru2 = geom.is_segment_legal(61.700, 5.350, 60.500, 4.875, 'F.Cu', '/USB_VBUS')
# R26.1 (60.500, 4.875) -> D4.2 (59.000, 5.600)
u3, ru3 = geom.is_segment_legal(60.500, 4.875, 59.000, 5.600, 'F.Cu', '/USB_VBUS')
print(f"USB_VBUS: u1={u1}({ru1}), u2={u2}({ru2}), u3={u3}({ru3})")

sys.exit(0)
