import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

print("Checking south of U1.10 (41.630, 2.435):")
for vy in [0.5, 0.7, 0.9, 1.1, 1.3, 1.5, 1.7, 1.9, 2.1]:
    s, r = geom.is_segment_legal(41.630, 2.435, 41.630, vy, 'F.Cu', '/SD_MISO')
    v, rv = geom.is_via_legal(41.630, vy, '/SD_MISO')
    print(f"vy={vy:.2f}: s={s} ({r}), v={v} ({rv})")
