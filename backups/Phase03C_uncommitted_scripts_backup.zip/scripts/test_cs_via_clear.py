import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
r27 = b.FindFootprintByReference('R27')
r27.SetOrientationDegrees(180.0)
r27.SetPosition(pcbnew.VECTOR2I(int(44.0*1e6), int(1.0*1e6)))

for t in list(b.GetTracks()):
    if t.GetNetname() == '/GPIO8_STRAP':
        b.Delete(t)
    elif t.GetNetname() == '/3V3' and (round(t.GetPosition().x/1e6, 1) == 42.0 or (t.GetClass() != 'PCB_VIA' and round(t.GetStart().x/1e6, 1) == 42.0)):
        b.Delete(t)

net_strap = b.FindNet('/GPIO8_STRAP')
t = pcbnew.PCB_TRACK(b)
t.SetStart(pcbnew.VECTOR2I(int(43.630*1e6), int(2.435*1e6)))
t.SetEnd(pcbnew.VECTOR2I(int(43.525*1e6), int(1.000*1e6)))
t.SetWidth(int(0.15*1e6))
t.SetLayer(b.GetLayerID('F.Cu'))
t.SetNet(net_strap)
b.Add(t)

geom = BoardGeometry(b)
for vx in [42.95, 43.00, 43.05, 43.10]:
    for vy in [1.60, 1.65, 1.70, 1.75]:
        v, rv = geom.is_via_legal(vx, vy, '/SD_CS')
        s, rs = geom.is_segment_legal(43.130, 2.435, vx, vy, 'F.Cu', '/SD_CS')
        if v and s:
            print(f"SD_CS via & seg OK at ({vx:.2f}, {vy:.2f})!")
