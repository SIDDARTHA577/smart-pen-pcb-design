import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
r27 = b.FindFootprintByReference('R27')
for rx in [44.0, 44.5, 45.0]:
    r27.SetPosition(pcbnew.VECTOR2I(int(rx*1e6), int(1.0*1e6)))
    geom = BoardGeometry(b)
    p1 = r27.FindPadByNumber('1')
    p2 = r27.FindPadByNumber('2')
    p1_ok = geom.is_via_legal(p1.GetPosition().x/1e6, p1.GetPosition().y/1e6, '/3V3')
    print(f"R27 at ({rx}, 1.0): check pads...")
