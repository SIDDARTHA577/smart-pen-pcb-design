import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
for t in b.Tracks():
    p = t.GetPosition() if isinstance(t, pcbnew.PCB_VIA) else t.GetStart()
    if abs(p.x/1e6 - 42.0) < 0.1 and abs(p.y/1e6 - 0.5) < 0.1:
        if isinstance(t, pcbnew.PCB_VIA):
            print(f"Via: {t.GetNetname()} at ({p.x/1e6:.3f}, {p.y/1e6:.3f})")
        else:
            p2 = t.GetEnd()
            print(f"Track: {t.GetNetname()} [{b.GetLayerName(t.GetLayer())}] ({p.x/1e6:.3f}, {p.y/1e6:.3f}) -> ({p2.x/1e6:.3f}, {p2.y/1e6:.3f})")
