import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

for x_int in range(360, 400, 5):
    x = x_int / 10.0
    for y_int in range(40, 55, 2):
        y = y_int / 10.0
        v_ok, reason = geom.is_via_legal(x, y, '/I2C_SCL')
        print(f"Via at ({x:.2f}, {y:.2f}): {v_ok} ({reason})")
