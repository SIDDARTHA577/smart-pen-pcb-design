import re
from pathlib import Path

pcb_text = Path("output/RevG/SmartPen.kicad_pcb").read_text(encoding="utf-8")
models = re.findall(r'\(model\s+"([^"]+)"', pcb_text)
print("3D models found:", len(models))
for m in models[:10]:
    print(" ", m)

