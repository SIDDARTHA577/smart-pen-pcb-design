import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

s, r = geom.is_segment_legal(60.050, 3.450, 60.050, 0.850, 'F.Cu', '/SD_CS')
print("SD_CS at X=60.050:", s, r)
s_top, r_top = geom.is_segment_legal(59.650, 4.200, 60.050, 3.450, 'F.Cu', '/SD_CS')
print("SD_CS top jog:", s_top, r_top)
s_bot, r_bot = geom.is_segment_legal(60.050, 0.850, 59.300, 0.850, 'F.Cu', '/SD_CS')
print("SD_CS bot jog:", s_bot, r_bot)
