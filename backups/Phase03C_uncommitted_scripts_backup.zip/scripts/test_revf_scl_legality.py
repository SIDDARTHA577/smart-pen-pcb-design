import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

test_scl_revf = [
    ('F.Cu', 4.700, 4.600, 4.700, 7.150),
    ('F.Cu', 6.675, 7.200, 7.500, 7.200),
    ('F.Cu', 7.500, 7.200, 7.500, 7.150),
    ('B.Cu', 4.700, 7.150, 7.500, 7.150),
    ('B.Cu', 7.500, 7.150, 24.250, 7.150),
    ('B.Cu', 24.250, 7.150, 25.000, 7.150),
    ('B.Cu', 25.000, 7.150, 25.000, 4.590),
    ('B.Cu', 25.000, 4.590, 36.500, 4.590),
    ('F.Cu', 36.500, 4.590, 40.480, 4.590),
]

print("Checking Rev F SCL segments:")
for lyr, x1, y1, x2, y2 in test_scl_revf:
    leg, r = geom.is_segment_legal(x1, y1, x2, y2, lyr, '/I2C_SCL')
    print(f"  {lyr} ({x1},{y1})->({x2},{y2}): {leg} ({r})")

print("\nChecking Rev F SCL vias:")
for vx, vy in [(4.700, 7.150), (7.500, 7.150), (36.500, 4.590)]:
    v_ok, r = geom.is_via_legal(vx, vy, '/I2C_SCL')
    print(f"  Via ({vx},{vy}): {v_ok} ({r})")

sys.exit(0)
