import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Testing B.Cu horizontal runs at different Y values between X=25.0 and 38.0:")
for y_int in range(50, 75, 2):
    y = y_int / 10.0
    s_ok, r = geom.is_segment_legal(25.000, y, 38.000, y, 'B.Cu', '/I2C_SCL')
    print(f"B.Cu Y={y:.2f}: {s_ok} ({r})")
