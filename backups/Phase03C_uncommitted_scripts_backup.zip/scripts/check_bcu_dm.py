import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Checking B.Cu corridor for USB_DM_CORE:")
for yi in range(65, 75, 1):
    y = yi / 10.0
    s_bcu, r = geom.is_segment_legal(52.0, y, 73.0, y, 'B.Cu', '/USB_DM_CORE')
    print(f"B.Cu y={y:.1f}: {s_bcu} ({r})")
