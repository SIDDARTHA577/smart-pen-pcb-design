with open('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb', 'r') as f:
    text = f.read()

import re
for m in re.finditer(r'\(connect_pads\b.*?\)', text, re.DOTALL):
    print(m.group(0))
