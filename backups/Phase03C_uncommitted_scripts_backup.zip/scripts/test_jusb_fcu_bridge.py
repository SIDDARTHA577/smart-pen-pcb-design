import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

s1, r1 = geom.is_segment_legal(76.000, 2.200, 80.800, 2.200, 'F.Cu', '/USB_VBUS')
s2, r2 = geom.is_segment_legal(80.800, 2.200, 80.800, 3.100, 'F.Cu', '/USB_VBUS')

print(f"s1 (76.0 -> 80.8 @ 2.2): {s1} ({r1})")
print(f"s2 (80.8, 2.2 -> J_USB.11): {s2} ({r2})")
