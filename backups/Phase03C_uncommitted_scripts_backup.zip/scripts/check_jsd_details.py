import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")

print("--- PADS OF J_SD ---")
jsd = b.FindFootprintByReference("J_SD")
print("J_SD center:", jsd.GetPosition().x/1e6, jsd.GetPosition().y/1e6)
print("J_SD bbox:", jsd.GetBoundingBox().GetX()/1e6, jsd.GetBoundingBox().GetY()/1e6, jsd.GetBoundingBox().GetWidth()/1e6, jsd.GetBoundingBox().GetHeight()/1e6)
for p in jsd.Pads():
    print(f"Pad {p.GetNumber()} ({p.GetNetname()}): pos=({p.GetPosition().x/1e6:.3f}, {p.GetPosition().y/1e6:.3f}) size=({p.GetSize().x/1e6:.3f}, {p.GetSize().y/1e6:.3f})")
