import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

v_ok, rv = geom.is_via_legal(56.000, 7.100, '/USB_DM_CORE')
s_f1, rf1 = geom.is_segment_legal(44.630, 7.235, 44.630, 8.400, 'F.Cu', '/USB_DM_CORE')
s_f2, rf2 = geom.is_segment_legal(44.630, 8.400, 56.000, 8.400, 'F.Cu', '/USB_DM_CORE')
s_f3, rf3 = geom.is_segment_legal(56.000, 8.400, 56.000, 7.100, 'F.Cu', '/USB_DM_CORE')

print(f"Via at (56.0, 7.1): {v_ok} ({rv})")
print(f"F.Cu: s1={s_f1}, s2={s_f2}, s3={s_f3}")
