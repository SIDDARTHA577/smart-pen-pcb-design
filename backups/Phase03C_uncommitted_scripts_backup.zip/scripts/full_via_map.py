import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
# Remove test group 4 tracks
dm_net = b.FindNet('/USB_DM_CORE')
dp_net = b.FindNet('/USB_DP_CORE')
to_remove = [t for t in b.Tracks() if t.GetNetCode() in [dm_net.GetNetCode(), dp_net.GetNetCode()]]
for t in to_remove:
    b.Remove(t)

geom = BoardGeometry(b)

print("Full legal via map for X: 69..74, Y: 1.0..8.5 for DM:")
for xi in range(690, 740, 2):
    x = xi / 10.0
    for yi in range(10, 86, 2):
        y = yi / 10.0
        v_ok, r = geom.is_via_legal(x, y, '/USB_DM_CORE')
        if v_ok:
            print(f"  ({x:.1f}, {y:.1f})")

sys.exit(0)
