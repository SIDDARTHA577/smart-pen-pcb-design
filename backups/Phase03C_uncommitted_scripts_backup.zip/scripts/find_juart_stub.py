import json, os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
d = json.load(open('reports/RevG/Phase03C/raw/candidate_scl_drc.json'))
for u in d.get('unconnected_items', []):
    desc = [i['description'] for i in u['items']]
    if any('J_UART' in s for s in desc):
        print("Found J_UART item:", desc)
        for i in u['items']:
            print("  Item:", i)
