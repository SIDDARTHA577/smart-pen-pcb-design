import pcbnew
import uuid

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

# Check zones
for z in board.Zones():
    if z.GetLayerName() == 'In1.Cu':
        print('Found In1.Cu zone, setting new UUID and island mode')
        z.m_Uuid = pcbnew.KIID(str(uuid.uuid4()))
        # Check island removal mode
        print('Current island removal mode:', z.GetIslandRemovalMode())
        # Set to 2 (never remove islands) or 1
        z.SetIslandRemovalMode(2)

filler = pcbnew.ZONE_FILLER(board)
filler.Fill(board.Zones())
board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('Filled and saved')

