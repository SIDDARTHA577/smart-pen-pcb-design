import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

in1_zones = []
for z in board.Zones():
    if board.GetLayerName(z.GetLayer()) == 'In1.Cu':
        in1_zones.append(z)

print(f'Found {len(in1_zones)} zones on In1.Cu')
if len(in1_zones) > 1:
    # remove the second one
    board.Remove(in1_zones[1])
    print('Removed duplicate In1.Cu zone')

board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

