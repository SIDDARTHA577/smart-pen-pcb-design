import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

for fp in board.Footprints():
    for p in fp.Pads():
        if p.GetNetname() == '/MCU_EN':
            pos = p.GetPosition()
            print(f'{fp.GetReference()}.{p.GetNumber()} at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})')

