import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

def pcb_to_mm(val):
    return val / 1e6

print("--- PADS ---")
for f in b.GetFootprints():
    for p in f.Pads():
        netname = p.GetNetname()
        if netname in ['/I2C_SCL', '/I2C_SDA']:
            pos = p.GetPosition()
            print(f"Pad: {f.GetReference()}.{p.GetName()} ({netname}) at ({pcb_to_mm(pos.x):.3f}, {pcb_to_mm(pos.y):.3f})")

print("\n--- VIAS ---")
for t in b.Tracks():
    if isinstance(t, pcbnew.PCB_VIA):
        netname = t.GetNetname()
        if netname in ['/I2C_SCL', '/I2C_SDA']:
            pos = t.GetPosition()
            print(f"Via: {netname} at ({pcb_to_mm(pos.x):.3f}, {pcb_to_mm(pos.y):.3f})")

print("\n--- TRACKS ---")
for t in b.Tracks():
    if not isinstance(t, pcbnew.PCB_VIA):
        netname = t.GetNetname()
        if netname in ['/I2C_SCL', '/I2C_SDA']:
            p1 = t.GetStart()
            p2 = t.GetEnd()
            layer = b.GetLayerName(t.GetLayer())
            print(f"Track: {netname} [{layer}] ({pcb_to_mm(p1.x):.3f}, {pcb_to_mm(p1.y):.3f}) -> ({pcb_to_mm(p2.x):.3f}, {pcb_to_mm(p2.y):.3f})")
