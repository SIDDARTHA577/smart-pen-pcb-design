import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try: import wx; wx.DisableAsserts()
except: pass
import pcbnew, shutil

shutil.copy('scratch_test_restore_vsys.kicad_pcb', 'scratch_test_bcu_cs.kicad_pcb')
shutil.copy('scratch_test_restore_vsys.kicad_pro', 'scratch_test_bcu_cs.kicad_pro')

b = pcbnew.LoadBoard('scratch_test_bcu_cs.kicad_pcb')

# 1. Delete freestanding stitching via at (55.00, 1.20)
for t in list(b.GetTracks()):
    if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 55.00 and round(t.GetPosition().y/1e6, 2) == 1.20:
        b.Delete(t)

# 2. Fix R27 silkscreen reference position (move to 44.0, 0.40)
r27 = b.FindFootprintByReference('R27')
if r27:
    r27.Reference().SetPosition(pcbnew.VECTOR2I(int(44.0 * 1e6), int(0.40 * 1e6)))

# 3. Move VSYS_RAW via from (59.50, 2.40) onto D4.1 pad at (59.00, 2.40)
for t in list(b.GetTracks()):
    if t.GetNetname() == '/VSYS_RAW':
        if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 59.50 and round(t.GetPosition().y/1e6, 2) == 2.40:
            b.Delete(t)
        elif t.GetClass() != 'PCB_VIA' and t.GetLayer() == b.GetLayerID('F.Cu'):
            b.Delete(t)

net_vsys = b.FindNet('/VSYS_RAW')
v_vsys = pcbnew.PCB_VIA(b)
v_vsys.SetPosition(pcbnew.VECTOR2I(int(59.000 * 1e6), int(2.400 * 1e6)))
v_vsys.SetWidth(int(0.500 * 1e6))
v_vsys.SetDrill(int(0.300 * 1e6))
v_vsys.SetNet(net_vsys)
b.Add(v_vsys)

# Connect In2.Cu from (59.5, 2.4) to (59.0, 2.4)
t_vsys = pcbnew.PCB_TRACK(b)
t_vsys.SetStart(pcbnew.VECTOR2I(int(59.500 * 1e6), int(2.400 * 1e6)))
t_vsys.SetEnd(pcbnew.VECTOR2I(int(59.000 * 1e6), int(2.400 * 1e6)))
t_vsys.SetWidth(int(0.200 * 1e6))
t_vsys.SetLayer(b.GetLayerID('In2.Cu'))
t_vsys.SetNet(net_vsys)
b.Add(t_vsys)

# 4. Route SD_CS on B.Cu
fcu = b.GetLayerID('F.Cu')
bcu = b.GetLayerID('B.Cu')
net_cs = b.FindNet('/SD_CS')

def add_trk(layer_id, x1, y1, x2, y2, w=0.15):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(round(x1 * 1e6)), int(round(y1 * 1e6))))
    t.SetEnd(pcbnew.VECTOR2I(int(round(x2 * 1e6)), int(round(y2 * 1e6))))
    t.SetWidth(int(round(w * 1e6)))
    t.SetLayer(layer_id)
    t.SetNet(net_cs)
    b.Add(t)
    return t

def add_via(x, y, drill=0.30, dia=0.50):
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(int(round(x * 1e6)), int(round(y * 1e6))))
    v.SetWidth(int(round(dia * 1e6)))
    v.SetDrill(int(round(drill * 1e6)))
    v.SetNet(net_cs)
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    b.Add(v)
    return v

# U1.13 escape to B.Cu
add_trk(fcu, 43.130, 2.435, 43.130, 1.950)
add_trk(fcu, 43.130, 1.950, 43.000, 1.820)
add_trk(fcu, 43.000, 1.820, 43.000, 1.600)
add_via(43.000, 1.600)

# B.Cu track to R18.2
add_trk(bcu, 43.000, 1.600, 43.000, 1.150)
add_trk(bcu, 43.000, 1.150, 56.975, 1.150)
add_via(56.975, 1.150)
add_trk(fcu, 56.975, 1.150, 56.975, 2.000)

# B.Cu track to J_SD.6
add_trk(bcu, 56.975, 1.150, 59.650, 1.150)
add_trk(bcu, 59.650, 1.150, 59.650, 0.850)
add_via(59.650, 0.850)
add_trk(fcu, 59.650, 0.850, 59.650, 4.200)

# Refill zones
filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
b.Save('scratch_test_bcu_cs.kicad_pcb')
print("Successfully generated scratch_test_bcu_cs.kicad_pcb")
