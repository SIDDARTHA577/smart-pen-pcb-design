import json
from pathlib import Path

drc_path = Path("reports/RevG/Phase03C/raw/baseline/Main_SmartPen_drc.json")
with open(drc_path, "r", encoding="utf-8") as f:
    drc = json.load(f)

print("=== Analyzing Clearance Violations by Net Pairs ===")
clearances = [v for v in drc["violations"] if v.get("type") == "clearance"]
net_pairs = {}
for c in clearances:
    items = c.get("items", [])
    nets = []
    for it in items:
        desc = it.get("description", "")
        if "[" in desc and "]" in desc:
            nets.append(desc.split("[")[1].split("]")[0])
        else:
            nets.append("unknown")
    pair = tuple(sorted(nets))
    net_pairs[pair] = net_pairs.get(pair, 0) + 1

for pair, cnt in sorted(net_pairs.items(), key=lambda x: x[1], reverse=True):
    print(f"  {pair[0]:20s} <-> {pair[1]:20s} : {cnt} violations")

