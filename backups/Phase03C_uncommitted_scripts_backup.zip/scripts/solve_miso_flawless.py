import pcbnew, math

b = pcbnew.LoadBoard('scratch_test_mosi_flawless.kicad_pcb')
fcu = b.GetLayerID('F.Cu')
in1 = b.GetLayerID('In1.Cu')
in2 = b.GetLayerID('In2.Cu')
bcu = b.GetLayerID('B.Cu')

# In scratch_test_mosi_flawless:
# D4 is at (59.0, 4.0).
# J_SD is at (58.4, 4.2). Pad 5 is at (59.15, 4.2). Pad 6 is at (59.65, 4.2).
# D4.1 is at (59.0, 2.4).
# We want to connect Pad 5 to U1.10 (41.63, 2.435).

# Let's check: from (59.40, 3.25), what options exist?
# Can a track go:
# Option A: East to X=60.0, then south to Y=1.2 to via (59.2, 1.2)?
# What blocks (59.4, 3.25) -> (60.0, 3.25) -> (60.0, 1.2) -> (59.2, 1.2)?
# The only obstacle was the SD_CS track on F.Cu at X=59.800!

# Where does SD_CS currently run?
print("Current SD_CS tracks:")
for t in b.GetTracks():
    if t.GetNetname() == '/SD_CS':
        p1, p2 = t.GetStart(), t.GetEnd()
        print(f"  {t.GetLayerName()}: ({pcbnew.ToMM(p1.x):.3f}, {pcbnew.ToMM(p1.y):.3f}) -> ({pcbnew.ToMM(p2.x):.3f}, {pcbnew.ToMM(p2.y):.3f})")
