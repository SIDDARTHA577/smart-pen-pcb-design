import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Checking I2C_SCL West:")
w1, rw1 = geom.is_segment_legal(4.700, 4.600, 4.700, 7.150, 'F.Cu', '/I2C_SCL')
vw1, rvw1 = geom.is_via_legal(4.700, 7.150, '/I2C_SCL')
w2, rw2 = geom.is_segment_legal(6.675, 7.200, 7.500, 7.200, 'F.Cu', '/I2C_SCL')
w3, rw3 = geom.is_segment_legal(7.500, 7.200, 7.500, 7.150, 'F.Cu', '/I2C_SCL')
vw2, rvw2 = geom.is_via_legal(7.500, 7.150, '/I2C_SCL')
wb1, rwb1 = geom.is_segment_legal(4.700, 7.150, 7.500, 7.150, 'B.Cu', '/I2C_SCL')
wb2, rwb2 = geom.is_segment_legal(7.500, 7.150, 24.250, 7.150, 'B.Cu', '/I2C_SCL')
print(f"  w1={w1}, vw1={vw1}, w2={w2}, w3={w3}, vw2={vw2}, wb1={wb1}, wb2={wb2}")

print("\nChecking I2C_SCL East:")
e1, re1 = geom.is_segment_legal(24.250, 7.150, 25.000, 7.150, 'B.Cu', '/I2C_SCL')
e2, re2 = geom.is_segment_legal(25.000, 7.150, 25.000, 5.600, 'B.Cu', '/I2C_SCL')
e3, re3 = geom.is_segment_legal(25.000, 5.600, 38.000, 5.600, 'B.Cu', '/I2C_SCL')
ve, rve = geom.is_via_legal(38.000, 5.600, '/I2C_SCL')
ef1, ref1 = geom.is_segment_legal(38.000, 5.600, 39.500, 4.585, 'F.Cu', '/I2C_SCL')
ef2, ref2 = geom.is_segment_legal(39.500, 4.585, 40.480, 4.585, 'F.Cu', '/I2C_SCL')
print(f"  e1={e1}, e2={e2}, e3={e3}, ve={ve}({rve}), ef1={ef1}({ref1}), ef2={ef2}({ref2})")

sys.exit(0)
