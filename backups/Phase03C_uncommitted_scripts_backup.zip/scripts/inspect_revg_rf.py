import pcbnew

board = pcbnew.LoadBoard('output/RevG/SmartPen.kicad_pcb')

for t in board.GetTracks():
    if t.GetNetname() == '/RF_LNA':
        s, e = t.GetStart(), t.GetEnd()
        layer = board.GetLayerName(t.GetLayer())
        if isinstance(t, pcbnew.PCB_VIA):
            pos = t.GetPosition()
            print(f'RevG baseline VIA /RF_LNA at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})')
        else:
            print(f'RevG baseline TRACK /RF_LNA [{layer}]: ({s.x/1e6:.3f}, {s.y/1e6:.3f}) -> ({e.x/1e6:.3f}, {e.y/1e6:.3f})')

