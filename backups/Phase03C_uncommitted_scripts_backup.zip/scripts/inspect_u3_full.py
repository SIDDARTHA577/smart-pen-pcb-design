import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
u3 = None
for f in b.GetFootprints():
    if f.GetReference() == 'U3':
        u3 = f
        break

print(f"U3 pos: ({u3.GetPosition().x/1e6:.3f}, {u3.GetPosition().y/1e6:.3f})")
for p in u3.Pads():
    pos = p.GetPosition()
    print(f"  Pad {p.GetName()} ({p.GetNetname()}) at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})")
