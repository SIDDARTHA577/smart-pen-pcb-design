import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
# Remove test group 4 tracks
dm_net = b.FindNet('/USB_DM_CORE')
dp_net = b.FindNet('/USB_DP_CORE')
to_remove = [t for t in b.Tracks() if t.GetNetCode() in [dm_net.GetNetCode(), dp_net.GetNetCode()]]
for t in to_remove:
    b.Remove(t)

geom = BoardGeometry(b)

print("Testing bridge via at X=71.8, Y=8.2:")
for y in [7.5, 7.8, 8.0, 8.2]:
    v_ok, r = geom.is_via_legal(71.8, y, '/USB_DM_CORE')
    print(f"  Via at (71.8, {y}): {v_ok} ({r})")

for x in [71.7, 71.8, 71.9, 72.0]:
    for y in [8.0, 8.2, 8.4]:
        v_ok, r = geom.is_via_legal(x, y, '/USB_DM_CORE')
        if v_ok:
            print(f"  Legal bridge via at ({x}, {y})")

sys.exit(0)
