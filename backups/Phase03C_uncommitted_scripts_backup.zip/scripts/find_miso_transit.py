import pcbnew, math

b = pcbnew.LoadBoard('scratch_test_mosi_flawless.kicad_pcb')
in1 = b.GetLayerID('In1.Cu')
bcu = b.GetLayerID('B.Cu')

# Test transit paths for MISO from (41.63, 0.6) to (57.3, 5.5)
# Check B.Cu and In1.Cu
# On In1.Cu: MOSI is currently:
# (41.13, 1.65) -> (41.45, 2.3) -> (43.6, 2.3) -> (44.5, 1.4) -> (57.6, 1.4) -> (58.65, 3.35)

# If MOSI is rerouted on In1.Cu to:
# (41.13, 1.65) -> (41.45, 1.4) -> (58.0, 1.4) -> (58.65, 3.35)
# Then MOSI stays strictly at Y <= 1.4 until X >= 58.0!
# Then MISO from (41.63, 0.6) can go:
# (41.63, 0.6) -> (42.0, 0.6) -> wait!
# Can MISO go north at X=42.0 or 43.0?
# What is around U1 on In1.Cu?
print("Checking In1.Cu obstacles:")
for t in b.GetTracks():
    if t.GetLayer() == in1:
        p1, p2 = t.GetStart(), t.GetEnd()
        print(f"  {t.GetNetname()}: ({pcbnew.ToMM(p1.x):.3f}, {pcbnew.ToMM(p1.y):.3f}) -> ({pcbnew.ToMM(p2.x):.3f}, {pcbnew.ToMM(p2.y):.3f})")
