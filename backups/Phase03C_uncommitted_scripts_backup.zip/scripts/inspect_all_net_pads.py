import pcbnew
from collections import defaultdict
from pathlib import Path

pcb_path = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb")
board = pcbnew.LoadBoard(str(pcb_path))

nets = board.GetNetsByName()
print(f"Total nets in board: {len(nets)}")

net_pads = defaultdict(list)
for fp in board.GetFootprints():
    ref = fp.GetReference()
    for pad in fp.Pads():
        netname = pad.GetNetname()
        if netname:
            pnum = pad.GetNumber()
            pos = pad.GetPosition()
            net_pads[netname].append((ref, pnum, pos.x/1e6, pos.y/1e6))

# Sort nets by pad count
for name, pads in sorted(net_pads.items(), key=lambda x: len(x[1]), reverse=True):
    print(f"\nNet: '{name}' ({len(pads)} pads)")
    for ref, pnum, x, y in sorted(pads, key=lambda p: p[2]):
        print(f"    {ref}.{pnum} @ ({x:.2f}, {y:.2f})")

