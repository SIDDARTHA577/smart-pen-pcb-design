import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
bcu_id = b.GetLayerID('B.Cu')

print("--- ITEMS on B.Cu between X=20 and 42 ---")
for t in b.Tracks():
    if t.GetLayer() == bcu_id:
        p1 = t.GetStart()
        p2 = t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if max(x1, x2) >= 20 and min(x1, x2) <= 42:
            print(f"Track: {t.GetNetname()} B.Cu ({x1:.3f},{y1:.3f}) -> ({x2:.3f},{y2:.3f})")
