import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# Via at (28.090, 4.400) is already verified legal!
# Track on In2.Cu: (28.090, 4.400) -> (30.753, 4.400) -> (30.753, 7.200)
p1, rp1 = geom.is_segment_legal(28.090, 4.400, 30.753, 4.400, 'In2.Cu', '/VBAT_SW')
p2, rp2 = geom.is_segment_legal(30.753, 4.400, 30.753, 7.200, 'In2.Cu', '/VBAT_SW')
# Via at (30.753, 7.200)
v_ok, rv = geom.is_via_legal(30.753, 7.200, '/VBAT_SW')
# F.Cu track to J_MOT.1:
p3, rp3 = geom.is_segment_legal(30.753, 7.200, 30.753, 6.285, 'F.Cu', '/VBAT_SW')

print(f"p1 In2={p1}({rp1})")
print(f"p2 In2={p2}({rp2})")
print(f"v={v_ok}({rv})")
print(f"p3 F.Cu={p3}({rp3})")

sys.exit(0)
