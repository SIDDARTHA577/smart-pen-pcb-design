import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)
print("Testing B.Cu segments from X=43.0 to 57.0 at Y in [2.2, 5.0]:")
for y in [2.2, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5]:
    s, r = geom.is_segment_legal(43.000, y, 57.000, y, 'B.Cu', '/SD_SCK')
    if s:
        print(f"  B.Cu Y={y:.2f} is 100% LEGAL!")
