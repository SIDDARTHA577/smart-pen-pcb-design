import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# Check via in Outline 3 around (34.5, 7.2) or (34.5, 7.0)
for x in [34.0, 34.2, 34.5, 34.8, 35.0]:
    for y in [6.8, 7.0, 7.2, 7.4]:
        v_ok, rv = geom.is_via_legal(x, y, '/GND')
        if v_ok:
            print(f"Outline 3 legal GND via at ({x:.2f}, {y:.2f})")

# Check via in Outline 4 around (17.0, 6.0) to (19.0, 7.0)
for x in [16.5, 17.0, 17.5, 18.0, 18.5, 19.0]:
    for y in [5.0, 5.5, 6.0, 6.5, 7.0]:
        v_ok, rv = geom.is_via_legal(x, y, '/GND')
        if v_ok:
            print(f"Outline 4 legal GND via at ({x:.2f}, {y:.2f})")
