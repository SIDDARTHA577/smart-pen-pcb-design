with open('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb') as f:
    lines = f.readlines()

for i, l in enumerate(lines):
    if '(zone' in l:
        print(f'Line {i+1}: {l.strip()}')
        for j in range(i+1, min(i+25, len(lines))):
            print(f'  {lines[j].strip()}')

