import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Checking X=73.8 on In2.Cu:")
print("In2 (72.0, 0.55) -> (73.8, 0.55):", geom.is_segment_legal(72.0, 0.55, 73.8, 0.55, 'In2.Cu', '/USB_DM_PORT'))
print("In2 (73.8, 0.55) -> (73.8, 8.5):", geom.is_segment_legal(73.8, 0.55, 73.8, 8.5, 'In2.Cu', '/USB_DM_PORT'))
print("In2 (73.8, 8.5) -> (72.5, 8.5):", geom.is_segment_legal(73.8, 8.5, 72.5, 8.5, 'In2.Cu', '/USB_DM_PORT'))

sys.exit(0)
