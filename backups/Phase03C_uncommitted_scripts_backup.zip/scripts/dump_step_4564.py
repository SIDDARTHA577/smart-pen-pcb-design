import json

with open(r'C:\Users\goran\AppData\Local\Temp\step_4564.txt', 'w') as out:
    pass

with open(r'C:\Users\goran\.gemini\antigravity\brain\ec1f5237-3a8d-4968-ab54-b82566efa1d3\.system_generated\logs\transcript.jsonl', encoding='utf-8') as f:
    for line in f:
        obj = json.loads(line)
        if obj.get('step_index') == 4564:
            print(obj.get('content'))
