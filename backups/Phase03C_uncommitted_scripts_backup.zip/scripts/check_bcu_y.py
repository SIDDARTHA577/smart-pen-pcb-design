import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

print("Checking B.Cu corridors:")
for y in [0.45, 0.50, 0.55, 0.60, 0.70, 0.80, 1.30, 1.40, 1.50, 2.10, 2.20]:
    s, r = geom.is_segment_legal(39.680, y, 58.150, y, 'B.Cu', '/SD_MOSI')
    print(f"B.Cu at Y={y:.2f}: {s} ({r})")
