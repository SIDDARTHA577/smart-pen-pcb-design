import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")
bcu = b.GetLayerID('B.Cu')

print("--- ALL B.Cu TRACKS and VIAS in Y=[0.5, 3.0] ---")
for t in b.GetTracks():
    if t.GetClass() == 'PCB_VIA':
        pos = t.GetPosition()
        x, y = pos.x/1e6, pos.y/1e6
        if 40.0 <= x <= 61.0 and 0.0 <= y <= 3.5:
            print(f"VIA Net: {t.GetNetname()} at ({x:.3f}, {y:.3f})")
    elif t.GetLayer() == bcu:
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (40.0 <= x1 <= 61.0 or 40.0 <= x2 <= 61.0) and (0.0 <= y1 <= 3.5 or 0.0 <= y2 <= 3.5):
            print(f"TRK Net: {t.GetNetname()} ({x1:.3f}, {y1:.3f}) -> ({x2:.3f}, {y2:.3f})")
