import pcbnew
import subprocess
import json

# Load the verified flawless base board
board = pcbnew.LoadBoard('scratch_test_mosi_flawless.kicad_pcb')

# Remove existing tracks and vias for SD_MOSI, SD_SCK, SD_MISO
# Keep SD_CS untouched! Keep CHG_STAT untouched! Keep VSYS_RAW untouched!
tracks_to_remove = []
for t in board.GetTracks():
    net = t.GetNetname()
    if net in ['/SD_SCK', '/SD_MOSI', '/SD_MISO']:
        tracks_to_remove.append(t)

print(f"Removing {len(tracks_to_remove)} old tracks/vias for SD_SCK, SD_MOSI, SD_MISO")
for t in tracks_to_remove:
    board.Remove(t)

# Helper functions
fcu = board.GetLayerID('F.Cu')
bcu = board.GetLayerID('B.Cu')
in1 = board.GetLayerID('In1.Cu')
in2 = board.GetLayerID('In2.Cu')

def add_track(netname, layer, x1, y1, x2, y2, width=0.15):
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(pcbnew.VECTOR2I_MM(x1, y1))
    t.SetEnd(pcbnew.VECTOR2I_MM(x2, y2))
    t.SetWidth(pcbnew.FromMM(width))
    t.SetLayer(layer)
    t.SetNet(board.FindNet(netname))
    board.Add(t)
    return t

def add_via(netname, x, y, drill=0.3, width=0.5):
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pcbnew.VECTOR2I_MM(x, y))
    v.SetDrill(pcbnew.FromMM(drill))
    v.SetWidth(pcbnew.FromMM(width))
    v.SetNet(board.FindNet(netname))
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    board.Add(v)
    return v

# --- 1. ROUTE SD_SCK (U1.12 to J_SD.3) ---
# Pad U1.12 is at (42.630, 2.435)
# Via at U1.12: (42.630, 1.150)
add_track('/SD_SCK', fcu, 42.630, 2.435, 42.630, 1.150)
add_via('/SD_SCK', 42.630, 1.150)

# SCK goes North at J_SD.3 (58.150, 4.200)
add_track('/SD_SCK', fcu, 58.150, 4.200, 58.150, 5.400)
add_track('/SD_SCK', fcu, 58.150, 5.400, 58.000, 5.400)
add_via('/SD_SCK', 58.000, 5.400)

# Transit on In1.Cu:
# From (42.630, 1.150) jog to Y=4.800? Or jog on In1.Cu?
# Let's check where In1.Cu is clear:
# On In1.Cu, between X=42.6 and X=58.0, let's jog from (42.630, 1.150) to (44.000, 5.400) -> (58.000, 5.400)
add_track('/SD_SCK', in1, 42.630, 1.150, 44.000, 2.520)
add_track('/SD_SCK', in1, 44.000, 2.520, 44.000, 5.400)
add_track('/SD_SCK', in1, 44.000, 5.400, 58.000, 5.400)

# --- 2. ROUTE SD_MOSI (U1.9 to J_SD.4) ---
# Pad U1.9 is at (41.130, 2.435)
add_track('/SD_MOSI', fcu, 41.130, 2.435, 41.130, 1.650)
add_via('/SD_MOSI', 41.130, 1.650)

# At J_SD.4 (58.650, 4.200):
# Upper track at Y=3.390 to West Playground at (58.000, 2.100)
add_track('/SD_MOSI', fcu, 58.650, 4.200, 58.650, 3.390)
add_track('/SD_MOSI', fcu, 58.650, 3.390, 58.000, 3.390)
add_track('/SD_MOSI', fcu, 58.000, 3.390, 58.000, 2.100)
add_via('/SD_MOSI', 58.000, 2.100)

# Transit on In1.Cu at Y=1.400:
add_track('/SD_MOSI', in1, 41.130, 1.650, 41.450, 1.400)
add_track('/SD_MOSI', in1, 41.450, 1.400, 57.500, 1.400)
add_track('/SD_MOSI', in1, 57.500, 1.400, 58.000, 2.100)

# --- 3. ROUTE SD_MISO (U1.10 to J_SD.5) ---
# Pad U1.10 is at (41.630, 2.435)
add_track('/SD_MISO', fcu, 41.630, 2.435, 41.630, 0.600)
add_via('/SD_MISO', 41.630, 0.600)

# At J_SD.5 (59.150, 4.200):
# Lower track at Y=3.110 to West Playground at (57.600, 2.700)
add_track('/SD_MISO', fcu, 59.150, 4.200, 59.150, 3.110)
add_track('/SD_MISO', fcu, 59.150, 3.110, 57.600, 3.110)
add_track('/SD_MISO', fcu, 57.600, 3.110, 57.600, 2.700)
add_via('/SD_MISO', 57.600, 2.700)

# Transit on In1.Cu at Y=0.850:
add_track('/SD_MISO', in1, 41.630, 0.600, 42.000, 0.850)
add_track('/SD_MISO', in1, 42.000, 0.850, 57.000, 0.850)
add_track('/SD_MISO', in1, 57.000, 0.850, 57.600, 2.700)

# Save test board
test_pcb = 'scratch_test_all4_victory.kicad_pcb'
board.Save(test_pcb)
print(f"Saved {test_pcb}")
