import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

vias = [
    (41.13, 0.55, '/SD_MOSI'),
    (58.65, 0.55, '/SD_MOSI'),
    (41.63, 1.15, '/SD_MISO'),
    (59.15, 1.15, '/SD_MISO'),
    (42.63, 1.75, '/SD_SCK'),
    (58.15, 1.75, '/SD_SCK'),
    (43.13, 0.85, '/SD_CS'),
    (59.65, 0.85, '/SD_CS')
]

for x, y, net in vias:
    ok, r = geom.is_via_legal(x, y, net)
    print(f"Via {net} at ({x}, {y}): {ok} ({r})")
