import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
fcu_id = b.GetLayerID('F.Cu')
bcu_id = b.GetLayerID('B.Cu')
in2_id = b.GetLayerID('In2.Cu')
scl_net = b.FindNet('/I2C_SCL')

def add_via(x, y, net):
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(int(x*1e6), int(y*1e6)))
    v.SetWidth(int(0.500*1e6))
    v.SetDrill(int(0.300*1e6))
    v.SetNet(net)
    b.Add(v)

def add_track(x1, y1, x2, y2, layer_id, net, width=0.20):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(x1*1e6), int(y1*1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2*1e6), int(y2*1e6)))
    t.SetLayer(layer_id)
    t.SetWidth(int(width*1e6))
    t.SetNet(net)
    b.Add(t)

# West:
add_track(4.700, 4.600, 4.700, 7.150, fcu_id, scl_net)
add_via(4.700, 7.150, scl_net)
add_track(4.700, 7.150, 7.500, 7.150, bcu_id, scl_net)
add_via(7.500, 7.150, scl_net)
add_track(7.500, 7.150, 7.500, 7.200, fcu_id, scl_net)
add_track(7.500, 7.200, 6.675, 7.200, fcu_id, scl_net)
add_track(7.500, 7.150, 24.250, 7.150, bcu_id, scl_net)

# East (on In2.Cu to avoid SDA crossing on B.Cu):
add_track(24.250, 7.150, 25.000, 7.150, in2_id, scl_net)
add_track(25.000, 7.150, 25.000, 5.600, in2_id, scl_net)
add_track(25.000, 5.600, 38.000, 5.600, in2_id, scl_net)
add_via(38.000, 5.600, scl_net)
add_track(38.000, 5.600, 38.200, 5.600, fcu_id, scl_net, 0.20)
add_track(38.200, 5.600, 38.600, 4.585, fcu_id, scl_net, 0.20)
# Use 0.15 mm width for the corridor past via /I2C_SDA to U1.5:
add_track(38.600, 4.585, 40.480, 4.585, fcu_id, scl_net, 0.15)

test_pcb = 'output/RevG/variants/FourLayer_Candidate/SmartPen_test_scl.kicad_pcb'
b.Save(test_pcb)
print("Updated SmartPen_test_scl.kicad_pcb")
