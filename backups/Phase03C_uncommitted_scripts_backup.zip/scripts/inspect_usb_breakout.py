import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- Items around X in [43, 46], Y in [7.0, 9.0] ---')
for t in board.GetTracks():
    s, e = t.GetStart(), t.GetEnd()
    sx, sy = s.x/1e6, s.y/1e6
    ex, ey = e.x/1e6, e.y/1e6
    if (43 <= sx <= 46 or 43 <= ex <= 46) and (7.0 <= sy <= 9.0 or 7.0 <= ey <= 9.0):
        print(f'{board.GetLayerName(t.GetLayer())} {t.GetNetname()}: ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})')

