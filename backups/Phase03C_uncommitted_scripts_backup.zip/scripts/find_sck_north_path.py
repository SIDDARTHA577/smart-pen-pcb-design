import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts')))
import astar_miso
import math

# Target: connect U1.12 (42.630, 2.435) to (58.0, 5.5) on In1.Cu
# At U1.12:
# U1.12 is at (42.630, 2.435).
# Where can U1.12 have a via?
# In scratch_test_mosi_flawless, via is at (42.630, 1.150).
# From (42.630, 1.150) on In1.Cu, can we reach (44.2, 5.5)?
# Let's test waypoints on In1.Cu:
print("Testing In1.Cu path for SCK:")
for xm in [43.8, 44.0, 44.2, 44.5]:
    for ym in [1.15, 1.4, 2.0, 2.5, 3.0, 5.5]:
        c1 = astar_miso.track_clear(astar_miso.in1, 42.63, 1.15, xm, ym)
        c2 = astar_miso.track_clear(astar_miso.in1, xm, ym, 44.2, 5.5)
        if c1 and c2:
            print(f"  Found SCK transit via ({xm}, {ym})")

# What if via at U1.12 is to the NORTH?
# Can U1.12 have a via at (42.63, 6.0) or (42.63, 5.5)?
# Let's check via_clear near U1:
for y in [3.0, 5.5, 6.0, 6.5]:
    print(f"  via_clear(42.63, {y}): {astar_miso.via_clear(42.63, y)}")
