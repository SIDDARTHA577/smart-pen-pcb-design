from pathlib import Path
import re

pcb_text = Path("output/RevG/SmartPen.kicad_pcb").read_text(encoding="utf-8")
chunks = pcb_text.split("\t(footprint ")
for c in chunks[1:]:
    ref_m = re.search(r'\(property "Reference" "([^"]+)"', c)
    at_m = re.search(r'\(at\s+([\d\.-]+)\s+([\d\.-]+)', c)
    if ref_m and at_m:
        x, y = float(at_m.group(1)), float(at_m.group(2))
        if 38.0 <= x <= 56.0:
            print(f"{ref_m.group(1):10s} at ({x:6.2f}, {y:5.2f})")

