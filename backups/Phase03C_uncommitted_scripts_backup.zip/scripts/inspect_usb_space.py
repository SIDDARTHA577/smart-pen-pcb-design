import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

# Let's inspect everything around X in [43, 48], Y in [4.0, 8.5] on all layers
print('--- Footprint pads in [43, 48] x [4.0, 8.5] ---')
for fp in board.Footprints():
    for p in fp.Pads():
        pos = p.GetPosition()
        px, py = pos.x/1e6, pos.y/1e6
        if 43 <= px <= 48 and 4.0 <= py <= 8.5:
            print(f'Pad {fp.GetReference()}.{p.GetNumber()} [{p.GetNetname()}] at ({px:.3f}, {py:.3f}), size ({p.GetSize().x/1e6:.3f}, {p.GetSize().y/1e6:.3f})')

