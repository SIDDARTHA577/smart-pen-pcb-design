import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
for t in b.Tracks():
    if isinstance(t, pcbnew.PCB_VIA):
        p = t.GetPosition()
        if abs(p.x/1e6 - 55.0) < 0.1 and abs(p.y/1e6 - 1.2) < 0.1:
            print(f"Via at ({p.x/1e6:.3f}, {p.y/1e6:.3f}) - Net: {t.GetNetname()}")
            # check connected tracks
            conns = [tr for tr in b.Tracks() if not isinstance(tr, pcbnew.PCB_VIA) and (tr.GetStart() == p or tr.GetEnd() == p)]
            print(f"  Connected tracks: {len(conns)}")
