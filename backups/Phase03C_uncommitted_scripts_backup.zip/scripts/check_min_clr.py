import pcbnew
b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
ds = b.GetDesignSettings()
print("Min clearance:", ds.GetSmallestClearanceValue()/1e6)
print("Track width:", ds.GetCurrentTrackWidth()/1e6)
