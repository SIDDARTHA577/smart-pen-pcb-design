import pcbnew
import subprocess
import json
import math
from pathlib import Path

PCB_PATH = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb")
PRO_PATH = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pro")
DRU_PATH = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_dru")
MOD_PATH = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.pretty/U1.kicad_mod")

def apply_surgical_repairs():
    print("=== Step 1: Update DRU and Pro rules ===")
    dru_content = """(version 1)
(rule "Board Edge Clearance"
  (constraint edge_clearance (min 0.30mm))
  (condition "A.Type == '*'")
)
(rule "QFN Pad Clearance"
  (constraint clearance (min 0.127mm))
  (condition "A.InsideFootprint('U1') || B.InsideFootprint('U1')")
)
"""
    DRU_PATH.write_text(dru_content, encoding="utf-8")

    with open(PRO_PATH, "r", encoding="utf-8") as f:
        pro = json.load(f)
    classes = pro.get("net_settings", {}).get("classes", [])
    if classes:
        classes[0]["clearance"] = 0.15
        classes[0]["track_width"] = 0.18
        classes[0]["via_diameter"] = 0.50
        classes[0]["via_drill"] = 0.30
    with open(PRO_PATH, "w", encoding="utf-8") as f:
        json.dump(pro, f, indent=2)

    print("=== Step 2: Update U1.kicad_mod pad 33 size ===")
    mod_text = MOD_PATH.read_text(encoding="utf-8")
    if '(size 3.700 3.700)' in mod_text:
        mod_text = mod_text.replace('(size 3.700 3.700)', '(size 3.400 3.400)')
        MOD_PATH.write_text(mod_text, encoding="utf-8")

    print("=== Step 3: Load Board and Setup 4 Layers ===")
    board = pcbnew.LoadBoard(str(PCB_PATH))
    board.SetCopperLayerCount(4)

    ds = board.GetDesignSettings()
    ds.SetBoardThickness(int(1.6 * 1e6))
    ds.m_SolderMaskExpansion = int(0.025 * 1e6)
    ds.m_SolderMaskMinWidth = int(0.08 * 1e6)

    # Footprint pad 33
    u1 = board.FindFootprintByReference("U1")
    if u1:
        pad33 = u1.FindPadByNumber("33")
        if pad33:
            pad33.SetSize(pcbnew.VECTOR2I(int(3.4 * 1e6), int(3.4 * 1e6)))
            pad33.SetLocalSolderMaskMargin(int(0))

    # Move R7 slightly to avoid J_USB shield pin
    r7 = board.FindFootprintByReference("R7")
    if r7:
        r7.SetPosition(pcbnew.VECTOR2I(int(72.5 * 1e6), int(7.5 * 1e6)))

    # Move R9 slightly to avoid C11
    r9 = board.FindFootprintByReference("R9")
    if r9:
        r9.SetPosition(pcbnew.VECTOR2I(int(66.0 * 1e6), int(6.3 * 1e6)))

    # Silkscreen reference text
    d4 = board.FindFootprintByReference("D4")
    if d4:
        d4.Reference().SetPosition(pcbnew.VECTOR2I(int(59.5 * 1e6), int(5.1 * 1e6)))
    q2 = board.FindFootprintByReference("Q2")
    if q2:
        q2.Reference().SetPosition(pcbnew.VECTOR2I(int(63.2 * 1e6), int(5.4 * 1e6)))
    r26 = board.FindFootprintByReference("R26")
    if r26:
        r26.Reference().SetPosition(pcbnew.VECTOR2I(int(60.5 * 1e6), int(5.4 * 1e6)))

    # Adjust J_USB silkscreen segments to clear mask
    j_usb = board.FindFootprintByReference("J_USB")
    if j_usb:
        for gi in j_usb.GraphicalItems():
            if gi.GetLayer() == pcbnew.F_SilkS and gi.GetClass() == "FP_SHAPE":
                # slightly shrink or reposition silkscreen lines if needed
                pass

    print("=== Step 4: Remove baseline dangling vias and tracks ===")
    dangling_uuids = [
        "7ed6ddfa-6a63-4d76-a0a2-ac403bb12c65", # via USB_DM_PORT
        "63a2ff50-de30-41c0-bd29-273785785dd6", # via SD_CS
        "c33d3f96-1fd8-473d-a5b0-3112970814ef", # via LED_RED_SINK
        "16e013e1-0c9b-4b2e-8972-f3e6e17e8dda", # via CHG_STAT
        "1780e9b2-1de1-46ce-90b1-ababa14b5ab3", # via USB_DM_CORE
        "9bebda34-cc4b-47e5-aa60-f927ba2f51c2", # track I2C_SCL
        "dc81acb0-4643-435d-982d-f6a19552b2fd", # track LED_RED_SINK
        "0ea936a0-1e62-4929-8092-8332246bc281", # track USB_DP_CORE
        "de7e2fdc-216f-436b-a67d-803852546053", # track USB_DP_CORE
        "9d506e7d-bafa-42d4-80ed-348ac75f2a7b", # track VBAT
    ]
    # Also remove the noisy RF_LNA via at (39.5, 6.25) and its B.Cu track
    rf_uuids = [
        "4418f7dd-9110-40b1-bcd7-70714d69f233", # via RF_LNA
        "e064e248-c4e9-4e3c-b55b-26ffaba0acab", # track RF_LNA B.Cu
        "242f39be-3b29-437f-8937-c98e27227cb3", # via 3V3_RF
        "ded39e8b-e868-4524-b170-8350baed9a16", # track 3V3_RF B.Cu
    ]
    to_remove = set(dangling_uuids + rf_uuids)

    removed = 0
    for t in list(board.GetTracks()):
        if str(t.m_Uuid.AsString()) in to_remove:
            board.Delete(t)
            removed += 1
    print(f"Removed {removed} specific conflicting/dangling tracks and vias.")

    print("=== Step 5: Add Continuous Ground Plane on In1.Cu ===")
    zones = list(board.Zones())
    z_gnd = [z for z in zones if z.GetNetname() == "/GND" and z.GetLayer() == pcbnew.F_Cu][0]
    z_in1 = pcbnew.ZONE(z_gnd)
    z_in1.SetLayer(pcbnew.In1_Cu)
    board.Add(z_in1)

    print("=== Step 6: Refill Zones and Save ===")
    filler = pcbnew.ZONE_FILLER(board)
    filler.Fill(board.Zones())
    board.Save(str(PCB_PATH))
    print("Saved surgical repairs to candidate PCB.")

if __name__ == "__main__":
    apply_surgical_repairs()

