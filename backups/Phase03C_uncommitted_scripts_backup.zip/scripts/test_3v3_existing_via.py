import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# From via (60.146, 7.807) to existing via (68.714, 6.563):
# Jog: (60.146, 7.807) -> (68.714, 7.807) -> (68.714, 6.563) on B.Cu
s1, r1 = geom.is_segment_legal(60.146, 7.807, 68.714, 7.807, 'B.Cu', '/3V3')
s2, r2 = geom.is_segment_legal(68.714, 7.807, 68.714, 6.563, 'B.Cu', '/3V3')
print(f"s1 (60.15->68.71 @ 7.81): {s1} ({r1})")
print(f"s2 (68.71, 7.81->6.56): {s2} ({r2})")
