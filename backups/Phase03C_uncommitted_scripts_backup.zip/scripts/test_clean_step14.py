import os, sys, math, json
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try: import wx; wx.DisableAsserts()
except: pass
import pcbnew, shutil

src_pcb = 'scratch_test_clean_step9.kicad_pcb'
dst_pcb = 'scratch_test_clean_step14.kicad_pcb'
shutil.copy(src_pcb, dst_pcb)
shutil.copy(src_pcb.replace('.kicad_pcb', '.kicad_pro'), dst_pcb.replace('.kicad_pcb', '.kicad_pro'))

b = pcbnew.LoadBoard(dst_pcb)
fcu = b.GetLayerID('F.Cu')
net_3v3 = b.FindNet('/3V3')

def add_trk(netname, layer_id, x1, y1, x2, y2, w=0.15):
    net = b.FindNet(netname)
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(round(x1 * 1e6)), int(round(y1 * 1e6))))
    t.SetEnd(pcbnew.VECTOR2I(int(round(x2 * 1e6)), int(round(y2 * 1e6))))
    t.SetWidth(int(round(w * 1e6)))
    t.SetLayer(layer_id)
    t.SetNet(net)
    b.Add(t)
    return t

# Connect 3V3 from (56.230, 2.564) to J_SD.1 at (57.150, 4.200) on F.Cu
add_trk('/3V3', fcu, 56.230, 2.564, 56.230, 4.200, 0.15)
add_trk('/3V3', fcu, 56.230, 4.200, 57.150, 4.200, 0.15)

filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
b.Save(dst_pcb)
print("Saved clean step 14.")