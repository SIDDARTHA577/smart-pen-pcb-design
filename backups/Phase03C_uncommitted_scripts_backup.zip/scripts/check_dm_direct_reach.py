import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Testing direct via west of R7.2 (72.500, 7.025):")
for xi in range(714, 723, 1):
    x = xi / 10.0
    for yi in range(65, 75, 1):
        y = yi / 10.0
        v_ok, rv = geom.is_via_legal(x, y, '/USB_DM_CORE')
        if v_ok:
            s_fcu, rf = geom.is_segment_legal(x, y, 72.500, 7.025, 'F.Cu', '/USB_DM_CORE')
            print(f"Via at ({x:.2f}, {y:.2f}): legal! F.Cu to R7.2: {s_fcu} ({rf})")
