import pcbnew

b = pcbnew.LoadBoard('scratch_test_mosi_flawless.kicad_pcb')

# We want to find legal positions for a 0.50mm via (drill 0.30mm, width 0.50mm)
# that doesn't violate clearance (>= 0.127mm) to any pad or via of DIFFERENT net,
# and doesn't violate edge clearance (>= 0.25mm) to board edge.

# Let's collect all pads and vias (excluding SD_MOSI via if we allow moving it)
pads = []
for f in b.GetFootprints():
    for p in f.Pads():
        pos = p.GetPosition()
        pads.append({
            'ref': f'{f.GetReference()}.{p.GetNumber()}',
            'net': p.GetNetname(),
            'pos': pos,
            'x': pcbnew.ToMM(pos.x),
            'y': pcbnew.ToMM(pos.y),
            'sx': pcbnew.ToMM(p.GetSizeX()),
            'sy': pcbnew.ToMM(p.GetSizeY()),
            'layer': p.GetLayerSet()
        })

vias = []
for t in b.GetTracks():
    if isinstance(t, pcbnew.PCB_VIA):
        pos = t.GetPosition()
        vias.append({
            'net': t.GetNetname(),
            'pos': pos,
            'x': pcbnew.ToMM(pos.x),
            'y': pcbnew.ToMM(pos.y),
            'drill': pcbnew.ToMM(t.GetDrill()),
            'width': pcbnew.ToMM(t.GetWidth(pcbnew.F_Cu))
        })

print(f"Total pads: {len(pads)}, Total vias: {len(vias)}")

def check_via_legal(x, y, netname, ignore_vias=[]):
    # board edge: Y in [0.0, 9.2], X in [0.0, 84.0]
    if y - 0.25 < 0.25 or y + 0.25 > 8.95:
        return False, "edge"
    # check pads
    for p in pads:
        if p['net'] == netname:
            continue
        # distance from (x,y) to pad rectangle
        dx = max(0.0, abs(x - p['x']) - p['sx'] / 2.0)
        dy = max(0.0, abs(y - p['y']) - p['sy'] / 2.0)
        dist = (dx**2 + dy**2)**0.5
        if dist - 0.25 < 0.127:
            return False, f"pad {p['ref']} [{p['net']}]"
    # check vias
    for v in vias:
        if (v['x'], v['y']) in ignore_vias:
            continue
        if v['net'] == netname:
            continue
        dist = ((x - v['x'])**2 + (y - v['y'])**2)**0.5
        if dist - (0.25 + v['width'] / 2.0) < 0.127:
            return False, f"via [{v['net']}] at ({v['x']:.2f},{v['y']:.2f})"
    return True, "ok"

legal_points = []
for xi in range(560, 615, 1): # 56.0 to 61.5, step 0.1mm
    x = xi / 10.0
    for yi in range(8, 75, 1): # 0.8 to 7.5, step 0.1mm
        y = yi / 10.0
        ok, reason = check_via_legal(x, y, '/SD_MISO')
        if ok:
            legal_points.append((x, y))

print(f"Total legal via locations found for /SD_MISO: {len(legal_points)}")
for x, y in legal_points:
    print(f"  ({x:.2f}, {y:.2f})")
