import pcbnew
from pathlib import Path

candidate_pcb = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb")
board = pcbnew.LoadBoard(str(candidate_pcb))

print("=== Existing Tracks in Candidate PCB ===")
tracks_by_net = {}
for t in board.GetTracks():
    net = t.GetNetname()
    if net not in tracks_by_net:
        tracks_by_net[net] = []
    tracks_by_net[net].append(t)

for net, trks in sorted(tracks_by_net.items()):
    via_count = sum(1 for t in trks if "VIA" in t.GetClass())
    trk_count = len(trks) - via_count
    print(f"Net '{net}': {trk_count} tracks, {via_count} vias")

