try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

def route_group1():
    board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
    
    # First, remove any existing HAPTIC and CHG_STAT items added in previous run
    to_rem = [t for t in board.GetTracks() if t.GetNetname() in ['/HAPTIC_GATE_DRIVE', '/CHG_STAT']]
    for t in to_rem:
        board.Remove(t)
    
    # Helper to add track
    def add_track(netname, layer_name, x1, y1, x2, y2, width=0.18):
        net = board.FindNet(netname)
        t = pcbnew.PCB_TRACK(board)
        t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
        t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
        t.SetWidth(int(width * 1e6))
        t.SetLayer(board.GetLayerID(layer_name))
        t.SetNet(net)
        board.Add(t)
        return t

    # Helper to add via
    def add_via(netname, x, y, dia=0.50, drill=0.30):
        net = board.FindNet(netname)
        v = pcbnew.PCB_VIA(board)
        v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
        v.SetWidth(int(dia * 1e6))
        v.SetDrill(int(drill * 1e6))
        v.SetNet(net)
        v.SetViaType(pcbnew.VIATYPE_THROUGH)
        board.Add(v)
        return v

    print('Applying collision-free HAPTIC and CHG_STAT routes...')

    # 1. /HAPTIC_GATE_DRIVE on In2.Cu
    add_track('/HAPTIC_GATE_DRIVE', 'F.Cu', 23.750, 2.750, 23.750, 1.800)
    add_via('/HAPTIC_GATE_DRIVE', 23.750, 1.800)
    add_track('/HAPTIC_GATE_DRIVE', 'In2.Cu', 23.750, 1.800, 26.525, 1.800)
    add_via('/HAPTIC_GATE_DRIVE', 26.525, 1.800)
    add_track('/HAPTIC_GATE_DRIVE', 'F.Cu', 26.525, 1.800, 26.525, 2.200)

    # 5. /CHG_STAT (routed on B.Cu at Y=1.000 jog to Y=1.800)
    add_track('/CHG_STAT', 'F.Cu', 24.250, 2.750, 24.250, 1.000)
    add_via('/CHG_STAT', 24.250, 1.000)
    add_track('/CHG_STAT', 'B.Cu', 24.250, 1.000, 44.000, 1.000)
    add_track('/CHG_STAT', 'B.Cu', 44.000, 1.000, 44.000, 1.800)
    add_track('/CHG_STAT', 'B.Cu', 44.000, 1.800, 66.050, 1.800)
    add_via('/CHG_STAT', 66.050, 1.800)
    add_track('/CHG_STAT', 'F.Cu', 66.050, 1.800, 66.050, 2.770)

    # Refill all zones
    filler = pcbnew.ZONE_FILLER(board)
    filler.Fill(board.Zones())

    board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
    print('HAPTIC and CHG_STAT successfully updated!')

if __name__ == '__main__':
    route_group1()
