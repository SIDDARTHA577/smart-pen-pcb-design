from pathlib import Path
import re

sch_text = Path("output/RevG/SmartPen.kicad_sch").read_text(encoding="utf-8")
for i, line in enumerate(sch_text.splitlines()):
    if "J_RF" in line or "RF_LNA" in line:
        print(f"Line {i+1}: {line}")
        for j in range(max(0, i-5), min(len(sch_text.splitlines()), i+15)):
            print("  ", sch_text.splitlines()[j])
        break

