import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

def trk(board, netname, layer_name, x1, y1, x2, y2, w=0.18):
    net = board.FindNet(netname)
    layer = board.GetLayerID(layer_name)
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    t.SetWidth(int(w * 1e6))
    t.SetLayer(layer)
    t.SetNet(net)
    board.Add(t)
    return t

def via(board, netname, x, y, drill=0.30, dia=0.50):
    net = board.FindNet(netname)
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    v.SetWidth(int(dia * 1e6))
    v.SetDrill(int(drill * 1e6))
    v.SetNet(net)
    board.Add(v)
    return v

# 1. Connect U1.15 to SW2.1 on F.Cu:
# U1.15 (44.130, 2.435) -> (44.130, 1.500) -> SW2.1 (45.704, 1.500)
trk(board, '/BOOT9', 'F.Cu', 44.130, 2.435, 44.130, 1.500)
trk(board, '/BOOT9', 'F.Cu', 44.130, 1.500, 45.704, 1.500)

# 2. Connect SW2.1 to R2.2 via B.Cu:
# Via at (45.704, 0.650)
via(board, '/BOOT9', 45.704, 0.650)
trk(board, '/BOOT9', 'F.Cu', 45.704, 1.500, 45.704, 0.650)

# Via at (52.225, 0.650)
via(board, '/BOOT9', 52.225, 0.650)
trk(board, '/BOOT9', 'B.Cu', 45.704, 0.650, 52.225, 0.650)
trk(board, '/BOOT9', 'F.Cu', 52.225, 0.650, 52.225, 2.250)

board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('BOOT9 routed cleanly')

