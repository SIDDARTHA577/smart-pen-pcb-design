import os, sys, math
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try: import wx; wx.DisableAsserts()
except: pass
import pcbnew

b = pcbnew.LoadBoard('scratch_test_restore_vsys.kicad_pcb')

# 4 Escapes:
# MOSI: (41.130, 2.435) -> (41.130, 1.450), via at (41.130, 1.450)
# MISO: (41.630, 2.435) -> (41.630, 0.500), via at (41.630, 0.500)
# SCK:  (42.630, 2.435) -> (42.630, 0.500), via at (42.630, 0.500)
# CS:   (43.130, 2.435) -> (43.130, 1.450), via at (43.130, 1.450)
# GPIO8_STRAP: (43.630, 2.435) -> (43.630, 0.800) -> (43.525, 0.800)

vias = [
    ('/SD_MOSI', 41.130, 1.450),
    ('/SD_MISO', 41.630, 0.500),
    ('/3V3_RTC', 42.130, 1.800), # existing
    ('/SD_SCK',  42.630, 0.500),
    ('/SD_CS',   43.130, 1.450),
]

print("--- Via-to-Via distances in U1 south cluster ---")
for i in range(len(vias)):
    for j in range(i+1, len(vias)):
        n1, x1, y1 = vias[i]
        n2, x2, y2 = vias[j]
        d = math.hypot(x1 - x2, y1 - y2)
        clr = d - 0.50
        print(f"{n1} vs {n2}: dist={d:.3f} mm (clr={clr:.3f} mm)")

print("\n--- Via-to-Track clearances in U1 south cluster ---")
tracks = [
    ('/SD_MOSI', 41.130, 2.435, 41.130, 1.450),
    ('/SD_MISO', 41.630, 2.435, 41.630, 0.500),
    ('/SD_SCK',  42.630, 2.435, 42.630, 0.500),
    ('/SD_CS',   43.130, 2.435, 43.130, 1.450),
    ('/GPIO8_STRAP', 43.630, 2.435, 43.630, 0.800),
]

for vn, vx, vy in vias:
    for tn, sx, sy, ex, ey in tracks:
        if vn == tn: continue
        dx, dy = ex - sx, ey - sy
        L2 = dx*dx + dy*dy
        u = max(0.0, min(1.0, ((vx - sx)*dx + (vy - sy)*dy) / L2))
        nx, ny = sx + u*dx, sy + u*dy
        d = math.hypot(vx - nx, vy - ny)
        clr = d - 0.25 - 0.075
        if clr < 0.30:
            print(f"Via {vn} at ({vx:.3f},{vy:.3f}) vs Track {tn} ({sx:.3f},{sy:.3f})->({ex:.3f},{ey:.3f}): dist={d:.3f} clr={clr:.3f} mm")
