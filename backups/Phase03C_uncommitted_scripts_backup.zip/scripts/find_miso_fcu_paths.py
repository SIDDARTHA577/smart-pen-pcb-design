import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts')))
import astar_miso
import math

# We want to find a point (vx, vy) such that:
# 1. via_clear(vx, vy) == True
# 2. A track on F.Cu can reach (vx, vy) from (59.15, 4.2) without collisions
# Let's test a dense grid of points (vx, vy) in X in [56.0, 61.0], Y in [0.5, 6.5]

print("Searching for (vx, vy) with legal via and F.Cu path from Pad 5:")
found = []

def test_fcu_path(vx, vy):
    # Try direct segment
    if astar_miso.track_clear(astar_miso.fcu, 59.15, 4.2, vx, vy):
        return [(59.15, 4.2), (vx, vy)]
    # Try 1-jog (ortho)
    # Jog 1: down to vy, then to vx
    if astar_miso.track_clear(astar_miso.fcu, 59.15, 4.2, 59.15, vy) and \
       astar_miso.track_clear(astar_miso.fcu, 59.15, vy, vx, vy):
        return [(59.15, 4.2), (59.15, vy), (vx, vy)]
    # Jog 2: down to y_mid, across to vx, then to vy
    for ym in [3.2, 3.25, 3.3, 3.35, 3.4, 3.1]:
        if astar_miso.track_clear(astar_miso.fcu, 59.15, 4.2, 59.15, ym) and \
           astar_miso.track_clear(astar_miso.fcu, 59.15, ym, vx, ym) and \
           astar_miso.track_clear(astar_miso.fcu, vx, ym, vx, vy):
            return [(59.15, 4.2), (59.15, ym), (vx, ym), (vx, vy)]
    return None

for xi in range(560, 615, 1): # 56.0 to 61.5, step 0.1
    x = xi / 10.0
    for yi in range(8, 65, 1): # 0.8 to 6.5, step 0.1
        y = yi / 10.0
        if astar_miso.via_clear(x, y):
            path = test_fcu_path(x, y)
            if path:
                found.append((x, y, path))
                print(f"Found candidate: via at ({x:.2f}, {y:.2f}) with path: {path}")

print(f"Total candidates found: {len(found)}")
