import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevF_Working/SmartPen.kicad_pcb')
for t in b.Tracks():
    if 'VBUS' in t.GetNetname():
        if isinstance(t, pcbnew.PCB_VIA):
            p = t.GetPosition()
            print(f"RevF Via: {t.GetNetname()} at ({p.x/1e6:.3f}, {p.y/1e6:.3f})")
        else:
            p1, p2 = t.GetStart(), t.GetEnd()
            print(f"RevF Track: {t.GetNetname()} [{b.GetLayerName(t.GetLayer())}] ({p1.x/1e6:.3f}, {p1.y/1e6:.3f}) -> ({p2.x/1e6:.3f}, {p2.y/1e6:.3f})")
