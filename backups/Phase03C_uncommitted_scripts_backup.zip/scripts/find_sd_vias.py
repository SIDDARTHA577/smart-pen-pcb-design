import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

for net in ['/SD_MOSI', '/SD_MISO', '/SD_SCK', '/SD_CS']:
    print(f"\nScanning legal vias for {net}:")
    found = []
    for xi in range(400, 450, 1):
        x = xi / 10.0
        for yi in range(2, 28, 1):
            y = yi / 10.0
            v_ok, r = geom.is_via_legal(x, y, net)
            if v_ok:
                found.append((x, y))
    print(f"  Total legal vias: {len(found)}")
    if found:
        print(f"  Samples: {found[:10]}")

sys.exit(0)
