import json
from collections import defaultdict
from pathlib import Path

drc_path = Path("reports/RevG/Phase03C/raw/baseline/Main_SmartPen_drc.json")
with open(drc_path, "r", encoding="utf-8") as f:
    drc = json.load(f)

violations = drc.get("violations", [])
unconnected = drc.get("unconnected_items", [])

print(f"Total Violations: {len(violations)}")
print(f"Total Unconnected Items: {len(unconnected)}")

by_type = defaultdict(list)
for i, v in enumerate(violations):
    by_type[v.get("type")].append((i, v))

for vtype, items in sorted(by_type.items()):
    print(f"\n=== {vtype} ({len(items)} items) ===")
    for idx, it in items:
        desc = it.get("description")
        sub_items = it.get("items", [])
        sub_desc = " <--> ".join(f"{s.get('description')} @ ({s.get('pos',{}).get('x')}, {s.get('pos',{}).get('y')})" for s in sub_items)
        print(f"  [{idx:3d}] {desc} | {sub_desc}")

