import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

# 1. Reconnect SW1.1 to MCU_EN via at (31.560, 3.590) on F.Cu
t_mcu_sw = pcbnew.PCB_TRACK(board)
t_mcu_sw.SetStart(pcbnew.VECTOR2I(int(31.556*1e6), int(1.500*1e6)))
t_mcu_sw.SetEnd(pcbnew.VECTOR2I(int(31.560*1e6), int(3.590*1e6)))
t_mcu_sw.SetWidth(int(0.18*1e6))
t_mcu_sw.SetLayer(pcbnew.F_Cu)
t_mcu_sw.SetNet(board.FindNet('/MCU_EN'))
board.Add(t_mcu_sw)
print('Added SW1.1 to MCU_EN via track')

# 2. Remove redundant USB_DP_PORT tracks and vias at Y=8.650
dp_to_remove = []
for t in board.GetTracks():
    if t.GetNetname() == '/USB_DP_PORT':
        if isinstance(t, pcbnew.PCB_VIA):
            pos = t.GetPosition()
            px, py = round(pos.x/1e6, 2), round(pos.y/1e6, 2)
            if py == 8.65 and px in [71.60, 78.15]:
                dp_to_remove.append(t)
        else:
            s, e = t.GetStart(), t.GetEnd()
            sy, ey = round(s.y/1e6, 2), round(e.y/1e6, 2)
            if sy == 8.65 or ey == 8.65:
                dp_to_remove.append(t)

for t in dp_to_remove:
    board.Remove(t)
print(f'Removed {len(dp_to_remove)} redundant USB_DP_PORT items at Y=8.65')

# 3. Remove old colliding USB_DP_CORE and USB_DM_CORE F.Cu tracks
usb_core_to_remove = []
for t in board.GetTracks():
    if t.GetNetname() in ['/USB_DP_CORE', '/USB_DM_CORE']:
        if not isinstance(t, pcbnew.PCB_VIA):
            if t.GetLayer() == pcbnew.F_Cu:
                usb_core_to_remove.append(t)

for t in usb_core_to_remove:
    board.Remove(t)
print(f'Removed {len(usb_core_to_remove)} old USB core F.Cu tracks')

# 4. Fix RF_LNA:
# Connect Via at (39.500, 6.250) to U1.1 (40.480, 6.585)
# Via at (39.500, 6.250) to Via at (51.500, 6.250) on B.Cu
# Via at (51.500, 6.250) to L2.1 (51.920, 5.300)
# First remove any existing tracks/vias on RF_LNA to start clean
rf_to_remove = []
for t in board.GetTracks():
    if t.GetNetname() == '/RF_LNA':
        rf_to_remove.append(t)
for t in rf_to_remove:
    board.Remove(t)

net_rf = board.FindNet('/RF_LNA')
# Via 1 at (39.500, 6.250)
v_rf1 = pcbnew.PCB_VIA(board)
v_rf1.SetPosition(pcbnew.VECTOR2I(int(39.500*1e6), int(6.250*1e6)))
v_rf1.SetWidth(int(0.50*1e6))
v_rf1.SetDrill(int(0.30*1e6))
v_rf1.SetNet(net_rf)
board.Add(v_rf1)

# F.Cu track: U1.1 (40.480, 6.585) -> (39.500, 6.585) -> (39.500, 6.250)
t_rf1 = pcbnew.PCB_TRACK(board)
t_rf1.SetStart(pcbnew.VECTOR2I(int(40.480*1e6), int(6.585*1e6)))
t_rf1.SetEnd(pcbnew.VECTOR2I(int(39.500*1e6), int(6.585*1e6)))
t_rf1.SetWidth(int(0.35*1e6))
t_rf1.SetLayer(pcbnew.F_Cu)
t_rf1.SetNet(net_rf)
board.Add(t_rf1)

t_rf2 = pcbnew.PCB_TRACK(board)
t_rf2.SetStart(pcbnew.VECTOR2I(int(39.500*1e6), int(6.585*1e6)))
t_rf2.SetEnd(pcbnew.VECTOR2I(int(39.500*1e6), int(6.250*1e6)))
t_rf2.SetWidth(int(0.35*1e6))
t_rf2.SetLayer(pcbnew.F_Cu)
t_rf2.SetNet(net_rf)
board.Add(t_rf2)

# Via 2 at (51.500, 6.250)
v_rf2 = pcbnew.PCB_VIA(board)
v_rf2.SetPosition(pcbnew.VECTOR2I(int(51.500*1e6), int(6.250*1e6)))
v_rf2.SetWidth(int(0.50*1e6))
v_rf2.SetDrill(int(0.30*1e6))
v_rf2.SetNet(net_rf)
board.Add(v_rf2)

# B.Cu track: (39.500, 6.250) -> (51.500, 6.250)
t_rf_b = pcbnew.PCB_TRACK(board)
t_rf_b.SetStart(pcbnew.VECTOR2I(int(39.500*1e6), int(6.250*1e6)))
t_rf_b.SetEnd(pcbnew.VECTOR2I(int(51.500*1e6), int(6.250*1e6)))
t_rf_b.SetWidth(int(0.35*1e6))
t_rf_b.SetLayer(pcbnew.B_Cu)
t_rf_b.SetNet(net_rf)
board.Add(t_rf_b)

# F.Cu track from via 2 (51.500, 6.250) to (51.500, 5.300) -> L2.1 (51.920, 5.300)
t_rf3 = pcbnew.PCB_TRACK(board)
t_rf3.SetStart(pcbnew.VECTOR2I(int(51.500*1e6), int(6.250*1e6)))
t_rf3.SetEnd(pcbnew.VECTOR2I(int(51.500*1e6), int(5.300*1e6)))
t_rf3.SetWidth(int(0.35*1e6))
t_rf3.SetLayer(pcbnew.F_Cu)
t_rf3.SetNet(net_rf)
board.Add(t_rf3)

t_rf4 = pcbnew.PCB_TRACK(board)
t_rf4.SetStart(pcbnew.VECTOR2I(int(51.500*1e6), int(5.300*1e6)))
t_rf4.SetEnd(pcbnew.VECTOR2I(int(51.920*1e6), int(5.300*1e6)))
t_rf4.SetWidth(int(0.35*1e6))
t_rf4.SetLayer(pcbnew.F_Cu)
t_rf4.SetNet(net_rf)
board.Add(t_rf4)

# And connect to C8.1 at (52.220, 3.600)
t_rf5 = pcbnew.PCB_TRACK(board)
t_rf5.SetStart(pcbnew.VECTOR2I(int(51.500*1e6), int(5.300*1e6)))
t_rf5.SetEnd(pcbnew.VECTOR2I(int(51.500*1e6), int(3.600*1e6)))
t_rf5.SetWidth(int(0.35*1e6))
t_rf5.SetLayer(pcbnew.F_Cu)
t_rf5.SetNet(net_rf)
board.Add(t_rf5)

t_rf6 = pcbnew.PCB_TRACK(board)
t_rf6.SetStart(pcbnew.VECTOR2I(int(51.500*1e6), int(3.600*1e6)))
t_rf6.SetEnd(pcbnew.VECTOR2I(int(52.220*1e6), int(3.600*1e6)))
t_rf6.SetWidth(int(0.35*1e6))
t_rf6.SetLayer(pcbnew.F_Cu)
t_rf6.SetNet(net_rf)
board.Add(t_rf6)
print('Rebuilt clean RF_LNA path')

board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('Saved board after Stage 1 cleanup')

