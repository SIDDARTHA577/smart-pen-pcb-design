import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Scanning Y corridors for VBAT_SW from 28.09 to 44.0 on B.Cu:")
for yi in range(30, 65, 2):
    y = yi / 10.0
    leg, r = geom.is_segment_legal(28.09, y, 44.0, y, 'B.Cu', '/VBAT_SW')
    print(f"  Y={y:.1f}: {leg} ({r})")

sys.exit(0)
