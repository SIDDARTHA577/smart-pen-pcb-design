import json
from pathlib import Path

drc_path = Path("reports/RevG/Phase03C/raw/baseline/Main_SmartPen_drc.json")
with open(drc_path, "r", encoding="utf-8") as f:
    drc = json.load(f)

bridges = [v for v in drc["violations"] if v.get("type") == "solder_mask_bridge"]
print(f"Total solder mask bridges: {len(bridges)}")
for i, b in enumerate(bridges):
    desc = b.get("description")
    items = [it.get("description") for it in b.get("items", [])]
    print(f"[{i+1}] {desc} -> {items}")

