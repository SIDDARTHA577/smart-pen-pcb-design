import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

sd_nets = {
    'MOSI': ('/SD_MOSI', 41.130),
    'MISO': ('/SD_MISO', 41.630),
    'SCK':  ('/SD_SCK',  42.630),
    'CS':   ('/SD_CS',   43.130)
}

print("Testing via positions north of U1 (X: 38..44, Y: 0.5..1.8):")
for name, (net, px) in sd_nets.items():
    print(f"\nNet {name} (origin pad at {px:.3f}, 2.435):")
    for x in [px - 1.0, px - 0.5, px, px + 0.5, px + 1.0, 39.5, 40.0, 40.5]:
        for y in [0.8, 1.0, 1.2, 1.4, 1.6]:
            v_ok, r = geom.is_via_legal(x, y, net)
            if v_ok:
                print(f"  Legal via at ({x:.2f}, {y:.2f})")

sys.exit(0)
