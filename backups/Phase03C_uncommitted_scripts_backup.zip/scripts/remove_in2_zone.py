import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
in2_id = board.GetLayerID('In2.Cu')

to_del = [z for z in board.Zones() if z.GetLayer() == in2_id]
print('Found In2 zones to delete:', len(to_del))
for z in to_del:
    board.Remove(z)

filler = pcbnew.ZONE_FILLER(board)
filler.Fill(board.Zones())
board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('Removed and saved')

