import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

# Remove existing BOOT9 tracks
to_del = []
for t in board.GetTracks():
    if t.GetNetname() == '/BOOT9':
        to_del.append(t)
for t in to_del:
    board.Remove(t)

def trk(board, netname, layer_name, x1, y1, x2, y2, w=0.18):
    net = board.FindNet(netname)
    layer = board.GetLayerID(layer_name)
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    t.SetWidth(int(w * 1e6))
    t.SetLayer(layer)
    t.SetNet(net)
    board.Add(t)
    return t

def via(board, netname, x, y, drill=0.30, dia=0.50):
    net = board.FindNet(netname)
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    v.SetWidth(int(dia * 1e6))
    v.SetDrill(int(drill * 1e6))
    v.SetNet(net)
    board.Add(v)
    return v

# Clean BOOT9:
# U1.15 is at (44.130, 2.435)
# Go straight down to Y=1.500 at X=44.130
# Pad 16 is at (44.630, 2.435). Edge of pad 16 is at X=44.630 - 0.125 = 44.505.
# At X=44.130, distance to pad 16 edge is 44.505 - 44.130 - 0.09 = 0.285 mm (> 0.15 mm).
# Once below pad 16 (at Y=1.500, bottom of pad 16 is at 2.435 - 0.375 = 2.060),
# clearance to pad 16 is 2.060 - 1.500 = 0.560 mm!
# Then go right to SW2.1 (45.704, 1.500)
trk(board, '/BOOT9', 'F.Cu', 44.130, 2.435, 44.130, 1.500)
trk(board, '/BOOT9', 'F.Cu', 44.130, 1.500, 45.704, 1.500)

# Connect SW2.1 (45.704, 1.500) to R2.2 (52.225, 2.250) via B.Cu:
# Via at (46.500, 0.650)
via(board, '/BOOT9', 46.500, 0.650)
trk(board, '/BOOT9', 'F.Cu', 45.704, 1.500, 46.500, 0.650)

# Via at (52.225, 0.650)
via(board, '/BOOT9', 52.225, 0.650)
trk(board, '/BOOT9', 'B.Cu', 46.500, 0.650, 52.225, 0.650)
trk(board, '/BOOT9', 'F.Cu', 52.225, 0.650, 52.225, 2.250)
print('Re-routed clean BOOT9 straight down')

board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
