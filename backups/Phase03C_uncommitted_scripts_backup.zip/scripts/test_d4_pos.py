import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
d4 = b.FindFootprintByReference('D4')

for dy in [3.0, 3.2, 3.4, 3.5]:
    d4.SetPosition(pcbnew.VECTOR2I(int(59.0*1e6), int(dy*1e6)))
    geom = BoardGeometry(b)
    p1 = d4.FindPadByNumber('1')
    p2 = d4.FindPadByNumber('2')
    p1_ok, r1 = geom.is_segment_legal(p1.GetPosition().x/1e6, p1.GetPosition().y/1e6, p1.GetPosition().x/1e6, p1.GetPosition().y/1e6, 'F.Cu', '/VSYS_RAW')
    p2_ok, r2 = geom.is_segment_legal(p2.GetPosition().x/1e6, p2.GetPosition().y/1e6, p2.GetPosition().x/1e6, p2.GetPosition().y/1e6, 'F.Cu', '/USB_VBUS')
    print(f"D4 at (59.0, {dy}): Pad 1={p1_ok} ({r1}), Pad 2={p2_ok} ({r2})")
