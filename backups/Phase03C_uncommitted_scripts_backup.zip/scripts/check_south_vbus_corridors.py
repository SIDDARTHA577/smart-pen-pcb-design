import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Checking corridors between Y=1.5 and 3.5 from X=67.5 to 73.75:")
for yi in range(15, 36, 3):
    y = yi / 10.0
    for layer in ['In2.Cu', 'B.Cu']:
        s, r = geom.is_segment_legal(67.5, y, 73.75, y, layer, '/USB_VBUS')
        print(f"y={y:.2f} on {layer}: {s} ({r})")
