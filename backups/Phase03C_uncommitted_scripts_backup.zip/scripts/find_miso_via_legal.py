import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
for t in list(b.GetTracks()):
    if t.GetNetname() == '/VSYS_RAW':
        if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 59.5 and round(t.GetPosition().y/1e6, 2) == 2.4:
            t.SetPosition(pcbnew.VECTOR2I(int(59.0*1e6), int(1.2*1e6)))

geom = BoardGeometry(b)
for vx in [59.60, 59.65, 59.70, 59.75, 59.80]:
    for vy in [0.90, 1.00, 1.10, 1.20, 1.30]:
        v, rv = geom.is_via_legal(vx, vy, '/SD_MISO')
        if v:
            print(f"SD_MISO via OK at ({vx:.2f}, {vy:.2f})")
