import json

d = json.load(open('reports/RevG/Phase03C/raw/candidate_vbus_drc.json'))
u1 = d.get('unconnected_items', [])[0]
print("GND Island items:", [i.get('description') for i in u1.get('items', [])])
print("Positions:", [i.get('pos') for i in u1.get('items', [])])
