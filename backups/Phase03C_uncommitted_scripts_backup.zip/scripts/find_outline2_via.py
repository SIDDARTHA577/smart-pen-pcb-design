import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

for x in [47.0, 48.0, 49.0, 50.0]:
    for y in [3.0, 4.0, 5.0, 6.0]:
        v_ok, rv = geom.is_via_legal(x, y, '/GND')
        if v_ok:
            print(f"Legal GND via at ({x:.1f}, {y:.1f})")
