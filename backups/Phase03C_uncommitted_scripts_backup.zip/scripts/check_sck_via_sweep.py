import pcbnew, math

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")

def test_via(vx, vy, netname='/SD_SCK'):
    print(f"\n--- Testing via at ({vx:.3f}, {vy:.3f}) for {netname} ---")
    min_dist = 999.0
    closest = None
    for fp in b.GetFootprints():
        for p in fp.Pads():
            if p.GetNetname() == netname: continue
            pos = p.GetPosition()
            dx = max(0, abs(vx - pos.x/1e6) - p.GetSize().x/2e6)
            dy = max(0, abs(vy - pos.y/1e6) - p.GetSize().y/2e6)
            d = math.hypot(dx, dy)
            if d < min_dist:
                min_dist = d
                closest = (fp.GetReference(), p.GetNumber(), p.GetNetname(), 'pad')
    for t in b.GetTracks():
        if t.GetNetname() == netname: continue
        if t.GetClass() == 'PCB_VIA':
            pos = t.GetPosition()
            d = math.hypot(vx - pos.x/1e6, vy - pos.y/1e6) - 0.25
            if d < min_dist:
                min_dist = d
                closest = (t.GetNetname(), 'via', pos.x/1e6, pos.y/1e6)
        else:
            p1, p2 = t.GetStart(), t.GetEnd()
            x1, y1 = p1.x/1e6, p1.y/1e6
            x2, y2 = p2.x/1e6, p2.y/1e6
            l2 = (x2-x1)**2 + (y2-y1)**2
            if l2 == 0: t_proj = 0
            else: t_proj = max(0, min(1, ((vx-x1)*(x2-x1) + (vy-y1)*(y2-y1)) / l2))
            proj_x = x1 + t_proj*(x2-x1)
            proj_y = y1 + t_proj*(y2-y1)
            d = math.hypot(vx - proj_x, vy - proj_y) - t.GetWidth()/2e6
            if d < min_dist:
                min_dist = d
                closest = (t.GetNetname(), b.GetLayerName(t.GetLayer()), 'trk')
    clr = min_dist - 0.25
    print(f"Closest item: {closest}, clearance = {clr:.3f} mm, Valid: {clr >= 0.150}")
    return clr >= 0.150

for y in [0.5, 0.7, 0.9, 1.15, 1.45, 1.6, 1.75]:
    test_via(42.630, y, '/SD_SCK')
