import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

test_vias = [
    ('MOSI_w', 41.130, 0.550, '/SD_MOSI'),
    ('MOSI_e', 58.650, 0.550, '/SD_MOSI'),
    ('CS_w',   43.130, 0.850, '/SD_CS'),
    ('CS_e',   59.650, 0.850, '/SD_CS'),
    ('MISO_w', 41.630, 1.150, '/SD_MISO'),
    ('MISO_e', 59.150, 1.150, '/SD_MISO'),
    ('SCK_w',  42.630, 1.750, '/SD_SCK'),
    ('SCK_e',  58.150, 1.750, '/SD_SCK'),
]

for name, x, y, net in test_vias:
    v_ok, r = geom.is_via_legal(x, y, net)
    print(f"Via {name} at ({x:.3f}, {y:.3f}): {v_ok} ({r})")

sys.exit(0)
