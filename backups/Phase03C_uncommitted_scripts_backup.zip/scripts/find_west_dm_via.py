import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Scanning for West DM via locations:")
for xi in range(480, 560, 5):
    x = xi / 10.0
    for yi in range(65, 85, 2):
        y = yi / 10.0
        v_ok, r = geom.is_via_legal(x, y, '/USB_DM_CORE')
        if v_ok:
            # check F.Cu from U1.25 (44.63, 7.235) to (44.63, 8.4) -> (x, 8.4) -> (x, y)
            s1, r1 = geom.is_segment_legal(44.63, 7.235, 44.63, 8.4, 'F.Cu', '/USB_DM_CORE')
            s2, r2 = geom.is_segment_legal(44.63, 8.4, x, 8.4, 'F.Cu', '/USB_DM_CORE')
            s3, r3 = geom.is_segment_legal(x, 8.4, x, y, 'F.Cu', '/USB_DM_CORE')
            if s1 and s2 and s3:
                # check In2.Cu from (x, y) to (73.0, y)
                s_in2, r_in2 = geom.is_segment_legal(x, y, 73.0, y, 'In2.Cu', '/USB_DM_CORE')
                print(f"Via at ({x:.1f}, {y:.1f}) - F.Cu reach: True, In2 straight to 73.0: {s_in2} ({r_in2})")
