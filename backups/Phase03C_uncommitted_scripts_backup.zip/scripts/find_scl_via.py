import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Scanning for via locations near U1.5 (40.480, 4.585):")
for x_int in range(350, 410, 2):
    x = x_int / 10.0
    for y_int in range(35, 75, 2):
        y = y_int / 10.0
        v_ok, reason = geom.is_via_legal(x, y, '/I2C_SCL')
        if v_ok:
            # check if F.Cu can reach U1.5
            f_ok, f_reason = geom.is_segment_legal(x, y, 40.480, 4.585, 'F.Cu', '/I2C_SCL')
            print(f"Via legal at ({x:.2f}, {y:.2f}) - F.Cu reach: {f_ok} ({f_reason})")
