import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
bcu = b.GetLayerID('B.Cu')
in2 = b.GetLayerID('In2.Cu')

print("--- B.Cu tracks between Y=0 and 3 ---")
for t in b.Tracks():
    if t.GetLayer() == bcu:
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if min(y1, y2) <= 3.0:
            print(f"B.Cu: {t.GetNetname()} ({x1:.3f},{y1:.3f}) -> ({x2:.3f},{y2:.3f})")

print("\n--- In2.Cu tracks between Y=0 and 3 ---")
for t in b.Tracks():
    if t.GetLayer() == in2:
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if min(y1, y2) <= 3.0:
            print(f"In2.Cu: {t.GetNetname()} ({x1:.3f},{y1:.3f}) -> ({x2:.3f},{y2:.3f})")

print("\n--- Vias between Y=0 and 3 ---")
for t in b.Tracks():
    if isinstance(t, pcbnew.PCB_VIA):
        p = t.GetPosition()
        x, y = p.x/1e6, p.y/1e6
        if y <= 3.0:
            print(f"Via: {t.GetNetname()} at ({x:.3f},{y:.3f})")
