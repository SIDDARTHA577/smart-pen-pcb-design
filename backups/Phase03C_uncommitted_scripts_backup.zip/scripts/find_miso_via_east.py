import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

for vx in [59.8, 60.0, 60.2, 60.4, 60.6, 60.8, 61.0]:
    for vy in [1.5, 1.8, 2.0, 2.2, 2.4, 2.6, 2.8, 3.0, 3.25]:
        v, rv = geom.is_via_legal(vx, vy, '/SD_MISO')
        if v:
            print(f"Via legal at ({vx:.2f}, {vy:.2f})")
