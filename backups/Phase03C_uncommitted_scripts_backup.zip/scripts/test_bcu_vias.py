import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# First remove the test group 4 tracks so geometry is clean
# (we will just test legality against baseline objects)
print("Testing B.Cu tracks for DM and DP:")
# DM enters R7.2 (72.500, 7.025)
# DP enters R8.2 (71.600, 7.025)

# West vias:
# DP at (54.0, 7.2), DM at (52.0, 7.0)
# East vias:
# Can DP via be at (71.600, 6.000) or (70.500, 6.000)?
# Can DM via be at (72.500, 6.000) or (72.500, 5.500)?
for x in [70.5, 71.0, 71.6, 72.0, 72.5]:
    for y in [5.5, 5.8, 6.0, 6.2]:
        v_ok, r = geom.is_via_legal(x, y, '/USB_DM_CORE')
        if v_ok:
            print(f"  Legal via DM at ({x}, {y})")
        v2_ok, r2 = geom.is_via_legal(x, y, '/USB_DP_CORE')
        if v2_ok:
            print(f"  Legal via DP at ({x}, {y})")

sys.exit(0)
