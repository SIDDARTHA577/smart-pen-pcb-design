import os
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    app = wx.App(False) if not wx.GetApp() else wx.GetApp()
    wx.DisableAsserts()
except Exception:
    pass

import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
for fp in b.GetFootprints():
    ref = fp.GetReference()
    for p in fp.Pads():
        net = p.GetNetname()
        if net in ['/USB_DM_CORE', '/USB_DP_CORE', '/I2C_SCL']:
            pos = p.GetPosition()
            print(f"{ref}.{p.GetNumber()} [{net}] at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})")

print("\nExisting tracks for /I2C_SCL:")
scl_net = b.FindNet('/I2C_SCL')
for t in b.TracksInNet(scl_net.GetNetCode()):
    if t.GetClass() == 'PCB_VIA':
        pos = t.GetPosition()
        print(f"VIA at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})")
    else:
        st = t.GetStart()
        en = t.GetEnd()
        print(f"TRACK on layer {t.GetLayerName()} from ({st.x/1e6:.3f}, {st.y/1e6:.3f}) to ({en.x/1e6:.3f}, {en.y/1e6:.3f})")
