import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# Via at (60.146, 7.807) is in Outline 1.
# Can a track run on B.Cu from (60.146, 7.807) to (60.146, 6.500)?
s1, r1 = geom.is_segment_legal(60.146, 7.807, 60.146, 6.500, 'B.Cu', '/3V3')
# And place a via at (60.146, 6.500) to In2.Cu (which is Outline 0):
v1, rv1 = geom.is_via_legal(60.146, 6.500, '/3V3')

print(f"B.Cu bridge: {s1} ({r1})")
print(f"Via at (60.146, 6.500): {v1} ({rv1})")
