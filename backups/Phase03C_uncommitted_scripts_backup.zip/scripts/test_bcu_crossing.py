import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

print("Checking B.Cu crossing at X=42.130:")
for y in [1.15, 1.20, 1.25, 1.30]:
    s, r = geom.is_segment_legal(41.000, y, 43.500, y, 'B.Cu', '/SD_MISO')
    print(f"B.Cu Y={y:.2f}: {s} ({r})")
