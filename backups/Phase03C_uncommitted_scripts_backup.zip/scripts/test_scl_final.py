import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

v_scl, rv = geom.is_via_legal(38.800, 4.585, '/I2C_SCL')
s_fcu, rf = geom.is_segment_legal(38.800, 4.585, 40.480, 4.585, 'F.Cu', '/I2C_SCL')
s_bcu, rb = geom.is_segment_legal(38.000, 5.600, 38.800, 4.585, 'B.Cu', '/I2C_SCL')
print(f"Via at (38.8, 4.585): {v_scl} ({rv})")
print(f"F.Cu to U1.5: {s_fcu} ({rf})")
print(f"B.Cu to via: {s_bcu} ({rb})")

sys.exit(0)
