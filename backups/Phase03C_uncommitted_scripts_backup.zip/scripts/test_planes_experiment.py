import pcbnew
import subprocess
import json
from pathlib import Path

candidate_pcb = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb")
board = pcbnew.LoadBoard(str(candidate_pcb))

# 1. Add In1.Cu GND zone
zones = list(board.Zones())
z_gnd_fcu = [z for z in zones if z.GetNetname() == "/GND" and z.GetLayer() == pcbnew.F_Cu][0]

z_in1 = pcbnew.ZONE(z_gnd_fcu)
z_in1.SetLayer(pcbnew.In1_Cu)
board.Add(z_in1)

# 2. Add In2.Cu 3V3 power zone!
net_3v3 = board.FindNet("/3V3")
assert net_3v3 is not None
z_in2 = pcbnew.ZONE(z_gnd_fcu)
z_in2.SetLayer(pcbnew.In2_Cu)
z_in2.SetNet(net_3v3)
board.Add(z_in2)

# Fill zones
filler = pcbnew.ZONE_FILLER(board)
filler.Fill(board.Zones())

test_pcb = Path("scratch_test_planes.kicad_pcb")
board.Save(str(test_pcb))

res = subprocess.run([
    r"C:\Users\goran\AppData\Local\Programs\KiCad\10.0\bin\kicad-cli.exe",
    "pcb", "drc", "--severity-all", "--format", "json", "-o", "scratch_planes_drc.json", str(test_pcb)
], capture_output=True, text=True)

with open("scratch_planes_drc.json", "r", encoding="utf-8") as f:
    d = json.load(f)

v = d.get("violations", [])
u = d.get("unconnected_items", [])
types = {}
for it in v:
    types[it["type"]] = types.get(it["type"], 0) + 1

print(f"Total violations: {len(v)}")
print(f"Total unconnected items: {len(u)}")
print("Violations breakdown:", types)

test_pcb.unlink(missing_ok=True)
Path("scratch_planes_drc.json").unlink(missing_ok=True)

