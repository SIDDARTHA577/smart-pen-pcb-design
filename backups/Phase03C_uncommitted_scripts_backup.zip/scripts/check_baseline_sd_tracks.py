import sys
sys.path.append('scripts')
import pcbnew

b = pcbnew.LoadBoard('output/RevG/SmartPen.kicad_pcb')
sd_nets = ['/SD_SCK', '/SD_MOSI', '/SD_MISO', '/SD_CS']
for t in b.GetTracks():
    if t.GetNetname() in sd_nets:
        s = t.GetStart()
        e = t.GetEnd()
        sx, sy = s.x/1e6, s.y/1e6
        ex, ey = e.x/1e6, e.y/1e6
        print(f"Baseline {t.GetClass()}: net={t.GetNetname()}, layer={b.GetLayerName(t.GetLayer())}, ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})")
