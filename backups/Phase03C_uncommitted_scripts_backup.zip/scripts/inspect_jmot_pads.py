import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
j_mot = b.FindFootprintByReference('J_MOT')
print("J_MOT pads:")
for p in j_mot.Pads():
    pos = p.GetPosition()
    sz = p.GetSize()
    print(f"  Pad {p.GetNumber()} [{p.GetNetname()}] at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f}) sz=({sz.x/1e6:.3f}, {sz.y/1e6:.3f})")

d3 = b.FindFootprintByReference('D3')
print("\nD3 pads:")
for p in d3.Pads():
    pos = p.GetPosition()
    sz = p.GetSize()
    print(f"  Pad {p.GetNumber()} [{p.GetNetname()}] at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f}) sz=({sz.x/1e6:.3f}, {sz.y/1e6:.3f})")

sys.exit(0)
