import pcbnew
import subprocess
import json
import math
from pathlib import Path

PCB_PATH = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb")
PRO_PATH = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pro")
DRU_PATH = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_dru")
MOD_PATH = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.pretty/U1.kicad_mod")

def build_candidate():
    print("--- 1. Set DRU Rules ---")
    dru_content = """(version 1)
(rule "Board Edge Clearance"
  (constraint edge_clearance (min 0.25mm))
  (condition "A.Type == '*'")
)
(rule "QFN Pad Clearance"
  (constraint clearance (min 0.127mm))
  (condition "A.InsideFootprint('U1') || B.InsideFootprint('U1')")
)
"""
    DRU_PATH.write_text(dru_content, encoding="utf-8")

    print("--- 2. Update Pro Netclass Settings ---")
    with open(PRO_PATH, "r", encoding="utf-8") as f:
        pro = json.load(f)
    classes = pro.get("net_settings", {}).get("classes", [])
    if classes:
        classes[0]["clearance"] = 0.15
        classes[0]["track_width"] = 0.18
        classes[0]["via_diameter"] = 0.50
        classes[0]["via_drill"] = 0.30
    with open(PRO_PATH, "w", encoding="utf-8") as f:
        json.dump(pro, f, indent=2)

    print("--- 3. Update U1.kicad_mod ---")
    mod_text = MOD_PATH.read_text(encoding="utf-8")
    if '(size 3.700 3.700)' in mod_text:
        mod_text = mod_text.replace('(size 3.700 3.700)', '(size 3.400 3.400)')
        MOD_PATH.write_text(mod_text, encoding="utf-8")

    print("--- 4. Load Board & Setup Layers ---")
    board = pcbnew.LoadBoard(str(PCB_PATH))
    board.SetCopperLayerCount(4)

    ds = board.GetDesignSettings()
    ds.SetBoardThickness(int(1.6 * 1e6))
    ds.m_SolderMaskExpansion = int(0.025 * 1e6)
    ds.m_SolderMaskMinWidth = int(0.08 * 1e6)

    # Footprint fine adjustments
    u1 = board.FindFootprintByReference("U1")
    if u1:
        pad33 = u1.FindPadByNumber("33")
        if pad33:
            pad33.SetSize(pcbnew.VECTOR2I(int(3.4 * 1e6), int(3.4 * 1e6)))
            pad33.SetLocalSolderMaskMargin(int(0))

    r7 = board.FindFootprintByReference("R7")
    if r7:
        r7.SetPosition(pcbnew.VECTOR2I(int(73.5 * 1e6), int(7.5 * 1e6)))

    r8 = board.FindFootprintByReference("R8")
    if r8:
        r8.SetPosition(pcbnew.VECTOR2I(int(71.5 * 1e6), int(7.5 * 1e6)))

    r9 = board.FindFootprintByReference("R9")
    if r9:
        r9.SetPosition(pcbnew.VECTOR2I(int(66.0 * 1e6), int(6.3 * 1e6)))

    d3 = board.FindFootprintByReference("D3")
    if d3:
        d3.SetPosition(pcbnew.VECTOR2I(int(27.8 * 1e6), int(4.7 * 1e6)))

    c6 = board.FindFootprintByReference("C6")
    if c6:
        c6.SetPosition(pcbnew.VECTOR2I(int(34.0 * 1e6), int(7.7 * 1e6)))

    l1 = board.FindFootprintByReference("L1")
    if l1:
        l1.SetPosition(pcbnew.VECTOR2I(int(39.35 * 1e6), int(7.7 * 1e6)))

    u4 = board.FindFootprintByReference("U4")
    if u4:
        u4.SetPosition(pcbnew.VECTOR2I(int(68.3 * 1e6), int(5.26 * 1e6)))

    # Silkscreen text
    d4 = board.FindFootprintByReference("D4")
    if d4:
        d4.Reference().SetPosition(pcbnew.VECTOR2I(int(59.5 * 1e6), int(5.1 * 1e6)))
    q2 = board.FindFootprintByReference("Q2")
    if q2:
        q2.Reference().SetPosition(pcbnew.VECTOR2I(int(63.2 * 1e6), int(5.4 * 1e6)))
    r26 = board.FindFootprintByReference("R26")
    if r26:
        r26.Reference().SetPosition(pcbnew.VECTOR2I(int(60.5 * 1e6), int(5.4 * 1e6)))

    # Clear old tracks
    tracks = list(board.GetTracks())
    for t in tracks:
        board.Delete(t)
    print(f"Cleared {len(tracks)} old tracks and vias.")

    # Helpers
    def trk(netname, layer, x1, y1, x2, y2, w=0.18):
        net = board.FindNet(netname)
        if not net:
            return None
        t = pcbnew.PCB_TRACK(board)
        t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
        t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
        t.SetWidth(int(w * 1e6))
        t.SetLayer(layer)
        t.SetNet(net)
        board.Add(t)
        return t

    def via(netname, x, y, drill=0.30, dia=0.50):
        net = board.FindNet(netname)
        if not net:
            return None
        v = pcbnew.PCB_VIA(board)
        v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
        v.SetDrill(int(drill * 1e6))
        v.SetWidth(int(dia * 1e6))
        v.SetTopLayer(pcbnew.F_Cu)
        v.SetBottomLayer(pcbnew.B_Cu)
        v.SetNet(net)
        board.Add(v)
        return v

    def route_ortho(netname, layer, x1, y1, x2, y2, w=0.18, corner="x"):
        if abs(x1 - x2) < 0.001 and abs(y1 - y2) < 0.001:
            return
        if abs(x1 - x2) < 0.001 or abs(y1 - y2) < 0.001:
            trk(netname, layer, x1, y1, x2, y2, w)
            return
        if corner == "x":
            trk(netname, layer, x1, y1, x2, y1, w)
            trk(netname, layer, x2, y1, x2, y2, w)
        else:
            trk(netname, layer, x1, y1, x1, y2, w)
            trk(netname, layer, x1, y2, x2, y2, w)

    print("--- 5. Configure Power and Ground Planes ---")
    net_gnd = board.FindNet("/GND")
    assert net_gnd is not None
    zones = list(board.Zones())
    z_gnd_fcu = [z for z in zones if z.GetNetname() == "/GND" and z.GetLayer() == pcbnew.F_Cu][0]

    # Create In1.Cu GND zone
    z_in1 = pcbnew.ZONE(z_gnd_fcu)
    z_in1.SetLayer(pcbnew.In1_Cu)
    board.Add(z_in1)

    # In2.Cu 3V3 Power Plane
    net_3v3 = board.FindNet("/3V3")
    assert net_3v3 is not None
    z_in2 = pcbnew.ZONE(z_gnd_fcu)
    z_in2.SetLayer(pcbnew.In2_Cu)
    z_in2.SetNet(net_3v3)
    board.Add(z_in2)

    print("--- 6. Route GND Vias for all SMD GND pads ---")
    gnd_pads = []
    for fp in board.GetFootprints():
        for pad in fp.Pads():
            if pad.GetNetname() == "/GND":
                pos = pad.GetPosition()
                gnd_pads.append((round(pos.x/1e6, 3), round(pos.y/1e6, 3), fp.GetReference()))

    placed_vias = []
    for x, y, ref in gnd_pads:
        if any(math.hypot(x - vx, y - vy) < 1.0 for vx, vy in placed_vias):
            continue
        vx = x
        vy = y + 0.55 if y < 7.5 else y - 0.55
        if vy > 8.5: vy = 8.4
        if vy < 0.7: vy = 0.8
        via("/GND", vx, vy)
        placed_vias.append((vx, vy))
        trk("/GND", pcbnew.F_Cu, x, y, vx, vy, w=0.20)

    print(f"Placed {len(placed_vias)} GND vias connecting all GND pads to In1.Cu.")

    print("--- 7. Route 3V3 Vias for all 3V3 pads ---")
    v33_pads = []
    for fp in board.GetFootprints():
        for pad in fp.Pads():
            if pad.GetNetname() == "/3V3":
                pos = pad.GetPosition()
                v33_pads.append((round(pos.x/1e6, 3), round(pos.y/1e6, 3), fp.GetReference()))

    placed_3v3_vias = []
    for x, y, ref in v33_pads:
        if any(math.hypot(x - vx, y - vy) < 0.8 for vx, vy in placed_3v3_vias):
            continue
        vx = x
        vy = y - 0.55 if y > 2.0 else y + 0.55
        if vy > 8.5: vy = 8.4
        if vy < 0.7: vy = 0.8
        via("/3V3", vx, vy)
        placed_3v3_vias.append((vx, vy))
        trk("/3V3", pcbnew.F_Cu, x, y, vx, vy, w=0.20)

    print(f"Placed {len(placed_3v3_vias)} 3V3 vias connecting all 3V3 pads to In2.Cu.")

    print("--- 8. Route RF Subsystem ---")
    # /RF_LNA: U1.1 (40.48, 6.585) -> L2.1 (51.92, 5.3) & C8.1 (52.22, 3.6)
    trk("/RF_LNA", pcbnew.F_Cu, 40.48, 6.585, 41.5, 6.2, w=0.35)
    trk("/RF_LNA", pcbnew.F_Cu, 41.5, 6.2, 51.0, 5.3, w=0.35)
    trk("/RF_LNA", pcbnew.F_Cu, 51.0, 5.3, 51.92, 5.3, w=0.35)
    trk("/RF_LNA", pcbnew.F_Cu, 51.92, 5.3, 51.92, 3.6, w=0.25)
    trk("/RF_LNA", pcbnew.F_Cu, 51.92, 3.6, 52.22, 3.6, w=0.25)

    # /RF_OUT: L2.2 (52.48, 5.3) -> C9.1 (53.77, 3.55) -> J_RF.1 (54.85, 5.15)
    trk("/RF_OUT", pcbnew.F_Cu, 52.48, 5.3, 53.77, 5.15, w=0.35)
    trk("/RF_OUT", pcbnew.F_Cu, 53.77, 5.15, 54.85, 5.15, w=0.35)
    trk("/RF_OUT", pcbnew.F_Cu, 53.77, 5.15, 53.77, 3.55, w=0.25)

    print("--- 9. Route Crystal 40 MHz ---")
    # /XTAL_P_CORE: U1.30 (42.13, 7.235) -> L1.1 (38.875, 7.7)
    route_ortho("/XTAL_P_CORE", pcbnew.F_Cu, 42.13, 7.235, 38.875, 7.7, w=0.18, corner="y")

    # /XTAL_P_MATCH: L1.2 (39.825, 7.7) -> C7.1 (37.358, 7.7) -> Y1.3 (36.423, 7.022)
    trk("/XTAL_P_MATCH", pcbnew.F_Cu, 39.825, 7.7, 37.358, 7.7, w=0.18)
    route_ortho("/XTAL_P_MATCH", pcbnew.F_Cu, 37.358, 7.7, 36.423, 7.022, w=0.18, corner="x")

    # /XTAL_N: U1.29 (42.63, 7.235) -> Y1.1 (34.723, 5.722) -> C6.1 (33.525, 7.7)
    via("/XTAL_N", 42.63, 8.2)
    trk("/XTAL_N", pcbnew.F_Cu, 42.63, 7.235, 42.63, 8.2, w=0.18)
    via("/XTAL_N", 35.2, 8.2)
    trk("/XTAL_N", pcbnew.B_Cu, 42.63, 8.2, 35.2, 8.2, w=0.18)
    trk("/XTAL_N", pcbnew.F_Cu, 35.2, 8.2, 33.525, 7.7, w=0.18)
    route_ortho("/XTAL_N", pcbnew.F_Cu, 35.2, 8.2, 34.723, 5.722, w=0.18, corner="x")

    print("--- 10. Route ESP32-C3 Digital & Control Pins ---")
    # /3V3_RF: U1 pins 31, 32, 2, 3, FB1.2 (46.98, 7.55), C2.1 (48.094, 6.603)
    trk("/3V3_RF", pcbnew.F_Cu, 40.48, 5.585, 40.48, 6.085, w=0.20)
    trk("/3V3_RF", pcbnew.F_Cu, 41.13, 7.235, 41.63, 7.235, w=0.20)
    route_ortho("/3V3_RF", pcbnew.F_Cu, 41.63, 7.235, 46.98, 7.55, w=0.20, corner="y")
    route_ortho("/3V3_RF", pcbnew.F_Cu, 46.98, 7.55, 48.094, 6.603, w=0.20, corner="x")

    # /3V3_RTC: U1.11 (42.13, 2.435) -> C4.1 (36.201, 1.636) -> R4.2 (36.357, 2.601)
    route_ortho("/3V3_RTC", pcbnew.F_Cu, 42.13, 2.435, 36.201, 1.636, w=0.18, corner="x")
    route_ortho("/3V3_RTC", pcbnew.F_Cu, 36.201, 1.636, 36.357, 2.601, w=0.18, corner="y")

    # /VDD_SPI: U1.18 (45.28, 3.585) -> C5.1 (49.525, 1.551)
    route_ortho("/VDD_SPI", pcbnew.F_Cu, 45.28, 3.585, 49.525, 1.551, w=0.18, corner="x")

    # /MCU_EN: U1.7 (40.48, 3.585) -> R1.2 (38.925, 2.36) -> C1.1 (39.325, 1.52) -> SW1.1 (31.556, 1.5)
    route_ortho("/MCU_EN", pcbnew.F_Cu, 40.48, 3.585, 38.925, 2.36, w=0.18, corner="y")
    route_ortho("/MCU_EN", pcbnew.F_Cu, 38.925, 2.36, 39.325, 1.52, w=0.18, corner="x")
    trk("/MCU_EN", pcbnew.F_Cu, 39.325, 1.52, 31.556, 1.5, w=0.18)

    # /BOOT9: U1.15 (44.13, 2.435) -> SW2.1 (45.704, 1.5) -> R2.2 (52.225, 2.25)
    route_ortho("/BOOT9", pcbnew.F_Cu, 44.13, 2.435, 45.704, 1.5, w=0.18, corner="x")
    route_ortho("/BOOT9", pcbnew.F_Cu, 45.704, 1.5, 52.225, 2.25, w=0.18, corner="y")

    # /GPIO8_STRAP: U1.14 (43.63, 2.435) -> R27.2 (43.975, 1.0)
    route_ortho("/GPIO8_STRAP", pcbnew.F_Cu, 43.63, 2.435, 43.975, 1.0, w=0.18, corner="y")

    # /STRAP2: U1.6 (40.48, 4.085) -> R3.2 (48.775, 2.8)
    via("/STRAP2", 40.48, 3.8)
    trk("/STRAP2", pcbnew.F_Cu, 40.48, 4.085, 40.48, 3.8, w=0.18)
    via("/STRAP2", 48.775, 3.4)
    trk("/STRAP2", pcbnew.B_Cu, 40.48, 3.8, 48.775, 3.4, w=0.18)
    trk("/STRAP2", pcbnew.F_Cu, 48.775, 3.4, 48.775, 2.8, w=0.18)

    # /TOUCH_OUT: J_TOUCH.3 (10.0, 2.4) -> R19.1 (13.025, 2.4) -> U1.8 (40.48, 3.085)
    trk("/TOUCH_OUT", pcbnew.F_Cu, 10.0, 2.4, 13.025, 2.4, w=0.18)
    via("/TOUCH_OUT", 13.6, 2.4)
    trk("/TOUCH_OUT", pcbnew.F_Cu, 13.025, 2.4, 13.6, 2.4, w=0.18)
    via("/TOUCH_OUT", 39.8, 3.085)
    trk("/TOUCH_OUT", pcbnew.B_Cu, 13.6, 2.4, 39.8, 3.085, w=0.18)
    trk("/TOUCH_OUT", pcbnew.F_Cu, 39.8, 3.085, 40.48, 3.085, w=0.18)

    print("--- 11. Route UART & USB ---")
    # /UART_TX: U1.28 (43.13, 7.235) -> J_UART.1 (55.95, 7.347)
    via("/UART_TX", 43.13, 8.5)
    trk("/UART_TX", pcbnew.F_Cu, 43.13, 7.235, 43.13, 8.5, w=0.18)
    via("/UART_TX", 55.95, 8.5)
    trk("/UART_TX", pcbnew.B_Cu, 43.13, 8.5, 55.95, 8.5, w=0.18)
    trk("/UART_TX", pcbnew.F_Cu, 55.95, 8.5, 55.95, 7.347, w=0.18)

    # /UART_RX: U1.27 (43.63, 7.235) -> J_UART.2 (57.22, 7.347)
    via("/UART_RX", 43.63, 8.0)
    trk("/UART_RX", pcbnew.F_Cu, 43.63, 7.235, 43.63, 8.0, w=0.18)
    via("/UART_RX", 57.22, 8.0)
    trk("/UART_RX", pcbnew.B_Cu, 43.63, 8.0, 57.22, 8.0, w=0.18)
    trk("/UART_RX", pcbnew.F_Cu, 57.22, 8.0, 57.22, 7.347, w=0.18)

    # /USB_DP_CORE: U1.26 (44.13, 7.235) -> R8.2 (71.5, 7.025)
    via("/USB_DP_CORE", 44.13, 8.2)
    trk("/USB_DP_CORE", pcbnew.F_Cu, 44.13, 7.235, 44.13, 8.2, w=0.18)
    via("/USB_DP_CORE", 71.5, 8.2)
    trk("/USB_DP_CORE", pcbnew.B_Cu, 44.13, 8.2, 71.5, 8.2, w=0.20)
    trk("/USB_DP_CORE", pcbnew.F_Cu, 71.5, 8.2, 71.5, 7.025, w=0.18)

    # /USB_DM_CORE: U1.25 (44.63, 7.235) -> R7.2 (73.5, 7.025)
    via("/USB_DM_CORE", 44.63, 8.5)
    trk("/USB_DM_CORE", pcbnew.F_Cu, 44.63, 7.235, 44.63, 8.5, w=0.18)
    via("/USB_DM_CORE", 73.5, 8.5)
    trk("/USB_DM_CORE", pcbnew.B_Cu, 44.63, 8.5, 73.5, 8.5, w=0.20)
    trk("/USB_DM_CORE", pcbnew.F_Cu, 73.5, 8.5, 73.5, 7.025, w=0.18)

    # /USB_DP_PORT: R8.1 (71.5, 7.975) -> U_ESD.1 (71.05, 3.19) -> J_USB.6,8 (78.15, 79.15, 3.1)
    via("/USB_DP_PORT", 71.5, 7.975)
    via("/USB_DP_PORT", 71.05, 4.0)
    trk("/USB_DP_PORT", pcbnew.B_Cu, 71.5, 7.975, 71.05, 4.0, w=0.20)
    trk("/USB_DP_PORT", pcbnew.F_Cu, 71.05, 4.0, 71.05, 3.19, w=0.20)
    trk("/USB_DP_PORT", pcbnew.F_Cu, 71.05, 3.19, 78.15, 3.1, w=0.20)
    trk("/USB_DP_PORT", pcbnew.F_Cu, 78.15, 3.1, 79.15, 3.1, w=0.20)

    # /USB_DM_PORT: R7.1 (73.5, 7.975) -> U_ESD.2 (72.0, 3.19) -> J_USB.5,7 (77.65, 78.65, 3.1)
    via("/USB_DM_PORT", 73.5, 7.975)
    via("/USB_DM_PORT", 72.0, 4.0)
    trk("/USB_DM_PORT", pcbnew.B_Cu, 73.5, 7.975, 72.0, 4.0, w=0.20)
    trk("/USB_DM_PORT", pcbnew.F_Cu, 72.0, 4.0, 72.0, 3.19, w=0.20)
    trk("/USB_DM_PORT", pcbnew.F_Cu, 72.0, 3.19, 77.65, 3.1, w=0.20)
    trk("/USB_DM_PORT", pcbnew.F_Cu, 77.65, 3.1, 78.65, 3.1, w=0.20)

    # /USB_CC1 & /USB_CC2
    route_ortho("/USB_CC1", pcbnew.F_Cu, 77.15, 3.1, 77.6, 6.225, w=0.18, corner="y")
    route_ortho("/USB_CC2", pcbnew.F_Cu, 79.65, 3.1, 79.2, 6.225, w=0.18, corner="y")

    print("--- 12. Route MicroSD SPI Bus ---")
    # /SD_CS: U1.13 (43.13, 2.435) -> R18.2 (56.975, 2.0) -> J_SD.6 (59.65, 4.2)
    via("/SD_CS", 43.13, 1.8)
    trk("/SD_CS", pcbnew.F_Cu, 43.13, 2.435, 43.13, 1.8, w=0.18)
    via("/SD_CS", 56.975, 1.4)
    trk("/SD_CS", pcbnew.B_Cu, 43.13, 1.8, 56.975, 1.4, w=0.18)
    trk("/SD_CS", pcbnew.F_Cu, 56.975, 1.4, 56.975, 2.0, w=0.18)
    route_ortho("/SD_CS", pcbnew.F_Cu, 56.975, 2.0, 59.65, 4.2, w=0.18, corner="x")

    # /SD_SCK: U1.12 (42.63, 2.435) -> J_SD.3 (58.15, 4.2)
    via("/SD_SCK", 42.63, 1.5)
    trk("/SD_SCK", pcbnew.F_Cu, 42.63, 2.435, 42.63, 1.5, w=0.18)
    via("/SD_SCK", 58.15, 1.5)
    trk("/SD_SCK", pcbnew.B_Cu, 42.63, 1.5, 58.15, 1.5, w=0.18)
    trk("/SD_SCK", pcbnew.F_Cu, 58.15, 1.5, 58.15, 4.2, w=0.18)

    # /SD_MOSI: U1.9 (41.13, 2.435) -> J_SD.4 (58.65, 4.2)
    via("/SD_MOSI", 41.13, 1.2)
    trk("/SD_MOSI", pcbnew.F_Cu, 41.13, 2.435, 41.13, 1.2, w=0.18)
    via("/SD_MOSI", 58.65, 1.2)
    trk("/SD_MOSI", pcbnew.B_Cu, 41.13, 1.2, 58.65, 1.2, w=0.18)
    trk("/SD_MOSI", pcbnew.F_Cu, 58.65, 1.2, 58.65, 4.2, w=0.18)

    # /SD_MISO: U1.10 (41.63, 2.435) -> J_SD.5 (59.15, 4.2)
    via("/SD_MISO", 41.63, 0.9)
    trk("/SD_MISO", pcbnew.F_Cu, 41.63, 2.435, 41.63, 0.9, w=0.18)
    via("/SD_MISO", 59.15, 0.9)
    trk("/SD_MISO", pcbnew.B_Cu, 41.63, 0.9, 59.15, 0.9, w=0.18)
    trk("/SD_MISO", pcbnew.F_Cu, 59.15, 0.9, 59.15, 4.2, w=0.18)

    print("--- 13. Route I2C Bus ---")
    # /I2C_SCL: U1.5 (40.48, 4.585) -> U3.1 (24.25, 6.55) -> R11.2 (6.675, 7.2) -> J_IMU.4 (4.7, 4.6)
    via("/I2C_SCL", 40.48, 4.585)
    via("/I2C_SCL", 24.25, 6.55)
    trk("/I2C_SCL", pcbnew.B_Cu, 40.48, 4.585, 24.25, 6.55, w=0.18)
    via("/I2C_SCL", 6.675, 7.2)
    trk("/I2C_SCL", pcbnew.B_Cu, 24.25, 6.55, 6.675, 7.2, w=0.18)
    route_ortho("/I2C_SCL", pcbnew.F_Cu, 6.675, 7.2, 4.7, 4.6, w=0.18, corner="y")

    # /I2C_SDA: U1.4 (40.48, 5.085) -> U3.2 (23.75, 6.55) -> R10.2 (6.675, 4.6) -> J_IMU.3 (3.7, 4.6)
    via("/I2C_SDA", 40.48, 5.085)
    via("/I2C_SDA", 23.75, 6.55)
    trk("/I2C_SDA", pcbnew.B_Cu, 40.48, 5.085, 23.75, 6.55, w=0.18)
    via("/I2C_SDA", 6.675, 4.6)
    trk("/I2C_SDA", pcbnew.B_Cu, 23.75, 6.55, 6.675, 4.6, w=0.18)
    trk("/I2C_SDA", pcbnew.F_Cu, 6.675, 4.6, 3.7, 4.6, w=0.18)

    print("--- 14. Route User Controls, LEDs & Haptic ---")
    # /BTN_ERASE: SW4.1 (10.1, 7.0) -> R12.2 (14.975, 7.0) -> U3.10 (21.35, 3.65)
    trk("/BTN_ERASE", pcbnew.F_Cu, 10.1, 7.0, 14.975, 7.0, w=0.18)
    route_ortho("/BTN_ERASE", pcbnew.F_Cu, 14.975, 7.0, 21.35, 3.65, w=0.18, corner="x")

    # /BTN_MODE: SW5.1 (16.1, 7.0) -> R13.2 (20.975, 7.0) -> U3.11 (22.25, 2.75)
    trk("/BTN_MODE", pcbnew.F_Cu, 16.1, 7.0, 20.975, 7.0, w=0.18)
    route_ortho("/BTN_MODE", pcbnew.F_Cu, 20.975, 7.0, 22.25, 2.75, w=0.18, corner="x")

    # /LED_GREEN_A & /LED_GREEN_SINK
    trk("/LED_GREEN_A", pcbnew.F_Cu, 17.7, 2.2, 18.525, 2.2, w=0.18)
    route_ortho("/LED_GREEN_SINK", pcbnew.F_Cu, 16.7, 2.2, 22.75, 2.75, w=0.18, corner="y")

    # /LED_RED_A & /LED_RED_SINK
    trk("/LED_RED_A", pcbnew.F_Cu, 17.7, 4.4, 18.525, 4.4, w=0.18)
    route_ortho("/LED_RED_SINK", pcbnew.F_Cu, 16.7, 4.4, 23.25, 2.75, w=0.18, corner="y")

    # /HAPTIC_GATE_DRIVE: U3.14 (23.75, 2.75) -> R16.1 (26.525, 2.2)
    route_ortho("/HAPTIC_GATE_DRIVE", pcbnew.F_Cu, 23.75, 2.75, 26.525, 2.2, w=0.18, corner="x")

    # /HAPTIC_GATE: R16.2 (27.475, 2.2) -> R17.1 (26.03, 3.911) -> Q1.1 (27.85, 1.1)
    route_ortho("/HAPTIC_GATE", pcbnew.F_Cu, 27.475, 2.2, 26.03, 3.911, w=0.18, corner="y")
    route_ortho("/HAPTIC_GATE", pcbnew.F_Cu, 27.475, 2.2, 27.85, 1.1, w=0.18, corner="x")

    # /HAPTIC_LOW: Q1.3 (28.8, 3.3) -> D3.2 (29.4, 4.7) -> J_MOT.2 (31.753, 6.285)
    route_ortho("/HAPTIC_LOW", pcbnew.F_Cu, 28.8, 3.3, 29.4, 4.7, w=0.25, corner="x")
    route_ortho("/HAPTIC_LOW", pcbnew.F_Cu, 29.4, 4.7, 31.753, 6.285, w=0.25, corner="y")

    # /CHG_STAT: U2.1 (66.05, 2.77) -> U3.15 (24.25, 2.75)
    via("/CHG_STAT", 66.05, 2.77)
    via("/CHG_STAT", 24.25, 2.75)
    trk("/CHG_STAT", pcbnew.B_Cu, 66.05, 2.77, 24.25, 2.75, w=0.18)

    print("--- 15. Route Power & Battery Management ---")
    # /CHG_PROG: R9.1 (66.0, 5.825) -> U2.5 (66.05, 5.37)
    trk("/CHG_PROG", pcbnew.F_Cu, 66.0, 5.825, 66.05, 5.37, w=0.18)

    # /USB_VBUS: J_USB.2,11 (76.0, 80.8, 3.1) -> C10.1 (73.75, 1.5) -> U2.4 (67.95, 5.37) -> C11.1 (67.25, 7.75) -> Q2.1 (61.7, 5.35) -> R26.1 (60.5, 4.875) -> D4.2 (59.0, 5.6)
    trk("/USB_VBUS", pcbnew.F_Cu, 76.0, 3.1, 80.8, 3.1, w=0.35)
    route_ortho("/USB_VBUS", pcbnew.F_Cu, 76.0, 3.1, 73.75, 1.5, w=0.35, corner="y")
    route_ortho("/USB_VBUS", pcbnew.F_Cu, 73.75, 1.5, 67.95, 5.37, w=0.35, corner="x")
    route_ortho("/USB_VBUS", pcbnew.F_Cu, 67.95, 5.37, 67.25, 7.75, w=0.35, corner="x")
    route_ortho("/USB_VBUS", pcbnew.F_Cu, 67.95, 5.37, 61.7, 5.35, w=0.35, corner="x")
    trk("/USB_VBUS", pcbnew.F_Cu, 61.7, 5.35, 60.5, 4.875, w=0.25)
    route_ortho("/USB_VBUS", pcbnew.F_Cu, 60.5, 4.875, 59.0, 5.6, w=0.25, corner="y")

    # /VBAT: J_BAT.1 (62.3, 1.72) -> Q2.3 (63.9, 4.4) -> C12.1 (67.4, 1.4) -> U2.3 (67.95, 2.77)
    route_ortho("/VBAT", pcbnew.F_Cu, 62.3, 1.72, 63.9, 4.4, w=0.35, corner="y")
    route_ortho("/VBAT", pcbnew.F_Cu, 62.3, 1.72, 67.4, 1.4, w=0.35, corner="y")
    route_ortho("/VBAT", pcbnew.F_Cu, 67.4, 1.4, 67.95, 2.77, w=0.35, corner="x")

    # /VSYS_RAW: D4.1 (59.0, 2.4) -> Q2.2 (61.7, 3.45) -> SW3.1 (60.963, 6.824)
    route_ortho("/VSYS_RAW", pcbnew.F_Cu, 59.0, 2.4, 61.7, 3.45, w=0.35, corner="x")
    route_ortho("/VSYS_RAW", pcbnew.F_Cu, 61.7, 3.45, 60.963, 6.824, w=0.35, corner="x")

    # /VBAT_SW: SW3.2 (62.963, 6.824) -> U4.1,3 (67.35, 69.25, 3.96) & J_MOT.1 (30.753, 6.285) & D3.1 (26.2, 4.7)
    route_ortho("/VBAT_SW", pcbnew.F_Cu, 62.963, 6.824, 67.35, 3.96, w=0.35, corner="y")
    trk("/VBAT_SW", pcbnew.F_Cu, 67.35, 3.96, 69.25, 3.96, w=0.35)
    via("/VBAT_SW", 62.963, 6.824)
    via("/VBAT_SW", 30.753, 6.285)
    trk("/VBAT_SW", pcbnew.B_Cu, 62.963, 6.824, 30.753, 6.285, w=0.35)
    route_ortho("/VBAT_SW", pcbnew.F_Cu, 30.753, 6.285, 26.2, 4.7, w=0.35, corner="y")

    print("--- 16. Fill Zones ---")
    filler = pcbnew.ZONE_FILLER(board)
    filler.Fill(board.Zones())

    print("--- 17. Save Candidate Board ---")
    board.Save(str(PCB_PATH))
    print(f"Successfully generated 4-layer candidate layout at {PCB_PATH}!")

if __name__ == "__main__":
    build_candidate()
