import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

pins = [
    (9, 41.130, 2.435, '/SD_MOSI'),
    (10, 41.630, 2.435, '/SD_MISO'),
    (12, 42.630, 2.435, '/SD_SCK'),
    (13, 43.130, 2.435, '/SD_CS'),
]

print("Scanning for escape vias near U1 south pins:")
for pin_num, px, py, net in pins:
    print(f"\n--- Pin {pin_num} ({net}) at ({px}, {py}) ---")
    for dx in [-0.5, 0.0, 0.5]:
        vx = px + dx
        for vy in [0.5, 0.8, 1.0, 1.2, 1.5, 2.0, 3.0]:
            v_ok, rv = geom.is_via_legal(vx, vy, net)
            if v_ok:
                s_ok, rs = geom.is_segment_legal(px, py, vx, vy, 'F.Cu', net)
                if s_ok:
                    print(f"  Legal via at ({vx:.3f}, {vy:.3f}) with F.Cu reach!")
