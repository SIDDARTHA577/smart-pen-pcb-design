import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
fcu_id = b.GetLayerID('F.Cu')

for z in b.Zones():
    if z.GetLayer() == fcu_id and z.GetNetname() == '/GND':
        poly = z.GetFilledPolysList(fcu_id)
        print(f"F.Cu GND zone has {poly.OutlineCount()} outlines:")
        for i in range(poly.OutlineCount()):
            bb = poly.Outline(i).BBox()
            x1, y1 = bb.GetX()/1e6, bb.GetY()/1e6
            x2, y2 = (bb.GetX()+bb.GetWidth())/1e6, (bb.GetY()+bb.GetHeight())/1e6
            # count GND pads/vias inside this bbox
            vias_in = 0
            for t in b.Tracks():
                if isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/GND':
                    p = t.GetPosition()
                    vx, vy = p.x/1e6, p.y/1e6
                    if x1 <= vx <= x2 and y1 <= vy <= y2:
                        vias_in += 1
            pads_in = 0
            for f in b.GetFootprints():
                for pad in f.Pads():
                    if pad.GetNetname() == '/GND':
                        p = pad.GetPosition()
                        px, py = p.x/1e6, p.y/1e6
                        if x1 <= px <= x2 and y1 <= py <= y2:
                            pads_in += 1
            print(f"  Outline {i}: ({x1:.2f}, {y1:.2f}) -> ({x2:.2f}, {y2:.2f}) | pads={pads_in}, vias={vias_in}")
