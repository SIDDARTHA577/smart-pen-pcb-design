import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

for ref in ['U1', 'L2', 'C8', 'C9', 'J_RF', 'AE1']:
    fp = board.FindFootprintByReference(ref)
    if fp:
        pos = fp.GetPosition()
        print(f'{ref} at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})')
        for p in fp.Pads():
            ppos = p.GetPosition()
            print(f'  {ref}.{p.GetNumber()} [{p.GetNetname()}] at ({ppos.x/1e6:.3f}, {ppos.y/1e6:.3f})')

