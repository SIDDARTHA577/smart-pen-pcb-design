import json

with open('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pro') as f:
    d = json.load(f)

def search_dict(obj, path=''):
    if isinstance(obj, dict):
        for k, v in obj.items():
            search_dict(v, f'{path}.{k}')
    elif isinstance(obj, list):
        for i, it in enumerate(obj):
            search_dict(it, f'{path}[{i}]')
    else:
        if any(w in path.lower() for w in ['spoke', 'thermal', 'zone', 'drc']):
            print(f'{path} = {obj}')

search_dict(d)

