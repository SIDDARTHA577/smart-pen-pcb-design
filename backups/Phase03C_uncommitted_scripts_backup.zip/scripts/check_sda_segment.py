import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
bcu_id = b.GetLayerID('B.Cu')

# Adjust VBAT_SW
to_remove = []
for t in b.Tracks():
    if not isinstance(t, pcbnew.PCB_VIA) and t.GetLayer() == bcu_id and t.GetNetname() == '/VBAT_SW':
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (x1 == 38.0 and x2 == 40.5) or (x1 == 40.5 and x2 == 52.0):
            to_remove.append(t)
for t in to_remove:
    b.Remove(t)

def add_track(x1, y1, x2, y2, layer_id, net_name, width=0.25):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(x1*1e6), int(y1*1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2*1e6), int(y2*1e6)))
    t.SetLayer(layer_id)
    t.SetWidth(int(width*1e6))
    t.SetNet(b.FindNet(net_name))
    b.Add(t)

add_track(38.000, 4.050, 41.200, 4.050, bcu_id, '/VBAT_SW', 0.25)
add_track(41.200, 4.050, 41.650, 4.500, bcu_id, '/VBAT_SW', 0.25)
add_track(41.650, 4.500, 52.000, 4.500, bcu_id, '/VBAT_SW', 0.25)

geom = BoardGeometry(b)

# Test jog from (38.0, 5.60) to (38.80, 4.585):
# But wait, what is on B.Cu at Y=5.080? /I2C_SDA is at Y=5.080!
print("Check I2C_SDA on B.Cu:")
for t in b.Tracks():
    if t.GetLayer() == bcu_id and t.GetNetname() == '/I2C_SDA':
        p1, p2 = t.GetStart(), t.GetEnd()
        print(f"I2C_SDA B.Cu: ({p1.x/1e6:.3f}, {p1.y/1e6:.3f}) -> ({p2.x/1e6:.3f}, {p2.y/1e6:.3f})")
