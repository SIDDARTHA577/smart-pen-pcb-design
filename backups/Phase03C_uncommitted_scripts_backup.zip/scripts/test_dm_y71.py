import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# From (53.0, 7.5) -> (53.0, 7.1) -> (70.0, 7.1):
s1, r1 = geom.is_segment_legal(53.000, 7.500, 53.000, 7.100, 'B.Cu', '/USB_DM_CORE')
s2, r2 = geom.is_segment_legal(53.000, 7.100, 68.000, 7.100, 'B.Cu', '/USB_DM_CORE')
print(f"B.Cu jog down: {s1} ({r1})")
print(f"B.Cu horiz at 7.1: {s2} ({r2})")
