import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

for f in b.GetFootprints():
    for p in f.Pads():
        if p.GetNetname() in ['/USB_DP_CORE', '/USB_DM_CORE']:
            pos = p.GetPosition()
            print(f"Pad: {f.GetReference()}.{p.GetName()} ({p.GetNetname()}) at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})")

for t in b.Tracks():
    if t.GetNetname() in ['/USB_DP_CORE', '/USB_DM_CORE']:
        if isinstance(t, pcbnew.PCB_VIA):
            p = t.GetPosition()
            print(f"Via: {t.GetNetname()} at ({p.x/1e6:.3f}, {p.y/1e6:.3f})")
        else:
            p1, p2 = t.GetStart(), t.GetEnd()
            print(f"Track: {t.GetNetname()} [{b.GetLayerName(t.GetLayer())}] ({p1.x/1e6:.3f}, {p1.y/1e6:.3f}) -> ({p2.x/1e6:.3f}, {p2.y/1e6:.3f})")
