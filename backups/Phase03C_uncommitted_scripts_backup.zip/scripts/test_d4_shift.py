import pcbnew
import math

board = pcbnew.LoadBoard('scratch_test_mosi_flawless.kicad_pcb')
d4 = board.FindFootprintByReference('D4')

# Test moving D4 to various Y positions
for test_y in [3.9, 3.8, 3.7, 3.6]:
    d4.SetPosition(pcbnew.VECTOR2I_MM(59.0, test_y))
    p1 = d4.FindPadByNumber('1') # VSYS_RAW
    p2 = d4.FindPadByNumber('2') # USB_VBUS
    
    pos1 = p1.GetPosition()
    pos2 = p2.GetPosition()
    x1, y1 = pcbnew.ToMM(pos1.x), pcbnew.ToMM(pos1.y)
    x2, y2 = pcbnew.ToMM(pos2.x), pcbnew.ToMM(pos2.y)
    
    # Check clearance of p1 and p2 to all OTHER footprints and vias
    min_clr1 = 999
    min_clr2 = 999
    col1 = None
    col2 = None
    
    for f in board.GetFootprints():
        if f.GetReference() == 'D4':
            continue
        for p in f.Pads():
            # pad 1
            if p.GetNetname() != p1.GetNetname():
                dx = max(0.0, abs(x1 - pcbnew.ToMM(p.GetPosition().x)) - (pcbnew.ToMM(p1.GetSizeX()) + pcbnew.ToMM(p.GetSizeX()))/2.0)
                dy = max(0.0, abs(y1 - pcbnew.ToMM(p.GetPosition().y)) - (pcbnew.ToMM(p1.GetSizeY()) + pcbnew.ToMM(p.GetSizeY()))/2.0)
                d = math.hypot(dx, dy)
                if d < min_clr1:
                    min_clr1 = d
                    col1 = f'{f.GetReference()}.{p.GetNumber()}'
            # pad 2
            if p.GetNetname() != p2.GetNetname():
                dx = max(0.0, abs(x2 - pcbnew.ToMM(p.GetPosition().x)) - (pcbnew.ToMM(p2.GetSizeX()) + pcbnew.ToMM(p.GetSizeX()))/2.0)
                dy = max(0.0, abs(y2 - pcbnew.ToMM(p.GetPosition().y)) - (pcbnew.ToMM(p2.GetSizeY()) + pcbnew.ToMM(p.GetSizeY()))/2.0)
                d = math.hypot(dx, dy)
                if d < min_clr2:
                    min_clr2 = d
                    col2 = f'{f.GetReference()}.{p.GetNumber()}'
                    
    print(f"D4 at Y={test_y:.2f}:")
    print(f"  Pad 1 ({x1:.2f}, {y1:.2f}): min_clr={min_clr1:.3f} mm to {col1}")
    print(f"  Pad 2 ({x2:.2f}, {y2:.2f}): min_clr={min_clr2:.3f} mm to {col2}")
