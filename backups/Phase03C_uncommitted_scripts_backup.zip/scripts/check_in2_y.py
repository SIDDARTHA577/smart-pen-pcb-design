import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

for y in [2.0, 2.1, 2.15, 2.2, 2.25, 2.3, 2.4]:
    s, r = geom.is_segment_legal(39.680, y, 58.150, y, 'In2.Cu', '/SD_MOSI')
    print(f"In2.Cu at Y={y:.2f}: {s} ({r})")
