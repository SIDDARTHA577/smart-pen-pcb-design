import pcbnew

board = pcbnew.LoadBoard('scratch_test_mosi_flawless.kicad_pcb')
for t in board.GetTracks():
    net = t.GetNetname()
    if any(s in net for s in ['SD_', 'VSYS', 'CHG']):
        p1 = t.GetStart()
        p2 = t.GetEnd()
        layer = t.GetLayerName()
        if isinstance(t, pcbnew.PCB_VIA):
            print(f'VIA {net}: at ({pcbnew.ToMM(p1.x):.3f}, {pcbnew.ToMM(p1.y):.3f}) drill={pcbnew.ToMM(t.GetDrill()):.3f} width={pcbnew.ToMM(t.GetWidth(pcbnew.F_Cu)):.3f}')
        else:
            print(f'TRACK {net} [{layer}]: ({pcbnew.ToMM(p1.x):.3f}, {pcbnew.ToMM(p1.y):.3f}) -> ({pcbnew.ToMM(p2.x):.3f}, {pcbnew.ToMM(p2.y):.3f}) w={pcbnew.ToMM(t.GetWidth()):.3f}')
