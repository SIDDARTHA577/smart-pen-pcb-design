import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Checking In2.Cu parallel corridors for MicroSD SPI bus:")
for y_test in [0.45, 0.85, 1.25, 1.65]:
    s, r = geom.is_segment_legal(43.5, y_test, 58.0, y_test, 'In2.Cu', '/SD_SCK')
    print(f"In2.Cu Y={y_test:.2f}: {s} ({r})")
