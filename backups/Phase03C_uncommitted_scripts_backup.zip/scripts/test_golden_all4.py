import os, sys, math, json, subprocess
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try: import wx; wx.DisableAsserts()
except: pass
import pcbnew, shutil

src_pcb = 'scratch_test_restore_vsys.kicad_pcb'
dst_pcb = 'scratch_golden_all4.kicad_pcb'
shutil.copy(src_pcb, dst_pcb)
shutil.copy(src_pcb.replace('.kicad_pcb', '.kicad_pro'), dst_pcb.replace('.kicad_pcb', '.kicad_pro'))

b = pcbnew.LoadBoard(dst_pcb)

# 1. Delete freestanding GND stitching via at (55.00, 1.20)
for t in list(b.GetTracks()):
    if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 55.00 and round(t.GetPosition().y/1e6, 2) == 1.20:
        b.Delete(t)

# 2. Hide R27 silkscreen reference
r27 = b.FindFootprintByReference('R27')
if r27:
    r27.Reference().SetVisible(False)

# 3. Clean any existing SD tracks
for netname in ['/SD_SCK', '/SD_MOSI', '/SD_MISO', '/SD_CS']:
    net = b.FindNet(netname)
    for t in list(b.GetTracks()):
        if t.GetNet() == net:
            b.Delete(t)

# 4. Fix GPIO8_STRAP: run straight south to Y=0.800, then west to R27.2
for t in list(b.GetTracks()):
    if t.GetNetname() == '/GPIO8_STRAP':
        b.Delete(t)

net_strap = b.FindNet('/GPIO8_STRAP')
bcu = b.GetLayerID('B.Cu')
fcu = b.GetLayerID('F.Cu')
in2 = b.GetLayerID('In2.Cu')

def add_trk(netname, layer_id, x1, y1, x2, y2, w=0.15):
    net = b.FindNet(netname)
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(round(x1 * 1e6)), int(round(y1 * 1e6))))
    t.SetEnd(pcbnew.VECTOR2I(int(round(x2 * 1e6)), int(round(y2 * 1e6))))
    t.SetWidth(int(round(w * 1e6)))
    t.SetLayer(layer_id)
    t.SetNet(net)
    b.Add(t)
    return t

def add_via(netname, x, y, drill=0.30, dia=0.50):
    net = b.FindNet(netname)
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(int(round(x * 1e6)), int(round(y * 1e6))))
    v.SetWidth(int(round(dia * 1e6)))
    v.SetDrill(int(round(drill * 1e6)))
    v.SetNet(net)
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    b.Add(v)
    return v

# Add straight GPIO8_STRAP
add_trk('/GPIO8_STRAP', fcu, 43.630, 2.435, 43.630, 0.800)
add_trk('/GPIO8_STRAP', fcu, 43.630, 0.800, 43.525, 0.800)

# 5. Fix CHG_STAT clean jog on B.Cu
for t in list(b.GetTracks()):
    if t.GetNetname() == '/CHG_STAT' and t.GetLayer() == bcu:
        b.Delete(t)

add_trk('/CHG_STAT', bcu, 24.25, 1.00, 39.00, 1.00, 0.18)
add_trk('/CHG_STAT', bcu, 39.00, 1.00, 39.00, 2.30, 0.18)
add_trk('/CHG_STAT', bcu, 39.00, 2.30, 44.00, 2.30, 0.18)
add_trk('/CHG_STAT', bcu, 44.00, 2.30, 44.00, 1.80, 0.18)
add_trk('/CHG_STAT', bcu, 44.00, 1.80, 66.05, 1.80, 0.18)

# 6. Move VSYS_RAW via from (59.50, 2.40) onto D4.1 pad at (59.00, 2.40)
for t in list(b.GetTracks()):
    if t.GetNetname() == '/VSYS_RAW':
        if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 59.50 and round(t.GetPosition().y/1e6, 2) == 2.40:
            b.Delete(t)
        elif t.GetClass() != 'PCB_VIA' and t.GetLayer() == fcu:
            b.Delete(t)

net_vsys = b.FindNet('/VSYS_RAW')
v_vsys = pcbnew.PCB_VIA(b)
v_vsys.SetPosition(pcbnew.VECTOR2I(int(59.000 * 1e6), int(2.400 * 1e6)))
v_vsys.SetWidth(int(0.500 * 1e6))
v_vsys.SetDrill(int(0.300 * 1e6))
v_vsys.SetNet(net_vsys)
b.Add(v_vsys)

# Connect In2.Cu from (59.5, 2.4) to (59.0, 2.4)
t_vsys = pcbnew.PCB_TRACK(b)
t_vsys.SetStart(pcbnew.VECTOR2I(int(59.500 * 1e6), int(2.400 * 1e6)))
t_vsys.SetEnd(pcbnew.VECTOR2I(int(59.000 * 1e6), int(2.400 * 1e6)))
t_vsys.SetWidth(int(0.200 * 1e6))
t_vsys.SetLayer(in2)
t_vsys.SetNet(net_vsys)
b.Add(t_vsys)

# ============================================================
# ROUTE 4 SD NETS
# ============================================================

# --- 1. /SD_CS ---
# U1.13 (43.130, 2.435) -> (43.130, 1.450) via
add_trk('/SD_CS', fcu, 43.130, 2.435, 43.130, 1.450)
add_via('/SD_CS', 43.130, 1.450)
# In2.Cu: (43.130, 1.450) -> (56.975, 1.450) via to R18.2
add_trk('/SD_CS', in2, 43.130, 1.450, 56.975, 1.450)
add_via('/SD_CS', 56.975, 1.450)
add_trk('/SD_CS', fcu, 56.975, 1.450, 56.975, 2.000) # R18.2
# In2.Cu continue east: (56.975, 1.450) -> (59.400, 1.450) -> (59.400, 0.850) via
add_trk('/SD_CS', in2, 56.975, 1.450, 59.400, 1.450)
add_trk('/SD_CS', in2, 59.400, 1.450, 59.400, 0.850)
add_via('/SD_CS', 59.400, 0.850)
# F.Cu: (59.400, 0.850) -> (59.800, 0.850) -> (59.800, 3.600) -> (59.650, 3.600) -> (59.650, 4.200) (J_SD.6)
add_trk('/SD_CS', fcu, 59.400, 0.850, 59.800, 0.850)
add_trk('/SD_CS', fcu, 59.800, 0.850, 59.800, 3.600)
add_trk('/SD_CS', fcu, 59.800, 3.600, 59.650, 3.600)
add_trk('/SD_CS', fcu, 59.650, 3.600, 59.650, 4.200)

# --- 2. /SD_SCK ---
# U1.12 (42.630, 2.435) -> (42.630, 0.500) via
add_trk('/SD_SCK', fcu, 42.630, 2.435, 42.630, 0.500)
add_via('/SD_SCK', 42.630, 0.500)
# In2.Cu: (42.630, 0.500) -> (42.630, 1.150) -> (58.150, 1.150) via
add_trk('/SD_SCK', in2, 42.630, 0.500, 42.630, 1.150)
add_trk('/SD_SCK', in2, 42.630, 1.150, 58.150, 1.150)
add_via('/SD_SCK', 58.150, 1.150)
# F.Cu: straight north to J_SD.3 at (58.150, 4.200)
add_trk('/SD_SCK', fcu, 58.150, 1.150, 58.150, 4.200)

# --- 3. /SD_MOSI ---
# U1.9 (41.130, 2.435) -> (41.130, 1.450) via
add_trk('/SD_MOSI', fcu, 41.130, 2.435, 41.130, 1.450)
add_via('/SD_MOSI', 41.130, 1.450)
# B.Cu: (41.130, 1.450) -> (56.400, 1.450) -> (56.400, 1.000) via
add_trk('/SD_MOSI', bcu, 41.130, 1.450, 56.400, 1.450)
add_trk('/SD_MOSI', bcu, 56.400, 1.450, 56.400, 1.000)
add_via('/SD_MOSI', 56.400, 1.000)
# F.Cu: (56.400, 1.000) -> (56.400, 3.250) -> (58.650, 3.250) -> (58.650, 4.200) (J_SD.4)
add_trk('/SD_MOSI', fcu, 56.400, 1.000, 56.400, 3.250)
add_trk('/SD_MOSI', fcu, 56.400, 3.250, 58.650, 3.250)
add_trk('/SD_MOSI', fcu, 58.650, 3.250, 58.650, 4.200)

# --- 4. /SD_MISO ---
# U1.10 (41.630, 2.435) -> (41.630, 0.500) via
add_trk('/SD_MISO', fcu, 41.630, 2.435, 41.630, 0.500)
add_via('/SD_MISO', 41.630, 0.500)
# B.Cu: (41.630, 0.500) -> (41.630, 1.150) -> (55.500, 1.150) -> (55.500, 0.600) via
add_trk('/SD_MISO', bcu, 41.630, 0.500, 41.630, 1.150)
add_trk('/SD_MISO', bcu, 41.630, 1.150, 55.500, 1.150)
add_trk('/SD_MISO', bcu, 55.500, 1.150, 55.500, 0.600)
add_via('/SD_MISO', 55.500, 0.600)
# F.Cu: (55.500, 0.600) -> (55.500, 3.000) -> (56.000, 3.000) -> (56.000, 3.500) -> (59.150, 3.500) -> (59.150, 4.200) (J_SD.5)
add_trk('/SD_MISO', fcu, 55.500, 0.600, 55.500, 3.000)
add_trk('/SD_MISO', fcu, 55.500, 3.000, 56.000, 3.000)
add_trk('/SD_MISO', fcu, 56.000, 3.000, 56.000, 3.500)
add_trk('/SD_MISO', fcu, 56.000, 3.500, 59.150, 3.500)
add_trk('/SD_MISO', fcu, 59.150, 3.500, 59.150, 4.200)

# Refill all copper zones
print("Refilling zones...")
filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
print("Fill complete.")

b.Save(dst_pcb)
print(f"Successfully saved {dst_pcb}")
