import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

nets_to_inspect = [
    '/VBAT_SW', '/USB_VBUS', '/VSYS_RAW', '/VBAT',
    '/SD_SCK', '/SD_MOSI', '/SD_MISO', '/SD_CS',
    '/USB_DM_CORE', '/USB_DP_CORE'
]

print("=== PADS ===")
for fp in b.GetFootprints():
    ref = fp.GetReference()
    for p in fp.Pads():
        net = p.GetNetname()
        if net in nets_to_inspect:
            pos = p.GetPosition()
            print(f"PAD {ref}.{p.GetNumber()} [{net}] at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})")

print("\n=== EXISTING TRACKS/VIAS ===")
for t in b.Tracks():
    net = t.GetNetname()
    if net in nets_to_inspect:
        if t.GetClass() == 'PCB_VIA':
            pos = t.GetPosition()
            print(f"VIA [{net}] at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})")
        else:
            st = t.GetStart()
            en = t.GetEnd()
            print(f"TRACK [{net}] {t.GetLayerName()} ({st.x/1e6:.3f}, {st.y/1e6:.3f}) -> ({en.x/1e6:.3f}, {en.y/1e6:.3f}) len={t.GetLength()/1e6:.3f}")

sys.exit(0)
