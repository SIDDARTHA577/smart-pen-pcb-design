import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Testing B.Cu corridors from X=54.0 to 70.5:")
for yi in range(68, 76, 1):
    y = yi / 10.0
    s, r = geom.is_segment_legal(54.0, y, 70.5, y, 'B.Cu', '/USB_DM_CORE')
    print(f"B.Cu y={y:.2f}: {s} ({r})")
