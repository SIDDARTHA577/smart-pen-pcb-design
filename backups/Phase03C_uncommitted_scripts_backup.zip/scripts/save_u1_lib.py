import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
u1_board = board.FindFootprintByReference('U1')

# Create a clean footprint clone to save to library
lib_path = 'output/RevG/variants/FourLayer_Candidate/SmartPen.pretty'
ok = pcbnew.FootprintSave(lib_path, u1_board)
print('FootprintSave result:', ok)

