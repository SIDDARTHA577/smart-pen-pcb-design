import sys
sys.path.append('scripts')
import pcbnew
b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
c1 = b.FindFootprintByReference('C1')
print("C1 pos:", c1.GetPosition().x/1e6, c1.GetPosition().y/1e6)
for p in c1.Pads():
    print("  Pad", p.GetNumber(), p.GetPosition().x/1e6, p.GetPosition().y/1e6)
