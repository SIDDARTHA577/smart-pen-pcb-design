import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

s1, r1 = geom.is_segment_legal(58.150, 4.200, 58.150, 5.500, 'F.Cu', '/SD_SCK')
s2, r2 = geom.is_segment_legal(58.150, 5.500, 57.500, 5.500, 'F.Cu', '/SD_SCK')
v, rv = geom.is_via_legal(57.500, 5.500, '/SD_SCK')

print('s1:', s1, r1)
print('s2:', s2, r2)
print('via:', v, rv)
