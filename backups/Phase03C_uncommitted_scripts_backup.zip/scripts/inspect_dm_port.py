import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
dm_port = b.FindNet('/USB_DM_PORT')
print("All tracks/vias for /USB_DM_PORT:")
for t in b.Tracks():
    if t.GetNetCode() == dm_port.GetNetCode():
        if isinstance(t, pcbnew.PCB_VIA):
            pos = t.GetPosition()
            print(f"  VIA at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})")
        else:
            s, e = t.GetStart(), t.GetEnd()
            print(f"  TRACK {t.GetLayerName()} ({s.x/1e6:.3f}, {s.y/1e6:.3f}) -> ({e.x/1e6:.3f}, {e.y/1e6:.3f})")

sys.exit(0)
