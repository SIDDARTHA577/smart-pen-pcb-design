import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
r27 = b.FindFootprintByReference('R27')
print("R27 position:", r27.GetPosition().x/1e6, r27.GetPosition().y/1e6, "rot:", r27.GetOrientationDegrees())
for p in r27.Pads():
    pos = p.GetPosition()
    sz = p.GetSize()
    print(f"  Pad {p.GetNumber()} [{p.GetNetname()}] at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f}), size=({sz.x/1e6:.3f}, {sz.y/1e6:.3f})")

sys.exit(0)
