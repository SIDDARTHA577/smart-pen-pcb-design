import os, sys, math
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try: import wx; wx.DisableAsserts()
except: pass
import pcbnew

b = pcbnew.LoadBoard('scratch_test_restore_vsys.kicad_pcb')

# Proposed F.Cu trace from R18.2 (56.975, 2.000) to J_SD.6 (59.650, 4.200):
# Segment 1: (56.975, 2.000) -> (56.975, 3.250)
# Segment 2: (56.975, 3.250) -> (59.650, 3.250)
# Segment 3: (59.650, 3.250) -> (59.650, 4.200)

segs = [
    (56.975, 2.000, 56.975, 3.250),
    (56.975, 3.250, 59.650, 3.250),
    (59.650, 3.250, 59.650, 4.200)
]

fcu = b.GetLayerID('F.Cu')

print("--- Checking proposed F.Cu segments against all existing F.Cu items ---")
for sx, sy, ex, ey in segs:
    print(f"Checking segment ({sx},{sy}) -> ({ex},{ey}):")
    # Check against all pads on F.Cu
    for fp in b.GetFootprints():
        for p in fp.Pads():
            if not p.IsOnLayer(fcu): continue
            if p.GetNetname() == '/SD_CS': continue
            pos = p.GetPosition()
            px, py = pos.x/1e6, pos.y/1e6
            # Dist to segment
            dx, dy = ex - sx, ey - sy
            L2 = dx*dx + dy*dy
            u = max(0.0, min(1.0, ((px - sx)*dx + (py - sy)*dy) / L2))
            nx, ny = sx + u*dx, sy + u*dy
            d = math.hypot(px - nx, py - ny)
            p_size = max(p.GetSize().x, p.GetSize().y) / 2e6
            clr = d - p_size - 0.075
            if clr < 0.25:
                print(f"  Close to pad {fp.GetReference()}.{p.GetNumber()} ({p.GetNetname()}) at ({px:.3f},{py:.3f}): dist={d:.3f} clr={clr:.3f}")
    # Check against all tracks on F.Cu
    for t in b.GetTracks():
        if t.GetNetname() == '/SD_CS': continue
        if t.GetLayer() != fcu: continue
        ts, te = t.GetStart(), t.GetEnd()
        tsx, tsy, tex, tey = ts.x/1e6, ts.y/1e6, te.x/1e6, te.y/1e6
        # Quick bbox check
        if max(tsx, tex) + 0.5 < min(sx, ex) or min(tsx, tex) - 0.5 > max(sx, ex): continue
        if max(tsy, tey) + 0.5 < min(sy, ey) or min(tsy, tey) - 0.5 > max(sy, ey): continue
        print(f"  Near track on F.Cu {t.GetNetname()} ({tsx:.3f},{tsy:.3f})->({tex:.3f},{tey:.3f})")
