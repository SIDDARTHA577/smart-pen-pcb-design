import sys
sys.path.append('scripts')
import pcbnew

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
for t in b.GetTracks():
    if t.GetNetname() == '/3V3_RTC':
        s, e = t.GetStart(), t.GetEnd()
        print(f"{t.GetClass()} {b.GetLayerName(t.GetLayer())}: ({s.x/1e6:.3f}, {s.y/1e6:.3f}) -> ({e.x/1e6:.3f}, {e.y/1e6:.3f})")
