import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print("TRACKS on B.Cu between X=44 and 58:")
for t in b.GetTracks():
    if not isinstance(t, pcbnew.PCB_VIA) and t.GetLayerName() == 'B.Cu':
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = s.x / 1e6, s.y / 1e6
        ex, ey = e.x / 1e6, e.y / 1e6
        if max(sx, ex) >= 44.0 and min(sx, ex) <= 58.0:
            print(f"  TRACK B.Cu [{t.GetNetname()}] ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})")

sys.exit(0)
