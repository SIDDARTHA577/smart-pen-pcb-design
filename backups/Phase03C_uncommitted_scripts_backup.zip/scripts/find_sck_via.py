import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
# Ensure R27 at (43.5, 1.0)
r27 = b.FindFootprintByReference('R27')
r27.SetPosition(pcbnew.VECTOR2I(int(43.5*1e6), int(1.0*1e6)))

geom = BoardGeometry(b)

print("Checking via for SD_SCK:")
for vx in [42.4, 42.5, 42.6, 42.63, 42.7, 42.8]:
    for vy in [0.4, 0.5, 0.6, 0.7, 0.8, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0]:
        v_ok, rv = geom.is_via_legal(vx, vy, '/SD_SCK')
        if v_ok:
            print(f"SD_SCK via OK at ({vx:.2f}, {vy:.2f})")
