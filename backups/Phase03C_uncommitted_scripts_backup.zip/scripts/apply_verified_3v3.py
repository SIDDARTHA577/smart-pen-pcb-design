import pcbnew

try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

vias_3v3 = {
    'J_SD.1': (56.945, 3.636),
    'U3.6': (21.555, 6.214),
    'U1.17': (45.666, 2.625),
    'R15.1': (20.075, 4.400),
    'R14.1': (20.075, 2.200),
    'C3.1': (49.689, 7.495),
    'J_IMU.1': (1.905, 5.164),
    'C14.1': (69.494, 3.050),
    'R1.1': (37.871, 1.769),
    'R27.1': (42.230, 1.564),
    'U4.5': (68.714, 6.563),
    'R18.1': (56.230, 2.564),
    'R4.1': (35.303, 2.010),
    'C15.1': (5.930, 2.564),
    'R3.1': (36.639, 4.545),
    'R2.1': (51.480, 2.814),
    'FB1.1': (46.080, 7.550),
    'J_TOUCH.1': (8.205, 2.964),
    'R11.1': (5.930, 7.764),
    'C13.1': (25.065, 7.886),
    'R12.1': (13.820, 6.436),
    'R13.1': (19.820, 6.436),
    'J_UART.4': (60.146, 7.807),
    'R10.1': (5.930, 5.164)
}

net_3v3 = board.FindNet('/3V3')
layer_fcu = board.GetLayerID('F.Cu')
layer_in2 = board.GetLayerID('In2.Cu')

def trk(board, net, layer, x1, y1, x2, y2, w=0.18):
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    t.SetWidth(int(w * 1e6))
    t.SetLayer(layer)
    t.SetNet(net)
    board.Add(t)
    return t

def via(board, net, x, y, drill=0.30, dia=0.50):
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    v.SetWidth(int(dia * 1e6))
    v.SetDrill(int(drill * 1e6))
    v.SetNet(net)
    board.Add(v)
    return v

# Place the 24 clean vias and tracks from pads to vias
for fp in board.Footprints():
    ref = fp.GetReference()
    for p in fp.Pads():
        if p.GetNetname() == '/3V3':
            key = f'{ref}.{p.GetNumber()}'
            if key in vias_3v3:
                vx, vy = vias_3v3[key]
                via(board, net_3v3, vx, vy)
                pos = p.GetPosition()
                px, py = pos.x / 1e6, pos.y / 1e6
                trk(board, net_3v3, layer_fcu, px, py, vx, vy)
                print(f'Placed via and track for {key}')

# Place U3.18 connection to C13.1 on F.Cu
trk(board, net_3v3, layer_fcu, 25.150, 4.650, 25.850, 4.650)
trk(board, net_3v3, layer_fcu, 25.850, 4.650, 25.850, 7.200)
trk(board, net_3v3, layer_fcu, 25.850, 7.200, 25.525, 7.500)
print('Connected U3.18 to C13.1 on F.Cu')

# Add In2.Cu zone for /3V3
zone = pcbnew.ZONE(board)
zone.SetNet(net_3v3)
zone.SetLayer(layer_in2)
poly = pcbnew.SHAPE_POLY_SET()
poly.NewOutline()
poly.Append(int(0.25 * 1e6), int(0.25 * 1e6))
poly.Append(int(83.75 * 1e6), int(0.25 * 1e6))
poly.Append(int(83.75 * 1e6), int(8.95 * 1e6))
poly.Append(int(0.25 * 1e6), int(8.95 * 1e6))
zone.SetOutline(poly)
zone.SetMinThickness(int(0.127 * 1e6))
zone.SetThermalReliefGap(int(0.15 * 1e6))
zone.SetThermalReliefSpokeWidth(int(0.18 * 1e6))
zone.SetIslandRemovalMode(2) # Never remove islands
board.Add(zone)

filler = pcbnew.ZONE_FILLER(board)
filler.Fill(board.Zones())
board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('Successfully placed verified 3V3 distribution and zone!')
