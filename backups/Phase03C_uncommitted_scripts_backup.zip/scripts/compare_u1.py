with open('output/RevG/variants/FourLayer_Candidate/SmartPen.pretty/U1.kicad_mod', 'r') as f:
    text = f.read()

import re
pads = re.findall(r'\(pad\s+"[^"]+".*?\)', text, re.DOTALL)
print(f'Found {len(pads)} pads in U1.kicad_mod')
if pads:
    print('Sample pad:', pads[0][:150])
