import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Checking I2C_SCL route:")
# West:
s_w_fcu, rw_fcu = geom.is_segment_legal(4.700, 4.600, 4.700, 7.150, 'F.Cu', '/I2C_SCL')
s_w_fcu2, rw_fcu2 = geom.is_segment_legal(4.700, 7.150, 6.675, 7.200, 'F.Cu', '/I2C_SCL')
s_w_fcu3, rw_fcu3 = geom.is_segment_legal(6.675, 7.200, 7.800, 7.150, 'F.Cu', '/I2C_SCL')
v_w_bcu, rvw = geom.is_via_legal(7.800, 7.150, '/I2C_SCL')
s_w_bcu, rw_bcu = geom.is_segment_legal(7.800, 7.150, 24.250, 7.150, 'B.Cu', '/I2C_SCL')
print(f"West: f1={s_w_fcu}({rw_fcu}), f2={s_w_fcu2}({rw_fcu2}), f3={s_w_fcu3}({rw_fcu3}), v={v_w_bcu}({rvw}), bcu={s_w_bcu}({rw_bcu})")

# East:
s_e_bcu, re_bcu = geom.is_segment_legal(24.250, 7.150, 39.500, 7.150, 'B.Cu', '/I2C_SCL')
s_e_bcu2, re_bcu2 = geom.is_segment_legal(39.500, 7.150, 39.500, 4.585, 'B.Cu', '/I2C_SCL')
v_e, rve = geom.is_via_legal(39.500, 4.585, '/I2C_SCL')
s_e_fcu, re_fcu = geom.is_segment_legal(39.500, 4.585, 40.480, 4.585, 'F.Cu', '/I2C_SCL')
print(f"East: bcu1={s_e_bcu}({re_bcu}), bcu2={s_e_bcu2}({re_bcu2}), v={v_e}({rve}), fcu={s_e_fcu}({re_fcu})")

sys.exit(0)
