import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
for t in b.Tracks():
    if t.GetNetname() == '/VBAT_SW' and t.GetLayerName() == 'F.Cu':
        s, e = t.GetStart(), t.GetEnd()
        l = t.GetLength() / 1e6
        print(f"TRACK F.Cu ({s.x/1e6:.3f}, {s.y/1e6:.3f}) -> ({e.x/1e6:.3f}, {e.y/1e6:.3f}) len={l:.4f}")

sys.exit(0)
