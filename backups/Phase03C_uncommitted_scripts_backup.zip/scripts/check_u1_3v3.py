import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")

print("--- 3V3 pads and tracks around U1 (X=35..48, Y=0..5) ---")
for fp in b.GetFootprints():
    for p in fp.Pads():
        if p.GetNetname() == '/3V3':
            pos = p.GetPosition()
            x, y = pos.x/1e6, pos.y/1e6
            if 35 <= x <= 48 and 0 <= y <= 5:
                print(f"FP: {fp.GetReference()} Pad: {p.GetNumber()} at ({x:.3f}, {y:.3f})")

for t in b.GetTracks():
    if t.GetNetname() == '/3V3':
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (35 <= x1 <= 48 or 35 <= x2 <= 48) and (0 <= y1 <= 5 or 0 <= y2 <= 5):
            if t.GetClass() == 'PCB_VIA':
                print(f"3V3 VIA at ({x1:.3f}, {y1:.3f})")
            else:
                print(f"3V3 TRK {b.GetLayerName(t.GetLayer())}: ({x1:.3f}, {y1:.3f}) -> ({x2:.3f}, {y2:.3f})")
