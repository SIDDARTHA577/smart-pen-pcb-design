import pcbnew, math

b = pcbnew.LoadBoard("scratch_test_clean_step5.kicad_pcb")

# Find where a via for SD_CS can be placed
# It connects to In2.Cu (where SD_CS runs) and F.Cu (where it reaches R18.2 at 56.975, 2.000)
# It passes through B.Cu, so it must avoid CHG_STAT (which runs along Y=1.800 on B.Cu)

# Let's check all (x, y) in X in [54.0, 58.0], Y in [0.5, 3.5]
# Let's test with KiCad DRC!

# First, what if CHG_STAT on B.Cu jogs?
# Where is CHG_STAT? CHG_STAT is at Y=1.800.
# If CHG_STAT at X=55.0 jogs to Y=2.300:
print("Checking B.Cu around X=55..58, Y=2.0..2.5:")
for t in b.GetTracks():
    if t.GetLayer() == b.GetLayerID('B.Cu') and t.GetNetname() != '/CHG_STAT':
        p1, p2 = t.GetStart(), t.GetEnd()
        print(f"B.Cu TRK {t.GetNetname()}: ({p1.x/1e6:.2f}, {p1.y/1e6:.2f}) -> ({p2.x/1e6:.2f}, {p2.y/1e6:.2f})")
    elif t.GetClass() == 'PCB_VIA':
        p = t.GetPosition()
        if 54.0 <= p.x/1e6 <= 58.0 and 1.0 <= p.y/1e6 <= 3.0:
            print(f"VIA {t.GetNetname()}: ({p.x/1e6:.3f}, {p.y/1e6:.3f})")
