with open('output/RevG/variants/FourLayer_Candidate/SmartPen.pretty/U1.kicad_mod') as f:
    text = f.read()
import re
m = re.search(r'\(pad\s+"1".*?\)', text, re.DOTALL)
if m:
    print(m.group(0))
else:
    print('Not found')

