import sys, math
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_restore_vsys.kicad_pcb')
geom = BoardGeometry(b)

# Nets:
# J_SD.3 (/SD_SCK)  at (58.150, 4.200)
# J_SD.4 (/SD_MOSI) at (58.650, 4.200)
# J_SD.5 (/SD_MISO) at (59.150, 4.200)
# J_SD.6 (/SD_CS)   at (59.650, 4.200)
# R18.2  (/SD_CS)   at (56.975, 2.000)

nets = ['/SD_SCK', '/SD_MOSI', '/SD_MISO', '/SD_CS']
pins = {
    '/SD_SCK': (58.150, 4.200),
    '/SD_MOSI': (58.650, 4.200),
    '/SD_MISO': (59.150, 4.200),
    '/SD_CS': (59.650, 4.200)
}

# Find all legal vias for each net in the east region
legal_vias = {net: [] for net in nets}

# Search box: X in [56.0, 60.5], Y in [0.4, 5.8]
xs = [round(56.0 + 0.1 * i, 3) for i in range(46)]
ys = [round(0.4 + 0.1 * i, 3) for i in range(55)]

for net in nets:
    for x in xs:
        for y in ys:
            v_ok, _ = geom.is_via_legal(x, y, net)
            if v_ok:
                legal_vias[net].append((x, y))

print("Legal via counts per net:")
for net in nets:
    print(f"  {net}: {len(legal_vias[net])} legal spots")

# Find a combination of 4 vias (one for each net) such that:
# 1. pairwise distance >= 0.65 mm
# 2. for each net, there is a legal F.Cu segment from pin to via
# 3. for each net, the via can reach its horizontal track layer (In2.Cu or B.Cu)

valid_combos = []
for v_sck in legal_vias['/SD_SCK']:
    # Check if SCK via can connect to J_SD.3 on F.Cu
    s_ok, _ = geom.is_segment_legal(pins['/SD_SCK'][0], pins['/SD_SCK'][1], v_sck[0], v_sck[1], 'F.Cu', '/SD_SCK')
    if not s_ok: continue
    for v_mosi in legal_vias['/SD_MOSI']:
        if math.hypot(v_sck[0] - v_mosi[0], v_sck[1] - v_mosi[1]) < 0.65: continue
        s_ok, _ = geom.is_segment_legal(pins['/SD_MOSI'][0], pins['/SD_MOSI'][1], v_mosi[0], v_mosi[1], 'F.Cu', '/SD_MOSI')
        if not s_ok: continue
        for v_miso in legal_vias['/SD_MISO']:
            if math.hypot(v_sck[0] - v_miso[0], v_sck[1] - v_miso[1]) < 0.65: continue
            if math.hypot(v_mosi[0] - v_miso[0], v_mosi[1] - v_miso[1]) < 0.65: continue
            s_ok, _ = geom.is_segment_legal(pins['/SD_MISO'][0], pins['/SD_MISO'][1], v_miso[0], v_miso[1], 'F.Cu', '/SD_MISO')
            if not s_ok: continue
            for v_cs in legal_vias['/SD_CS']:
                if math.hypot(v_sck[0] - v_cs[0], v_sck[1] - v_cs[1]) < 0.65: continue
                if math.hypot(v_mosi[0] - v_cs[0], v_mosi[1] - v_cs[1]) < 0.65: continue
                if math.hypot(v_miso[0] - v_cs[0], v_miso[1] - v_cs[1]) < 0.65: continue
                s_ok, _ = geom.is_segment_legal(pins['/SD_CS'][0], pins['/SD_CS'][1], v_cs[0], v_cs[1], 'F.Cu', '/SD_CS')
                if not s_ok: continue
                valid_combos.append((v_sck, v_mosi, v_miso, v_cs))
                if len(valid_combos) >= 5:
                    break
            if len(valid_combos) >= 5: break
        if len(valid_combos) >= 5: break
    if len(valid_combos) >= 5: break

print(f"Found {len(valid_combos)} valid combinations!")
for i, (v_sck, v_mosi, v_miso, v_cs) in enumerate(valid_combos):
    print(f"Combo {i+1}:")
    print(f"  SCK:  {v_sck}")
    print(f"  MOSI: {v_mosi}")
    print(f"  MISO: {v_miso}")
    print(f"  CS:   {v_cs}")
