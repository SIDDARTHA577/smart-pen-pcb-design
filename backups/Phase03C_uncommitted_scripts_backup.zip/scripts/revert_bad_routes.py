import pcbnew

try:
    import wx
    wx.DisableAsserts()
except: pass

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

# Nets that need to be reverted and rerouted
problem_nets = [
    '/USB_CC1', '/USB_CC2', '/USB_DM_PORT', '/USB_DP_PORT',
    '/USB_DP_CORE', '/USB_DM_CORE',
    '/3V3_RTC', '/SD_SCK', '/SD_MOSI', '/SD_MISO', '/SD_CS',
    '/I2C_SCL', '/3V3_RF',
    '/USB_VBUS', '/VBAT', '/VSYS_RAW', '/VBAT_SW',
    '/BTN_MODE', '/LED_GREEN_SINK', '/LED_RED_SINK',
    '/HAPTIC_GATE_DRIVE', '/CHG_STAT'
]

# Record BASELINE tracks (from before route_all_remaining.py was run)
# These are the existing tracks that should be preserved
baseline_tracks = {
    '/USB_DM_PORT': [
        ('F.Cu', 78.650, 3.100, 78.650, 0.550),
        ('F.Cu', 72.000, 0.550, 72.000, 3.190),
        ('B.Cu', 72.000, 0.550, 78.650, 0.550),
    ],
    '/USB_DP_PORT': [
        ('F.Cu', 71.050, 1.200, 71.050, 3.190),
        ('F.Cu', 78.150, 3.100, 78.150, 1.200),
        ('B.Cu', 71.050, 1.200, 78.150, 1.200),
    ],
    '/I2C_SCL': [
        ('F.Cu', 24.250, 6.550, 24.250, 7.150),
    ],
    '/3V3_RF': [
        ('F.Cu', 46.705, 7.550, 48.090, 7.550),
    ],
    '/BTN_MODE': [
        ('F.Cu', 16.100, 8.200, 20.980, 8.200),
        ('F.Cu', 20.980, 8.200, 20.980, 7.000),
    ],
    '/HAPTIC_GATE': [
        ('F.Cu', 26.030, 3.910, 26.030, 3.100),
    ],
    '/VBAT_SW': [
        ('B.Cu', 62.963, 4.400, 68.114, 4.400),
    ],
}

baseline_vias = {
    '/USB_DM_PORT': [(78.650, 0.550), (72.000, 0.550)],
    '/USB_DP_PORT': [(78.150, 1.200), (71.050, 1.200)],
    '/I2C_SCL': [(24.250, 7.150)],
}

# Remove all tracks on problem nets
to_del = [t for t in board.GetTracks() if t.GetNetname() in problem_nets]
print(f'Removing {len(to_del)} tracks/vias on problem nets')
for t in to_del:
    board.Remove(t)

# Restore baseline tracks
def trk(netname, layer_name, x1, y1, x2, y2, w=0.18):
    net = board.FindNet(netname)
    layer = board.GetLayerID(layer_name)
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(pcbnew.VECTOR2I(int(x1*1e6), int(y1*1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2*1e6), int(y2*1e6)))
    t.SetWidth(int(w*1e6))
    t.SetLayer(layer)
    t.SetNet(net)
    board.Add(t)

def via_add(netname, x, y, drill=0.30, dia=0.50):
    net = board.FindNet(netname)
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pcbnew.VECTOR2I(int(x*1e6), int(y*1e6)))
    v.SetWidth(int(dia*1e6))
    v.SetDrill(int(drill*1e6))
    v.SetNet(net)
    board.Add(v)

for netname, trks in baseline_tracks.items():
    for layer, x1, y1, x2, y2 in trks:
        trk(netname, layer, x1, y1, x2, y2)

for netname, vias in baseline_vias.items():
    for x, y in vias:
        via_add(netname, x, y)

filler = pcbnew.ZONE_FILLER(board)
filler.Fill(board.Zones())
board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('Reverted problem nets, restored baseline tracks')

