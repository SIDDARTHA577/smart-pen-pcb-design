import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")
in2 = b.GetLayerID('In2.Cu')

print("--- ALL In2.Cu TRACKS between X=40 and 60 ---")
for t in b.GetTracks():
    if t.GetLayer() == in2 and not isinstance(t, pcbnew.PCB_VIA):
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (40 <= x1 <= 60 or 40 <= x2 <= 60):
            print(f"TRK Net: {t.GetNetname()} ({x1:.3f}, {y1:.3f}) -> ({x2:.3f}, {y2:.3f}) W: {t.GetWidth()/1e6:.3f}")
