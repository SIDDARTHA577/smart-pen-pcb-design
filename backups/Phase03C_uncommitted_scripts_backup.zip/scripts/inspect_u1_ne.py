import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print("PADS near U1 northeast (X: 43..50, Y: 0.5..3.5):")
for p in b.GetPads():
    pos = p.GetPosition()
    px, py = pos.x / 1e6, pos.y / 1e6
    if 43.0 <= px <= 50.0 and 0.5 <= py <= 3.5:
        fp = p.GetParentFootprint()
        ref = fp.GetReference() if fp else '?'
        print(f"  {ref}.{p.GetNumber()} [{p.GetNetname()}] at ({px:.3f}, {py:.3f})")

print("\nTRACKS near U1 northeast (X: 43..50, Y: 0.5..3.5):")
for t in b.GetTracks():
    s, e = t.GetStart(), t.GetEnd()
    sx, sy = s.x / 1e6, s.y / 1e6
    ex, ey = e.x / 1e6, e.y / 1e6
    if ((43.0 <= sx <= 50.0 and 0.5 <= sy <= 3.5) or 
        (43.0 <= ex <= 50.0 and 0.5 <= ey <= 3.5)):
        print(f"  TRACK {t.GetLayerName()} [{t.GetNetname()}] ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})")

sys.exit(0)
