import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- F.Cu items between X=40..53, Y=4.5..7.5 ---')
for fp in board.Footprints():
    for p in fp.Pads():
        pos = p.GetPosition()
        px, py = pos.x/1e6, pos.y/1e6
        if 40 <= px <= 53 and 4.5 <= py <= 7.5:
            print(f'Pad {fp.GetReference()}.{p.GetNumber()} [{p.GetNetname()}] at ({px:.3f}, {py:.3f})')

for t in board.GetTracks():
    if t.GetLayer() == pcbnew.F_Cu:
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = s.x/1e6, s.y/1e6
        ex, ey = e.x/1e6, e.y/1e6
        if max(sx, ex) >= 40 and min(sx, ex) <= 53 and max(sy, ey) >= 4.5 and min(sy, ey) <= 7.5:
            print(f'Track {t.GetNetname()}: ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})')

