import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
import shutil

shutil.copy('scratch_test_vip.kicad_pcb', 'scratch_test_perfect.kicad_pcb')
shutil.copy('scratch_test_vip.kicad_pro', 'scratch_test_perfect.kicad_pro')

b = pcbnew.LoadBoard('scratch_test_perfect.kicad_pcb')

# 1. Delete freestanding GND via at (55.00, 1.20)
for t in list(b.GetTracks()):
    if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 55.00 and round(t.GetPosition().y/1e6, 2) == 1.20:
        b.Delete(t)

# 2. Fix VSYS_RAW via: move from (59.5, 2.4) to (59.0, 1.2)
for t in list(b.GetTracks()):
    if t.GetNetname() == '/VSYS_RAW':
        if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 59.50 and round(t.GetPosition().y/1e6, 2) == 2.40:
            t.SetPosition(pcbnew.VECTOR2I(int(59.000*1e6), int(1.200*1e6)))
        elif t.GetClass() != 'PCB_VIA':
            s, e = t.GetStart(), t.GetEnd()
            if round(s.x/1e6, 2) == 59.50 and round(s.y/1e6, 2) == 2.40:
                t.SetStart(pcbnew.VECTOR2I(int(59.000*1e6), int(1.200*1e6)))
            if round(e.x/1e6, 2) == 59.50 and round(e.y/1e6, 2) == 2.40:
                t.SetEnd(pcbnew.VECTOR2I(int(59.000*1e6), int(1.200*1e6)))

net_vsys = b.FindNet('/VSYS_RAW')
t_vsys = pcbnew.PCB_TRACK(b)
t_vsys.SetStart(pcbnew.VECTOR2I(int(59.000*1e6), int(2.400*1e6)))
t_vsys.SetEnd(pcbnew.VECTOR2I(int(59.000*1e6), int(1.200*1e6)))
t_vsys.SetWidth(int(0.15*1e6))
t_vsys.SetLayer(b.GetLayerID('F.Cu'))
t_vsys.SetNet(net_vsys)
b.Add(t_vsys)

# 3. Fix GPIO8_STRAP: jog down at X=43.630 to Y=1.000, then turn west to R27.2 (42.975, 1.000)
for t in list(b.GetTracks()):
    if t.GetNetname() == '/GPIO8_STRAP':
        b.Delete(t)

net_strap = b.FindNet('/GPIO8_STRAP')
def add_trk(layer, sx, sy, ex, ey, net, w=0.15):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(sx*1e6), int(sy*1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(ex*1e6), int(ey*1e6)))
    t.SetWidth(int(w*1e6))
    t.SetLayer(b.GetLayerID(layer))
    t.SetNet(net)
    b.Add(t)
    return t

def add_via(x, y, net, dia=0.50, drill=0.30):
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(int(x*1e6), int(y*1e6)))
    v.SetWidth(int(dia*1e6))
    v.SetDrill(int(drill*1e6))
    v.SetTopLayer(b.GetLayerID('F.Cu'))
    v.SetBottomLayer(b.GetLayerID('B.Cu'))
    v.SetNet(net)
    b.Add(v)
    return v

add_trk('F.Cu', 43.630, 2.435, 43.630, 1.000, net_strap)
add_trk('F.Cu', 43.630, 1.000, 42.975, 1.000, net_strap)

# 4. Clear existing SD tracks
net_cs   = b.FindNet('/SD_CS')
net_sck  = b.FindNet('/SD_SCK')
net_mosi = b.FindNet('/SD_MOSI')
net_miso = b.FindNet('/SD_MISO')

for net in [net_cs, net_sck, net_mosi, net_miso]:
    for t in list(b.GetTracks()):
        if t.GetNet() == net:
            b.Delete(t)

# --- 1. ROUTE SD_CS ---
# U1.13 (43.130, 2.435) -> (43.130, 1.750) -> via to In2.Cu
add_trk('F.Cu', 43.130, 2.435, 43.130, 1.750, net_cs)
add_via(43.130, 1.750, net_cs)
# In2.Cu: (43.130, 1.750) -> (43.130, 1.200) -> (56.975, 1.200)
add_trk('In2.Cu', 43.130, 1.750, 43.130, 1.200, net_cs)
add_trk('In2.Cu', 43.130, 1.200, 56.975, 1.200, net_cs)
# Connect to R18.2: via at (56.975, 1.200) -> F.Cu to (56.975, 2.000)
# But wait, to avoid cutting 3V3 plane, place via at (57.100, 1.200)
add_via(57.100, 1.200, net_cs)
add_trk('In2.Cu', 56.975, 1.200, 57.100, 1.200, net_cs)
add_trk('F.Cu', 57.100, 1.200, 56.975, 2.000, net_cs)
# Continue on In2.Cu to (59.400, 1.200) -> (59.400, 0.850) -> via
add_trk('In2.Cu', 57.100, 1.200, 59.400, 1.200, net_cs)
add_trk('In2.Cu', 59.400, 1.200, 59.400, 0.850, net_cs)
add_via(59.400, 0.850, net_cs)
# F.Cu: (59.400, 0.850) -> (59.800, 0.850) -> (59.800, 3.600) -> (59.650, 4.200) (J_SD.6)
add_trk('F.Cu', 59.400, 0.850, 59.800, 0.850, net_cs)
add_trk('F.Cu', 59.800, 0.850, 59.800, 3.600, net_cs)
add_trk('F.Cu', 59.800, 3.600, 59.650, 4.200, net_cs)

# --- 2. ROUTE SD_SCK ---
# J_SD.3 (58.150, 4.200) -> (58.150, 5.500) -> (57.500, 5.500) -> via to B.Cu
add_trk('F.Cu', 58.150, 4.200, 58.150, 5.500, net_sck)
add_trk('F.Cu', 58.150, 5.500, 57.500, 5.500, net_sck)
add_via(57.500, 5.500, net_sck)
# B.Cu: (57.500, 5.500) -> (57.500, 2.200) -> (57.000, 2.200) -> (57.000, 1.450) -> via to In2.Cu
add_trk('B.Cu', 57.500, 5.500, 57.500, 2.200, net_sck)
add_trk('B.Cu', 57.500, 2.200, 57.000, 2.200, net_sck)
add_trk('B.Cu', 57.000, 2.200, 57.000, 1.450, net_sck)
add_via(57.000, 1.450, net_sck)
# In2.Cu: (57.000, 1.450) -> (43.000, 1.450)
add_trk('In2.Cu', 57.000, 1.450, 43.000, 1.450, net_sck)
# To U1.12 (42.630, 2.435): via at (43.000, 2.100) or (42.630, 2.100)
# Let's check via at (42.630, 2.100):
add_trk('In2.Cu', 43.000, 1.450, 43.000, 2.100, net_sck)
add_trk('In2.Cu', 43.000, 2.100, 42.630, 2.100, net_sck)
add_via(42.630, 2.100, net_sck)
add_trk('F.Cu', 42.630, 2.100, 42.630, 2.435, net_sck)

# Refill zones
filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())

b.Save('scratch_test_perfect.kicad_pcb')
print("Successfully saved scratch_test_perfect.kicad_pcb")
