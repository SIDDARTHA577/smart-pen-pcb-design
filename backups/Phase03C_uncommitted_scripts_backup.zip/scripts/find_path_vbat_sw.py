import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# Print all vias and tracks on B.Cu between X=25 and 65, Y=2.5 and 6.5
print("All obstacles between X=25 and 65, Y=2.5 and 6.5:")
for v in geom.vias:
    if 25.0 <= v['x'] <= 65.0 and 2.5 <= v['y'] <= 6.5:
        print(f"  VIA [{v['net']}] at ({v['x']:.3f}, {v['y']:.3f})")

for t in geom.tracks:
    if t['layer'] == 'B.Cu':
        if max(t['x1'], t['x2']) >= 25.0 and min(t['x1'], t['x2']) <= 65.0:
            if max(t['y1'], t['y2']) >= 2.5 and min(t['y1'], t['y2']) <= 6.5:
                print(f"  TRACK B.Cu [{t['net']}] ({t['x1']:.3f}, {t['y1']:.3f}) -> ({t['x2']:.3f}, {t['y2']:.3f})")

sys.exit(0)
