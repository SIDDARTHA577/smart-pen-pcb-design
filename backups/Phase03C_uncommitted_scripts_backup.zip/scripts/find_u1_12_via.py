import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

print("Searching via for U1.12 (/SD_SCK):")
for vx in [42.3, 42.4, 42.5, 42.63, 42.7, 42.8, 42.9, 43.0, 43.1]:
    for vy in [0.4, 0.5, 0.6, 0.7, 0.8, 1.0, 1.2, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0]:
        v, rv = geom.is_via_legal(vx, vy, '/SD_SCK')
        if v:
            print(f"Via OK at ({vx:.2f}, {vy:.2f})")
