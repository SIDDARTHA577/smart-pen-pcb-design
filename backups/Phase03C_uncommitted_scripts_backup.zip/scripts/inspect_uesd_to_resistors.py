import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- PADS in X: 70.5..73.0, Y: 3.0..8.2 ---')
for p in board.GetPads():
    pos = p.GetPosition()
    x, y = pos.x / 1e6, pos.y / 1e6
    if 70.5 <= x <= 73.0 and 3.0 <= y <= 8.2:
        fp = p.GetParentFootprint()
        ref = fp.GetReference() if fp else '?'
        print(f'{ref}.{p.GetNumber()} [{p.GetNetname()}] at ({x:.3f}, {y:.3f}) size ({p.GetSize().x/1e6:.3f}, {p.GetSize().y/1e6:.3f})')

