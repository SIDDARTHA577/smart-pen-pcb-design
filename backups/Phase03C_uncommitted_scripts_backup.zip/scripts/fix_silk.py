import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

for ref in ['R26', 'D4', 'Q2']:
    fp = board.FindFootprintByReference(ref)
    ref_field = fp.Reference()
    # hide the silkscreen reference
    ref_field.SetVisible(False)

# Adjust J_USB silkscreen lines
j_usb = board.FindFootprintByReference('J_USB')
for g in j_usb.GraphicalItems():
    if g.GetLayer() == pcbnew.F_SilkS and g.GetShapeStr() == 'Line':
        # Check if line is at X=73.93 or X=82.87
        sx = round(g.GetStart().x / 1e6, 2)
        ex = round(g.GetEnd().x / 1e6, 2)
        if sx in [73.93, 82.87] and ex in [73.93, 82.87]:
            # Move to F_Fab or shorten
            g.SetLayer(pcbnew.F_Fab)

board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('Adjusted silkscreen on candidate PCB')

