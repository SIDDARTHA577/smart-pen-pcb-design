import json
from pathlib import Path

with open("scratch_candidate_drc.json", "r", encoding="utf-8") as f:
    d = json.load(f)

print("=== Violations involving Tracks and Vias ===")
tracks_to_fix = set()
for v in d.get("violations", []):
    vtype = v.get("type")
    if vtype in ["clearance", "hole_clearance", "shorting_items", "track_dangling", "via_dangling"]:
        print(f"[{vtype}] {v.get('description')}")
        for it in v.get("items", []):
            desc = it.get("description", "")
            pos = it.get("pos", {})
            uuid = it.get("uuid", "")
            print(f"    {desc} @ ({pos.get('x')}, {pos.get('y')}) uuid={uuid}")
            if "Track" in desc or "Via" in desc:
                tracks_to_fix.add((desc, uuid, pos.get("x"), pos.get("y")))

print(f"\nTotal offending track/via items: {len(tracks_to_fix)}")
