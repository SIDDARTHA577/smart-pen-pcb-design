import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
# Move 3V3_RTC via to (42.130, 0.700)
for t in list(b.GetTracks()):
    if t.GetNetname() == '/3V3_RTC':
        if t.GetClass() == 'PCB_VIA' and abs(t.GetPosition().x/1e6 - 42.13) < 0.1:
            t.SetPosition(pcbnew.VECTOR2I(int(42.130*1e6), int(0.700*1e6)))
        elif t.GetClass() == 'PCB_TRACK' and b.GetLayerName(t.GetLayer()) == 'F.Cu':
            s, e = t.GetStart(), t.GetEnd()
            if abs(s.x/1e6 - 42.13) < 0.1 and abs(e.x/1e6 - 42.13) < 0.1:
                t.SetStart(pcbnew.VECTOR2I(int(42.130*1e6), int(0.700*1e6)))
                t.SetEnd(pcbnew.VECTOR2I(int(42.130*1e6), int(2.435*1e6)))
        elif t.GetClass() == 'PCB_TRACK' and b.GetLayerName(t.GetLayer()) == 'In2.Cu':
            s, e = t.GetStart(), t.GetEnd()
            if abs(e.x/1e6 - 42.13) < 0.1 and abs(e.y/1e6 - 1.8) < 0.1:
                t.SetEnd(pcbnew.VECTOR2I(int(42.130*1e6), int(0.700*1e6)))
            elif abs(s.x/1e6 - 42.13) < 0.1 and abs(e.x/1e6 - 42.13) < 0.1:
                t.SetStart(pcbnew.VECTOR2I(int(42.130*1e6), int(1.100*1e6)))
                t.SetEnd(pcbnew.VECTOR2I(int(42.130*1e6), int(0.700*1e6)))

geom = BoardGeometry(b)
print("3V3_RTC via at (42.13, 0.70):", geom.is_via_legal(42.130, 0.700, '/3V3_RTC'))
print("SD_SCK via at (42.63, 1.75):", geom.is_via_legal(42.630, 1.750, '/SD_SCK'))
print("SD_CS via at (43.13, 1.75):", geom.is_via_legal(43.130, 1.750, '/SD_CS'))
print("Distance between SCK via and CS via:", 43.13 - 42.63)
