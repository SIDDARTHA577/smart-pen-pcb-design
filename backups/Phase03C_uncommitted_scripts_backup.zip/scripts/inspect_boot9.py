import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- Pads around X in [44, 53], Y in [0.5, 2.6] ---')
for fp in board.Footprints():
    for p in fp.Pads():
        pos = p.GetPosition()
        px, py = pos.x/1e6, pos.y/1e6
        if 44 <= px <= 53 and 0.5 <= py <= 2.6:
            print(f'Pad {fp.GetReference()}.{p.GetNumber()} [{p.GetNetname()}] at ({px:.3f}, {py:.3f}), size ({p.GetSize().x/1e6:.3f}, {p.GetSize().y/1e6:.3f})')

print('--- Tracks on B.Cu in X in [44, 53], Y in [0.5, 2.6] ---')
for t in board.GetTracks():
    if t.GetLayer() == pcbnew.B_Cu:
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = s.x/1e6, s.y/1e6
        ex, ey = e.x/1e6, e.y/1e6
        if max(sx, ex) >= 44 and min(sx, ex) <= 53 and max(sy, ey) >= 0.5 and min(sy, ey) <= 2.6:
            print(f'B.Cu {t.GetNetname()}: ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})')

