import json

with open('reports/RevG/Phase03C/raw/candidate_vbus_drc.json', 'r') as f:
    d = json.load(f)

unconn = d.get('unconnected_items', [])
print(f"Total unconnected items: {len(unconn)}")
for idx, u in enumerate(unconn):
    items = [i.get('description', '') for i in u.get('items', [])]
    print(f"[{idx+1}] {u.get('type')}: {' <---> '.join(items)}")
