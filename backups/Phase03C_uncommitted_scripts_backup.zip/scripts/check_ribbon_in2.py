import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
# Delete freestanding GND via at (55.00, 1.20)
for t in list(b.GetTracks()):
    if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 55.00 and round(t.GetPosition().y/1e6, 2) == 1.20:
        b.Delete(t)

# Move VSYS_RAW via from (59.5, 2.4) to (59.0, 1.2)
for t in list(b.GetTracks()):
    if t.GetNetname() == '/VSYS_RAW':
        if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 59.50 and round(t.GetPosition().y/1e6, 2) == 2.40:
            t.SetPosition(pcbnew.VECTOR2I(int(59.000*1e6), int(1.200*1e6)))

geom = BoardGeometry(b)

print("Checking 4 Ribbon tracks on In2.Cu:")
# 1. SD_CS at Y=0.850: from X=43.000 to X=59.300
s1, r1 = geom.is_segment_legal(43.000, 0.850, 59.300, 0.850, 'In2.Cu', '/SD_CS')
print(f"1. SD_CS (Y=0.850): {s1} ({r1})")

# 2. SD_MOSI at Y=1.150: from X=41.130 to X=57.400
s2, r2 = geom.is_segment_legal(41.130, 1.150, 57.400, 1.150, 'In2.Cu', '/SD_MOSI')
print(f"2. SD_MOSI (Y=1.150): {s2} ({r2})")

# 3. SD_SCK at Y=1.450: from X=42.630 to X=57.500
s3, r3 = geom.is_segment_legal(42.630, 1.450, 57.500, 1.450, 'In2.Cu', '/SD_SCK')
print(f"3. SD_SCK (Y=1.450): {s3} ({r3})")

# 4. SD_MISO at Y=1.750: from X=41.400 to X=59.650
s4, r4 = geom.is_segment_legal(41.400, 1.750, 59.650, 1.750, 'In2.Cu', '/SD_MISO')
print(f"4. SD_MISO (Y=1.750): {s4} ({r4})")
