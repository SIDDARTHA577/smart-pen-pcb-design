import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

board_path = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb'
b = pcbnew.LoadBoard(board_path)

fcu = b.GetLayerID('F.Cu')
in1 = b.GetLayerID('In1.Cu')
in2 = b.GetLayerID('In2.Cu')
bcu = b.GetLayerID('B.Cu')

def add_track(net, layer, x1, y1, x2, y2, w=0.18):
    t = pcbnew.PCB_TRACK(b)
    t.SetNet(net)
    t.SetLayer(layer)
    t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    t.SetWidth(int(w * 1e6))
    b.Add(t)

def add_via(net, x, y, dia=0.50, drill=0.30):
    v = pcbnew.PCB_VIA(b)
    v.SetNet(net)
    v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    v.SetWidth(int(dia * 1e6))
    v.SetDrill(int(drill * 1e6))
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    b.Add(v)

tracks = [t for t in b.Tracks()]

# 1. Fix VBAT_SW Y=4.800 -> Y=4.500
vbat_net = b.FindNet('/VBAT_SW')
for t in tracks:
    if t.GetNetname() == '/VBAT_SW' and t.GetLayerName() == 'B.Cu':
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = s.x / 1e6, s.y / 1e6
        ex, ey = e.x / 1e6, e.y / 1e6
        if abs(sy - 4.8) < 0.05 and abs(ey - 4.8) < 0.05:
            b.Remove(t)
        elif abs(sy - 4.05) < 0.05 and abs(ey - 4.8) < 0.05:
            b.Remove(t)
        elif abs(sy - 4.8) < 0.05 and abs(ey - 4.4) < 0.05:
            b.Remove(t)

# Add clean Y=4.500 segment
add_track(vbat_net, bcu, 38.000, 4.050, 40.500, 4.500)
add_track(vbat_net, bcu, 40.500, 4.500, 52.000, 4.500)
add_track(vbat_net, bcu, 52.000, 4.500, 54.000, 4.400)

# Connect West VBAT_SW:
# From via (28.090, 4.400) to D3.1 (28.086, 4.704)
# And to J_MOT.1 (30.753, 6.285) via F.Cu: (28.086, 4.704) -> (28.086, 7.800) -> (30.753, 7.800) -> (30.753, 6.285)
# Wait, let's remove any isolated via at (30.753, 7.200)
for t in [tr for tr in b.Tracks()]:
    if isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/VBAT_SW':
        pos = t.GetPosition()
        if abs(pos.x/1e6 - 30.753) < 0.2:
            b.Remove(t)

# Connect D3.1 to J_MOT.1 around GND via (28.00, 6.40):
# Run at X=29.00 on F.Cu!
add_track(vbat_net, fcu, 28.086, 4.704, 29.000, 4.704)
add_track(vbat_net, fcu, 29.000, 4.704, 29.000, 7.800)
add_track(vbat_net, fcu, 29.000, 7.800, 30.753, 7.800)
add_track(vbat_net, fcu, 30.753, 7.800, 30.753, 6.285)

# Refill and save
filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
b.Save(board_path)
print("VBAT_SW fixed cleanly!")
sys.exit(0)
