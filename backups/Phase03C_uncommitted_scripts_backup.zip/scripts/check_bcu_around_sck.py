import sys
sys.path.append('scripts')
import pcbnew

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
print("=== B.Cu tracks from X=56 to 58, Y=1.0 to 6.0 ===")
for t in b.GetTracks():
    if b.GetLayerName(t.GetLayer()) == 'B.Cu':
        s = t.GetStart()
        e = t.GetEnd()
        sx, sy = s.x/1e6, s.y/1e6
        ex, ey = e.x/1e6, e.y/1e6
        if (56.0 <= sx <= 58.0 or 56.0 <= ex <= 58.0) and (1.0 <= sy <= 6.0 or 1.0 <= ey <= 6.0):
            print(f"{t.GetClass()} net={t.GetNetname()}: ({sx:.2f}, {sy:.2f}) -> ({ex:.2f}, {ey:.2f})")
