import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')

# Move R27 to (44.5, 1.0)
r27 = b.FindFootprintByReference('R27')
r27.SetPosition(pcbnew.VECTOR2I(int(44.5*1e6), int(1.0*1e6)))

# Remove old GPIO8_STRAP and 3V3 via for R27
for t in list(b.GetTracks()):
    if t.GetNetname() == '/GPIO8_STRAP':
        b.Delete(t)
    elif t.GetNetname() == '/3V3' and (round(t.GetPosition().x/1e6, 1) == 42.0 or (t.GetClass() != 'PCB_VIA' and round(t.GetStart().x/1e6, 1) == 42.0)):
        b.Delete(t)

# Add 3V3 via for R27 at (44.0, 0.5)
net_3v3 = b.FindNet('/3V3')
v_3v3 = pcbnew.PCB_VIA(b)
v_3v3.SetPosition(pcbnew.VECTOR2I(int(44.0*1e6), int(0.5*1e6)))
v_3v3.SetWidth(int(0.5*1e6))
v_3v3.SetDrill(int(0.3*1e6))
v_3v3.SetTopLayer(b.GetLayerID('F.Cu'))
v_3v3.SetBottomLayer(b.GetLayerID('B.Cu'))
v_3v3.SetNet(net_3v3)
b.Add(v_3v3)

# Track from R27.1 (44.025, 1.000) to via (44.0, 0.5)
t_3v3 = pcbnew.PCB_TRACK(b)
t_3v3.SetStart(pcbnew.VECTOR2I(int(44.025*1e6), int(1.0*1e6)))
t_3v3.SetEnd(pcbnew.VECTOR2I(int(44.0*1e6), int(0.5*1e6)))
t_3v3.SetWidth(int(0.15*1e6))
t_3v3.SetLayer(b.GetLayerID('F.Cu'))
t_3v3.SetNet(net_3v3)
b.Add(t_3v3)

# Connect GPIO8_STRAP from U1.14 (43.630, 2.435) to R27.2 (44.975, 1.000)
# (43.630, 2.435) -> (43.630, 1.000) -> (44.975, 1.000)
net_strap = b.FindNet('/GPIO8_STRAP')
ts1 = pcbnew.PCB_TRACK(b)
ts1.SetStart(pcbnew.VECTOR2I(int(43.630*1e6), int(2.435*1e6)))
ts1.SetEnd(pcbnew.VECTOR2I(int(43.630*1e6), int(1.000*1e6)))
ts1.SetWidth(int(0.15*1e6))
ts1.SetLayer(b.GetLayerID('F.Cu'))
ts1.SetNet(net_strap)
b.Add(ts1)

ts2 = pcbnew.PCB_TRACK(b)
ts2.SetStart(pcbnew.VECTOR2I(int(43.630*1e6), int(1.000*1e6)))
ts2.SetEnd(pcbnew.VECTOR2I(int(44.975*1e6), int(1.000*1e6)))
ts2.SetWidth(int(0.15*1e6))
ts2.SetLayer(b.GetLayerID('F.Cu'))
ts2.SetNet(net_strap)
b.Add(ts2)

geom = BoardGeometry(b)
print("GPIO8_STRAP s1:", geom.is_segment_legal(43.630, 2.435, 43.630, 1.000, 'F.Cu', '/GPIO8_STRAP'))
print("GPIO8_STRAP s2:", geom.is_segment_legal(43.630, 1.000, 44.975, 1.000, 'F.Cu', '/GPIO8_STRAP'))
print("R27.1 3V3 via:", geom.is_via_legal(44.0, 0.5, '/3V3'))

# Now test via for SD_CS at (43.13, 1.75):
print("SD_CS via at (43.13, 1.75):", geom.is_via_legal(43.130, 1.750, '/SD_CS'))
print("SD_CS s1:", geom.is_segment_legal(43.130, 2.435, 43.130, 1.750, 'F.Cu', '/SD_CS'))

# Now test via for SD_SCK at (42.63, 0.50) or (42.63, 0.60) or (42.63, 0.70):
for vy in [0.5, 0.6, 0.7, 0.8, 0.9, 1.0]:
    v_ok, rv = geom.is_via_legal(42.630, vy, '/SD_SCK')
    if v_ok:
        s_ok, rs = geom.is_segment_legal(42.630, 2.435, 42.630, vy, 'F.Cu', '/SD_SCK')
        print(f"SD_SCK at (42.63, {vy}): via={v_ok}, segment={s_ok}")
