import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# Check B.Cu at Y=1.800 from 24.250 to 44.000
leg, r = geom.is_segment_legal(24.25, 1.8, 44.0, 1.8, 'B.Cu', '/CHG_STAT')
print(f"CHG_STAT at Y=1.8 on B.Cu: {leg} ({r})")

sys.exit(0)
