import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- All B.Cu items with X in [39, 50] ---')
for t in board.GetTracks():
    if t.GetLayer() == pcbnew.B_Cu or isinstance(t, pcbnew.PCB_VIA):
        s = t.GetPosition() if isinstance(t, pcbnew.PCB_VIA) else t.GetStart()
        e = t.GetPosition() if isinstance(t, pcbnew.PCB_VIA) else t.GetEnd()
        sx, sy = s.x/1e6, s.y/1e6
        ex, ey = e.x/1e6, e.y/1e6
        if max(sx, ex) >= 38 and min(sx, ex) <= 51:
            t_type = 'VIA' if isinstance(t, pcbnew.PCB_VIA) else 'TRACK'
            print(f'{t_type} {t.GetNetname()}: ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})')

