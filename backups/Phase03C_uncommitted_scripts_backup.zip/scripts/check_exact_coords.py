import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")
u1 = b.FindFootprintByReference("U1")
r18 = b.FindFootprintByReference("R18")
r27 = b.FindFootprintByReference("R27")
jsd = b.FindFootprintByReference("J_SD")

print("U1 center:", u1.GetPosition().x/1e6, u1.GetPosition().y/1e6)
for p in u1.Pads():
    if p.GetNumber() in ["9", "10", "11", "12", "13", "14"]:
        print(f"U1.{p.GetNumber()} ({p.GetNetname()}):", p.GetPosition().x/1e6, p.GetPosition().y/1e6)

print("\nR18 center:", r18.GetPosition().x/1e6, r18.GetPosition().y/1e6)
for p in r18.Pads():
    print(f"R18.{p.GetNumber()} ({p.GetNetname()}):", p.GetPosition().x/1e6, p.GetPosition().y/1e6)

print("\nR27 center:", r27.GetPosition().x/1e6, r27.GetPosition().y/1e6)
for p in r27.Pads():
    print(f"R27.{p.GetNumber()} ({p.GetNetname()}):", p.GetPosition().x/1e6, p.GetPosition().y/1e6)

print("\nJ_SD pads:")
for p in jsd.Pads():
    print(f"J_SD.{p.GetNumber()} ({p.GetNetname()}):", p.GetPosition().x/1e6, p.GetPosition().y/1e6)
