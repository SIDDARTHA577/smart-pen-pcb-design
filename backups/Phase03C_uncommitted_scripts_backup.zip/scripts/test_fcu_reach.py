import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Testing F.Cu tracks from X=44 to 54:")
for y in [8.35, 8.40, 8.45, 8.50, 8.55, 8.60]:
    leg, reason = geom.is_segment_legal(44.63, y, 53.0, y, 'F.Cu', '/USB_DM_CORE')
    print(f"  F.Cu (44.63, {y:.2f}) -> (53.0, {y:.2f}): {leg} ({reason})")

sys.exit(0)
