import pcbnew

b = pcbnew.LoadBoard("scratch_test_clean_swap.kicad_pcb")
for t in b.GetTracks():
    if isinstance(t, pcbnew.PCB_VIA):
        p = t.GetPosition()
        if 44.0 <= p.x/1e6 <= 45.0 and 0.0 <= p.y/1e6 <= 1.5:
            print(f"Found via near R27: Net: {t.GetNetname()} Pos: ({p.x/1e6:.3f}, {p.y/1e6:.3f})")
