import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

# 1. Clean up MCU_EN tracks
# U1.7 is at (40.480, 3.585)
# MCU_EN via is at (38.930, 3.590)
# R1.2 is at (38.925, 2.360)
# C1.1 is at (39.325, 1.520)

# Remove all MCU_EN tracks around (38-41, 1.5-3.6) except the B.Cu track
mcu_tracks_to_remove = []
for t in board.GetTracks():
    if t.GetNetname() == '/MCU_EN':
        if not isinstance(t, pcbnew.PCB_VIA):
            s, e = t.GetStart(), t.GetEnd()
            layer = t.GetLayer()
            if layer == pcbnew.F_Cu:
                mcu_tracks_to_remove.append(t)

for t in mcu_tracks_to_remove:
    board.Remove(t)

# Add clean MCU_EN tracks on F.Cu:
# 1. From U1.7 (40.480, 3.585) to Via (38.930, 3.590)
t1 = pcbnew.PCB_TRACK(board)
t1.SetStart(pcbnew.VECTOR2I(int(40.480*1e6), int(3.585*1e6)))
t1.SetEnd(pcbnew.VECTOR2I(int(38.930*1e6), int(3.590*1e6)))
t1.SetWidth(int(0.18*1e6))
t1.SetLayer(pcbnew.F_Cu)
t1.SetNet(board.FindNet('/MCU_EN'))
board.Add(t1)

# 2. From Via (38.930, 3.590) down to R1.2 (38.925, 2.360)
t2 = pcbnew.PCB_TRACK(board)
t2.SetStart(pcbnew.VECTOR2I(int(38.930*1e6), int(3.590*1e6)))
t2.SetEnd(pcbnew.VECTOR2I(int(38.925*1e6), int(2.360*1e6)))
t2.SetWidth(int(0.18*1e6))
t2.SetLayer(pcbnew.F_Cu)
t2.SetNet(board.FindNet('/MCU_EN'))
board.Add(t2)

# 3. From R1.2 (38.925, 2.360) to C1.1 (39.325, 1.520)
t3 = pcbnew.PCB_TRACK(board)
t3.SetStart(pcbnew.VECTOR2I(int(38.925*1e6), int(2.360*1e6)))
t3.SetEnd(pcbnew.VECTOR2I(int(38.925*1e6), int(1.520*1e6)))
t3.SetWidth(int(0.18*1e6))
t3.SetLayer(pcbnew.F_Cu)
t3.SetNet(board.FindNet('/MCU_EN'))
board.Add(t3)

t4 = pcbnew.PCB_TRACK(board)
t4.SetStart(pcbnew.VECTOR2I(int(38.925*1e6), int(1.520*1e6)))
t4.SetEnd(pcbnew.VECTOR2I(int(39.325*1e6), int(1.520*1e6)))
t4.SetWidth(int(0.18*1e6))
t4.SetLayer(pcbnew.F_Cu)
t4.SetNet(board.FindNet('/MCU_EN'))
board.Add(t4)

# 2. Fix TOUCH_OUT:
# Remove existing TOUCH_OUT tracks and via between U1.8 and B.Cu track
touch_tracks_to_remove = []
for t in board.GetTracks():
    if t.GetNetname() == '/TOUCH_OUT':
        if isinstance(t, pcbnew.PCB_VIA):
            pos = t.GetPosition()
            px = pos.x/1e6
            if px > 20: # near U1
                touch_tracks_to_remove.append(t)
        else:
            s, e = t.GetStart(), t.GetEnd()
            sx, ex = s.x/1e6, e.x/1e6
            if sx > 20 or ex > 20:
                touch_tracks_to_remove.append(t)

for t in touch_tracks_to_remove:
    board.Remove(t)

# Place TOUCH_OUT via at (39.600, 3.085)
v_touch = pcbnew.PCB_VIA(board)
v_touch.SetPosition(pcbnew.VECTOR2I(int(39.600*1e6), int(3.085*1e6)))
v_touch.SetWidth(int(0.50*1e6))
v_touch.SetDrill(int(0.30*1e6))
v_touch.SetNet(board.FindNet('/TOUCH_OUT'))
board.Add(v_touch)

# F.Cu track: U1.8 (40.480, 3.085) -> (39.600, 3.085)
t_touch_f = pcbnew.PCB_TRACK(board)
t_touch_f.SetStart(pcbnew.VECTOR2I(int(40.480*1e6), int(3.085*1e6)))
t_touch_f.SetEnd(pcbnew.VECTOR2I(int(39.600*1e6), int(3.085*1e6)))
t_touch_f.SetWidth(int(0.18*1e6))
t_touch_f.SetLayer(pcbnew.F_Cu)
t_touch_f.SetNet(board.FindNet('/TOUCH_OUT'))
board.Add(t_touch_f)

# B.Cu track: from via (39.600, 3.085) -> jog to (39.000, 2.750) -> (13.030, 2.750)
t_touch_b1 = pcbnew.PCB_TRACK(board)
t_touch_b1.SetStart(pcbnew.VECTOR2I(int(39.600*1e6), int(3.085*1e6)))
t_touch_b1.SetEnd(pcbnew.VECTOR2I(int(39.000*1e6), int(2.750*1e6)))
t_touch_b1.SetWidth(int(0.18*1e6))
t_touch_b1.SetLayer(pcbnew.B_Cu)
t_touch_b1.SetNet(board.FindNet('/TOUCH_OUT'))
board.Add(t_touch_b1)

t_touch_b2 = pcbnew.PCB_TRACK(board)
t_touch_b2.SetStart(pcbnew.VECTOR2I(int(39.000*1e6), int(2.750*1e6)))
t_touch_b2.SetEnd(pcbnew.VECTOR2I(int(13.030*1e6), int(2.750*1e6)))
t_touch_b2.SetWidth(int(0.18*1e6))
t_touch_b2.SetLayer(pcbnew.B_Cu)
t_touch_b2.SetNet(board.FindNet('/TOUCH_OUT'))
board.Add(t_touch_b2)

board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('Cleaned and rerouted MCU_EN and TOUCH_OUT')

