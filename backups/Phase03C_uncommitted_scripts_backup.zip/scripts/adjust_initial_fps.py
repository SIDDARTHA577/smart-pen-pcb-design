import pcbnew
from pathlib import Path

pcb_path = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb")
mod_path = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.pretty/U1.kicad_mod")

# 1. Update U1.kicad_mod
mod_text = mod_path.read_text(encoding="utf-8")
# Replace pad 33 size from 3.700 3.700 to 3.400 3.400 per Espressif ESP32-C3 datasheet
if '(pad "33" smd rect (at 0.000 0.000) (size 3.700 3.700)' in mod_text:
    mod_text = mod_text.replace(
        '(pad "33" smd rect (at 0.000 0.000) (size 3.700 3.700)',
        '(pad "33" smd rect (at 0.000 0.000) (size 3.400 3.400)'
    )
    mod_path.write_text(mod_text, encoding="utf-8")
    print("Updated U1.kicad_mod pad 33 size to 3.400 x 3.400 mm.")

# 2. Update board footprint directly
board = pcbnew.LoadBoard(str(pcb_path))
u1 = board.FindFootprintByReference("U1")
assert u1 is not None
pad33 = u1.FindPadByNumber("33")
assert pad33 is not None
pad33.SetSize(pcbnew.VECTOR2I(int(3.4 * 1e6), int(3.4 * 1e6)))
pad33.SetLocalSolderMaskMargin(int(0)) # 0 margin for thermal pad

# 3. Update R7 position to avoid J_USB shield pin (pad 15)
r7 = board.FindFootprintByReference("R7")
if r7:
    # R7 was at (73.0, 7.50). Move to (72.2, 7.30)
    print(f"R7 original pos: ({r7.GetPosition().x/1e6}, {r7.GetPosition().y/1e6})")
    r7.SetPosition(pcbnew.VECTOR2I(int(72.2 * 1e6), int(7.30 * 1e6)))
    print(f"R7 new pos: ({r7.GetPosition().x/1e6}, {r7.GetPosition().y/1e6})")

# 4. Update R9 position to avoid C11
r9 = board.FindFootprintByReference("R9")
if r9:
    # R9 was at (66.30, 6.70). Move to (66.0, 6.30)
    print(f"R9 original pos: ({r9.GetPosition().x/1e6}, {r9.GetPosition().y/1e6})")
    r9.SetPosition(pcbnew.VECTOR2I(int(66.0 * 1e6), int(6.30 * 1e6)))
    print(f"R9 new pos: ({r9.GetPosition().x/1e6}, {r9.GetPosition().y/1e6})")

# 5. Fix Silkscreen text positions
d4 = board.FindFootprintByReference("D4")
if d4:
    d4.Reference().SetPosition(pcbnew.VECTOR2I(int(59.5 * 1e6), int(5.1 * 1e6)))
q2 = board.FindFootprintByReference("Q2")
if q2:
    q2.Reference().SetPosition(pcbnew.VECTOR2I(int(63.2 * 1e6), int(5.4 * 1e6)))
r26 = board.FindFootprintByReference("R26")
if r26:
    r26.Reference().SetPosition(pcbnew.VECTOR2I(int(60.5 * 1e6), int(5.4 * 1e6)))

board.Save(str(pcb_path))
print("Saved initial footprint/text adjustments to candidate PCB.")

