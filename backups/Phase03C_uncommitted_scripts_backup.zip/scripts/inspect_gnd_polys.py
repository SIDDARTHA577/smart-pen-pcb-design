import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
fcu_id = b.GetLayerID('F.Cu')

for z in b.Zones():
    if z.GetLayer() == fcu_id and z.GetNetname() == '/GND':
        poly = z.GetFilledPolysList(fcu_id)
        print(f"F.Cu GND zone has {poly.OutlineCount()} outlines")
        for i in range(poly.OutlineCount()):
            bb = poly.Outline(i).BBox()
            print(f"  Outline {i}: ({bb.GetX()/1e6:.2f}, {bb.GetY()/1e6:.2f}) -> ({(bb.GetX()+bb.GetWidth())/1e6:.2f}, {(bb.GetY()+bb.GetHeight())/1e6:.2f})")
