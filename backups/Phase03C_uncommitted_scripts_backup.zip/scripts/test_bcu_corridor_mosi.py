import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
# Delete freestanding GND via at (55.00, 1.20)
for t in list(b.GetTracks()):
    if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 55.00 and round(t.GetPosition().y/1e6, 2) == 1.20:
        b.Delete(t)

geom = BoardGeometry(b)
print("Testing B.Cu from 39.680 to 57.000:")
for y in [1.30, 1.35, 1.40, 1.45, 1.50, 1.55]:
    s, r = geom.is_segment_legal(39.680, y, 57.000, y, 'B.Cu', '/SD_MOSI')
    print(f"B.Cu at Y={y:.2f}: {s} ({r})")
