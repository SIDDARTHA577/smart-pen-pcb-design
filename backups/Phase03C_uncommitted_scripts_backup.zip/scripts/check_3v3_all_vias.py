import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")
net_3v3 = b.FindNet("/3V3")

print("--- ALL 3V3 VIAS ---")
for t in b.GetTracks():
    if t.GetNet() == net_3v3 and t.GetClass() == 'PCB_VIA':
        p = t.GetPosition()
        print(f"3V3 VIA Pos: ({p.x/1e6:.3f}, {p.y/1e6:.3f})")
