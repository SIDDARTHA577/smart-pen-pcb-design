import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

for p in board.GetPads():
    pos = p.GetPosition()
    x, y = pos.x / 1e6, pos.y / 1e6
    if 43.0 <= x <= 47.0 and 7.0 <= y <= 9.0:
        fp = p.GetParentFootprint()
        ref = fp.GetReference() if fp else '?'
        print(f'Pad {ref}.{p.GetNumber()} [{p.GetNetname()}] at ({x:.3f}, {y:.3f}) size ({p.GetSize().x/1e6:.3f}, {p.GetSize().y/1e6:.3f})')

for t in board.GetTracks():
    s, e = t.GetStart(), t.GetEnd()
    if (43.0 <= s.x/1e6 <= 47.0 and 7.0 <= s.y/1e6 <= 9.0) or (43.0 <= e.x/1e6 <= 47.0 and 7.0 <= e.y/1e6 <= 9.0):
        print(f'{t.GetClass()} [{t.GetNetname()}] {t.GetLayerName()} ({s.x/1e6:.3f}, {s.y/1e6:.3f}) -> ({e.x/1e6:.3f}, {e.y/1e6:.3f})')

