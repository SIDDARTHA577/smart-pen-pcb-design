import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

v1, rv1 = geom.is_via_legal(76.000, 4.000, '/USB_VBUS')
v2, rv2 = geom.is_via_legal(80.800, 4.000, '/USB_VBUS')
s_bcu, rb = geom.is_segment_legal(76.000, 4.000, 80.800, 4.000, 'B.Cu', '/USB_VBUS')

print(f"Via at (76.0, 4.0): {v1} ({rv1})")
print(f"Via at (80.8, 4.0): {v2} ({rv2})")
print(f"B.Cu bridge (76.0->80.8 @ 4.0): {s_bcu} ({rb})")
