import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
bcu_id = b.GetLayerID('B.Cu')

print("--- ITEMS on B.Cu between X=37 and 40, Y=4.3 and 5.8 ---")
for t in b.Tracks():
    if t.GetLayer() == bcu_id:
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if max(x1, x2) >= 37 and min(x1, x2) <= 40 and max(y1, y2) >= 4.3 and min(y1, y2) <= 5.8:
            print(f"Track B.Cu: {t.GetNetname()} ({x1:.3f},{y1:.3f}) -> ({x2:.3f},{y2:.3f})")

for t in b.Tracks():
    if isinstance(t, pcbnew.PCB_VIA):
        p = t.GetPosition()
        x, y = p.x/1e6, p.y/1e6
        if 37 <= x <= 40 and 4.3 <= y <= 5.8:
            print(f"Via: {t.GetNetname()} at ({x:.3f},{y:.3f})")
