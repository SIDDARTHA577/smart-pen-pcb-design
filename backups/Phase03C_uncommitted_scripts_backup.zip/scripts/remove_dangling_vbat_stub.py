import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

board_path = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb'
b = pcbnew.LoadBoard(board_path)

tracks = [t for t in b.Tracks()]
for t in tracks:
    if t.GetNetname() == '/VBAT_SW' and t.GetLayerName() == 'F.Cu':
        s = t.GetStart()
        if abs(s.y / 1e6 - 7.8) < 0.1:
            b.Remove(t)
            print("Removed dangling stub at Y=7.800!")

b.Save(board_path)
sys.exit(0)
