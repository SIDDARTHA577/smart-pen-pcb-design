import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')

# Update GPIO8_STRAP to jog at Y=1.000 instead of Y=1.600
for t in list(b.GetTracks()):
    if t.GetNetname() == '/GPIO8_STRAP':
        b.Delete(t)

net_strap = b.FindNet('/GPIO8_STRAP')
# (43.630, 2.435) -> (43.630, 1.000) -> (42.975, 1.000)
t1 = pcbnew.PCB_TRACK(b)
t1.SetStart(pcbnew.VECTOR2I(int(43.630*1e6), int(2.435*1e6)))
t1.SetEnd(pcbnew.VECTOR2I(int(43.630*1e6), int(1.000*1e6)))
t1.SetWidth(int(0.15*1e6))
t1.SetLayer(b.GetLayerID('F.Cu'))
t1.SetNet(net_strap)
b.Add(t1)

t2 = pcbnew.PCB_TRACK(b)
t2.SetStart(pcbnew.VECTOR2I(int(43.630*1e6), int(1.000*1e6)))
t2.SetEnd(pcbnew.VECTOR2I(int(42.975*1e6), int(1.000*1e6)))
t2.SetWidth(int(0.15*1e6))
t2.SetLayer(b.GetLayerID('F.Cu'))
t2.SetNet(net_strap)
b.Add(t2)

geom = BoardGeometry(b)
print("GPIO8_STRAP t1:", geom.is_segment_legal(43.630, 2.435, 43.630, 1.000, 'F.Cu', '/GPIO8_STRAP'))
print("GPIO8_STRAP t2:", geom.is_segment_legal(43.630, 1.000, 42.975, 1.000, 'F.Cu', '/GPIO8_STRAP'))

print("\nNow testing SD_CS from U1.13:")
s_cs, r_cs = geom.is_segment_legal(43.130, 2.435, 43.130, 1.750, 'F.Cu', '/SD_CS')
v_cs, rv_cs = geom.is_via_legal(43.130, 1.750, '/SD_CS')
print(f"SD_CS segment: {s_cs} ({r_cs})")
print(f"SD_CS via: {v_cs} ({rv_cs})")
