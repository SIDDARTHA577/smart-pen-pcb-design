import sys
sys.path.append('scripts')
import pcbnew

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
jbat = b.FindFootprintByReference('J_BAT')
print('J_BAT layer:', b.GetLayerName(jbat.GetLayer()), 'pos:', jbat.GetPosition().x/1e6, jbat.GetPosition().y/1e6)
for p in jbat.Pads():
    pos = p.GetPosition()
    print(f"Pad {p.GetNumber()} ({p.GetNetname()}): ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})")
