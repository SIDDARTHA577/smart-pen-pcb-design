import os
import hashlib
import json
import subprocess
from pathlib import Path

KICAD_CLI = r"C:\Users\goran\AppData\Local\Programs\KiCad\10.0\bin\kicad-cli.exe"
BASE_DIR = Path(".")
RAW_BASELINE_DIR = Path("reports/RevG/Phase03C/raw/baseline")
RAW_BASELINE_DIR.mkdir(parents=True, exist_ok=True)

files_to_hash = [
    "output/RevG/SmartPen.kicad_sch",
    "output/RevG/SmartPen.kicad_pcb",
    "output/RevG/SmartPen.kicad_pro",
    "output/RevG/SmartPen.kicad_prl",
    "output/RevG/SmartPen.kicad_dru",
    "output/RevG/SmartPen_Lib.kicad_sym",
    "output/RevG/fp-lib-table",
    "output/RevG/sym-lib-table",
    "output/RevG/Front_MPU/Front_MPU.kicad_sch",
    "output/RevG/Front_MPU/Front_MPU.kicad_pcb",
    "output/RevG/MicroSD_Carrier/MicroSD_Carrier.kicad_sch",
    "output/RevG/MicroSD_Carrier/MicroSD_Carrier.kicad_pcb",
    "output/RevG/Touch_Sensor/Touch_Sensor.kicad_sch",
    "output/RevG/Touch_Sensor/Touch_Sensor.kicad_pcb",
]

hashes = {}
print("=== SHA-256 Hashes of Baseline Files ===")
for rel_path in files_to_hash:
    p = Path(rel_path)
    if p.exists():
        h = hashlib.sha256(p.read_bytes()).hexdigest()
        hashes[rel_path] = h
        print(f"{rel_path}: {h}")
    else:
        print(f"MISSING: {rel_path}")

with open(RAW_BASELINE_DIR / "file_hashes.json", "w", encoding="utf-8") as f:
    json.dump(hashes, f, indent=2)

commands = [
    # Main PCB DRC
    ("Main_SmartPen_drc_rpt", [KICAD_CLI, "pcb", "drc", "--severity-all", "--schematic-parity", "--all-track-errors", "--refill-zones", "--format", "report", "-o", str(RAW_BASELINE_DIR / "Main_SmartPen_drc.rpt"), "output/RevG/SmartPen.kicad_pcb"]),
    ("Main_SmartPen_drc_json", [KICAD_CLI, "pcb", "drc", "--severity-all", "--schematic-parity", "--all-track-errors", "--refill-zones", "--format", "json", "-o", str(RAW_BASELINE_DIR / "Main_SmartPen_drc.json"), "output/RevG/SmartPen.kicad_pcb"]),
    # Main PCB ERC
    ("Main_SmartPen_erc_rpt", [KICAD_CLI, "sch", "erc", "--severity-all", "--format", "report", "-o", str(RAW_BASELINE_DIR / "Main_SmartPen_erc.rpt"), "output/RevG/SmartPen.kicad_sch"]),
    ("Main_SmartPen_erc_json", [KICAD_CLI, "sch", "erc", "--severity-all", "--format", "json", "-o", str(RAW_BASELINE_DIR / "Main_SmartPen_erc.json"), "output/RevG/SmartPen.kicad_sch"]),
    # Front MPU DRC & ERC
    ("Front_MPU_drc_rpt", [KICAD_CLI, "pcb", "drc", "--severity-all", "--schematic-parity", "--all-track-errors", "--refill-zones", "--format", "report", "-o", str(RAW_BASELINE_DIR / "Front_MPU_drc.rpt"), "output/RevG/Front_MPU/Front_MPU.kicad_pcb"]),
    ("Front_MPU_drc_json", [KICAD_CLI, "pcb", "drc", "--severity-all", "--schematic-parity", "--all-track-errors", "--refill-zones", "--format", "json", "-o", str(RAW_BASELINE_DIR / "Front_MPU_drc.json"), "output/RevG/Front_MPU/Front_MPU.kicad_pcb"]),
    ("Front_MPU_erc_rpt", [KICAD_CLI, "sch", "erc", "--severity-all", "--format", "report", "-o", str(RAW_BASELINE_DIR / "Front_MPU_erc.rpt"), "output/RevG/Front_MPU/Front_MPU.kicad_sch"]),
    ("Front_MPU_erc_json", [KICAD_CLI, "sch", "erc", "--severity-all", "--format", "json", "-o", str(RAW_BASELINE_DIR / "Front_MPU_erc.json"), "output/RevG/Front_MPU/Front_MPU.kicad_sch"]),
    # MicroSD Carrier DRC & ERC
    ("MicroSD_Carrier_drc_rpt", [KICAD_CLI, "pcb", "drc", "--severity-all", "--schematic-parity", "--all-track-errors", "--refill-zones", "--format", "report", "-o", str(RAW_BASELINE_DIR / "MicroSD_Carrier_drc.rpt"), "output/RevG/MicroSD_Carrier/MicroSD_Carrier.kicad_pcb"]),
    ("MicroSD_Carrier_drc_json", [KICAD_CLI, "pcb", "drc", "--severity-all", "--schematic-parity", "--all-track-errors", "--refill-zones", "--format", "json", "-o", str(RAW_BASELINE_DIR / "MicroSD_Carrier_drc.json"), "output/RevG/MicroSD_Carrier/MicroSD_Carrier.kicad_pcb"]),
    ("MicroSD_Carrier_erc_rpt", [KICAD_CLI, "sch", "erc", "--severity-all", "--format", "report", "-o", str(RAW_BASELINE_DIR / "MicroSD_Carrier_erc.rpt"), "output/RevG/MicroSD_Carrier/MicroSD_Carrier.kicad_sch"]),
    ("MicroSD_Carrier_erc_json", [KICAD_CLI, "sch", "erc", "--severity-all", "--format", "json", "-o", str(RAW_BASELINE_DIR / "MicroSD_Carrier_erc.json"), "output/RevG/MicroSD_Carrier/MicroSD_Carrier.kicad_sch"]),
    # Touch Sensor DRC & ERC
    ("Touch_Sensor_drc_rpt", [KICAD_CLI, "pcb", "drc", "--severity-all", "--schematic-parity", "--all-track-errors", "--refill-zones", "--format", "report", "-o", str(RAW_BASELINE_DIR / "Touch_Sensor_drc.rpt"), "output/RevG/Touch_Sensor/Touch_Sensor.kicad_pcb"]),
    ("Touch_Sensor_drc_json", [KICAD_CLI, "pcb", "drc", "--severity-all", "--schematic-parity", "--all-track-errors", "--refill-zones", "--format", "json", "-o", str(RAW_BASELINE_DIR / "Touch_Sensor_drc.json"), "output/RevG/Touch_Sensor/Touch_Sensor.kicad_pcb"]),
    ("Touch_Sensor_erc_rpt", [KICAD_CLI, "sch", "erc", "--severity-all", "--format", "report", "-o", str(RAW_BASELINE_DIR / "Touch_Sensor_erc.rpt"), "output/RevG/Touch_Sensor/Touch_Sensor.kicad_sch"]),
    ("Touch_Sensor_erc_json", [KICAD_CLI, "sch", "erc", "--severity-all", "--format", "json", "-o", str(RAW_BASELINE_DIR / "Touch_Sensor_erc.json"), "output/RevG/Touch_Sensor/Touch_Sensor.kicad_sch"]),
]

log_entries = []
print("\n=== Executing Baseline KiCad Verification Commands ===")
for name, cmd in commands:
    cmd_str = " ".join(f'"{c}"' if " " in c else c for c in cmd)
    print(f"Running {name}...")
    res = subprocess.run(cmd, capture_output=True, text=True)
    entry = {
        "name": name,
        "command": cmd_str,
        "exit_code": res.returncode,
        "stdout": res.stdout,
        "stderr": res.stderr
    }
    log_entries.append(entry)
    print(f"  Exit code: {res.returncode}")

with open(RAW_BASELINE_DIR / "baseline_execution_log.json", "w", encoding="utf-8") as f:
    json.dump(log_entries, f, indent=2)

print("\n=== Baseline Main PCB DRC Results ===")
with open(RAW_BASELINE_DIR / "Main_SmartPen_drc.json", "r", encoding="utf-8") as f:
    main_drc = json.load(f)

violations = main_drc.get("violations", [])
unconnected = main_drc.get("unconnected_items", [])
parity = main_drc.get("schematic_parity_issues", [])

types = {}
for v in violations:
    t = v.get("type", "unknown")
    types[t] = types.get(t, 0) + 1

print(f"Total violations: {len(violations)}")
print(f"Total unconnected items: {len(unconnected)}")
print(f"Total schematic parity issues: {len(parity)}")
print("Violations breakdown:")
for t, cnt in sorted(types.items()):
    print(f"  {t}: {cnt}")

assert len(violations) == 144, f"Expected 144 violations, got {len(violations)}"
assert len(unconnected) == 67, f"Expected 67 unconnected items, got {len(unconnected)}"
assert len(parity) == 0, f"Expected 0 parity issues, got {len(parity)}"
assert types.get("shorting_items", 0) == 0, "Expected 0 shorting items"
assert types.get("lib_footprint_mismatch", 0) == 0, "Expected 0 lib footprint mismatches"
assert types.get("tracks_crossing", 0) == 0, "Expected 0 tracks crossing"
print("\n>>> Baseline matches expected values exactly! <<<")

