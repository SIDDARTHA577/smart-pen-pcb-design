import pcbnew

b = pcbnew.LoadBoard("scratch_test_clean_step16.kicad_pcb")

for z in b.Zones():
    if z.GetNetname() == '/3V3':
        layer = z.GetLayer()
        filled = z.GetFilledPolysList(layer)
        print(f"3V3 Zone on {b.GetLayerName(layer)} has {filled.OutlineCount()} outlines")
        for i in range(filled.OutlineCount()):
            poly = filled.Outline(i)
            bb = poly.BBox()
            print(f"  Outline {i}: bbox X=[{bb.GetX()/1e6:.2f}, {(bb.GetX()+bb.GetWidth())/1e6:.2f}], Y=[{bb.GetY()/1e6:.2f}, {(bb.GetY()+bb.GetHeight())/1e6:.2f}]")
