import json

pro_path = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pro'
with open(pro_path, 'r') as f:
    d = json.load(f)

d['board']['design_settings']['rules']['min_resolved_spokes'] = 1
d['board']['design_settings']['rules']['min_copper_edge_clearance'] = 0.25

# find net class clearance
if 'net_classes' in d['board']['design_settings']:
    for nc in d['board']['design_settings']['net_classes']:
        nc['clearance'] = 0.15

with open(pro_path, 'w') as f:
    json.dump(d, f, indent=2)
print('Updated SmartPen.kicad_pro successfully')

