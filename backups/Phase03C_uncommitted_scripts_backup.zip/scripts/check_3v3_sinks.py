import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")
for fp in b.GetFootprints():
    for p in fp.Pads():
        if p.GetNetname() == '/3V3':
            print(f"FP: {fp.GetReference()} Pad: {p.GetNumber()} Pos: ({p.GetPosition().x/1e6:.3f}, {p.GetPosition().y/1e6:.3f})")
