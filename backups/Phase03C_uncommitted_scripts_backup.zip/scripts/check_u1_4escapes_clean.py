import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
r27 = b.FindFootprintByReference('R27')
r27.SetOrientationDegrees(180.0)
r27.SetPosition(pcbnew.VECTOR2I(int(44.0*1e6), int(1.0*1e6)))

for t in list(b.GetTracks()):
    if t.GetNetname() == '/GPIO8_STRAP':
        b.Delete(t)
    elif t.GetNetname() == '/3V3' and round(t.GetPosition().x/1e6, 1) == 42.0:
        b.Delete(t)

# Add GPIO8_STRAP and 3V3 for R27
net_strap = b.FindNet('/GPIO8_STRAP')
net_3v3 = b.FindNet('/3V3')
def add_trk(layer, sx, sy, ex, ey, net):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(sx*1e6), int(sy*1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(ex*1e6), int(ey*1e6)))
    t.SetWidth(int(0.15*1e6))
    t.SetLayer(b.GetLayerID(layer))
    t.SetNet(net)
    b.Add(t)

def add_via(x, y, net):
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(int(x*1e6), int(y*1e6)))
    v.SetWidth(int(0.50*1e6))
    v.SetDrill(int(0.30*1e6))
    v.SetTopLayer(b.GetLayerID('F.Cu'))
    v.SetBottomLayer(b.GetLayerID('B.Cu'))
    v.SetNet(net)
    b.Add(v)

add_trk('F.Cu', 43.630, 2.435, 43.525, 1.000, net_strap)
add_trk('F.Cu', 44.475, 1.000, 44.475, 0.450, net_3v3)
add_via(44.475, 0.450, net_3v3)

geom = BoardGeometry(b)

vias = [
    ('/SD_MOSI', 41.130, 0.500, 41.130, 2.435),
    ('/SD_SCK',  42.630, 0.500, 42.630, 2.435),
    ('/SD_MISO', 41.400, 1.600, 41.630, 2.435),
    ('/SD_CS',   43.000, 1.700, 43.130, 2.435),
]

for net, vx, vy, px, py in vias:
    v_ok, rv = geom.is_via_legal(vx, vy, net)
    s_ok, rs = geom.is_segment_legal(px, py, vx, vy, 'F.Cu', net)
    print(f"{net}: via=({vx}, {vy}) {v_ok} ({rv}), seg from ({px}, {py}) {s_ok} ({rs})")
