import os, sys, pcbnew, shutil

src_pcb = 'scratch_test_restore_vsys.kicad_pcb'
dst_pcb = 'scratch_test_fcu_cs_clean.kicad_pcb'
shutil.copy(src_pcb, dst_pcb)
shutil.copy(src_pcb.replace('.kicad_pcb', '.kicad_pro'), dst_pcb.replace('.kicad_pcb', '.kicad_pro'))

b = pcbnew.LoadBoard(dst_pcb)
fcu = b.GetLayerID('F.Cu')
in2 = b.GetLayerID('In2.Cu')
net_cs = b.FindNet('/SD_CS')
net_vsys = b.FindNet('/VSYS_RAW')

# Hide R27 text
r27 = b.FindFootprintByReference('R27')
if r27: r27.Reference().SetVisible(False)

# Move VSYS_RAW via from (59.50, 2.40) onto D4.1 pad at (59.00, 2.40)
for t in list(b.GetTracks()):
    if t.GetNetname() == '/VSYS_RAW':
        if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 59.50 and round(t.GetPosition().y/1e6, 2) == 2.40:
            b.Delete(t)
        elif t.GetClass() != 'PCB_VIA' and t.GetLayer() == fcu:
            b.Delete(t)

v_vsys = pcbnew.PCB_VIA(b)
v_vsys.SetPosition(pcbnew.VECTOR2I(int(59.000 * 1e6), int(2.400 * 1e6)))
v_vsys.SetWidth(int(0.500 * 1e6))
v_vsys.SetDrill(int(0.300 * 1e6))
v_vsys.SetNet(net_vsys)
v_vsys.SetViaType(pcbnew.VIATYPE_THROUGH)
b.Add(v_vsys)

t_vsys = pcbnew.PCB_TRACK(b)
t_vsys.SetStart(pcbnew.VECTOR2I(int(59.500 * 1e6), int(2.400 * 1e6)))
t_vsys.SetEnd(pcbnew.VECTOR2I(int(59.000 * 1e6), int(2.400 * 1e6)))
t_vsys.SetWidth(int(0.200 * 1e6))
t_vsys.SetLayer(in2)
t_vsys.SetNet(net_vsys)
b.Add(t_vsys)

def add_trk(x1, y1, x2, y2, w=0.15):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(round(x1 * 1e6)), int(round(y1 * 1e6))))
    t.SetEnd(pcbnew.VECTOR2I(int(round(x2 * 1e6)), int(round(y2 * 1e6))))
    t.SetWidth(int(round(w * 1e6)))
    t.SetLayer(fcu)
    t.SetNet(net_cs)
    b.Add(t)
    return t

# R18.2 at (56.975, 2.000) to J_SD.6 at (59.650, 4.200) on F.Cu
add_trk(56.975, 2.000, 56.975, 1.000)
add_trk(56.975, 1.000, 59.800, 1.000)
add_trk(59.800, 1.000, 59.800, 3.600)
add_trk(59.800, 3.600, 59.650, 3.600)
add_trk(59.650, 3.600, 59.650, 4.200)

filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
b.Save(dst_pcb)
print("Saved F.Cu CS clean test.")
