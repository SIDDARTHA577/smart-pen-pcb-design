import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

# Remove existing STRAP2 tracks and vias
to_del = []
for t in board.GetTracks():
    if t.GetNetname() == '/STRAP2':
        to_del.append(t)
for t in to_del:
    board.Remove(t)

# Move R3 to (37.5, 4.085)
r3 = board.FindFootprintByReference('R3')
r3.SetPosition(pcbnew.VECTOR2I(int(37.5 * 1e6), int(4.085 * 1e6)))
r3.SetOrientation(pcbnew.EDA_ANGLE(0, pcbnew.DEGREES_T))

# Inspect R3 pads
p1 = r3.FindPadByNumber('1')
p2 = r3.FindPadByNumber('2')
p1_pos = p1.GetPosition()
p2_pos = p2.GetPosition()
print(f'R3.1 at ({p1_pos.x/1e6:.3f}, {p1_pos.y/1e6:.3f})')
print(f'R3.2 at ({p2_pos.x/1e6:.3f}, {p2_pos.y/1e6:.3f})')

# Connect R3.2 (STRAP2) to U1.6 (40.480, 4.085)
t_strap2 = pcbnew.PCB_TRACK(board)
t_strap2.SetStart(p2_pos)
t_strap2.SetEnd(pcbnew.VECTOR2I(int(40.480 * 1e6), int(4.085 * 1e6)))
t_strap2.SetWidth(int(0.18 * 1e6))
t_strap2.SetLayer(pcbnew.F_Cu)
t_strap2.SetNet(board.FindNet('/STRAP2'))
board.Add(t_strap2)

board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('Moved R3 and routed STRAP2 on F.Cu')

