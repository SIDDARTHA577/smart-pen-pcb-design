import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
# Delete (42.0, 0.5) via
for t in list(b.GetTracks()):
    if t.GetNetname() == '/3V3' and round(t.GetPosition().x/1e6, 1) == 42.0:
        b.Delete(t)

geom = BoardGeometry(b)
s_bcu, r_b = geom.is_segment_legal(41.130, 0.500, 43.000, 0.500, 'B.Cu', '/SD_MOSI')
print("SD_MOSI B.Cu (41.13 to 43.0, Y=0.5):", s_bcu, r_b)
v_43, rv = geom.is_via_legal(43.000, 0.500, '/SD_MOSI')
print("Via at (43.0, 0.5):", v_43, rv)
