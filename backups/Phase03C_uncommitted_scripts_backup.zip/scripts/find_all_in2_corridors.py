import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
# Delete freestanding GND via at (55.00, 1.20)
for t in list(b.GetTracks()):
    if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 55.00 and round(t.GetPosition().y/1e6, 2) == 1.20:
        b.Delete(t)

geom = BoardGeometry(b)
print("Testing In2.Cu segments from X=43.0 to 57.0:")
for y in [1.15, 1.20, 1.25, 1.30, 1.35, 1.40, 1.45, 1.50, 1.55, 1.60, 1.65, 1.70, 1.75, 1.80, 1.85, 1.90, 1.95, 2.00]:
    s, r = geom.is_segment_legal(43.000, y, 57.000, y, 'In2.Cu', '/SD_MOSI')
    if s:
        print(f"  Y={y:.2f} is 100% LEGAL!")
