import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

for ref in ['R26', 'D4', 'Q2']:
    fp = board.FindFootprintByReference(ref)
    ref_prop = fp.Reference()
    pos = ref_prop.GetPosition()
    print(f'{ref} position: ({pos.x/1e6:.3f}, {pos.y/1e6:.3f}), fp at ({fp.GetPosition().x/1e6:.3f}, {fp.GetPosition().y/1e6:.3f})')

j_usb = board.FindFootprintByReference('J_USB')
print(f'J_USB at ({j_usb.GetPosition().x/1e6:.3f}, {j_usb.GetPosition().y/1e6:.3f})')
for g in j_usb.GraphicalItems():
    if g.GetLayer() == pcbnew.F_SilkS:
        print(f'J_USB Silk item: {g.GetShapeStr()}, start={g.GetStart().x/1e6:.3f}, {g.GetStart().y/1e6:.3f}, end={g.GetEnd().x/1e6:.3f}, {g.GetEnd().y/1e6:.3f}')

