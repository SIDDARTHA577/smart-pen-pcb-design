import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")
bcu = b.GetLayerID('B.Cu')

print("--- Objects on B.Cu between X=44 and 67, Y in [2.1, 2.5] ---")
for t in b.GetTracks():
    if t.GetClass() == 'PCB_VIA':
        p = t.GetPosition()
        x, y = p.x/1e6, p.y/1e6
        if 44.0 <= x <= 67.0 and 2.0 <= y <= 2.6:
            print(f"VIA Net: {t.GetNetname()} at ({x:.3f}, {y:.3f})")
    elif t.GetLayer() == bcu and t.GetNetname() != '/CHG_STAT':
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (44.0 <= x1 <= 67.0 or 44.0 <= x2 <= 67.0) and (2.0 <= y1 <= 2.6 or 2.0 <= y2 <= 2.6):
            print(f"TRK Net: {t.GetNetname()} ({x1:.3f}, {y1:.3f}) -> ({x2:.3f}, {y2:.3f})")
