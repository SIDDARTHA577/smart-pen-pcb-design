import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("1. Checking SCL East via at (39.0, 5.6):")
v_scl, rv = geom.is_via_legal(39.0, 5.6, '/I2C_SCL')
s_scl_fcu, rf = geom.is_segment_legal(39.0, 5.6, 40.480, 4.585, 'F.Cu', '/I2C_SCL')
print(f"  via={v_scl}({rv}), fcu={s_scl_fcu}({rf})")

print("\n2. Checking J_MOT connection from south (Y=8.0):")
# Run around mounting pad: J_MOT.1 is at (30.753, 6.285)
# (28.086, 4.704) -> (28.086, 8.4) -> (30.753, 8.4) -> (30.753, 6.285)
s_jm1, r1 = geom.is_segment_legal(28.086, 4.704, 28.086, 8.4, 'F.Cu', '/VBAT_SW')
s_jm2, r2 = geom.is_segment_legal(28.086, 8.4, 30.753, 8.4, 'F.Cu', '/VBAT_SW')
s_jm3, r3 = geom.is_segment_legal(30.753, 8.4, 30.753, 6.285, 'F.Cu', '/VBAT_SW')
print(f"  J_MOT path at Y=8.4: s1={s_jm1}({r1}), s2={s_jm2}({r2}), s3={s_jm3}({r3})")

sys.exit(0)
