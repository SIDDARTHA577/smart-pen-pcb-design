import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts')))
import astar_miso

# Let's test if SCK can go from (58.0, 5.4) to (42.63, 1.15) or (42.63, 2.435)
# on In1.Cu, In2.Cu, or B.Cu:
print("Searching for SCK path from (58.0, 5.4) to U1.12:")

for lid, lname in [(astar_miso.in1, 'In1.Cu'), (astar_miso.in2, 'In2.Cu'), (astar_miso.bcu, 'B.Cu')]:
    print(f"=== Layer {lname} ===")
    # Can we go straight west at Y=5.4?
    # Test from X=58.0 to X=44.0 at Y=5.4
    c1 = astar_miso.track_clear(lid, 44.0, 5.4, 58.0, 5.4)
    print(f"  Y=5.4 (44.0 to 58.0): {c1}")
    for y in [4.5, 4.8, 5.0, 5.2, 5.4, 5.5, 5.8, 6.0]:
        c = astar_miso.track_clear(lid, 44.0, y, 58.0, y)
        if c:
            print(f"  {lname} clear at Y={y:.2f} from 44.0 to 58.0")
