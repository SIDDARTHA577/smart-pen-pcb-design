try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

def route_group3():
    board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

    # Helper to add track
    def add_track(netname, layer_name, x1, y1, x2, y2, width=0.18):
        net = board.FindNet(netname)
        t = pcbnew.PCB_TRACK(board)
        t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
        t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
        t.SetWidth(int(width * 1e6))
        t.SetLayer(board.GetLayerID(layer_name))
        t.SetNet(net)
        board.Add(t)
        return t

    # Helper to add via
    def add_via(netname, x, y, dia=0.50, drill=0.30):
        net = board.FindNet(netname)
        v = pcbnew.PCB_VIA(board)
        v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
        v.SetWidth(int(dia * 1e6))
        v.SetDrill(int(drill * 1e6))
        v.SetNet(net)
        v.SetViaType(pcbnew.VIATYPE_THROUGH)
        board.Add(v)
        return v

    print('Applying verified Group 3 routes (USB CC & Port)...')

    # 1. /USB_CC1
    add_track('/USB_CC1', 'F.Cu', 77.150, 3.100, 77.150, 5.500)
    add_track('/USB_CC1', 'F.Cu', 77.150, 5.500, 77.600, 6.225)

    # 2. /USB_CC2
    add_track('/USB_CC2', 'F.Cu', 79.650, 3.100, 79.650, 5.500)
    add_track('/USB_CC2', 'F.Cu', 79.650, 5.500, 79.200, 6.225)

    # 3. /USB_DM_PORT
    # Connect J_USB.5 to B.Cu track at (77.650, 0.550)
    add_track('/USB_DM_PORT', 'F.Cu', 77.650, 3.100, 77.650, 0.550)
    add_via('/USB_DM_PORT', 77.650, 0.550)

    # Route from via at (72.000, 0.550) to R7.1 via In2.Cu
    add_track('/USB_DM_PORT', 'In2.Cu', 72.000, 0.550, 72.500, 1.500)
    add_track('/USB_DM_PORT', 'In2.Cu', 72.500, 1.500, 72.500, 8.500)
    add_via('/USB_DM_PORT', 72.500, 8.500)
    add_track('/USB_DM_PORT', 'F.Cu', 72.500, 8.500, 72.500, 7.975)

    # 4. /USB_DP_PORT
    # Connect J_USB.8 to B.Cu track at (79.150, 1.200)
    add_track('/USB_DP_PORT', 'F.Cu', 79.150, 3.100, 79.150, 1.200)
    add_via('/USB_DP_PORT', 79.150, 1.200)
    add_track('/USB_DP_PORT', 'B.Cu', 78.150, 1.200, 79.150, 1.200)

    # Route from via at (71.050, 1.200) to R8.1 via B.Cu
    add_track('/USB_DP_PORT', 'B.Cu', 71.050, 1.200, 71.050, 8.500)
    add_track('/USB_DP_PORT', 'B.Cu', 71.050, 8.500, 71.600, 8.500)
    add_via('/USB_DP_PORT', 71.600, 8.500)
    add_track('/USB_DP_PORT', 'F.Cu', 71.600, 8.500, 71.600, 7.975)

    # Refill all zones
    filler = pcbnew.ZONE_FILLER(board)
    filler.Fill(board.Zones())

    board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
    print('Successfully applied Group 3 routes!')

if __name__ == '__main__':
    route_group3()
