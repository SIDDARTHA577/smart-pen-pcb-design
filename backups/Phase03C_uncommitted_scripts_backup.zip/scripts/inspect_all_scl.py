import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
scl_net = b.FindNet('/I2C_SCL')
print(f"NET: {scl_net.GetNetname()} code={scl_net.GetNetCode()}")
for t in b.Tracks():
    if t.GetNetCode() == scl_net.GetNetCode():
        if t.GetClass() == 'PCB_VIA':
            pos = t.GetPosition()
            print(f"  VIA at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})")
        else:
            st = t.GetStart()
            en = t.GetEnd()
            print(f"  TRACK {t.GetLayerName()} ({st.x/1e6:.3f}, {st.y/1e6:.3f}) -> ({en.x/1e6:.3f}, {en.y/1e6:.3f})")

sys.exit(0)
