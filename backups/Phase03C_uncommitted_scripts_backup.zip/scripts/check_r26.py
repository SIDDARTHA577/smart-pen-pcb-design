import sys
sys.path.append('scripts')
import pcbnew

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
r26 = b.FindFootprintByReference('R26')
print('R26 pos:', r26.GetPosition().x/1e6, r26.GetPosition().y/1e6, 'rot:', r26.GetOrientation().AsDegrees())
for p in r26.Pads():
    pos = p.GetPosition()
    print(f"  Pad {p.GetNumber()} ({p.GetNetname()}): ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})")
