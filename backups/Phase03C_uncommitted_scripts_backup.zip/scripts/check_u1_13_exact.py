import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

print("Checking U1.13 (SD_CS):")
# Test segment from (43.130, 2.435) to various Y
for vy in [1.5, 1.6, 1.7, 1.75, 1.8, 1.9, 2.0, 2.1, 2.2]:
    s_ok, rs = geom.is_segment_legal(43.130, 2.435, 43.130, vy, 'F.Cu', '/SD_CS')
    v_ok, rv = geom.is_via_legal(43.130, vy, '/SD_CS')
    print(f"vy={vy:.2f}: seg={s_ok} ({rs}), via={v_ok} ({rv})")
