import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Testing In2.Cu horizontal runs at different Y values between X=25.0 and 38.8:")
for y_int in range(45, 68, 2):
    y = y_int / 10.0
    s_ok, r = geom.is_segment_legal(25.000, y, 38.800, y, 'In2.Cu', '/I2C_SCL')
    print(f"In2.Cu Y={y:.2f}: {s_ok} ({r})")
