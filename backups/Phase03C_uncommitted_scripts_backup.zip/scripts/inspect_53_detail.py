import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- PADS around X=53.5, Y=6.0..8.8 ---')
for p in board.GetPads():
    pos = p.GetPosition()
    x, y = pos.x / 1e6, pos.y / 1e6
    if 51.0 <= x <= 56.0 and 6.0 <= y <= 8.8:
        fp = p.GetParentFootprint()
        ref = fp.GetReference() if fp else '?'
        print(f'{ref}.{p.GetNumber()} [{p.GetNetname()}] at ({x:.3f}, {y:.3f}) layer {p.GetLayerName()}')

print('--- TRACKS around X=53.5, Y=6.0..8.8 ---')
for t in board.GetTracks():
    s, e = t.GetStart(), t.GetEnd()
    sx, sy = s.x/1e6, s.y/1e6
    ex, ey = e.x/1e6, e.y/1e6
    if (51.0 <= sx <= 56.0 and 6.0 <= sy <= 8.8) or (51.0 <= ex <= 56.0 and 6.0 <= ey <= 8.8):
        print(f'{t.GetClass()} [{t.GetNetname()}] {t.GetLayerName()} ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})')

