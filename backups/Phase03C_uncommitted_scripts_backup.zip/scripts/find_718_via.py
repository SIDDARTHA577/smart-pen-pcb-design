import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Scanning for via locations at X=71.775:")
for yi in range(10, 85, 2):
    y = yi / 10.0
    v_ok, rv = geom.is_via_legal(71.775, y, '/USB_VBUS')
    if v_ok:
        # Check In2.Cu from (67.5, y) to (71.775, y)
        s_in, rin = geom.is_segment_legal(67.5, y, 71.775, y, 'In2.Cu', '/USB_VBUS')
        # Check B.Cu from (71.775, y) to (73.75, y)
        s_b, rb = geom.is_segment_legal(71.775, y, 73.75, y, 'B.Cu', '/USB_VBUS')
        print(f"y={y:.1f}: via=True, In2_west={s_in}({rin}), BCu_east={s_b}({rb})")
