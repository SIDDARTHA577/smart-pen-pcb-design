import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

for p in board.GetPads():
    fp = p.GetParentFootprint()
    if fp and fp.GetReference() == 'U1':
        num = int(p.GetNumber())
        if 17 <= num <= 24:
            pos = p.GetPosition()
            print(f'U1.{num} [{p.GetNetname()}] at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})')

