import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- ALL TRACKS ON B.Cu between X=40 and X=75 ---')
for t in board.GetTracks():
    if t.GetLayerName() == 'B.Cu':
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = s.x/1e6, s.y/1e6
        ex, ey = e.x/1e6, e.y/1e6
        if max(sx, ex) >= 40.0 and min(sx, ex) <= 75.0:
            print(f'{t.GetNetname()}: ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f}) w={t.GetWidth()/1e6:.3f}')

