import os, sys, math, json
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try: import wx; wx.DisableAsserts()
except: pass
import pcbnew, shutil

src_pcb = 'scratch_test_restore_vsys.kicad_pcb'
dst_pcb = 'scratch_test_clean_step3.kicad_pcb'
shutil.copy(src_pcb, dst_pcb)
shutil.copy(src_pcb.replace('.kicad_pcb', '.kicad_pro'), dst_pcb.replace('.kicad_pcb', '.kicad_pro'))

b = pcbnew.LoadBoard(dst_pcb)

# 1. Delete freestanding stitching via at (55.00, 1.20)
for t in list(b.GetTracks()):
    if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 55.00 and round(t.GetPosition().y/1e6, 2) == 1.20:
        b.Delete(t)

# 2. Fix R27 silkscreen reference: hide text
r27 = b.FindFootprintByReference('R27')
if r27:
    r27.Reference().SetVisible(False)

# 3. Clean any existing SD tracks
for netname in ['/SD_SCK', '/SD_MOSI', '/SD_MISO', '/SD_CS']:
    net = b.FindNet(netname)
    for t in list(b.GetTracks()):
        if t.GetNet() == net:
            b.Delete(t)

# 4. CHG_STAT clean jog
for t in list(b.GetTracks()):
    if t.GetNetname() == '/CHG_STAT' and t.GetLayer() == b.GetLayerID('B.Cu'):
        b.Delete(t)

bcu = b.GetLayerID('B.Cu')
fcu = b.GetLayerID('F.Cu')
in2 = b.GetLayerID('In2.Cu')

def add_trk(netname, layer_id, x1, y1, x2, y2, w=0.15):
    net = b.FindNet(netname)
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(round(x1 * 1e6)), int(round(y1 * 1e6))))
    t.SetEnd(pcbnew.VECTOR2I(int(round(x2 * 1e6)), int(round(y2 * 1e6))))
    t.SetWidth(int(round(w * 1e6)))
    t.SetLayer(layer_id)
    t.SetNet(net)
    b.Add(t)
    return t

def add_via(netname, x, y, drill=0.30, dia=0.50):
    net = b.FindNet(netname)
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(int(round(x * 1e6)), int(round(y * 1e6))))
    v.SetWidth(int(round(dia * 1e6)))
    v.SetDrill(int(round(drill * 1e6)))
    v.SetNet(net)
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    b.Add(v)
    return v

# CHG_STAT jog: turns down at X=44.0 to Y=1.800
add_trk('/CHG_STAT', bcu, 24.25, 1.00, 39.00, 1.00, 0.18)
add_trk('/CHG_STAT', bcu, 39.00, 1.00, 39.00, 2.30, 0.18)
add_trk('/CHG_STAT', bcu, 39.00, 2.30, 44.00, 2.30, 0.18)
add_trk('/CHG_STAT', bcu, 44.00, 2.30, 44.00, 1.80, 0.18)
add_trk('/CHG_STAT', bcu, 44.00, 1.80, 66.05, 1.80, 0.18)

# Clean GPIO8_STRAP straight south
for t in list(b.GetTracks()):
    if t.GetNetname() == '/GPIO8_STRAP':
        b.Delete(t)

add_trk('/GPIO8_STRAP', fcu, 43.630, 2.435, 43.630, 0.800)
add_trk('/GPIO8_STRAP', fcu, 43.630, 0.800, 43.525, 0.800)

# Move VSYS_RAW via from (59.50, 2.40) onto D4.1 pad at (59.00, 2.40)
for t in list(b.GetTracks()):
    if t.GetNetname() == '/VSYS_RAW':
        if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 59.50 and round(t.GetPosition().y/1e6, 2) == 2.40:
            b.Delete(t)
        elif t.GetClass() != 'PCB_VIA' and t.GetLayer() == fcu:
            b.Delete(t)

net_vsys = b.FindNet('/VSYS_RAW')
v_vsys = pcbnew.PCB_VIA(b)
v_vsys.SetPosition(pcbnew.VECTOR2I(int(59.000 * 1e6), int(2.400 * 1e6)))
v_vsys.SetWidth(int(0.500 * 1e6))
v_vsys.SetDrill(int(0.300 * 1e6))
v_vsys.SetNet(net_vsys)
b.Add(v_vsys)

t_vsys = pcbnew.PCB_TRACK(b)
t_vsys.SetStart(pcbnew.VECTOR2I(int(59.500 * 1e6), int(2.400 * 1e6)))
t_vsys.SetEnd(pcbnew.VECTOR2I(int(59.000 * 1e6), int(2.400 * 1e6)))
t_vsys.SetWidth(int(0.200 * 1e6))
t_vsys.SetLayer(in2)
t_vsys.SetNet(net_vsys)
b.Add(t_vsys)

# 1. SD_CS on In2.Cu
add_trk('/SD_CS', fcu, 43.130, 2.435, 43.130, 1.750)
add_via('/SD_CS', 43.130, 1.750)
add_trk('/SD_CS', in2, 43.130, 1.750, 43.130, 1.450)
add_trk('/SD_CS', in2, 43.130, 1.450, 56.975, 1.450)
add_trk('/SD_CS', in2, 56.975, 1.450, 56.975, 1.200)
add_via('/SD_CS', 56.975, 1.200)
add_trk('/SD_CS', fcu, 56.975, 1.200, 56.975, 2.000) # R18.2
add_trk('/SD_CS', in2, 56.975, 1.450, 59.400, 1.450)
add_trk('/SD_CS', in2, 59.400, 1.450, 59.400, 0.850)
add_via('/SD_CS', 59.400, 0.850)
add_trk('/SD_CS', fcu, 59.400, 0.850, 59.800, 0.850)
add_trk('/SD_CS', fcu, 59.800, 0.850, 59.800, 3.600)
add_trk('/SD_CS', fcu, 59.800, 3.600, 59.650, 3.600)
add_trk('/SD_CS', fcu, 59.650, 3.600, 59.650, 4.200) # J_SD.6

# 2. SD_SCK on In2.Cu
add_trk('/SD_SCK', fcu, 42.630, 2.435, 42.630, 0.500)
add_via('/SD_SCK', 42.630, 0.500)
add_trk('/SD_SCK', in2, 42.630, 0.500, 42.630, 1.150)
add_trk('/SD_SCK', in2, 42.630, 1.150, 57.500, 1.150)
add_trk('/SD_SCK', in2, 57.500, 1.150, 57.500, 3.200)
add_trk('/SD_SCK', in2, 57.500, 3.200, 58.150, 3.200)
add_via('/SD_SCK', 58.150, 3.200)
add_trk('/SD_SCK', fcu, 58.150, 3.200, 58.150, 4.200) # J_SD.3

# Refill all copper zones
filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
b.Save(dst_pcb)
print("Saved clean step 3.")
