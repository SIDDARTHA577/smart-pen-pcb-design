import os, sys, pcbnew, shutil

src_pcb = 'scratch_test_restore_vsys.kicad_pcb'
dst_pcb = 'scratch_test_fcu_cs.kicad_pcb'
shutil.copy(src_pcb, dst_pcb)
shutil.copy(src_pcb.replace('.kicad_pcb', '.kicad_pro'), dst_pcb.replace('.kicad_pcb', '.kicad_pro'))

b = pcbnew.LoadBoard(dst_pcb)
fcu = b.GetLayerID('F.Cu')
net = b.FindNet('/SD_CS')

# Hide R27 text
r27 = b.FindFootprintByReference('R27')
if r27: r27.Reference().SetVisible(False)

def add_trk(x1, y1, x2, y2, w=0.15):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(round(x1 * 1e6)), int(round(y1 * 1e6))))
    t.SetEnd(pcbnew.VECTOR2I(int(round(x2 * 1e6)), int(round(y2 * 1e6))))
    t.SetWidth(int(round(w * 1e6)))
    t.SetLayer(fcu)
    t.SetNet(net)
    b.Add(t)
    return t

# R18.2 at (56.975, 2.000) to J_SD.6 at (59.650, 4.200) on F.Cu
add_trk(56.975, 2.000, 56.975, 1.000)
add_trk(56.975, 1.000, 59.800, 1.000)
add_trk(59.800, 1.000, 59.800, 3.600)
add_trk(59.800, 3.600, 59.650, 3.600)
add_trk(59.650, 3.600, 59.650, 4.200)

filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
b.Save(dst_pcb)
print("Saved F.Cu CS test.")
