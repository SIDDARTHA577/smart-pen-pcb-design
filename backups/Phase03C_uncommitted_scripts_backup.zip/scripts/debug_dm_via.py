import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

for x_w in [54.8, 55.0, 55.2, 55.5, 56.0]:
    for y_w in [6.8, 6.9, 7.0]:
        v_ok, rv = geom.is_via_legal(x_w, y_w, '/USB_DM_CORE')
        s_fcu3, rf3 = geom.is_segment_legal(x_w, 8.4, x_w, y_w, 'F.Cu', '/USB_DM_CORE')
        print(f"({x_w}, {y_w}): via={v_ok}({rv}), fcu_drop={s_fcu3}({rf3})")
