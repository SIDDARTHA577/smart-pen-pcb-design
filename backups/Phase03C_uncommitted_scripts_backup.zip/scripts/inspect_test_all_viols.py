import json
from collections import Counter

d = json.load(open('reports/RevG/Phase03C/raw/test_all_drc.json'))
viols = d.get('violations', [])
print(f"Total violations: {len(viols)}")
types = Counter([v.get('type') for v in viols])
for t, c in types.items():
    print(f"  {t}: {c}")

print("\nSample violations:")
for v in viols[:10]:
    items = [i.get('description', '') for i in v.get('items', [])]
    print(f"  [{v.get('type')}] {v.get('description')} :: {' <-> '.join(items)}")
