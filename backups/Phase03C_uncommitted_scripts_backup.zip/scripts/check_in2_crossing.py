import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# Check crossing on In2.Cu at X=35.0, 36.0, 37.0, 38.0
for x in [35.0, 36.0, 37.0, 38.0]:
    s, r = geom.is_segment_legal(x, 5.600, x, 4.585, 'In2.Cu', '/I2C_SCL')
    print(f"Crossing at X={x:.1f} on In2.Cu: {s} ({r})")
