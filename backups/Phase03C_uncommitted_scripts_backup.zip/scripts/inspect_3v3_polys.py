import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
in2_id = b.GetLayerID('In2.Cu')

for z in b.Zones():
    if z.GetLayer() == in2_id and z.GetNetname() == '/3V3':
        poly = z.GetFilledPolysList(in2_id)
        print(f"In2.Cu 3V3 zone has {poly.OutlineCount()} outlines")
        for i in range(poly.OutlineCount()):
            bb = poly.Outline(i).BBox()
            print(f"  Outline {i}: ({bb.GetX()/1e6:.2f}, {bb.GetY()/1e6:.2f}) -> ({(bb.GetX()+bb.GetWidth())/1e6:.2f}, {(bb.GetY()+bb.GetHeight())/1e6:.2f})")
