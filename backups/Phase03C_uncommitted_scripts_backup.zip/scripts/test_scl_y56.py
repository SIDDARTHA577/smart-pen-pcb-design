import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Checking SCL east corridor at Y=5.6 on B.Cu:")
# (24.250, 7.150) -> (25.000, 7.150) -> (25.000, 5.600) -> (39.000, 5.600)
s1, r1 = geom.is_segment_legal(24.25, 7.15, 25.0, 7.15, 'B.Cu', '/I2C_SCL')
s2, r2 = geom.is_segment_legal(25.0, 7.15, 25.0, 5.6, 'B.Cu', '/I2C_SCL')
s3, r3 = geom.is_segment_legal(25.0, 5.6, 38.0, 5.6, 'B.Cu', '/I2C_SCL')
print(f"s1={s1}({r1}), s2={s2}({r2}), s3={s3}({r3})")

# Test via near U1.5 (40.480, 4.585)
for x in [37.5, 38.0, 38.5, 39.0, 39.5]:
    for y in [4.0, 4.2, 4.4, 4.6, 4.8]:
        v_ok, rv = geom.is_via_legal(x, y, '/I2C_SCL')
        if v_ok:
            s_fcu, rf = geom.is_segment_legal(x, y, 40.480, 4.585, 'F.Cu', '/I2C_SCL')
            if s_fcu:
                print(f"  Legal via at ({x},{y}) and F.Cu segment to U1.5 legal!")

sys.exit(0)
