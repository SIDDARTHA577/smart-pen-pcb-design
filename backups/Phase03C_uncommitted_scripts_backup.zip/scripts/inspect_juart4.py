import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
for f in b.GetFootprints():
    if f.GetReference() == 'J_UART':
        for p in f.Pads():
            if p.GetName() == '4':
                pos = p.GetPosition()
                print(f"J_UART.4 at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})")

for t in b.Tracks():
    if t.GetNetname() == '/3V3':
        p1, p2 = t.GetStart(), t.GetEnd()
        if abs(p1.x/1e6 - 55.0) < 3.0 and abs(p1.y/1e6 - 7.0) < 3.0:
            print(f"3V3 track: ({p1.x/1e6:.3f}, {p1.y/1e6:.3f}) -> ({p2.x/1e6:.3f}, {p2.y/1e6:.3f}) layer {b.GetLayerName(t.GetLayer())}")
