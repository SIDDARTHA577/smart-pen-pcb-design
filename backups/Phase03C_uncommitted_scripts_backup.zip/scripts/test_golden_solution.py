import pcbnew, shutil

# Create scratch_test_golden.kicad_pcb from scratch_test_mosi_flawless
shutil.copyfile('scratch_test_mosi_flawless.kicad_pcb', 'scratch_test_golden.kicad_pcb')
shutil.copyfile('scratch_test_mosi_flawless.kicad_pro', 'scratch_test_golden.kicad_pro')
shutil.copyfile('scratch_test_mosi_flawless.kicad_prl', 'scratch_test_golden.kicad_prl')

b = pcbnew.LoadBoard('scratch_test_golden.kicad_pcb')
fcu = b.GetLayerID('F.Cu')
in1 = b.GetLayerID('In1.Cu')
in2 = b.GetLayerID('In2.Cu')
bcu = b.GetLayerID('B.Cu')

# 1. Update D4 footprint pads to standard SOD-123 dimensions: (0.900, 0.800)
d4 = b.FindFootprintByReference('D4')
d4.SetPosition(pcbnew.VECTOR2I_MM(59.400, 4.200))
p1 = d4.FindPadByNumber('1')
p2 = d4.FindPadByNumber('2')

# Since D4 is rotated -90 deg:
# width on PCB is footprint Y, height on PCB is footprint X
p1.SetSize(pcbnew.VECTOR2I_MM(0.800, 0.900))
p2.SetSize(pcbnew.VECTOR2I_MM(0.800, 0.900))

p1_pos = p1.GetPosition()
p2_pos = p2.GetPosition()
print(f"D4.1 pos: ({pcbnew.ToMM(p1_pos.x):.3f}, {pcbnew.ToMM(p1_pos.y):.3f}), size=({pcbnew.ToMM(p1.GetSizeX()):.3f}, {pcbnew.ToMM(p1.GetSizeY()):.3f})")
print(f"D4.2 pos: ({pcbnew.ToMM(p2_pos.x):.3f}, {pcbnew.ToMM(p2_pos.y):.3f}), size=({pcbnew.ToMM(p2.GetSizeX()):.3f}, {pcbnew.ToMM(p2.GetSizeY()):.3f})")

# 2. Update VSYS_RAW via on Pad 1 to (59.400, 2.600)
for t in b.GetTracks():
    if isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/VSYS_RAW':
        pos = t.GetPosition()
        if abs(pcbnew.ToMM(pos.x) - 59.0) < 0.05 and abs(pcbnew.ToMM(pos.y) - 2.4) < 0.05:
            t.SetPosition(pcbnew.VECTOR2I_MM(59.400, 2.600))
            print("Moved VSYS_RAW via to (59.4, 2.6)")
    elif not isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/VSYS_RAW':
        p1_t, p2_t = t.GetStart(), t.GetEnd()
        x1, y1 = pcbnew.ToMM(p1_t.x), pcbnew.ToMM(p1_t.y)
        x2, y2 = pcbnew.ToMM(p2_t.x), pcbnew.ToMM(p2_t.y)
        # horizontal segment into D4.1: (59.5, 2.4) -> (59.0, 2.4)
        if abs(y1 - 2.4) < 0.05 and abs(y2 - 2.4) < 0.05:
            t.SetStart(pcbnew.VECTOR2I_MM(59.500, 2.600))
            t.SetEnd(pcbnew.VECTOR2I_MM(59.400, 2.600))
            print("Updated VSYS_RAW horizontal segment to Y=2.6")
        # vertical trunk end: (59.5, 6.5) -> (59.5, 2.4)
        if abs(x1 - 59.5) < 0.05 and abs(x2 - 59.5) < 0.05 and abs(y2 - 2.4) < 0.05:
            t.SetEnd(pcbnew.VECTOR2I_MM(59.500, 2.600))
            print("Updated VSYS_RAW vertical trunk end to Y=2.6")

# 3. Update USB_VBUS track to Pad 2 at (59.400, 5.800)
for t in b.GetTracks():
    if not isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/USB_VBUS' and t.GetLayer() == fcu:
        p1_t, p2_t = t.GetStart(), t.GetEnd()
        x2, y2 = pcbnew.ToMM(p2_t.x), pcbnew.ToMM(p2_t.y)
        if abs(x2 - 59.0) < 0.05 and abs(y2 - 5.6) < 0.05:
            t.SetEnd(pcbnew.VECTOR2I_MM(59.400, 5.800))
            print("Updated USB_VBUS track end to (59.4, 5.8)")

# 4. Connect /SD_MISO:
def add_tr(netname, lid, x1, y1, x2, y2, w=0.150):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I_MM(x1, y1))
    t.SetEnd(pcbnew.VECTOR2I_MM(x2, y2))
    t.SetWidth(pcbnew.FromMM(w))
    t.SetLayer(lid)
    t.SetNet(b.FindNet(netname))
    b.Add(t)
    return t

# At J_SD: North Escape
# Pad 5 (59.150, 4.200) -> (59.150, 5.050) -> (57.300, 5.050) -> (57.300, 5.500)
add_tr('/SD_MISO', fcu, 59.150, 4.200, 59.150, 5.050)
add_tr('/SD_MISO', fcu, 59.150, 5.050, 57.300, 5.050)
add_tr('/SD_MISO', fcu, 57.300, 5.050, 57.300, 5.500)

v_miso_sd = pcbnew.PCB_VIA(b)
v_miso_sd.SetPosition(pcbnew.VECTOR2I_MM(57.300, 5.500))
v_miso_sd.SetDrill(pcbnew.FromMM(0.300))
v_miso_sd.SetWidth(pcbnew.FromMM(0.500))
v_miso_sd.SetNet(b.FindNet('/SD_MISO'))
v_miso_sd.SetViaType(pcbnew.VIATYPE_THROUGH)
b.Add(v_miso_sd)

# At U1: South Escape
# U1.10 (41.630, 2.435) -> (41.630, 0.600)
add_tr('/SD_MISO', fcu, 41.630, 2.435, 41.630, 0.600)
v_miso_u1 = pcbnew.PCB_VIA(b)
v_miso_u1.SetPosition(pcbnew.VECTOR2I_MM(41.630, 0.600))
v_miso_u1.SetDrill(pcbnew.FromMM(0.300))
v_miso_u1.SetWidth(pcbnew.FromMM(0.500))
v_miso_u1.SetNet(b.FindNet('/SD_MISO'))
v_miso_u1.SetViaType(pcbnew.VIATYPE_THROUGH)
b.Add(v_miso_u1)

# Transit on In1.Cu:
# From (41.630, 0.600) -> (43.000, 0.600) -> (44.000, 1.400) -> (56.000, 1.400) -> (57.300, 5.500)
# Wait, let's see how In1.Cu connects (56.0, 1.4) to (57.3, 5.5)!
# MOSI is at (58.65, 3.35) via, and its In1.Cu trace was (57.6, 1.4) -> (58.65, 3.35).
# If MISO goes from (56.0, 1.4) to (57.3, 5.5):
# Wait! Does that cross MOSI?
# Where is MOSI? MOSI comes from (44.5, 2.0) -> (57.6, 2.0) -> (58.65, 3.35)!
# Let's check MOSI route on In1.Cu in scratch_test_mosi_flawless:
# In scratch_test_mosi_flawless, MOSI on In1.Cu was:
# (41.13, 1.65) -> (41.45, 2.3) -> (43.6, 2.3) -> (44.5, 1.4) -> (57.6, 1.4) -> (58.65, 3.35)!
# Notice: in scratch_test_mosi_flawless, MOSI was at Y = 1.400!
# If MOSI is at Y = 1.400, then MISO climbing to 5.500 from the south would cross MOSI!
# BUT what if MISO travels on B.Cu instead of In1.Cu?
# On B.Cu:
# From (41.630, 0.600) -> (55.000, 0.600) -> (57.300, 5.500)?
# Wait, let's check what layer is completely clear!
