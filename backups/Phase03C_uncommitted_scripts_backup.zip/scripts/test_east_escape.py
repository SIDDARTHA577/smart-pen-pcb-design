import sys
from pathlib import Path
sys.path.insert(0, str(Path('scripts')))
import astar_miso
import pcbnew

board = pcbnew.LoadBoard('scratch_test_mosi_flawless.kicad_pcb')

# Let's test the entire MISO escape path on F.Cu via X=59.800:
# Segment 1: (59.15, 4.20) -> (59.15, 3.25)
s1 = astar_miso.track_clear(astar_miso.fcu, 59.15, 4.20, 59.15, 3.25)
# Segment 2: (59.15, 3.25) -> (59.80, 3.25)
# Note: In scratch_test_mosi_flawless, SD_CS is currently at 59.80 on F.Cu,
# so let's temporarily ignore SD_CS tracks to test if it's geometry-clear!
print("S1 (59.15, 4.2) -> (59.15, 3.25):", s1)

# Let's check via at (59.70, 1.30)
v_ok = astar_miso.via_clear(59.70, 1.30)
print("Via (59.70, 1.30) clear:", v_ok)
