import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_restore_vsys.kicad_pcb')
geom = BoardGeometry(b)

print("--- Testing candidate via spots for the 4 SD nets near J_SD ---")
for x in [56.5, 57.0, 57.4, 57.5, 57.8, 58.0, 58.15, 58.5, 59.0, 59.3, 59.65]:
    for y in [0.5, 0.7, 0.85, 1.0, 1.15, 1.3, 1.45, 2.0, 2.5, 2.8, 3.2, 5.0, 5.5]:
        v_ok, rv = geom.is_via_legal(x, y, '/SD_SCK')
        if v_ok:
            print(f"Legal via at ({x:.2f}, {y:.2f})")
