import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
bcu_id = b.GetLayerID('B.Cu')

# Adjust VBAT_SW jog
to_remove = []
for t in b.Tracks():
    if not isinstance(t, pcbnew.PCB_VIA) and t.GetLayer() == bcu_id and t.GetNetname() == '/VBAT_SW':
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (x1 == 38.0 and x2 == 40.5) or (x1 == 40.5 and x2 == 52.0):
            to_remove.append(t)
for t in to_remove:
    b.Remove(t)

def add_track(x1, y1, x2, y2, layer_id, net_name, width=0.25):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(x1*1e6), int(y1*1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2*1e6), int(y2*1e6)))
    t.SetLayer(layer_id)
    t.SetWidth(int(width*1e6))
    t.SetNet(b.FindNet(net_name))
    b.Add(t)

add_track(38.000, 4.050, 41.200, 4.050, bcu_id, '/VBAT_SW', 0.25)
add_track(41.200, 4.050, 41.650, 4.500, bcu_id, '/VBAT_SW', 0.25)
add_track(41.650, 4.500, 52.000, 4.500, bcu_id, '/VBAT_SW', 0.25)

geom = BoardGeometry(b)

print("Checking how far west Y=4.585 reaches from X=38.800:")
for x_west in [38.0, 37.0, 36.0, 35.0, 34.0, 33.0, 32.0, 31.0, 30.0, 29.0]:
    s, r = geom.is_segment_legal(x_west, 4.585, 38.800, 4.585, 'B.Cu', '/I2C_SCL')
    print(f"X={x_west:.1f} to 38.8: {s} ({r})")
