from pathlib import Path
import re

pcb_text = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb").read_text(encoding="utf-8")
matches = re.finditer(r'\(zone\s+.*?\(net\s+"([^"]+)"\)\s+\(layer\s+"([^"]+)"\)', pcb_text, re.DOTALL)
count = 0
for m in matches:
    count += 1
    print(f"Zone {count}: Net={m.group(1)} Layer={m.group(2)}")

