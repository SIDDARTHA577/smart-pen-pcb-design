import pcbnew
from collections import defaultdict
from pathlib import Path

pcb_path = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb")
board = pcbnew.LoadBoard(str(pcb_path))

tracks = board.GetTracks()
print(f"Total track/via segments: {len(tracks)}")

by_layer = defaultdict(int)
by_net = defaultdict(int)
vias = []
for t in tracks:
    if t.GetClass() == "PCB_VIA" or t.GetClass() == "VIA":
        vias.append(t)
    else:
        by_layer[t.GetLayerName()] += 1
    by_net[t.GetNetname()] += 1

print("Tracks by layer:")
for l, c in by_layer.items():
    print(f"  {l}: {c}")

print(f"Total vias: {len(vias)}")
print(f"Total nets with tracks: {len(by_net)}")

