import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
fcu = b.GetLayerID('F.Cu')
in2 = b.GetLayerID('In2.Cu')
net = b.FindNet('/VSYS_RAW')

def add_via(x, y):
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(int(x*1e6), int(y*1e6)))
    v.SetWidth(int(0.500*1e6))
    v.SetDrill(int(0.300*1e6))
    v.SetNet(net)
    b.Add(v)

def add_track(x1, y1, x2, y2, layer_id, width=0.20):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(x1*1e6), int(y1*1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2*1e6), int(y2*1e6)))
    t.SetLayer(layer_id)
    t.SetWidth(int(width*1e6))
    t.SetNet(net)
    b.Add(t)

# Main run:
add_track(60.963, 6.824, 60.500, 6.500, fcu)
add_via(60.500, 6.500)
add_track(60.500, 6.500, 59.500, 6.500, in2)
add_track(59.500, 6.500, 59.500, 2.400, in2)
add_via(59.500, 2.400)
add_track(59.500, 2.400, 59.000, 2.400, fcu) # D4.1

# Q2.2 tap:
add_track(59.500, 3.450, 61.500, 3.450, in2)
add_via(61.500, 3.450)
add_track(61.500, 3.450, 61.700, 3.450, fcu) # Q2.2

candidate_pcb = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb'
b.Save(candidate_pcb)
print("Saved VSYS_RAW route to candidate PCB!")
