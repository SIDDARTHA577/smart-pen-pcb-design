import sys
sys.path.append('scripts')
import pcbnew

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
r18 = b.FindFootprintByReference('R18')
print('R18 pos:', r18.GetPosition().x/1e6, r18.GetPosition().y/1e6, 'rot:', r18.GetOrientation().AsDegrees())
for p in r18.Pads():
    pos = p.GetPosition()
    print(f"  Pad {p.GetNumber()} ({p.GetNetname()}): ({pos.x/1e6:.3f}, {pos.y/1e6:.3f}) layer={b.GetLayerName(p.GetLayer())}")
