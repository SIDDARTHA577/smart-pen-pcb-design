import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")
bcu = b.GetLayerID('B.Cu')

print("--- Objects on B.Cu between X=37 and 45, Y in [0.0, 2.0] ---")
for t in b.GetTracks():
    if t.GetClass() == 'PCB_VIA':
        p = t.GetPosition()
        x, y = p.x/1e6, p.y/1e6
        if 37.0 <= x <= 45.0 and 0.0 <= y <= 2.0:
            print(f"VIA {t.GetNetname()}: ({x:.3f}, {y:.3f})")
    elif t.GetLayer() == bcu:
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (37.0 <= x1 <= 45.0 or 37.0 <= x2 <= 45.0) and (0.0 <= y1 <= 2.0 or 0.0 <= y2 <= 2.0):
            print(f"TRK {t.GetNetname()}: ({x1:.3f}, {y1:.3f}) -> ({x2:.3f}, {y2:.3f})")
