import pcbnew

b = pcbnew.LoadBoard("scratch_test_clean_step9.kicad_pcb")
fcu = b.GetLayerID('F.Cu')
net_3v3 = b.FindNet('/3V3')

print("--- Objects on F.Cu between X=55.5 and 57.5, Y in [2.0, 4.5] ---")
for fp in b.GetFootprints():
    for p in fp.Pads():
        pos = p.GetPosition()
        x, y = pos.x/1e6, pos.y/1e6
        if 55.5 <= x <= 57.5 and 2.0 <= y <= 4.5:
            print(f"FP: {fp.GetReference()} Pad: {p.GetNumber()} Net: {p.GetNetname()} at ({x:.3f}, {y:.3f})")

for t in b.GetTracks():
    if t.GetLayer() == fcu:
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (55.5 <= x1 <= 57.5 or 55.5 <= x2 <= 57.5) and (2.0 <= y1 <= 4.5 or 2.0 <= y2 <= 4.5):
            print(f"TRK {t.GetNetname()}: ({x1:.3f}, {y1:.3f}) -> ({x2:.3f}, {y2:.3f})")
