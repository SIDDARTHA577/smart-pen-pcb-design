import json

d = json.load(open('reports/RevG/Phase03C/raw/candidate_scl_drc.json'))
u10 = d.get('unconnected_items', [])[9]
print("Item 10 items:")
for i in u10.get('items', []):
    print(" ", i.get('pos'), i.get('description'))
