import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

print("--- Testing SD_MISO and SD_CS East Highway ---")

# SD_CS (Pad 6 at 59.650, 4.200):
# (59.650, 4.200) -> (60.100, 3.750) -> (60.100, 0.850) -> (59.650, 0.850) -> via at (59.650, 0.850)
s_cs1, r_cs1 = geom.is_segment_legal(59.650, 4.200, 60.100, 3.750, 'F.Cu', '/SD_CS')
s_cs2, r_cs2 = geom.is_segment_legal(60.100, 3.750, 60.100, 0.850, 'F.Cu', '/SD_CS')
s_cs3, r_cs3 = geom.is_segment_legal(60.100, 0.850, 59.650, 0.850, 'F.Cu', '/SD_CS')
v_cs, rv_cs = geom.is_via_legal(59.650, 0.850, '/SD_CS')
print(f"SD_CS East Route: s1={s_cs1}({r_cs1}), s2={s_cs2}({r_cs2}), s3={s_cs3}({r_cs3}), via={v_cs}({rv_cs})")

# SD_MISO (Pad 5 at 59.150, 4.200):
# (59.150, 4.200) -> (59.150, 3.300) -> (59.750, 3.300) -> (59.750, 1.400) -> via at (59.750, 1.400)
# Or via at (59.300, 1.400)
s_m1, r_m1 = geom.is_segment_legal(59.150, 4.200, 59.150, 3.300, 'F.Cu', '/SD_MISO')
s_m2, r_m2 = geom.is_segment_legal(59.150, 3.300, 59.750, 3.300, 'F.Cu', '/SD_MISO')
s_m3, r_m3 = geom.is_segment_legal(59.750, 3.300, 59.750, 1.400, 'F.Cu', '/SD_MISO')
v_m, rv_m = geom.is_via_legal(59.750, 1.400, '/SD_MISO')
print(f"SD_MISO East Route: s1={s_m1}({r_m1}), s2={s_m2}({r_m2}), s3={s_m3}({r_m3}), via={v_m}({rv_m})")
