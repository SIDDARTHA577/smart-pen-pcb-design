import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- PADS X: 44..48, Y: 5.5..8.5 ---')
for p in board.GetPads():
    pos = p.GetPosition()
    x, y = pos.x / 1e6, pos.y / 1e6
    if 44.0 <= x <= 48.0 and 5.5 <= y <= 8.5:
        fp = p.GetParentFootprint()
        ref = fp.GetReference() if fp else '?'
        print(f'{ref}.{p.GetNumber()} [{p.GetNetname()}] at ({x:.3f}, {y:.3f}) size ({p.GetSize().x/1e6:.3f}, {p.GetSize().y/1e6:.3f})')

print('--- TRACKS on F.Cu X: 44..48, Y: 5.5..8.5 ---')
for t in board.GetTracks():
    if t.GetLayerName() == 'F.Cu':
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = s.x/1e6, s.y/1e6
        ex, ey = e.x/1e6, e.y/1e6
        if (44.0 <= sx <= 48.0 and 5.5 <= sy <= 8.5) or (44.0 <= ex <= 48.0 and 5.5 <= ey <= 8.5):
            print(f'{t.GetNetname()}: ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})')

