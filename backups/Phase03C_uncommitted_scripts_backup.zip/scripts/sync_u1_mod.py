with open('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb', 'r') as f:
    pcb = f.read()

import re
pos = pcb.find('SmartPen:U1')
end = pcb.find('(footprint', pos + 20)
pcb_u1 = pcb[pos:end]

with open('output/RevG/variants/FourLayer_Candidate/SmartPen.pretty/U1.kicad_mod', 'r') as f:
    mod = f.read()

# Replace each pad in mod with the corresponding pad in pcb_u1 (removing net and uuid)
for pnum in [str(i) for i in range(1, 34)]:
    pm_pcb = re.search(r'\(pad\s+"' + pnum + r'".*?\n\t\t\)', pcb_u1, re.DOTALL)
    if pm_pcb:
        pad_str = pm_pcb.group(0)
        # remove net and uuid
        pad_clean = re.sub(r'\n\t\t\t\(net\s+"[^"]+"\)', '', pad_str)
        pad_clean = re.sub(r'\n\t\t\t\(uuid\s+"[^"]+"\)', '', pad_clean)
        # In mod, indentation is 1 tab less:
        # replace in mod
        mod = re.sub(r'\(pad\s+"' + pnum + r'".*?\n\t\)', pad_clean.replace('\t\t\t', '\t\t').replace('\t\t)', '\t)'), mod, flags=re.DOTALL)

with open('output/RevG/variants/FourLayer_Candidate/SmartPen.pretty/U1.kicad_mod', 'w') as f:
    f.write(mod)
print('Synchronized U1.kicad_mod with SmartPen.kicad_pcb')

