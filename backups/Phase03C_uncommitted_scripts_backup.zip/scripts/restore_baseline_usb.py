import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

nets_to_clean = ['/USB_CC1', '/USB_CC2', '/USB_DP_PORT', '/USB_DM_PORT', '/USB_DP_CORE', '/USB_DM_CORE']

to_del = []
for t in board.GetTracks():
    if t.GetNetname() in nets_to_clean:
        # Check if it was one of the newly added tracks/vias
        # Let's inspect
        to_del.append(t)

# Wait, baseline had some tracks for USB_DM_PORT and USB_DP_PORT!
# Baseline tracks were:
# PCB_TRACK [/USB_DM_PORT] F.Cu (78.650, 3.100) -> (78.650, 0.550)
# PCB_TRACK [/USB_DM_PORT] F.Cu (72.000, 0.550) -> (72.000, 3.190)
# PCB_VIA [/USB_DM_PORT] F.Cu (78.650, 0.550) -> (78.650, 0.550)
# PCB_VIA [/USB_DM_PORT] F.Cu (72.000, 0.550) -> (72.000, 0.550)
# PCB_TRACK [/USB_DM_PORT] B.Cu (72.000, 0.550) -> (78.650, 0.550)
# PCB_TRACK [/USB_DP_PORT] F.Cu (71.050, 1.200) -> (71.050, 3.190)
# PCB_TRACK [/USB_DP_PORT] F.Cu (78.150, 3.100) -> (78.150, 1.200)
# PCB_VIA [/USB_DP_PORT] F.Cu (78.150, 1.200) -> (78.150, 1.200)
# PCB_VIA [/USB_DP_PORT] F.Cu (71.050, 1.200) -> (71.050, 1.200)
# PCB_TRACK [/USB_DP_PORT] B.Cu (71.050, 1.200) -> (78.150, 1.200)

for t in to_del:
    board.Remove(t)

# Restore baseline USB tracks
def trk(board, netname, layer_name, x1, y1, x2, y2, w=0.18):
    net = board.FindNet(netname)
    layer = board.GetLayerID(layer_name)
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    t.SetWidth(int(w * 1e6))
    t.SetLayer(layer)
    t.SetNet(net)
    board.Add(t)
    return t

def via(board, netname, x, y, drill=0.30, dia=0.50):
    net = board.FindNet(netname)
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    v.SetWidth(int(dia * 1e6))
    v.SetDrill(int(drill * 1e6))
    v.SetNet(net)
    board.Add(v)
    return v

# DM baseline
trk(board, '/USB_DM_PORT', 'F.Cu', 78.650, 3.100, 78.650, 0.550)
via(board, '/USB_DM_PORT', 78.650, 0.550)
trk(board, '/USB_DM_PORT', 'B.Cu', 72.000, 0.550, 78.650, 0.550)
via(board, '/USB_DM_PORT', 72.000, 0.550)
trk(board, '/USB_DM_PORT', 'F.Cu', 72.000, 0.550, 72.000, 3.190)

# DP baseline
trk(board, '/USB_DP_PORT', 'F.Cu', 78.150, 3.100, 78.150, 1.200)
via(board, '/USB_DP_PORT', 78.150, 1.200)
trk(board, '/USB_DP_PORT', 'B.Cu', 71.050, 1.200, 78.150, 1.200)
via(board, '/USB_DP_PORT', 71.050, 1.200)
trk(board, '/USB_DP_PORT', 'F.Cu', 71.050, 1.200, 71.050, 3.190)

filler = pcbnew.ZONE_FILLER(board)
filler.Fill(board.Zones())
board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('Restored baseline USB tracks')

