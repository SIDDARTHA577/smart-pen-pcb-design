import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

for ref in ['R26', 'D4', 'Q2']:
    fp = board.FindFootprintByReference(ref)
    print(f'=== {ref} ===')
    for p in fp.Pads():
        pos = p.GetPosition()
        size = p.GetSize()
        print(f'  Pad {p.GetNumber()} at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f}), size ({size.x/1e6:.3f}, {size.y/1e6:.3f})')

