import os, sys, math
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try: import wx; wx.DisableAsserts()
except: pass
import pcbnew, shutil

src_pcb = 'scratch_test_restore_vsys.kicad_pcb'
dst_pcb = 'scratch_test_master_sd.kicad_pcb'
shutil.copy(src_pcb, dst_pcb)
shutil.copy(src_pcb.replace('.kicad_pcb', '.kicad_pro'), dst_pcb.replace('.kicad_pcb', '.kicad_pro'))

b = pcbnew.LoadBoard(dst_pcb)

# 1. Delete freestanding stitching via at (55.00, 1.20)
for t in list(b.GetTracks()):
    if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 55.00 and round(t.GetPosition().y/1e6, 2) == 1.20:
        b.Delete(t)

# 2. Fix R27 silkscreen reference: hide or move to safe spot (44.0, 1.25)
r27 = b.FindFootprintByReference('R27')
if r27:
    r27.Reference().SetVisible(False)

# 3. Clean any existing SD tracks
for netname in ['/SD_SCK', '/SD_MOSI', '/SD_MISO', '/SD_CS']:
    net = b.FindNet(netname)
    for t in list(b.GetTracks()):
        if t.GetNet() == net:
            b.Delete(t)

# 4. CHG_STAT jog on B.Cu:
# Delete B.Cu CHG_STAT tracks from 24.25 to 66.05
for t in list(b.GetTracks()):
    if t.GetNetname() == '/CHG_STAT' and t.GetLayer() == b.GetLayerID('B.Cu'):
        b.Delete(t)

bcu = b.GetLayerID('B.Cu')
fcu = b.GetLayerID('F.Cu')
in2 = b.GetLayerID('In2.Cu')

def add_trk(netname, layer_id, x1, y1, x2, y2, w=0.15):
    net = b.FindNet(netname)
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(round(x1 * 1e6)), int(round(y1 * 1e6))))
    t.SetEnd(pcbnew.VECTOR2I(int(round(x2 * 1e6)), int(round(y2 * 1e6))))
    t.SetWidth(int(round(w * 1e6)))
    t.SetLayer(layer_id)
    t.SetNet(net)
    b.Add(t)
    return t

def add_via(netname, x, y, drill=0.30, dia=0.50):
    net = b.FindNet(netname)
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(int(round(x * 1e6)), int(round(y * 1e6))))
    v.SetWidth(int(round(dia * 1e6)))
    v.SetDrill(int(round(drill * 1e6)))
    v.SetNet(net)
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    b.Add(v)
    return v

# Apply CHG_STAT clean jog
add_trk('/CHG_STAT', bcu, 24.25, 1.00, 39.00, 1.00, 0.18)
add_trk('/CHG_STAT', bcu, 39.00, 1.00, 39.00, 2.30, 0.18)
add_trk('/CHG_STAT', bcu, 39.00, 2.30, 44.00, 2.30, 0.18)
add_trk('/CHG_STAT', bcu, 44.00, 2.30, 44.00, 1.80, 0.18)
add_trk('/CHG_STAT', bcu, 44.00, 1.80, 66.05, 1.80, 0.18)

# --- ROUTE 1: /SD_SCK (on In2.Cu at Y=1.450) ---
# U1.12 (42.630, 2.435) escape south to via at (42.630, 0.500)
add_trk('/SD_SCK', fcu, 42.630, 2.435, 42.630, 0.500)
add_via('/SD_SCK', 42.630, 0.500)
# In2.Cu: (42.630, 0.500) -> (42.630, 1.450) -> (58.150, 1.450)
add_trk('/SD_SCK', in2, 42.630, 0.500, 42.630, 1.450)
add_trk('/SD_SCK', in2, 42.630, 1.450, 58.150, 1.450)
add_via('/SD_SCK', 58.150, 1.450)
# F.Cu: straight north to J_SD.3 at (58.150, 4.200)
add_trk('/SD_SCK', fcu, 58.150, 1.450, 58.150, 4.200)

# --- ROUTE 2: /SD_CS (on In2.Cu at Y=1.150) ---
# U1.13 (43.130, 2.435) escape
add_trk('/SD_CS', fcu, 43.130, 2.435, 43.130, 1.950)
add_trk('/SD_CS', fcu, 43.130, 1.950, 43.000, 1.820)
add_trk('/SD_CS', fcu, 43.000, 1.820, 43.000, 1.600)
add_via('/SD_CS', 43.000, 1.600)
# In2.Cu ribbon to R18.2
add_trk('/SD_CS', in2, 43.000, 1.600, 43.000, 1.150)
add_trk('/SD_CS', in2, 43.000, 1.150, 56.975, 1.150)
add_via('/SD_CS', 56.975, 1.150)
add_trk('/SD_CS', fcu, 56.975, 1.150, 56.975, 2.000)
# Continue on In2.Cu to (59.650, 1.150) -> (59.650, 0.850)
add_trk('/SD_CS', in2, 56.975, 1.150, 59.650, 1.150)
add_trk('/SD_CS', in2, 59.650, 1.150, 59.650, 0.850)
add_via('/SD_CS', 59.650, 0.850)
# F.Cu jog to clear D4.1: (59.650, 0.850) -> (59.800, 0.850) -> (59.800, 3.600) -> (59.650, 3.600) -> (59.650, 4.200)
add_trk('/SD_CS', fcu, 59.650, 0.850, 59.800, 0.850)
add_trk('/SD_CS', fcu, 59.800, 0.850, 59.800, 3.600)
add_trk('/SD_CS', fcu, 59.800, 3.600, 59.650, 3.600)
add_trk('/SD_CS', fcu, 59.650, 3.600, 59.650, 4.200)

# --- ROUTE 3: /SD_MOSI (on B.Cu at Y=1.150) ---
# U1.9 (41.130, 2.435) -> (41.130, 1.600) via
add_trk('/SD_MOSI', fcu, 41.130, 2.435, 41.130, 1.600)
add_via('/SD_MOSI', 41.130, 1.600)
# B.Cu: (41.130, 1.600) -> (41.130, 1.150) -> (56.000, 1.150) -> (56.000, 2.750) -> (57.400, 2.750) via
add_trk('/SD_MOSI', bcu, 41.130, 1.600, 41.130, 1.150)
add_trk('/SD_MOSI', bcu, 41.130, 1.150, 56.000, 1.150)
add_trk('/SD_MOSI', bcu, 56.000, 1.150, 56.000, 2.750)
add_trk('/SD_MOSI', bcu, 56.000, 2.750, 57.400, 2.750)
add_via('/SD_MOSI', 57.400, 2.750)
# F.Cu: (57.400, 2.750) -> (57.400, 3.200) -> (58.650, 3.200) -> (58.650, 4.200) (J_SD.4)
add_trk('/SD_MOSI', fcu, 57.400, 2.750, 57.400, 3.200)
add_trk('/SD_MOSI', fcu, 57.400, 3.200, 58.650, 3.200)
add_trk('/SD_MOSI', fcu, 58.650, 3.200, 58.650, 4.200)

# --- ROUTE 4: /SD_MISO (on B.Cu at Y=1.450) ---
# U1.10 (41.630, 2.435) -> (41.630, 0.500) via
add_trk('/SD_MISO', fcu, 41.630, 2.435, 41.630, 0.500)
add_via('/SD_MISO', 41.630, 0.500)
# B.Cu: (41.630, 0.500) -> (41.630, 1.450) -> (55.500, 1.450) -> (55.500, 3.150) -> (57.850, 3.150) via
add_trk('/SD_MISO', bcu, 41.630, 0.500, 41.630, 1.450)
add_trk('/SD_MISO', bcu, 41.630, 1.450, 55.500, 1.450)
add_trk('/SD_MISO', bcu, 55.500, 1.450, 55.500, 3.150)
add_trk('/SD_MISO', bcu, 55.500, 3.150, 57.850, 3.150)
add_via('/SD_MISO', 57.850, 3.150)
# F.Cu: (57.850, 3.150) -> (57.850, 3.450) -> (59.150, 3.450) -> (59.150, 4.200) (J_SD.5)
add_trk('/SD_MISO', fcu, 57.850, 3.150, 57.850, 3.450)
add_trk('/SD_MISO', fcu, 57.850, 3.450, 59.150, 3.450)
add_trk('/SD_MISO', fcu, 59.150, 3.450, 59.150, 4.200)

# Refill all zones
filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())

b.Save(dst_pcb)
print(f"Successfully generated {dst_pcb}")
