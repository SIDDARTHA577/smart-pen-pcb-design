import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
fcu_id = b.GetLayerID('F.Cu')

print("--- PADS on F.Cu between X=37 and 42, Y=3.5 and 6.0 ---")
for f in b.GetFootprints():
    for p in f.Pads():
        pos = p.GetPosition()
        x, y = pos.x/1e6, pos.y/1e6
        if 37 <= x <= 42 and 3.5 <= y <= 6.0:
            print(f"Pad: {f.GetReference()}.{p.GetName()} ({p.GetNetname()}) at ({x:.3f}, {y:.3f}) size ({p.GetSize().x/1e6:.3f}, {p.GetSize().y/1e6:.3f})")

print("\n--- TRACKS on F.Cu between X=37 and 42, Y=3.5 and 6.0 ---")
for t in b.Tracks():
    if not isinstance(t, pcbnew.PCB_VIA) and t.GetLayer() == fcu_id:
        p1 = t.GetStart()
        p2 = t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if max(x1, x2) >= 37 and min(x1, x2) <= 42 and max(y1, y2) >= 3.5 and min(y1, y2) <= 6.0:
            print(f"Track: {t.GetNetname()} F.Cu ({x1:.3f},{y1:.3f}) -> ({x2:.3f},{y2:.3f})")
