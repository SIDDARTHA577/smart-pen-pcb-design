import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- F.Cu items in [41, 43.5] x [0.5, 1.8] ---')
for fp in board.Footprints():
    for p in fp.Pads():
        pos = p.GetPosition()
        px, py = pos.x/1e6, pos.y/1e6
        if 41 <= px <= 43.5 and 0.5 <= py <= 1.8:
            print(f'Pad {fp.GetReference()}.{p.GetNumber()} [{p.GetNetname()}] at ({px:.3f}, {py:.3f})')

