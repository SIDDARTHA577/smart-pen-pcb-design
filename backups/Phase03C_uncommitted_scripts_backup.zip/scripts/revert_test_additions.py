import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

board_path = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb'
b = pcbnew.LoadBoard(board_path)

nets_to_clean = [
    '/SD_MOSI', '/SD_MISO', '/SD_SCK', '/SD_CS',
    '/VSYS_RAW', '/VBAT', '/USB_VBUS', '/I2C_SCL',
    '/USB_DM_CORE'
]

tracks = [t for t in b.Tracks()]
for t in tracks:
    if t.GetNetname() in nets_to_clean:
        # Keep only the original baseline I2C_SCL track from U3.1 to (24.25, 7.15)
        if t.GetNetname() == '/I2C_SCL':
            if isinstance(t, pcbnew.PCB_VIA):
                pos = t.GetPosition()
                if abs(pos.x/1e6 - 24.25) < 0.2 and abs(pos.y/1e6 - 7.15) < 0.2:
                    continue # keep baseline via
            else:
                s = t.GetStart()
                if abs(s.x/1e6 - 24.25) < 0.2 and abs(s.y/1e6 - 6.55) < 0.2:
                    continue # keep baseline track
        b.Remove(t)

# Also remove via on 3V3 at (52.0, 2.8)
for t in [tr for tr in b.Tracks()]:
    if isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/3V3':
        pos = t.GetPosition()
        if abs(pos.x/1e6 - 52.0) < 0.2 and abs(pos.y/1e6 - 2.8) < 0.2:
            b.Remove(t)

filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
b.Save(board_path)
print("Reverted to clean baseline!")
sys.exit(0)
