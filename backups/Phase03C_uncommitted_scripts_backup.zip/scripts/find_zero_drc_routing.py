import os, sys, math, json, subprocess
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try: import wx; wx.DisableAsserts()
except: pass
import pcbnew, shutil
from strict_clearance_checker import BoardGeometry

def try_candidate(name, u1_vias, east_vias, routes):
    src_pcb = 'scratch_test_restore_vsys.kicad_pcb'
    dst_pcb = f'scratch_{name}.kicad_pcb'
    shutil.copy(src_pcb, dst_pcb)
    shutil.copy(src_pcb.replace('.kicad_pcb', '.kicad_pro'), dst_pcb.replace('.kicad_pcb', '.kicad_pro'))

    b = pcbnew.LoadBoard(dst_pcb)
    
    # 1. Delete freestanding GND via at (55.0, 1.2)
    for t in list(b.GetTracks()):
        if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 55.00 and round(t.GetPosition().y/1e6, 2) == 1.20:
            b.Delete(t)
            
    # 2. Hide R27 silkscreen reference
    r27 = b.FindFootprintByReference('R27')
    if r27:
        r27.Reference().SetVisible(False)
        
    # 3. Clean any existing SD tracks
    for netname in ['/SD_SCK', '/SD_MOSI', '/SD_MISO', '/SD_CS']:
        net = b.FindNet(netname)
        for t in list(b.GetTracks()):
            if t.GetNet() == net:
                b.Delete(t)

    # 4. CHG_STAT jog on B.Cu
    for t in list(b.GetTracks()):
        if t.GetNetname() == '/CHG_STAT' and t.GetLayer() == b.GetLayerID('B.Cu'):
            b.Delete(t)

    bcu = b.GetLayerID('B.Cu')
    fcu = b.GetLayerID('F.Cu')
    in2 = b.GetLayerID('In2.Cu')

    def add_trk(netname, layer_id, x1, y1, x2, y2, w=0.15):
        net = b.FindNet(netname)
        t = pcbnew.PCB_TRACK(b)
        t.SetStart(pcbnew.VECTOR2I(int(round(x1 * 1e6)), int(round(y1 * 1e6))))
        t.SetEnd(pcbnew.VECTOR2I(int(round(x2 * 1e6)), int(round(y2 * 1e6))))
        t.SetWidth(int(round(w * 1e6)))
        t.SetLayer(layer_id)
        t.SetNet(net)
        b.Add(t)
        return t

    def add_via(netname, x, y, drill=0.30, dia=0.50):
        net = b.FindNet(netname)
        v = pcbnew.PCB_VIA(b)
        v.SetPosition(pcbnew.VECTOR2I(int(round(x * 1e6)), int(round(y * 1e6))))
        v.SetWidth(int(round(dia * 1e6)))
        v.SetDrill(int(round(drill * 1e6)))
        v.SetNet(net)
        v.SetViaType(pcbnew.VIATYPE_THROUGH)
        b.Add(v)
        return v

    # CHG_STAT jog
    add_trk('/CHG_STAT', bcu, 24.25, 1.00, 39.00, 1.00, 0.18)
    add_trk('/CHG_STAT', bcu, 39.00, 1.00, 39.00, 2.30, 0.18)
    add_trk('/CHG_STAT', bcu, 39.00, 2.30, 44.00, 2.30, 0.18)
    add_trk('/CHG_STAT', bcu, 44.00, 2.30, 44.00, 1.80, 0.18)
    add_trk('/CHG_STAT', bcu, 44.00, 1.80, 66.05, 1.80, 0.18)

    # Add all vias
    for netname, vx, vy in u1_vias + east_vias:
        add_via(netname, vx, vy)

    # Add all tracks
    for netname, layer_name, x1, y1, x2, y2, w in routes:
        lid = b.GetLayerID(layer_name)
        add_trk(netname, lid, x1, y1, x2, y2, w)

    # Refill zones
    filler = pcbnew.ZONE_FILLER(b)
    filler.Fill(b.Zones())
    b.Save(dst_pcb)

    # Run DRC
    drc_json = f'scratch_{name}_drc.json'
    cmd = [
        r'C:\Users\goran\AppData\Local\Programs\KiCad\10.0\bin\kicad-cli.exe',
        'pcb', 'drc',
        '--severity-all',
        '--all-track-errors',
        '--format', 'json',
        '-o', drc_json,
        dst_pcb
    ]
    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if os.path.exists(drc_json):
        d = json.load(open(drc_json))
        viols = d.get('violations', [])
        unconns = d.get('unconnected_items', [])
        non_lib_viols = [v for v in viols if v['type'] != 'lib_footprint_mismatch']
        print(f"[{name}] Non-lib violations: {len(non_lib_viols)}, Unconnected: {len(unconns)}")
        if len(non_lib_viols) > 0:
            for v in non_lib_viols[:5]:
                print(f"   {v['type']}: {[it['description'] for it in v.get('items', [])]}")
        return len(non_lib_viols), len(unconns)
    return -1, -1

print("Helper ready.")

# Candidate 1:
# SD_CS on B.Cu at Y=1.150, tapping R18.2 via at (56.975, 1.150)
# SD_MOSI on In2.Cu at Y=1.450
# SD_SCK on In2.Cu at Y=1.150 (from 42.63 to 58.15)
# SD_MISO on B.Cu at Y=1.450

u1_vias_c1 = [
    ('/SD_CS', 43.000, 1.600),
    ('/SD_SCK', 42.630, 0.500),
    ('/SD_MOSI', 41.130, 0.500),
    ('/SD_MISO', 41.630, 1.600),
]

# Let's inspect via clearances at U1
print("Testing U1 vias:")
for i in range(len(u1_vias_c1)):
    for j in range(i+1, len(u1_vias_c1)):
        n1, x1, y1 = u1_vias_c1[i]
        n2, x2, y2 = u1_vias_c1[j]
        d = math.hypot(x1 - x2, y1 - y2)
        print(f"  {n1} vs {n2}: {d:.3f} mm")
