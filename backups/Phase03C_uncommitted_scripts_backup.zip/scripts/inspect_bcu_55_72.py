import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- TRACKS & VIAS on B.Cu in X: 55..72, Y: 5.0..8.0 ---')
for t in board.GetTracks():
    if t.GetLayerName() == 'B.Cu':
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = s.x/1e6, s.y/1e6
        ex, ey = e.x/1e6, e.y/1e6
        if (55.0 <= sx <= 72.0 and 5.0 <= sy <= 8.0) or (55.0 <= ex <= 72.0 and 5.0 <= ey <= 8.0):
            print(f'{t.GetClass()} [{t.GetNetname()}] ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})')

