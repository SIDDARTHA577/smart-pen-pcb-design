import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Checking In2.Cu route for SCL East:")
s1, r1 = geom.is_segment_legal(24.250, 7.150, 25.000, 7.150, 'In2.Cu', '/I2C_SCL')
s2, r2 = geom.is_segment_legal(25.000, 7.150, 25.000, 5.600, 'In2.Cu', '/I2C_SCL')
s3, r3 = geom.is_segment_legal(25.000, 5.600, 38.000, 5.600, 'In2.Cu', '/I2C_SCL')

print(f"s1 on In2.Cu: {s1} ({r1})")
print(f"s2 on In2.Cu: {s2} ({r2})")
print(f"s3 on In2.Cu: {s3} ({r3})")
