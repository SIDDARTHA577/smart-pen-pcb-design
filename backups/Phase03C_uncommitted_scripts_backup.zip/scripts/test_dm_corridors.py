import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Testing In2.Cu corridors for DM from (52.0, y) to (73.0, y):")
for yi in range(50, 85, 2):
    y = yi / 10.0
    leg, r = geom.is_segment_legal(52.0, y, 73.0, y, 'In2.Cu', '/USB_DM_CORE')
    print(f"  y={y:.1f}: {leg} ({r})")

print("\nTesting jogged paths for DM on In2.Cu:")
# e.g. (52.0, 7.0) -> (66.0, 7.0) -> (66.0, 7.6) -> (73.0, 7.6) -> (73.0, 7.0)
s1, r1 = geom.is_segment_legal(52.0, 7.0, 66.0, 7.0, 'In2.Cu', '/USB_DM_CORE')
s2, r2 = geom.is_segment_legal(66.0, 7.0, 66.0, 7.8, 'In2.Cu', '/USB_DM_CORE')
s3, r3 = geom.is_segment_legal(66.0, 7.8, 73.0, 7.8, 'In2.Cu', '/USB_DM_CORE')
s4, r4 = geom.is_segment_legal(73.0, 7.8, 73.0, 7.0, 'In2.Cu', '/USB_DM_CORE')
print(f"Jogged path: s1={s1}({r1}), s2={s2}({r2}), s3={s3}({r3}), s4={s4}({r4})")

sys.exit(0)
