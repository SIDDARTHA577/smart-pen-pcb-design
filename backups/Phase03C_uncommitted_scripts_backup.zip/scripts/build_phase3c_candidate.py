import pcbnew
import json
import re

pcb_path = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb'
pro_path = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pro'

# 1. Copy fresh baseline
with open('output/RevG/SmartPen.kicad_pcb', 'r', encoding='utf-8') as f:
    pcb_text = f.read()

# Configure 4 copper layers and solder mask expansion in text
# In layers block: add In1.Cu and In2.Cu
pcb_text = pcb_text.replace(
    '(layers\n\t\t(0 "F.Cu" signal)',
    '(layers\n\t\t(0 "F.Cu" signal)\n\t\t(1 "In1.Cu" power)\n\t\t(2 "In2.Cu" power)'
)
# Update setup block
pcb_text = re.sub(r'\(pad_to_mask_clearance\s+[-\d.]+\)', '(pad_to_mask_clearance 0.025)', pcb_text)
pcb_text = re.sub(r'\(solder_mask_min_width\s+[-\d.]+\)', '(solder_mask_min_width 0.08)', pcb_text)

with open(pcb_path, 'w', encoding='utf-8') as f:
    f.write(pcb_text)
print('Updated layers and setup in PCB text')

# 2. Update U1 footprint in PCB and Library
board = pcbnew.LoadBoard(pcb_path)
u1 = board.FindFootprintByReference('U1')
# Update pad 33
p33 = u1.FindPadByNumber('33')
p33.SetSize(pcbnew.VECTOR2I(int(3.40 * 1e6), int(3.40 * 1e6)))

# Update pads 1-32
for i in range(1, 33):
    p = u1.FindPadByNumber(str(i))
    if p:
        p.SetShape(pcbnew.PAD_SHAPE_ROUNDRECT)
        p.SetRoundRectRadiusRatio(0.25)
        if (1 <= i <= 8) or (17 <= i <= 24):
            p.SetSize(pcbnew.VECTOR2I(int(0.75 * 1e6), int(0.25 * 1e6)))
        else:
            p.SetSize(pcbnew.VECTOR2I(int(0.25 * 1e6), int(0.75 * 1e6)))

# Save U1 to library
lib_path = 'output/RevG/variants/FourLayer_Candidate/SmartPen.pretty'
pcbnew.FootprintSave(lib_path, u1)
print('Updated U1 footprint in board and library')

# 3. Silkscreen adjustments
for ref in ['R26', 'D4', 'Q2']:
    fp = board.FindFootprintByReference(ref)
    if fp:
        fp.Reference().SetVisible(False)

j_usb = board.FindFootprintByReference('J_USB')
for g in j_usb.GraphicalItems():
    if g.GetLayer() == pcbnew.F_SilkS and g.GetShapeStr() == 'Line':
        sx = round(g.GetStart().x / 1e6, 2)
        ex = round(g.GetEnd().x / 1e6, 2)
        if sx in [73.93, 82.87] and ex in [73.93, 82.87]:
            g.SetLayer(pcbnew.F_Fab)
pcbnew.FootprintSave(lib_path, j_usb)
print('Adjusted silkscreen on R26, D4, Q2, J_USB')

# 4. Remove dangling stubs and old colliding tracks
to_remove = []
for t in board.GetTracks():
    net = t.GetNetname()
    if isinstance(t, pcbnew.PCB_VIA):
        pos = t.GetPosition()
        px, py = round(pos.x/1e6, 3), round(pos.y/1e6, 3)
        if net == '/RF_LNA' and px in [51.5, 39.5] and py == 6.25:
            to_remove.append(t)
        elif net == '/3V3_RF' and px == 38.5 and py == 5.8:
            to_remove.append(t)
        elif net == '/USB_DP_CORE' and px == 54.5 and py == 7.6:
            to_remove.append(t)
        elif net == '/VBAT' and px == 67.4 and py == 1.0:
            to_remove.append(t)
        elif net == '/USB_DP_PORT' and px in [71.60, 78.15] and py == 8.65:
            to_remove.append(t)
    else:
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = round(s.x/1e6, 3), round(s.y/1e6, 3)
        ex, ey = round(e.x/1e6, 3), round(e.y/1e6, 3)
        if net == '/RF_LNA':
            to_remove.append(t)
        elif net in ['/USB_DP_CORE', '/USB_DM_CORE'] and t.GetLayer() == pcbnew.F_Cu:
            to_remove.append(t)
        elif net == '/SD_CS' and sx == 59.65 and ex == 59.65 and sy == 4.2 and ey == 0.85:
            to_remove.append(t)
        elif net == '/CHG_PROG' and sx == 66.3 and ex == 66.3 and sy == 5.373 and ey == 6.225:
            to_remove.append(t)
        elif net == '/LED_RED_SINK' and sx == 23.25 and ex == 23.25 and sy == 2.75 and ey == 1.15:
            to_remove.append(t)
        elif net == '/VBAT' and sx == 67.4 and ex == 67.4 and sy == 1.0 and ey == 1.4:
            to_remove.append(t)
        elif net == '/USB_DP_PORT' and (sy == 8.65 or ey == 8.65):
            to_remove.append(t)
        elif net == '/USB_DM_PORT' and sx == 78.65 and ex == 78.65 and sy == 3.1 and ey == 8.05:
            to_remove.append(t)
        elif net == '/3V3_RF' and ((sx == 40.48 and ex == 38.5) or (sx == 46.705 and ex == 46.705 and ey == 5.8)):
            to_remove.append(t)

for t in to_remove:
    board.Remove(t)
print(f'Removed {len(to_remove)} dangling/colliding items')

# 5. Rebuild MCU_EN and TOUCH_OUT
mcu_tracks_to_remove = []
touch_tracks_to_remove = []
for t in board.GetTracks():
    if t.GetNetname() == '/MCU_EN' and t.GetLayer() == pcbnew.F_Cu:
        if not isinstance(t, pcbnew.PCB_VIA):
            mcu_tracks_to_remove.append(t)
    elif t.GetNetname() == '/TOUCH_OUT':
        if isinstance(t, pcbnew.PCB_VIA):
            if t.GetPosition().x/1e6 > 20:
                touch_tracks_to_remove.append(t)
        else:
            if max(t.GetStart().x/1e6, t.GetEnd().x/1e6) > 20:
                touch_tracks_to_remove.append(t)

for t in mcu_tracks_to_remove + touch_tracks_to_remove:
    board.Remove(t)

# MCU_EN F.Cu tracks
def mk_track(board, x1, y1, x2, y2, netname, layer_name='F.Cu', width=0.18):
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(pcbnew.VECTOR2I(int(x1*1e6), int(y1*1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2*1e6), int(y2*1e6)))
    t.SetWidth(int(width*1e6))
    t.SetLayer(board.GetLayerID(layer_name))
    t.SetNet(board.FindNet(netname))
    board.Add(t)
    return t

mk_track(board, 40.480, 3.585, 38.930, 3.590, '/MCU_EN', 'F.Cu')
mk_track(board, 38.930, 3.590, 38.925, 2.360, '/MCU_EN', 'F.Cu')
mk_track(board, 38.925, 2.360, 38.925, 1.520, '/MCU_EN', 'F.Cu')
mk_track(board, 38.925, 1.520, 39.325, 1.520, '/MCU_EN', 'F.Cu')
mk_track(board, 31.556, 1.500, 31.560, 3.590, '/MCU_EN', 'F.Cu')

# TOUCH_OUT via and tracks
v_touch = pcbnew.PCB_VIA(board)
v_touch.SetPosition(pcbnew.VECTOR2I(int(39.600*1e6), int(3.085*1e6)))
v_touch.SetWidth(int(0.50*1e6))
v_touch.SetDrill(int(0.30*1e6))
v_touch.SetNet(board.FindNet('/TOUCH_OUT'))
board.Add(v_touch)

mk_track(board, 40.480, 3.085, 39.600, 3.085, '/TOUCH_OUT', 'F.Cu')
mk_track(board, 39.600, 3.085, 39.000, 2.750, '/TOUCH_OUT', 'B.Cu')
mk_track(board, 39.000, 2.750, 13.030, 2.750, '/TOUCH_OUT', 'B.Cu')

# 6. Rebuild RF_LNA path
net_rf = board.FindNet('/RF_LNA')
v_rf1 = pcbnew.PCB_VIA(board)
v_rf1.SetPosition(pcbnew.VECTOR2I(int(39.500*1e6), int(6.250*1e6)))
v_rf1.SetWidth(int(0.50*1e6))
v_rf1.SetDrill(int(0.30*1e6))
v_rf1.SetNet(net_rf)
board.Add(v_rf1)

mk_track(board, 40.480, 6.585, 39.500, 6.585, '/RF_LNA', 'F.Cu', 0.35)
mk_track(board, 39.500, 6.585, 39.500, 6.250, '/RF_LNA', 'F.Cu', 0.35)

v_rf2 = pcbnew.PCB_VIA(board)
v_rf2.SetPosition(pcbnew.VECTOR2I(int(51.500*1e6), int(6.250*1e6)))
v_rf2.SetWidth(int(0.50*1e6))
v_rf2.SetDrill(int(0.30*1e6))
v_rf2.SetNet(net_rf)
board.Add(v_rf2)

mk_track(board, 39.500, 6.250, 51.500, 6.250, '/RF_LNA', 'B.Cu', 0.35)
mk_track(board, 51.500, 6.250, 51.500, 5.300, '/RF_LNA', 'F.Cu', 0.35)
mk_track(board, 51.500, 5.300, 51.920, 5.300, '/RF_LNA', 'F.Cu', 0.35)
mk_track(board, 51.500, 5.300, 51.500, 3.600, '/RF_LNA', 'F.Cu', 0.35)
mk_track(board, 51.500, 3.600, 52.220, 3.600, '/RF_LNA', 'F.Cu', 0.35)

# 7. Add In1.Cu GND continuous plane
z_gnd = pcbnew.ZONE(board)
z_gnd.SetLayer(board.GetLayerID('In1.Cu'))
z_gnd.SetNet(board.FindNet('/GND'))
outline = z_gnd.Outline()
outline.NewOutline()
outline.Append(int(0.40 * 1e6), int(0.40 * 1e6))
outline.Append(int(83.60 * 1e6), int(0.40 * 1e6))
outline.Append(int(83.60 * 1e6), int(8.80 * 1e6))
outline.Append(int(0.40 * 1e6), int(8.80 * 1e6))
z_gnd.SetPadConnection(pcbnew.ZONE_CONNECTION_THERMAL)
z_gnd.SetThermalReliefGap(int(0.15 * 1e6))
z_gnd.SetThermalReliefSpokeWidth(int(0.20 * 1e6))
board.Add(z_gnd)

# 8. Add 4 GND vias to Pad 33 of U1
net_gnd = board.FindNet('/GND')
for vx, vy in [(42.2, 4.3), (42.2, 5.3), (43.5, 4.3), (43.5, 5.3)]:
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pcbnew.VECTOR2I(int(vx * 1e6), int(vy * 1e6)))
    v.SetWidth(int(0.50 * 1e6))
    v.SetDrill(int(0.30 * 1e6))
    v.SetNet(net_gnd)
    board.Add(v)

board.Save(pcb_path)
print('Board saved cleanly')

# Update min_resolved_spokes in pro
with open(pro_path, 'r') as f:
    d = json.load(f)
d['board']['design_settings']['rules']['min_resolved_spokes'] = 1
d['board']['design_settings']['rules']['min_copper_edge_clearance'] = 0.25
d['board']['net_classes'][0]['clearance'] = 0.15
with open(pro_path, 'w') as f:
    json.dump(d, f, indent=2)
print('Updated SmartPen.kicad_pro')
