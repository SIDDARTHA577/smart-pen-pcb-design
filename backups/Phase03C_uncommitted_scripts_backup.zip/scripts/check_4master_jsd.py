import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
# Ensure VSYS_RAW via is on D4.1 at (59.0, 2.4)
for t in list(b.GetTracks()):
    if t.GetNetname() == '/VSYS_RAW':
        if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().y/1e6, 1) in [2.4, 1.2]:
            t.SetPosition(pcbnew.VECTOR2I(int(59.000*1e6), int(2.400*1e6)))

geom = BoardGeometry(b)

print("Checking the 4 Master SD Routes at J_SD:")

# 1. SD_SCK:
s1, r1 = geom.is_segment_legal(58.150, 4.200, 58.150, 5.500, 'F.Cu', '/SD_SCK')
s2, r2 = geom.is_segment_legal(58.150, 5.500, 57.500, 5.500, 'F.Cu', '/SD_SCK')
v1, rv1 = geom.is_via_legal(57.500, 5.500, '/SD_SCK')
print(f"1. SCK: s1={s1}, s2={s2}, via={v1} ({rv1})")

# 2. SD_MOSI:
s1, r1 = geom.is_segment_legal(58.650, 4.200, 58.650, 3.250, 'F.Cu', '/SD_MOSI')
s2, r2 = geom.is_segment_legal(58.650, 3.250, 57.400, 3.250, 'F.Cu', '/SD_MOSI')
s3, r3 = geom.is_segment_legal(57.400, 3.250, 57.400, 2.800, 'F.Cu', '/SD_MOSI')
v2, rv2 = geom.is_via_legal(57.400, 2.800, '/SD_MOSI')
print(f"2. MOSI: s1={s1}, s2={s2}, s3={s3}, via={v2} ({rv2})")

# 3. SD_MISO:
s1, r1 = geom.is_segment_legal(59.150, 4.200, 59.150, 3.250, 'F.Cu', '/SD_MISO')
s2, r2 = geom.is_segment_legal(59.150, 3.250, 59.800, 3.250, 'F.Cu', '/SD_MISO')
s3, r3 = geom.is_segment_legal(59.800, 3.250, 59.800, 1.300, 'F.Cu', '/SD_MISO')
s4, r4 = geom.is_segment_legal(59.800, 1.300, 59.650, 1.300, 'F.Cu', '/SD_MISO')
v3, rv3 = geom.is_via_legal(59.650, 1.300, '/SD_MISO')
print(f"3. MISO: s1={s1}, s2={s2}, s3={s3}, s4={s4}, via={v3} ({rv3})")

# 4. SD_CS:
# CS goes around D4 on F.Cu:
# Wait! If MISO uses Y=3.250 to go to X=59.800, can CS use X=59.650 down to Y=0.700?
# Let's check:
v4, rv4 = geom.is_via_legal(59.300, 0.700, '/SD_CS')
print(f"4. CS via at (59.30, 0.70): via={v4} ({rv4})")
