import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")
net_3v3 = b.FindNet("/3V3")

print("--- 3V3 tracks/vias near X=42..47 ---")
for t in b.GetTracks():
    if t.GetNet() == net_3v3:
        p1 = t.GetStart()
        p2 = t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (42 <= x1 <= 47 or 42 <= x2 <= 47) and (0 <= y1 <= 4 or 0 <= y2 <= 4):
            if t.GetClass() == 'PCB_VIA':
                print(f"VIA Pos: ({x1:.3f}, {y1:.3f})")
            else:
                print(f"TRK Layer: {b.GetLayerName(t.GetLayer())} Start: ({x1:.3f}, {y1:.3f}) End: ({x2:.3f}, {y2:.3f})")

for fp in b.GetFootprints():
    if fp.GetReference() == 'R27':
        for p in fp.Pads():
            if p.GetNetname() == '/3V3':
                print("R27 3V3 pad:", p.GetPosition().x/1e6, p.GetPosition().y/1e6)
