import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

# 1. Move thermal vias from 5.8 to 5.2
gnd_net = b.FindNet('/GND')
to_remove = []
for t in b.GetTracks():
    if isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/GND':
        pos = t.GetPosition()
        px, py = pos.x / 1e6, pos.y / 1e6
        if 42.0 <= px <= 44.0 and 5.5 <= py <= 6.0:
            to_remove.append(t)
for t in to_remove:
    b.Remove(t)

for vx, vy in [(42.2, 5.2), (43.5, 5.2)]:
    v = pcbnew.PCB_VIA(b)
    v.SetNet(gnd_net)
    v.SetPosition(pcbnew.VECTOR2I(int(vx * 1e6), int(vy * 1e6)))
    v.SetWidth(int(0.50 * 1e6))
    v.SetDrill(int(0.30 * 1e6))
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    b.Add(v)

# 2. Remove the shorting via at (30.753, 4.400)
vbat_net = b.FindNet('/VBAT_SW')
for t in list(b.GetTracks()):
    if isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/VBAT_SW':
        pos = t.GetPosition()
        px, py = pos.x / 1e6, pos.y / 1e6
        if abs(px - 30.753) < 0.1 and abs(py - 4.400) < 0.1:
            b.Remove(t)

geom = BoardGeometry(b)

# Check thermal vias at Y=5.2:
v1, r1 = geom.is_via_legal(42.2, 5.2, '/GND')
v2, r2 = geom.is_via_legal(43.5, 5.2, '/GND')
print(f"Thermal vias at 5.2: v1={v1}({r1}), v2={v2}({r2})")

# Check path from (28.090, 4.400) south to Y=7.2, east to (30.753, 7.200) on In2.Cu:
s_down, rd = geom.is_segment_legal(28.090, 4.400, 28.090, 7.200, 'In2.Cu', '/VBAT_SW')
s_east, re = geom.is_segment_legal(28.090, 7.200, 30.753, 7.200, 'In2.Cu', '/VBAT_SW')
print(f"In2 run to J_MOT: down={s_down}({rd}), east={s_east}({re})")

sys.exit(0)
