import os, sys, math
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try: import wx; wx.DisableAsserts()
except: pass
import pcbnew

b = pcbnew.LoadBoard('scratch_test_restore_vsys.kicad_pcb')

# Test via at (59.650, 5.000) for /SD_CS
vx, vy = 59.650, 5.000
print(f"--- Checking via at ({vx}, {vy}) ---")
for t in b.GetTracks():
    if t.GetNetname() == '/SD_CS': continue
    if t.GetClass() == 'PCB_VIA':
        p = t.GetPosition()
        px, py = p.x/1e6, p.y/1e6
        d = math.hypot(px - vx, py - vy)
        if d < 1.0:
            print(f"VIA {t.GetNetname()} at ({px:.3f},{py:.3f}): dist={d:.3f} clr={d-0.50:.3f}")
    else:
        s, e = t.GetStart(), t.GetEnd()
        sx, sy, ex, ey = s.x/1e6, s.y/1e6, e.x/1e6, e.y/1e6
        dx, dy = ex - sx, ey - sy
        L2 = dx*dx + dy*dy
        u = max(0.0, min(1.0, ((vx - sx)*dx + (vy - sy)*dy) / L2))
        nx, ny = sx + u*dx, sy + u*dy
        d = math.hypot(vx - nx, vy - ny)
        w = t.GetWidth()/1e6
        clr = d - 0.25 - w/2
        if clr < 0.25:
            print(f"Track on {t.GetLayerName()} {t.GetNetname()} ({sx:.3f},{sy:.3f})->({ex:.3f},{ey:.3f}): clr={clr:.3f}")

for fp in b.GetFootprints():
    for p in fp.Pads():
        if p.GetNetname() == '/SD_CS': continue
        pos = p.GetPosition()
        px, py = pos.x/1e6, pos.y/1e6
        d = math.hypot(px - vx, py - vy)
        sz = max(p.GetSize().x, p.GetSize().y)/2e6
        clr = d - 0.25 - sz
        if clr < 0.25:
            print(f"Pad {fp.GetReference()}.{p.GetNumber()} ({p.GetNetname()}) at ({px:.3f},{py:.3f}): clr={clr:.3f}")
