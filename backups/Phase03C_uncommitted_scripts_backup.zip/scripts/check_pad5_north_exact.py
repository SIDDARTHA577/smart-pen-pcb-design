import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

print("Checking north of Pad 5 (59.150, 4.200):")
for y in [4.5, 4.8, 5.0, 5.5, 6.0, 6.5, 7.0]:
    s, r = geom.is_segment_legal(59.150, 4.200, 59.150, y, 'F.Cu', '/SD_MISO')
    print(f"y={y}: {s} ({r})")
