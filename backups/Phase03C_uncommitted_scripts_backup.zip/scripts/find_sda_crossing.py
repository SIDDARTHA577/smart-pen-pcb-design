import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
bcu_id = b.GetLayerID('B.Cu')

for t in b.Tracks():
    if t.GetLayer() == bcu_id and t.GetNetname() == '/I2C_SDA':
        p1, p2 = t.GetStart(), t.GetEnd()
        length = t.GetLength()/1e6
        print(f"I2C_SDA B.Cu track len={length:.4f}: ({p1.x/1e6:.3f},{p1.y/1e6:.3f}) -> ({p2.x/1e6:.3f},{p2.y/1e6:.3f})")
