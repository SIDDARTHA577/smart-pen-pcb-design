import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')

# Update GPIO8_STRAP to jog at Y=1.000
for t in list(b.GetTracks()):
    if t.GetNetname() == '/GPIO8_STRAP':
        b.Delete(t)

net_strap = b.FindNet('/GPIO8_STRAP')
t1 = pcbnew.PCB_TRACK(b)
t1.SetStart(pcbnew.VECTOR2I(int(43.630*1e6), int(2.435*1e6)))
t1.SetEnd(pcbnew.VECTOR2I(int(43.630*1e6), int(1.000*1e6)))
t1.SetWidth(int(0.15*1e6))
t1.SetLayer(b.GetLayerID('F.Cu'))
t1.SetNet(net_strap)
b.Add(t1)

t2 = pcbnew.PCB_TRACK(b)
t2.SetStart(pcbnew.VECTOR2I(int(43.630*1e6), int(1.000*1e6)))
t2.SetEnd(pcbnew.VECTOR2I(int(42.975*1e6), int(1.000*1e6)))
t2.SetWidth(int(0.15*1e6))
t2.SetLayer(b.GetLayerID('F.Cu'))
t2.SetNet(net_strap)
b.Add(t2)

geom = BoardGeometry(b)

print("Testing SD_SCK escapes from U1.12 (42.630, 2.435):")
for vy in [0.4, 0.5, 0.6, 0.7, 0.8, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9]:
    for vx in [42.630, 42.500, 42.700]:
        s_ok, rs = geom.is_segment_legal(42.630, 2.435, vx, vy, 'F.Cu', '/SD_SCK')
        v_ok, rv = geom.is_via_legal(vx, vy, '/SD_SCK')
        if s_ok and v_ok:
            print(f"SD_SCK via & segment OK at ({vx:.3f}, {vy:.3f})")
