import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# Check segment on F.Cu from (38.000, 5.600) -> (38.800, 5.600) -> (38.800, 4.585) -> (40.480, 4.585)
s1, r1 = geom.is_segment_legal(38.000, 5.600, 38.600, 5.600, 'F.Cu', '/I2C_SCL')
s2, r2 = geom.is_segment_legal(38.600, 5.600, 38.800, 4.585, 'F.Cu', '/I2C_SCL')
s3, r3 = geom.is_segment_legal(38.800, 4.585, 40.480, 4.585, 'F.Cu', '/I2C_SCL')

print(f"s1 (38.0->38.6 @ 5.6): {s1} ({r1})")
print(f"s2 (38.6, 5.6 -> 38.8, 4.585): {s2} ({r2})")
print(f"s3 (38.8->40.48 @ 4.585): {s3} ({r3})")
