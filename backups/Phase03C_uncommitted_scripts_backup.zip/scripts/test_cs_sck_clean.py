import os, sys, pcbnew, shutil

src_pcb = 'scratch_test_fcu_cs_clean.kicad_pcb'
dst_pcb = 'scratch_test_triplet_drc.kicad_pcb'
shutil.copy(src_pcb, dst_pcb)
shutil.copy(src_pcb.replace('.kicad_pcb', '.kicad_pro'), dst_pcb.replace('.kicad_pcb', '.kicad_pro'))

b = pcbnew.LoadBoard(dst_pcb)
fcu = b.GetLayerID('F.Cu')
bcu = b.GetLayerID('B.Cu')
in2 = b.GetLayerID('In2.Cu')

net_sck = b.FindNet('/SD_SCK')
net_mosi = b.FindNet('/SD_MOSI')
net_miso = b.FindNet('/SD_MISO')
net_cs = b.FindNet('/SD_CS')

def add_trk(net, layer_id, x1, y1, x2, y2, w=0.15):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(round(x1 * 1e6)), int(round(y1 * 1e6))))
    t.SetEnd(pcbnew.VECTOR2I(int(round(x2 * 1e6)), int(round(y2 * 1e6))))
    t.SetWidth(int(round(w * 1e6)))
    t.SetLayer(layer_id)
    t.SetNet(net)
    b.Add(t)
    return t

def add_via(net, x, y, drill=0.30, dia=0.50):
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(int(round(x * 1e6)), int(round(y * 1e6))))
    v.SetWidth(int(round(dia * 1e6)))
    v.SetDrill(int(round(drill * 1e6)))
    v.SetNet(net)
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    b.Add(v)
    return v

# --- 1. SD_CS (U1.13 to R18.2 on In2.Cu) ---
# U1.13 at (43.130, 2.435) -> (43.130, 1.450)
add_trk(net_cs, fcu, 43.130, 2.435, 43.130, 1.450)
add_via(net_cs, 43.130, 1.450)
# In2.Cu to R18.2 via at (56.975, 1.450)
add_trk(net_cs, in2, 43.130, 1.450, 56.975, 1.450)
add_via(net_cs, 56.975, 1.450)
add_trk(net_cs, fcu, 56.975, 1.450, 56.975, 2.000)

# --- 2. SD_SCK (U1.12 to J_SD.3 on In2.Cu) ---
# U1.12 at (42.630, 2.435) -> (42.630, 0.500)
add_trk(net_sck, fcu, 42.630, 2.435, 42.630, 0.500)
add_via(net_sck, 42.630, 0.500)
add_trk(net_sck, in2, 42.630, 0.500, 42.630, 1.150)
add_trk(net_sck, in2, 42.630, 1.150, 58.150, 1.150)
add_trk(net_sck, in2, 58.150, 1.150, 58.150, 1.600)
add_via(net_sck, 58.150, 1.600)
add_trk(net_sck, fcu, 58.150, 1.600, 58.150, 4.200)

# Also test R27.1 3V3 jumper on B.Cu to guarantee 3V3 continuity
add_trk(b.FindNet('/3V3'), bcu, 44.475, 0.500, 45.666, 0.500)
add_trk(b.FindNet('/3V3'), bcu, 45.666, 0.500, 45.666, 2.625)

filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
b.Save(dst_pcb)
print("Saved CS and SCK test.")
