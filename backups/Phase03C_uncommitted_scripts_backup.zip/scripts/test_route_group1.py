import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

def trk(board, netname, layer_name, x1, y1, x2, y2, w=0.18):
    net = board.FindNet(netname)
    layer = board.GetLayerID(layer_name)
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    t.SetWidth(int(w * 1e6))
    t.SetLayer(layer)
    t.SetNet(net)
    board.Add(t)
    return t

def via(board, netname, x, y, drill=0.30, dia=0.50):
    net = board.FindNet(netname)
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    v.SetWidth(int(dia * 1e6))
    v.SetDrill(int(drill * 1e6))
    v.SetNet(net)
    board.Add(v)
    return v

# 1. Net /GPIO8_STRAP:
# U1.14 is at (43.630, 2.435)
# R27.2 is at (43.975, 1.000)
# Both are on F.Cu! Distance is ~1.5 mm. Clear vertical corridor:
trk(board, '/GPIO8_STRAP', 'F.Cu', 43.630, 2.435, 43.630, 1.600)
trk(board, '/GPIO8_STRAP', 'F.Cu', 43.630, 1.600, 43.975, 1.600)
trk(board, '/GPIO8_STRAP', 'F.Cu', 43.975, 1.600, 43.975, 1.000)
print('Routed GPIO8_STRAP on F.Cu')

# 2. Net /STRAP2:
# U1.6 is at (40.480, 4.085)
# R3.2 is at (48.775, 2.800)
# Route via B.Cu:
# Breakout from U1.6 (40.480, 4.085) -> (39.600, 4.085) [via to B.Cu]
via(board, '/STRAP2', 39.600, 4.085)
trk(board, '/STRAP2', 'F.Cu', 40.480, 4.085, 39.600, 4.085)
# On B.Cu: (39.600, 4.085) -> (39.600, 4.200) -> (48.775, 4.200) -> (48.775, 3.500) [via to F.Cu]
via(board, '/STRAP2', 48.775, 3.500)
trk(board, '/STRAP2', 'B.Cu', 39.600, 4.085, 39.600, 4.200)
trk(board, '/STRAP2', 'B.Cu', 39.600, 4.200, 48.775, 4.200)
trk(board, '/STRAP2', 'B.Cu', 48.775, 4.200, 48.775, 3.500)
# On F.Cu: (48.775, 3.500) -> R3.2 (48.775, 2.800)
trk(board, '/STRAP2', 'F.Cu', 48.775, 3.500, 48.775, 2.800)
print('Routed STRAP2')

# 3. Net /3V3_RTC:
# U1.11 is at (42.130, 2.435)
# Existing track ends at (36.360, 1.640)
# Route via B.Cu:
# U1.11 (42.130, 2.435) -> (42.130, 1.700) [via to B.Cu]
via(board, '/3V3_RTC', 42.130, 1.700)
trk(board, '/3V3_RTC', 'F.Cu', 42.130, 2.435, 42.130, 1.700)
via(board, '/3V3_RTC', 36.360, 1.000)
trk(board, '/3V3_RTC', 'B.Cu', 42.130, 1.700, 36.360, 1.700)
trk(board, '/3V3_RTC', 'B.Cu', 36.360, 1.700, 36.360, 1.000)
trk(board, '/3V3_RTC', 'F.Cu', 36.360, 1.000, 36.360, 1.640)
print('Routed 3V3_RTC')

board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

