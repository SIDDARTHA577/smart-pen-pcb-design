import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- PADS in X: 70..74, Y: 6.5..7.5 ---')
for p in board.GetPads():
    pos = p.GetPosition()
    x, y = pos.x / 1e6, pos.y / 1e6
    if 70.0 <= x <= 74.0 and 6.5 <= y <= 7.5:
        fp = p.GetParentFootprint()
        ref = fp.GetReference() if fp else '?'
        print(f'{ref}.{p.GetNumber()} [{p.GetNetname()}] at ({x:.3f}, {y:.3f}) layer {p.GetLayerName()}')

print('--- TRACKS on F.Cu in X: 70..74, Y: 6.5..7.5 ---')
for t in board.GetTracks():
    if t.GetLayerName() == 'F.Cu':
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = s.x/1e6, s.y/1e6
        ex, ey = e.x/1e6, e.y/1e6
        if (70.0 <= sx <= 74.0 and 6.5 <= sy <= 7.5) or (70.0 <= ex <= 74.0 and 6.5 <= ey <= 7.5):
            print(f'{t.GetNetname()}: ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})')

