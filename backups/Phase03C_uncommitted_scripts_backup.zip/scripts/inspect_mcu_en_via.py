import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

for t in board.GetTracks():
    if t.GetNetname() == '/MCU_EN' and isinstance(t, pcbnew.PCB_VIA):
        pos = t.GetPosition()
        print(f'MCU_EN VIA at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f}): top={board.GetLayerName(t.TopLayer())}, bot={board.GetLayerName(t.BottomLayer())}')
