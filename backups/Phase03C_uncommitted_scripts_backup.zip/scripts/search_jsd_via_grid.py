import pcbnew, math

b = pcbnew.LoadBoard("scratch_test_fcu_cs_clean.kicad_pcb")

# Collect all pads and tracks on F.Cu, In2.Cu, B.Cu in X in [55, 61], Y in [0, 6]
elements = []
for fp in b.GetFootprints():
    for p in fp.Pads():
        pos = p.GetPosition()
        x, y = pos.x/1e6, pos.y/1e6
        if 55.0 <= x <= 61.0 and 0.0 <= y <= 6.0:
            elements.append(('pad', fp.GetReference(), p.GetNetname(), x, y, p.GetSize().x/1e6, p.GetSize().y/1e6))

for t in b.GetTracks():
    if t.GetClass() == 'PCB_VIA':
        p = t.GetPosition()
        x, y = p.x/1e6, p.y/1e6
        if 55.0 <= x <= 61.0 and 0.0 <= y <= 6.0:
            elements.append(('via', 'VIA', t.GetNetname(), x, y, 0.50, 0.50))

print("Total elements to avoid:", len(elements))

def is_via_valid(vx, vy, netname, dia=0.50):
    for etype, name, net, x, y, sx, sy in elements:
        if net == netname:
            continue
        dx = max(0, abs(vx - x) - sx/2)
        dy = max(0, abs(vy - y) - sy/2)
        d = math.hypot(dx, dy)
        if d < (dia/2 + 0.155):
            return False
    return True

# Search all valid via locations in X in [56.5, 60.5], Y in [0.5, 5.0]
valid_locations = []
for xi in range(565, 605, 1):
    x = xi / 10.0
    for yi in range(5, 45, 1):
        y = yi / 10.0
        # test generic net
        if is_via_valid(x, y, '/SD_SCK'):
            valid_locations.append((x, y))

print(f"Total valid via locations found: {len(valid_locations)}")
# Print samples grouped by region
north_locs = [p for p in valid_locations if p[1] <= 2.0]
mid_locs = [p for p in valid_locations if 2.5 <= p[1] <= 3.5]
south_locs = [p for p in valid_locations if p[1] >= 4.5]
print(f"North (Y <= 2.0): {len(north_locs)} locations")
print(f"Mid (2.5 <= Y <= 3.5): {len(mid_locs)} locations")
print(f"South (Y >= 4.5): {len(south_locs)} locations")

# Print some mid locations:
print("Some Mid locations (X, Y):", mid_locs[:15])
