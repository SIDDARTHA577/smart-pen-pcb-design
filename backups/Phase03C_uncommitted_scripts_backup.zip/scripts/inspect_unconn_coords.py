import json

with open('reports/RevG/Phase03C/raw/Candidate_FourLayer_drc.json') as f:
    d = json.load(f)

for u in d.get('unconnected_items', []):
    items = u.get('items', [])
    pos1 = items[0].get('pos', {})
    pos2 = items[1].get('pos', {})
    desc1 = items[0].get('description', '')
    desc2 = items[1].get('description', '')
    print(f"[{desc1}] ({pos1.get('x')}, {pos1.get('y')})  -->  [{desc2}] ({pos2.get('x')}, {pos2.get('y')})")

