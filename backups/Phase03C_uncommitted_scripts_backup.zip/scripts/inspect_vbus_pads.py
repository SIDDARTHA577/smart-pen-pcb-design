import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
for ref in ['R26', 'D4', 'C11', 'C10', 'J_USB', 'U2', 'Q2']:
    for f in b.GetFootprints():
        if f.GetReference() == ref:
            for p in f.Pads():
                if p.GetNetname() == '/USB_VBUS':
                    pos = p.GetPosition()
                    print(f"{ref}.{p.GetName()} at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})")
