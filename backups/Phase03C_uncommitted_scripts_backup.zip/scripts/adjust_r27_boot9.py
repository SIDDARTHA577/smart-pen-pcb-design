import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

# Remove existing GPIO8_STRAP and BOOT9 tracks
to_del = []
for t in board.GetTracks():
    if t.GetNetname() in ['/GPIO8_STRAP', '/BOOT9']:
        to_del.append(t)
for t in to_del:
    board.Remove(t)

# Shift R27 to (42.5, 1.0)
r27 = board.FindFootprintByReference('R27')
r27.SetPosition(pcbnew.VECTOR2I(int(42.5 * 1e6), int(1.0 * 1e6)))

def trk(board, netname, layer_name, x1, y1, x2, y2, w=0.18):
    net = board.FindNet(netname)
    layer = board.GetLayerID(layer_name)
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    t.SetWidth(int(w * 1e6))
    t.SetLayer(layer)
    t.SetNet(net)
    board.Add(t)
    return t

def via(board, netname, x, y, drill=0.30, dia=0.50):
    net = board.FindNet(netname)
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    v.SetWidth(int(dia * 1e6))
    v.SetDrill(int(drill * 1e6))
    v.SetNet(net)
    board.Add(v)
    return v

# R27.2 is at (42.975, 1.000)
# Connect U1.14 (43.630, 2.435) to R27.2 (42.975, 1.000):
# (43.630, 2.435) -> (43.630, 1.600) -> (42.975, 1.600) -> (42.975, 1.000)
trk(board, '/GPIO8_STRAP', 'F.Cu', 43.630, 2.435, 43.630, 1.600)
trk(board, '/GPIO8_STRAP', 'F.Cu', 43.630, 1.600, 42.975, 1.600)
trk(board, '/GPIO8_STRAP', 'F.Cu', 42.975, 1.600, 42.975, 1.000)

# Connect U1.15 (44.130, 2.435) to SW2.1 (45.704, 1.500) and R2.2:
# (44.130, 2.435) -> (44.130, 1.500) -> (45.704, 1.500)
trk(board, '/BOOT9', 'F.Cu', 44.130, 2.435, 44.130, 1.500)
trk(board, '/BOOT9', 'F.Cu', 44.130, 1.500, 45.704, 1.500)

# Via to B.Cu at (46.500, 0.650)
via(board, '/BOOT9', 46.500, 0.650)
trk(board, '/BOOT9', 'F.Cu', 45.704, 1.500, 46.500, 0.650)

# Via to B.Cu at (52.225, 0.650)
via(board, '/BOOT9', 52.225, 0.650)
trk(board, '/BOOT9', 'B.Cu', 46.500, 0.650, 52.225, 0.650)
trk(board, '/BOOT9', 'F.Cu', 52.225, 0.650, 52.225, 2.250)

board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('Adjusted R27 and routed BOOT9 cleanly')

