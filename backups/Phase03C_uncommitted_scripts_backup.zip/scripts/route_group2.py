try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

def route_group2():
    board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

    # Helper to add track
    def add_track(netname, layer_name, x1, y1, x2, y2, width=0.18):
        net = board.FindNet(netname)
        t = pcbnew.PCB_TRACK(board)
        t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
        t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
        t.SetWidth(int(width * 1e6))
        t.SetLayer(board.GetLayerID(layer_name))
        t.SetNet(net)
        board.Add(t)
        return t

    # Helper to add via
    def add_via(netname, x, y, dia=0.50, drill=0.30):
        net = board.FindNet(netname)
        v = pcbnew.PCB_VIA(board)
        v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
        v.SetWidth(int(dia * 1e6))
        v.SetDrill(int(drill * 1e6))
        v.SetNet(net)
        v.SetViaType(pcbnew.VIATYPE_THROUGH)
        board.Add(v)
        return v

    print('Routing Group 2 nets (3V3_RTC and 3V3_RF)...')

    # --- 1. R27.1 3V3 via relocation ---
    to_rem = [t for t in board.GetTracks() if (isinstance(t, pcbnew.PCB_VIA) and abs(t.GetPosition().x/1e6 - 42.230) < 0.05 and abs(t.GetPosition().y/1e6 - 1.564) < 0.05) or (not isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/3V3' and abs(t.GetStart().x/1e6 - 42.025) < 0.05 and abs(t.GetEnd().x/1e6 - 42.230) < 0.05)]
    for t in to_rem:
        board.Remove(t)

    add_via('/3V3', 42.000, 0.500)
    add_track('/3V3', 'F.Cu', 42.025, 1.000, 42.000, 0.500)

    # --- 2. 3V3_RTC ---
    add_track('/3V3_RTC', 'F.Cu', 36.201, 1.636, 36.357, 2.601)
    add_via('/3V3_RTC', 36.000, 1.600)
    add_track('/3V3_RTC', 'F.Cu', 36.000, 1.600, 36.201, 1.636)
    add_track('/3V3_RTC', 'In2.Cu', 36.000, 1.600, 36.000, 1.100)
    add_track('/3V3_RTC', 'In2.Cu', 36.000, 1.100, 42.130, 1.100)
    add_track('/3V3_RTC', 'In2.Cu', 42.130, 1.100, 42.130, 1.800)
    add_via('/3V3_RTC', 42.130, 1.800)
    add_track('/3V3_RTC', 'F.Cu', 42.130, 1.800, 42.130, 2.435)

    # --- 3. 3V3_RF ---
    add_track('/3V3_RF', 'F.Cu', 41.130, 7.235, 41.630, 7.235)
    add_track('/3V3_RF', 'F.Cu', 41.380, 7.235, 41.380, 7.500)
    add_via('/3V3_RF', 41.380, 7.500)

    add_track('/3V3_RF', 'F.Cu', 40.480, 5.585, 40.480, 6.085)
    add_track('/3V3_RF', 'F.Cu', 40.480, 5.585, 39.000, 5.700)
    add_via('/3V3_RF', 39.000, 5.700)

    add_track('/3V3_RF', 'In2.Cu', 39.000, 5.700, 39.000, 7.000)
    add_track('/3V3_RF', 'In2.Cu', 39.000, 7.000, 41.380, 7.000)
    add_track('/3V3_RF', 'In2.Cu', 41.380, 7.000, 47.500, 7.000)
    add_track('/3V3_RF', 'In2.Cu', 41.380, 7.000, 41.380, 7.500)

    add_via('/3V3_RF', 47.500, 7.000)
    add_track('/3V3_RF', 'F.Cu', 47.500, 7.000, 47.500, 7.550)
    add_track('/3V3_RF', 'F.Cu', 48.090, 7.550, 48.094, 6.603)

    # Refill all zones
    filler = pcbnew.ZONE_FILLER(board)
    filler.Fill(board.Zones())

    board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
    print('Successfully applied Group 2 routes!')

if __name__ == '__main__':
    route_group2()

