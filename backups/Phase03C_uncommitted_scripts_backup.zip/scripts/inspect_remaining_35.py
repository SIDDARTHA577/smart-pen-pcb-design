import json
from pathlib import Path

with open("scratch_surgical_drc.json", "r", encoding="utf-8") as f:
    d = json.load(f)

for vtype in ["clearance", "hole_clearance", "starved_thermal", "via_dangling", "track_dangling", "silk_over_copper"]:
    items = [v for v in d["violations"] if v.get("type") == vtype]
    print(f"\n=== {vtype} ({len(items)}) ===")
    for i, it in enumerate(items):
        print(f"[{i+1}] {it.get('description')}")
        for sub in it.get("items", []):
            print(f"    {sub.get('description')} @ ({sub.get('pos', {}).get('x')}, {sub.get('pos', {}).get('y')}) uuid={sub.get('uuid')}")

