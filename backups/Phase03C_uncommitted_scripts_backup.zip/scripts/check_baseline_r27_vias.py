import sys
sys.path.append('scripts')
import pcbnew

b = pcbnew.LoadBoard('output/RevG/SmartPen.kicad_pcb')
for t in b.GetTracks():
    if t.GetNetname() == '/3V3':
        s = t.GetPosition() if t.GetClass() == 'PCB_VIA' else t.GetStart()
        sx, sy = s.x/1e6, s.y/1e6
        if 41.0 <= sx <= 45.0 and 0.0 <= sy <= 2.0:
            print(f"Baseline {t.GetClass()}: ({sx:.3f}, {sy:.3f})")
