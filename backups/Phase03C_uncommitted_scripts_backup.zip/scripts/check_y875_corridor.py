import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Checking corridors at Y=8.750 from X=54.0 to 73.0:")
for layer in ['F.Cu', 'In2.Cu', 'B.Cu']:
    s, r = geom.is_segment_legal(54.0, 8.75, 73.0, 8.75, layer, '/USB_DM_CORE')
    print(f"Layer {layer} at Y=8.75: {s} ({r})")
