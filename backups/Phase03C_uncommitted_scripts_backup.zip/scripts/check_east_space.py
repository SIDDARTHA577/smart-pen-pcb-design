import sys
sys.path.append('scripts')
import pcbnew

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
print("=== Footprints and tracks at X in [44, 48], Y in [0, 2] ===")
for fp in b.GetFootprints():
    pos = fp.GetPosition()
    px, py = pos.x/1e6, pos.y/1e6
    if 44.0 <= px <= 48.0 and 0.0 <= py <= 2.0:
        print(f"FP: {fp.GetReference()} at ({px:.3f}, {py:.3f})")
for t in b.GetTracks():
    s, e = t.GetStart(), t.GetEnd()
    sx, sy, ex, ey = s.x/1e6, s.y/1e6, e.x/1e6, e.y/1e6
    if (44.0 <= sx <= 48.0 or 44.0 <= ex <= 48.0) and (0.0 <= sy <= 2.0 or 0.0 <= ey <= 2.0):
        print(f"Track {t.GetClass()} net={t.GetNetname()} layer={b.GetLayerName(t.GetLayer())}: ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})")
