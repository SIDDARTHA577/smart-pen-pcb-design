from pathlib import Path

sch_text = Path("output/RevG/SmartPen.kicad_sch").read_text(encoding="utf-8")
for i, line in enumerate(sch_text.splitlines()):
    if "L2" in line or "C8" in line or "C9" in line:
        print(f"Line {i+1}: {line}")
        for j in range(max(0, i-5), min(len(sch_text.splitlines()), i+20)):
            print("  ", sch_text.splitlines()[j])
        print("="*40)

