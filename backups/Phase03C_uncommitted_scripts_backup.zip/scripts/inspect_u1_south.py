import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print("PADS near U1 south (X: 40..46, Y: 7.0..9.2):")
for p in b.GetPads():
    pos = p.GetPosition()
    px, py = pos.x / 1e6, pos.y / 1e6
    if 40.0 <= px <= 46.0 and 7.0 <= py <= 9.2:
        fp = p.GetParentFootprint()
        ref = fp.GetReference() if fp else '?'
        print(f"  {ref}.{p.GetNumber()} [{p.GetNetname()}] at ({px:.3f}, {py:.3f})")

print("\nTRACKS/VIAS near U1 south:")
for t in b.GetTracks():
    if isinstance(t, pcbnew.PCB_VIA):
        pos = t.GetPosition()
        px, py = pos.x / 1e6, pos.y / 1e6
        if 40.0 <= px <= 46.0 and 7.0 <= py <= 9.2:
            print(f"  VIA [{t.GetNetname()}] at ({px:.3f}, {py:.3f})")
    else:
        s, e = t.GetStart(), t.GetEnd()
        sx, sy = s.x / 1e6, s.y / 1e6
        ex, ey = e.x / 1e6, e.y / 1e6
        if (40.0 <= sx <= 46.0 and 7.0 <= sy <= 9.2) or (40.0 <= ex <= 46.0 and 7.0 <= ey <= 9.2):
            print(f"  TRACK {t.GetLayerName()} [{t.GetNetname()}] ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})")

sys.exit(0)
