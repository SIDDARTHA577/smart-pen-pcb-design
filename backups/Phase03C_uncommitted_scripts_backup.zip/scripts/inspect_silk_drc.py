import json

with open('reports/RevG/Phase03C/raw/Candidate_FourLayer_drc.json') as f:
    d = json.load(f)

for v in d.get('violations', []):
    if v.get('type') == 'silk_over_copper':
        print(v.get('description'))
        for it in v.get('items', []):
            print('  ', it.get('description'), it.get('pos'))

