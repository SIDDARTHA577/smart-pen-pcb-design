import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- F.Cu items in [44, 46] x [1.0, 2.6] ---')
for fp in board.Footprints():
    for p in fp.Pads():
        pos = p.GetPosition()
        px, py = pos.x/1e6, pos.y/1e6
        if 44 <= px <= 46 and 1.0 <= py <= 2.6:
            print(f'Pad {fp.GetReference()}.{p.GetNumber()} [{p.GetNetname()}] at ({px:.3f}, {py:.3f}), size ({p.GetSize().x/1e6:.3f}, {p.GetSize().y/1e6:.3f})')

