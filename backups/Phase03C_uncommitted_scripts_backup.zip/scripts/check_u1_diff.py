import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
u1_board = board.FindFootprintByReference('U1')

lib_path = 'output/RevG/variants/FourLayer_Candidate/SmartPen.pretty'
u1_lib = pcbnew.FootprintLoad(lib_path, 'U1')

print('Board pads count:', len(list(u1_board.Pads())))
print('Lib pads count:', len(list(u1_lib.Pads())))

diffs = 0
for pb in u1_board.Pads():
    pl = u1_lib.FindPadByNumber(pb.GetNumber())
    if not pl:
        print(f'Pad {pb.GetNumber()} missing in lib!')
        diffs += 1
        continue
    if pb.GetSize() != pl.GetSize():
        print(f'Pad {pb.GetNumber()} size mismatch: board={pb.GetSize()}, lib={pl.GetSize()}')
        diffs += 1
    if pb.GetShape() != pl.GetShape():
        print(f'Pad {pb.GetNumber()} shape mismatch: board={pb.GetShape()}, lib={pl.GetShape()}')
        diffs += 1
    if pb.GetRoundRectRadiusRatio() != pl.GetRoundRectRadiusRatio():
        print(f'Pad {pb.GetNumber()} rratio mismatch: board={pb.GetRoundRectRadiusRatio()}, lib={pl.GetRoundRectRadiusRatio()}')
        diffs += 1

print(f'Total pad differences: {diffs}')
