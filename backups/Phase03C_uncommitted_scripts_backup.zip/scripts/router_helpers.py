import pcbnew
import math
from pathlib import Path

def setup_board_rules_and_stackup(board):
    board.SetCopperLayerCount(4)
    ds = board.GetDesignSettings()
    ds.SetBoardThickness(int(1.6 * 1e6))
    ds.m_SolderMaskExpansion = int(0.025 * 1e6)
    ds.m_SolderMaskMinWidth = int(0.08 * 1e6)
    
    # Netclass settings
    nc = ds.GetNetClasses().Find("Default")
    if nc:
        nc.SetClearance(int(0.15 * 1e6))
        nc.SetTrackWidth(int(0.18 * 1e6))
        nc.SetViaDiameter(int(0.50 * 1e6))
        nc.SetViaDrill(int(0.30 * 1e6))

def clear_existing_tracks(board):
    tracks = list(board.GetTracks())
    for t in tracks:
        board.Delete(t)
    print(f"Cleared {len(tracks)} existing tracks and vias.")

def add_track(board, netname, layer_id, x1, y1, x2, y2, width_mm=0.18):
    net = board.FindNet(netname)
    if not net:
        print(f"Warning: Net {netname} not found!")
        return None
    track = pcbnew.PCB_TRACK(board)
    track.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    track.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    track.SetWidth(int(width_mm * 1e6))
    track.SetLayer(layer_id)
    track.SetNet(net)
    board.Add(track)
    return track

def add_via(board, netname, x, y, drill_mm=0.30, dia_mm=0.50):
    net = board.FindNet(netname)
    if not net:
        print(f"Warning: Net {netname} not found!")
        return None
    via = pcbnew.PCB_VIA(board)
    via.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    via.SetDrill(int(drill_mm * 1e6))
    via.SetWidth(int(dia_mm * 1e6))
    via.SetTopLayer(pcbnew.F_Cu)
    via.SetBottomLayer(pcbnew.B_Cu)
    via.SetNet(net)
    board.Add(via)
    return via

def route_manhattan(board, netname, layer_id, x1, y1, x2, y2, width_mm=0.18, corner_first="x"):
    """Route orthogonal 2-segment L-shaped track."""
    if abs(x1 - x2) < 0.001 and abs(y1 - y2) < 0.001:
        return
    if abs(x1 - x2) < 0.001 or abs(y1 - y2) < 0.001:
        add_track(board, netname, layer_id, x1, y1, x2, y2, width_mm)
        return
    
    if corner_first == "x":
        add_track(board, netname, layer_id, x1, y1, x2, y1, width_mm)
        add_track(board, netname, layer_id, x2, y1, x2, y2, width_mm)
    else:
        add_track(board, netname, layer_id, x1, y1, x1, y2, width_mm)
        add_track(board, netname, layer_id, x1, y2, x2, y2, width_mm)

