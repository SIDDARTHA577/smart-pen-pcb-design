from pathlib import Path

pcb_text = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb").read_text(encoding="utf-8")
for i, line in enumerate(pcb_text.splitlines()):
    if line.strip().startswith("(zone"):
        print(f"Line {i+1}: {line[:60]}")
        for j in range(i, min(i+25, len(pcb_text.splitlines()))):
            print("  ", pcb_text.splitlines()[j])
        break

