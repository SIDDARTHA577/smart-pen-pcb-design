import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# Test via for 3V3_RTC at (42.130, 1.300):
v_rtc, rv_rtc = geom.is_via_legal(42.130, 1.300, '/3V3_RTC')
s_rtc_fcu, rf_rtc = geom.is_segment_legal(42.130, 1.300, 42.130, 2.435, 'F.Cu', '/3V3_RTC')
print(f"3V3_RTC via at (42.13, 1.3): {v_rtc} ({rv_rtc}), F.Cu reach: {s_rtc_fcu}")
