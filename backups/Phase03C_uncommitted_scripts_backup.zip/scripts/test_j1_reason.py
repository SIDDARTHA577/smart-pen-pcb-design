import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

j1, rj1 = geom.is_segment_legal(28.09, 4.4, 41.0, 4.4, 'B.Cu', '/VBAT_SW')
print(f"j1: {j1} ({rj1})")

sys.exit(0)
