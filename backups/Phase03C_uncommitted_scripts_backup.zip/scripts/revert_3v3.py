import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

# Remove In2.Cu zone
to_del_zones = [z for z in board.Zones() if z.GetLayerName() == 'In2.Cu']
for z in to_del_zones:
    board.Remove(z)

# Remove tracks and vias on /3V3
to_del_tracks = [t for t in board.GetTracks() if t.GetNetname() == '/3V3']
for t in to_del_tracks:
    board.Remove(t)

filler = pcbnew.ZONE_FILLER(board)
filler.Fill(board.Zones())
board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('Removed 3V3 test tracks/vias/zone')

