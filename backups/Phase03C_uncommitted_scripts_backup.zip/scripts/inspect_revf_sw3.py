import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

b = pcbnew.LoadBoard('output/RevF_Working/SmartPen.kicad_pcb')
sw3 = b.FindFootprintByReference('SW3')
for p in sw3.Pads():
    print(f"SW3 Pad {p.GetNumber()}: net={p.GetNetname()}")

q2 = b.FindFootprintByReference('Q2')
for p in q2.Pads():
    print(f"Q2 Pad {p.GetNumber()}: net={p.GetNetname()}")

d4 = b.FindFootprintByReference('D4')
for p in d4.Pads():
    print(f"D4 Pad {p.GetNumber()}: net={p.GetNetname()}")

sys.exit(0)
