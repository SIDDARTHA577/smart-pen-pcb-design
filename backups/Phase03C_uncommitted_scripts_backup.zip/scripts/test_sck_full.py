import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

# SCK route:
# F.Cu: Pad 3 (58.150, 4.200) -> (58.150, 5.500) -> (57.500, 5.500)
# Via 1: at (57.500, 5.500)
# B.Cu: (57.500, 5.500) -> (57.500, 2.200) -> (57.000, 2.200) -> (57.000, 1.450)
# Via 2: at (57.000, 1.450)
# In2.Cu: (57.000, 1.450) -> (42.700, 1.450) -> (42.700, 0.500)
# Via 3: at (42.700, 0.500)
# F.Cu: (42.700, 0.500) -> (42.630, 2.435) (U1.12)

print("Checking SCK segments:")
print("s1 F.Cu:", geom.is_segment_legal(58.150, 4.200, 58.150, 5.500, 'F.Cu', '/SD_SCK'))
print("s2 F.Cu:", geom.is_segment_legal(58.150, 5.500, 57.500, 5.500, 'F.Cu', '/SD_SCK'))
print("via1:", geom.is_via_legal(57.500, 5.500, '/SD_SCK'))
print("s3 B.Cu:", geom.is_segment_legal(57.500, 5.500, 57.500, 2.200, 'B.Cu', '/SD_SCK'))
print("s4 B.Cu:", geom.is_segment_legal(57.500, 2.200, 57.000, 2.200, 'B.Cu', '/SD_SCK'))
print("s5 B.Cu:", geom.is_segment_legal(57.000, 2.200, 57.000, 1.450, 'B.Cu', '/SD_SCK'))
print("via2:", geom.is_via_legal(57.000, 1.450, '/SD_SCK'))
print("s6 In2.Cu:", geom.is_segment_legal(57.000, 1.450, 42.700, 1.450, 'In2.Cu', '/SD_SCK'))
print("s7 In2.Cu:", geom.is_segment_legal(42.700, 1.450, 42.700, 0.500, 'In2.Cu', '/SD_SCK'))
print("via3:", geom.is_via_legal(42.700, 0.500, '/SD_SCK'))
print("s8 F.Cu:", geom.is_segment_legal(42.700, 0.500, 42.630, 2.435, 'F.Cu', '/SD_SCK'))
