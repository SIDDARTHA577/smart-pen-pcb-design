import pcbnew
board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
j_usb = board.FindFootprintByReference('J_USB')
pcbnew.FootprintSave('output/RevG/variants/FourLayer_Candidate/SmartPen.pretty', j_usb)
print('Saved J_USB to library')

