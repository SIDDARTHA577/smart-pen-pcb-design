import pcbnew
import math

try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass

class BoardGeometry:
    def __init__(self, board):
        self.board = board
        self.vias = []
        self.tracks = []
        self.pads = []
        
        for t in board.GetTracks():
            if isinstance(t, pcbnew.PCB_VIA):
                pos = t.GetPosition()
                self.vias.append({
                    'x': pos.x / 1e6,
                    'y': pos.y / 1e6,
                    'net': t.GetNetname(),
                    'dia': t.GetWidth(pcbnew.F_Cu) / 1e6,
                    'drill': t.GetDrill() / 1e6
                })
            else:
                s = t.GetStart()
                e = t.GetEnd()
                self.tracks.append({
                    'x1': s.x / 1e6,
                    'y1': s.y / 1e6,
                    'x2': e.x / 1e6,
                    'y2': e.y / 1e6,
                    'layer': t.GetLayerName(),
                    'net': t.GetNetname(),
                    'w': t.GetWidth() / 1e6
                })
                
        for p in board.GetPads():
            pos = p.GetPosition()
            sz = p.GetSize()
            fp = p.GetParentFootprint()
            ref = fp.GetReference() if fp else '?'
            self.pads.append({
                'ref': ref,
                'num': p.GetNumber(),
                'x': pos.x / 1e6,
                'y': pos.y / 1e6,
                'sx': sz.x / 1e6,
                'sy': sz.y / 1e6,
                'net': p.GetNetname(),
                'layer': p.GetLayerName()
            })

    def is_via_legal(self, vx, vy, netname, dia=0.50, drill=0.30):
        r_via = dia / 2.0
        r_drill = drill / 2.0
        
        # 1. Board bounds (edge clearance 0.25 mm)
        if vx - r_via < 0.25 or vx + r_via > (84.0 - 0.25):
            return False, 'board_bounds_x'
        if vy - r_via < 0.25 or vy + r_via > (9.20 - 0.25):
            return False, 'board_bounds_y'
            
        # 2. Vias (hole clearance 0.25 mm, copper 0.15 mm)
        for v in self.vias:
            dx = vx - v['x']
            dy = vy - v['y']
            dist = math.hypot(dx, dy)
            if dist < (r_drill + v['drill']/2.0 + 0.250):
                return False, f'via_drill ({dist:.3f} < 0.55)'
            if v['net'] != netname and dist < (r_via + v['dia']/2.0 + 0.150):
                return False, f'via_cu ({dist:.3f} < 0.65)'

        # 3. Pads on ALL layers
        for p in self.pads:
            if p['net'] != netname:
                cx = max(p['x'] - p['sx']/2.0, min(vx, p['x'] + p['sx']/2.0))
                cy = max(p['y'] - p['sy']/2.0, min(vy, p['y'] + p['sy']/2.0))
                dist = math.hypot(vx - cx, vy - cy)
                if dist < 0.405: # r_via + 0.15 = 0.40 mm
                    return False, f'pad {p["ref"]}.{p["num"]}[{p["net"]}]: dist {dist:.3f}'

        # 4. Tracks on ALL layers
        for t in self.tracks:
            if t['net'] != netname:
                x1, y1, x2, y2 = t['x1'], t['y1'], t['x2'], t['y2']
                dx = x2 - x1
                dy = y2 - y1
                l2 = dx*dx + dy*dy
                if l2 == 0:
                    dist = math.hypot(vx - x1, vy - y1)
                else:
                    u = max(0.0, min(1.0, ((vx - x1)*dx + (vy - y1)*dy) / l2))
                    dist = math.hypot(vx - (x1 + u*dx), vy - (y1 + u*dy))
                req = 0.405 + t['w']/2.0
                if dist < req:
                    return False, f'track {t["layer"]} [{t["net"]}]: dist {dist:.3f}'

        return True, 'OK'

    def is_segment_legal(self, x1, y1, x2, y2, layer_name, netname, w=0.18):
        r = w / 2.0
        # Check pads on layer
        for p in self.pads:
            if p['net'] != netname:
                for i in range(11):
                    frac = i / 10.0
                    sx = x1 + frac * (x2 - x1)
                    sy = y1 + frac * (y2 - y1)
                    cx = max(p['x'] - p['sx']/2.0, min(sx, p['x'] + p['sx']/2.0))
                    cy = max(p['y'] - p['sy']/2.0, min(sy, p['y'] + p['sy']/2.0))
                    if math.hypot(sx - cx, sy - cy) < (r + 0.155):
                        return False, f'seg_pad {p["ref"]}.{p["num"]}[{p["net"]}]'

        # Check tracks on same layer
        for t in self.tracks:
            if t['layer'] == layer_name and t['net'] != netname:
                for i in range(11):
                    frac = i / 10.0
                    sx = x1 + frac * (x2 - x1)
                    sy = y1 + frac * (y2 - y1)
                    tx1, ty1, tx2, ty2 = t['x1'], t['y1'], t['x2'], t['y2']
                    tdx = tx2 - tx1
                    tdy = ty2 - ty1
                    tl2 = tdx*tdx + tdy*tdy
                    if tl2 == 0:
                        dist = math.hypot(sx - tx1, sy - ty1)
                    else:
                        u = max(0.0, min(1.0, ((sx - tx1)*tdx + (sy - ty1)*tdy) / tl2))
                        dist = math.hypot(sx - (tx1 + u*tdx), sy - (ty1 + u*tdy))
                    if dist < (r + t['w']/2.0 + 0.155):
                        return False, f'seg_track [{t["net"]}]'

        return True, 'OK'

if __name__ == '__main__':
    board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
    geom = BoardGeometry(board)
    print(f'Loaded BoardGeometry: {len(geom.vias)} vias, {len(geom.tracks)} tracks, {len(geom.pads)} pads without any asserts.')
