import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

m1, rm1 = geom.is_segment_legal(28.086, 4.704, 30.753, 4.704, 'F.Cu', '/VBAT_SW')
m2, rm2 = geom.is_segment_legal(30.753, 4.704, 30.753, 6.285, 'F.Cu', '/VBAT_SW')
print(f"J_MOT connection: m1={m1}({rm1}), m2={m2}({rm2})")

v_u4_3, ru4 = geom.is_via_legal(70.014, 4.400, '/VBAT_SW')
s_u4_3, rsu4 = geom.is_segment_legal(70.014, 4.400, 70.014, 3.963, 'F.Cu', '/VBAT_SW')
print(f"U4.3 via and drop: v={v_u4_3}({ru4}), s={s_u4_3}({rsu4})")

sys.exit(0)
