import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")

# Find the 3V3 zone
z3v3 = None
for z in b.Zones():
    if z.GetNetname() == '/3V3':
        z3v3 = z
        break

print("3V3 Zone outline:")
bb = z3v3.GetBoundingBox()
print(f"BBox: X=[{bb.GetX()/1e6:.2f}, {(bb.GetX()+bb.GetWidth())/1e6:.2f}], Y=[{bb.GetY()/1e6:.2f}, {(bb.GetY()+bb.GetHeight())/1e6:.2f}]")

# Check all tracks on In2.Cu that cross X=50..70
print("\nIn2.Cu tracks crossing X=50..70:")
for t in b.GetTracks():
    if t.GetLayer() == b.GetLayerID('In2.Cu'):
        p1, p2 = t.GetStart(), t.GetEnd()
        print(f"TRK {t.GetNetname()}: ({p1.x/1e6:.2f}, {p1.y/1e6:.2f}) -> ({p2.x/1e6:.2f}, {p2.y/1e6:.2f})")
