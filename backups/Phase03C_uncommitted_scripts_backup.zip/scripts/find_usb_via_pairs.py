import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# Find legal via pairs for DM and DP
# DM originates at U1.25 (44.630, 7.235)
# DP originates at U1.26 (44.130, 7.235)
# R7.2 is at (72.500, 7.025)
# R8.2 is at (71.600, 7.025)

print("Scanning via positions near U1 for DM:")
dm_vias_west = []
for x in [45.0, 46.0, 47.0, 48.0, 49.0, 50.0, 51.0, 52.0, 53.0, 54.0]:
    for y in [7.0, 7.1, 7.2, 7.3, 7.4, 7.5]:
        v_ok, r = geom.is_via_legal(x, y, '/USB_DM_CORE')
        if v_ok:
            dm_vias_west.append((x, y))

print("Legal DM west vias:", dm_vias_west)

print("\nScanning via positions near U1 for DP:")
dp_vias_west = []
for x in [45.0, 46.0, 47.0, 48.0, 49.0, 50.0, 51.0, 52.0, 53.0, 54.0]:
    for y in [7.0, 7.1, 7.2, 7.3, 7.4, 7.5]:
        v_ok, r = geom.is_via_legal(x, y, '/USB_DP_CORE')
        if v_ok:
            dp_vias_west.append((x, y))

print("Legal DP west vias:", dp_vias_west)

print("\nScanning east vias near R7/R8:")
dm_vias_east = []
dp_vias_east = []
for x in [70.0, 70.5, 71.0, 71.5, 72.0, 72.5, 73.0, 73.5]:
    for y in [6.5, 6.8, 7.0, 7.2, 7.5, 7.8, 8.0, 8.2]:
        v_ok, r = geom.is_via_legal(x, y, '/USB_DM_CORE')
        if v_ok:
            dm_vias_east.append((x, y))
        v2_ok, r2 = geom.is_via_legal(x, y, '/USB_DP_CORE')
        if v2_ok:
            dp_vias_east.append((x, y))

print("Legal DM east vias:", dm_vias_east)
print("Legal DP east vias:", dp_vias_east)

sys.exit(0)
