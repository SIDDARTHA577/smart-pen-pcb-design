import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

tracks = list(board.GetTracks())
print(f'Total tracks/vias in board: {len(tracks)}')

by_net = {}
for t in tracks:
    netname = t.GetNetname()
    by_net.setdefault(netname, []).append(t)

for netname, tlist in sorted(by_net.items(), key=lambda x: x[0]):
    vias = [t for t in tlist if isinstance(t, pcbnew.PCB_VIA)]
    segs = [t for t in tlist if not isinstance(t, pcbnew.PCB_VIA)]
    print(f'Net {netname}: {len(segs)} segments, {len(vias)} vias')

