import pcbnew
import subprocess
import json

board = pcbnew.LoadBoard('scratch_test_mosi_flawless.kicad_pcb')

fcu = board.GetLayerID('F.Cu')
bcu = board.GetLayerID('B.Cu')
in1 = board.GetLayerID('In1.Cu')
in2 = board.GetLayerID('In2.Cu')

# In scratch_test_mosi_flawless:
# SD_CS has tracks on F.Cu:
# (56.975, 2.000) -> (56.975, 0.500) -> (59.800, 0.500) -> (59.800, 3.600) -> (59.650, 3.600) -> (59.650, 4.200)
# Let's remove the F.Cu segment of SD_CS that goes from (56.975, 0.5) to (59.65, 4.2)
cs_fcu_to_remove = []
for t in board.GetTracks():
    if not isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/SD_CS' and t.GetLayerName() == 'F.Cu':
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = pcbnew.ToMM(p1.x), pcbnew.ToMM(p1.y)
        x2, y2 = pcbnew.ToMM(p2.x), pcbnew.ToMM(p2.y)
        # keep the track from via (56.975, 2.3) to R18.2 (56.975, 2.0)
        if min(y1, y2) < 1.9 or max(x1, x2) > 57.0:
            cs_fcu_to_remove.append(t)

print(f"Removing {len(cs_fcu_to_remove)} SD_CS F.Cu tracks")
for t in cs_fcu_to_remove:
    board.Remove(t)

# Helper functions
def add_track(netname, layer, x1, y1, x2, y2, width=0.15):
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(pcbnew.VECTOR2I_MM(x1, y1))
    t.SetEnd(pcbnew.VECTOR2I_MM(x2, y2))
    t.SetWidth(pcbnew.FromMM(width))
    t.SetLayer(layer)
    t.SetNet(board.FindNet(netname))
    board.Add(t)
    return t

def add_via(netname, x, y, drill=0.3, width=0.5):
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pcbnew.VECTOR2I_MM(x, y))
    v.SetDrill(pcbnew.FromMM(drill))
    v.SetWidth(pcbnew.FromMM(width))
    v.SetNet(board.FindNet(netname))
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    board.Add(v)
    return v

# --- 1. REROUTE SD_CS on B.Cu ---
# R18.2 is at (56.975, 2.000). Via /SD_CS is at (56.975, 2.300).
# That via is already connected to In2.Cu and F.Cu R18.2.
# Now on B.Cu:
# From (56.975, 2.300), go south to (56.975, 0.500) on B.Cu
add_track('/SD_CS', bcu, 56.975, 2.300, 56.975, 0.500)
add_track('/SD_CS', bcu, 56.975, 0.500, 59.800, 0.500)
add_track('/SD_CS', bcu, 59.800, 0.500, 59.800, 3.200)
# Via from B.Cu to F.Cu at (59.800, 3.200)
add_via('/SD_CS', 59.800, 3.200)
# F.Cu track from (59.800, 3.200) into Pad 6 (59.650, 4.200)
add_track('/SD_CS', fcu, 59.800, 3.200, 59.650, 3.600)
add_track('/SD_CS', fcu, 59.650, 3.600, 59.650, 4.200)

# --- 2. ROUTE SD_MISO on F.Cu and In1.Cu ---
# At J_SD.5 (59.150, 4.200):
# Down to Y=3.250 on F.Cu
add_track('/SD_MISO', fcu, 59.150, 4.200, 59.150, 3.250)
# East along Y=3.250 to X=59.500 on F.Cu
# Wait, let's see if it can reach X=59.500, then south to Y=1.300!
add_track('/SD_MISO', fcu, 59.150, 3.250, 59.450, 3.250)
add_track('/SD_MISO', fcu, 59.450, 3.250, 59.450, 1.300)
add_track('/SD_MISO', fcu, 59.450, 1.300, 59.150, 1.300)
add_via('/SD_MISO', 59.150, 1.300)

# At U1.10 (41.630, 2.435):
add_track('/SD_MISO', fcu, 41.630, 2.435, 41.630, 0.600)
add_via('/SD_MISO', 41.630, 0.600)

# Transit on In1.Cu:
# From (41.630, 0.600) -> (43.500, 0.600) -> (44.500, 2.000) -> (56.000, 2.000)
# Then from (56.000, 2.000) -> (57.000, 1.800) -> (58.500, 1.800) -> (59.150, 1.300)
add_track('/SD_MISO', in1, 41.630, 0.600, 43.500, 0.600)
add_track('/SD_MISO', in1, 43.500, 0.600, 44.500, 2.000)
add_track('/SD_MISO', in1, 44.500, 2.000, 56.000, 2.000)
add_track('/SD_MISO', in1, 56.000, 2.000, 57.000, 1.800)
add_track('/SD_MISO', in1, 57.000, 1.800, 58.500, 1.800)
add_track('/SD_MISO', in1, 58.500, 1.800, 59.150, 1.300)

out_pcb = 'scratch_test_miso_east.kicad_pcb'
board.Save(out_pcb)
print(f"Saved {out_pcb}")
