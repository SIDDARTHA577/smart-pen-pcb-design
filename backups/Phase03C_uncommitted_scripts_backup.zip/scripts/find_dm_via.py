import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

for xi in range(718, 736, 1):
    x = xi / 10.0
    for yi in range(60, 75, 1):
        y = yi / 10.0
        v_dm, r = geom.is_via_legal(x, y, '/USB_DM_CORE')
        if v_dm:
            s_fcu, rs = geom.is_segment_legal(x, y, 72.5, 7.025, 'F.Cu', '/USB_DM_CORE')
            if s_fcu:
                print(f"DM via legal at ({x:.2f}, {y:.2f}) and F.Cu segment legal!")

sys.exit(0)
