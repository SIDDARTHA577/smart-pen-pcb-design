import json
from pathlib import Path

drc_path = Path("reports/RevG/Phase03C/raw/baseline/Main_SmartPen_drc.json")
with open(drc_path, "r", encoding="utf-8") as f:
    drc = json.load(f)

for vtype in ["hole_clearance", "starved_thermal", "via_dangling", "track_dangling", "silk_over_copper", "silk_overlap"]:
    items = [v for v in drc["violations"] if v.get("type") == vtype]
    print(f"\n=================== {vtype} ({len(items)}) ===================")
    for i, it in enumerate(items):
        print(f"[{i+1}] {it.get('description')}")
        for sub in it.get("items", []):
            print(f"    Item: {sub.get('description')} @ ({sub.get('pos', {}).get('x')}, {sub.get('pos', {}).get('y')}) uuid={sub.get('uuid')}")

