import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

board_path = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb'
b = pcbnew.LoadBoard(board_path)

# Let's inspect all remaining unconnected items and current violations
fcu = b.GetLayerID('F.Cu')
in1 = b.GetLayerID('In1.Cu')
in2 = b.GetLayerID('In2.Cu')
bcu = b.GetLayerID('B.Cu')

def add_track(b, net, layer, x1, y1, x2, y2, w=0.18):
    t = pcbnew.PCB_TRACK(b)
    t.SetNet(net)
    t.SetLayer(layer)
    t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    t.SetWidth(int(w * 1e6))
    b.Add(t)

def add_via(b, net, x, y, dia=0.50, drill=0.30):
    v = pcbnew.PCB_VIA(b)
    v.SetNet(net)
    v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    v.SetWidth(int(dia * 1e6))
    v.SetDrill(int(drill * 1e6))
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    b.Add(v)

print("Master solver framework ready.")
sys.exit(0)
