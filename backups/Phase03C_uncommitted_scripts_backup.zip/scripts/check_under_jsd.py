import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")
bcu = b.GetLayerID('B.Cu')

print("--- Objects on B.Cu under J_SD (X=56..61, Y=3.5..6.0) ---")
for t in b.GetTracks():
    if t.GetLayer() == bcu and not isinstance(t, pcbnew.PCB_VIA):
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (56.0 <= x1 <= 61.0 or 56.0 <= x2 <= 61.0) and (3.5 <= y1 <= 6.0 or 3.5 <= y2 <= 6.0):
            print(f"TRK Net: {t.GetNetname()} ({x1:.3f}, {y1:.3f}) -> ({x2:.3f}, {y2:.3f})")
    elif isinstance(t, pcbnew.PCB_VIA):
        pos = t.GetPosition()
        x, y = pos.x/1e6, pos.y/1e6
        if 56.0 <= x <= 61.0 and 3.5 <= y <= 6.0:
            print(f"VIA Net: {t.GetNetname()} at ({x:.3f}, {y:.3f})")
