import shutil
from pathlib import Path
import pcbnew

SRC_DIR = Path("output/RevG")
DST_DIR = Path("output/RevG/variants/FourLayer_Candidate")

DST_DIR.mkdir(parents=True, exist_ok=True)

# Copy files
files_to_copy = [
    "SmartPen.kicad_sch",
    "SmartPen.kicad_pcb",
    "SmartPen.kicad_pro",
    "SmartPen.kicad_prl",
    "SmartPen.kicad_dru",
    "SmartPen_Lib.kicad_sym",
    "fp-lib-table",
    "sym-lib-table",
]

for f in files_to_copy:
    src_file = SRC_DIR / f
    dst_file = DST_DIR / f
    if src_file.exists():
        shutil.copy2(src_file, dst_file)
        print(f"Copied {f} -> {dst_file}")

# Copy SmartPen.pretty directory
pretty_src = SRC_DIR / "SmartPen.pretty"
pretty_dst = DST_DIR / "SmartPen.pretty"
if pretty_dst.exists():
    shutil.rmtree(pretty_dst)
shutil.copytree(pretty_src, pretty_dst)
print(f"Copied SmartPen.pretty directory -> {pretty_dst}")

# Open DST board in pcbnew and configure 4 copper layers
pcb_path = DST_DIR / "SmartPen.kicad_pcb"
board = pcbnew.LoadBoard(str(pcb_path))
board.SetCopperLayerCount(4)
board.Save(str(pcb_path))
print("Successfully converted FourLayer_Candidate/SmartPen.kicad_pcb to 4 copper layers.")

