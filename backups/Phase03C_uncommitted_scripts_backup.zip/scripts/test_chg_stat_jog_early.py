import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

leg, r = geom.is_segment_legal(39.5, 1.8, 44.0, 1.8, 'B.Cu', '/CHG_STAT')
print(f"CHG_STAT at Y=1.8 from 39.5 to 44.0 on B.Cu: {leg} ({r})")

sys.exit(0)
