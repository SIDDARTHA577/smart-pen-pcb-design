import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except:
    pass
import pcbnew

b = pcbnew.LoadBoard("scratch_test_clean_step10.kicad_pcb")

print("--- 3V3 Items X in [50, 70] ---")
for t in b.GetTracks():
    if t.GetNetname() == '/3V3':
        p1 = t.GetStart()
        p2 = t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (50 <= x1 <= 70 or 50 <= x2 <= 70):
            if t.GetClass() == 'PCB_VIA':
                print(f"VIA: ({x1:.3f}, {y1:.3f})")
            else:
                print(f"TRK {b.GetLayerName(t.GetLayer())}: ({x1:.3f}, {y1:.3f}) -> ({x2:.3f}, {y2:.3f})")

for fp in b.GetFootprints():
    for p in fp.Pads():
        if p.GetNetname() == '/3V3':
            pos = p.GetPosition()
            x, y = pos.x/1e6, pos.y/1e6
            if 50 <= x <= 70:
                print(f"PAD {fp.GetReference()}.{p.GetNumber()}: ({x:.3f}, {y:.3f})")
