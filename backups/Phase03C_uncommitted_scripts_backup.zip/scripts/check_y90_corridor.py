import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

for yi in [8.9, 9.0, 9.1]:
    for layer in ['F.Cu', 'In2.Cu', 'B.Cu']:
        s, r = geom.is_segment_legal(54.0, yi, 73.0, yi, layer, '/USB_DM_CORE')
        print(f"Layer {layer} at Y={yi:.1f}: {s} ({r})")
