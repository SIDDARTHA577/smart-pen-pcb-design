with open('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_sch', encoding='utf-8') as f:
    text = f.read()

idx = text.find('"D4"')
if idx != -1:
    print(text[max(0, idx-100):idx+300])
