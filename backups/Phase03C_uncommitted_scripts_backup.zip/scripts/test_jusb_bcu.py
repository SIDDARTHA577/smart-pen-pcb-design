import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Testing B.Cu route from C10.1 to J_USB.2 and J_USB.11:")
# Via at (73.750, 0.800):
v1, rv1 = geom.is_via_legal(73.750, 0.800, '/USB_VBUS')
# Via at (76.000, 1.800):
v2, rv2 = geom.is_via_legal(76.000, 1.800, '/USB_VBUS')
# Via at (80.800, 1.800):
v3, rv3 = geom.is_via_legal(80.800, 1.800, '/USB_VBUS')

s_bcu, rb = geom.is_segment_legal(73.750, 1.800, 80.800, 1.800, 'B.Cu', '/USB_VBUS')

print(f"v1={v1}({rv1}), v2={v2}({rv2}), v3={v3}({rv3})")
print(f"s_bcu at 1.8: {s_bcu} ({rb})")
