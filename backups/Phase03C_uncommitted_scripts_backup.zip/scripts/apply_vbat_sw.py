import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

board_path = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb'
b = pcbnew.LoadBoard(board_path)

net = b.FindNet('/VBAT_SW')
fcu = b.GetLayerID('F.Cu')
in2 = b.GetLayerID('In2.Cu')
bcu = b.GetLayerID('B.Cu')

def add_track(net, layer, x1, y1, x2, y2, w=0.18):
    t = pcbnew.PCB_TRACK(b)
    t.SetNet(net)
    t.SetLayer(layer)
    t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    t.SetWidth(int(w * 1e6))
    b.Add(t)

def add_via(net, x, y, dia=0.50, drill=0.30):
    v = pcbnew.PCB_VIA(b)
    v.SetNet(net)
    v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    v.SetWidth(int(dia * 1e6))
    v.SetDrill(int(drill * 1e6))
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    b.Add(v)

# 1. Update U1 thermal vias to 4-corner pattern
gnd_net = b.FindNet('/GND')
to_remove = []
for t in b.GetTracks():
    if isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/GND':
        pos = t.GetPosition()
        px, py = pos.x / 1e6, pos.y / 1e6
        if 42.0 <= px <= 44.0 and 4.0 <= py <= 5.5:
            to_remove.append(t)
for t in to_remove:
    b.Remove(t)

for vx, vy in [(42.2, 3.8), (43.5, 3.8), (42.2, 5.8), (43.5, 5.8)]:
    add_via(gnd_net, vx, vy)

# 2. Add VBAT_SW Vias
add_via(net, 28.090, 4.400)
add_via(net, 30.753, 4.400)
add_via(net, 30.753, 7.200)
add_via(net, 62.963, 4.400)
add_via(net, 68.114, 4.400)
add_via(net, 70.014, 4.400)

# 3. Add F.Cu tracks
add_track(net, fcu, 28.090, 4.400, 28.086, 4.704) # to D3.1
add_track(net, fcu, 30.753, 7.200, 30.753, 6.285) # to J_MOT.1
add_track(net, fcu, 62.963, 4.400, 62.963, 6.824) # to SW3.2
add_track(net, fcu, 68.114, 4.400, 68.114, 3.963) # to U4.1
add_track(net, fcu, 70.014, 4.400, 70.014, 3.963) # to U4.3

# 4. Add In2.Cu track for J_MOT tap
add_track(net, in2, 30.753, 4.400, 30.753, 7.200)

# 5. Add B.Cu main run
segs = [
    (28.090, 4.400, 30.753, 4.400),
    (30.753, 4.400, 34.000, 4.400),
    (34.000, 4.400, 35.000, 4.050),
    (35.000, 4.050, 38.000, 4.050),
    (38.000, 4.050, 40.500, 4.800),
    (40.500, 4.800, 52.000, 4.800),
    (52.000, 4.800, 54.000, 4.400),
    (54.000, 4.400, 62.963, 4.400),
    (68.114, 4.400, 70.014, 4.400) # bridge to U4.3
]
for x1, y1, x2, y2 in segs:
    add_track(net, bcu, x1, y1, x2, y2)

filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
b.Save(board_path)
print("VBAT_SW successfully routed!")
sys.exit(0)
