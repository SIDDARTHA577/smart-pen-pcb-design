import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

for y_test in [3.2, 3.3, 3.4, 3.5, 3.6]:
    v_ok, v_r = geom.is_via_legal(37.025, y_test, '/3V3')
    f_ok, f_r = geom.is_segment_legal(37.025, y_test, 37.025, 4.085, 'F.Cu', '/3V3')
    print(f"Via at (37.025, {y_test:.2f}): {v_ok} ({v_r}), F.Cu to R3.1: {f_ok} ({f_r})")
