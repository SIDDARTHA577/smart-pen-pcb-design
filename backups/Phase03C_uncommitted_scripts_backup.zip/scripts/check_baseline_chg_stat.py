import pcbnew
b = pcbnew.LoadBoard('output/RevG/SmartPen.kicad_pcb')
for t in b.GetTracks():
    if t.GetNetname() == '/CHG_STAT':
        s, e = t.GetStart(), t.GetEnd()
        print(f"Baseline CHG_STAT: layer={b.GetLayerName(t.GetLayer())}, ({s.x/1e6:.3f}, {s.y/1e6:.3f}) -> ({e.x/1e6:.3f}, {e.y/1e6:.3f})")
