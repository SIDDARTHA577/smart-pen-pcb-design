with open('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb', 'r', encoding='utf-8') as f:
    text = f.read()

# Replace the uuid of In1.Cu zone
# Find "(layer \"In1.Cu\")\n    (uuid \"56e52d42-fd14-45c9-9f61-7a35d3828ce5\")"
old_str = '(layer "In1.Cu")\n    (uuid "56e52d42-fd14-45c9-9f61-7a35d3828ce5")'
new_str = '(layer "In1.Cu")\n    (uuid "a1b2c3d4-e5f6-47a8-b9c0-d1e2f3a4b5c6")'

if old_str in text:
    text = text.replace(old_str, new_str, 1)
    with open('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb', 'w', encoding='utf-8') as f:
        f.write(text)
    print('Successfully replaced In1.Cu UUID')
else:
    print('Pattern not found')

