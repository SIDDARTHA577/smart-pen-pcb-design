import sys
sys.path.append('scripts')
import pcbnew

b = pcbnew.LoadBoard('output/RevG/SmartPen.kicad_pcb')
d4 = b.FindFootprintByReference('D4')
print('Baseline D4 pos:', d4.GetPosition().x/1e6, d4.GetPosition().y/1e6, 'orientation:', d4.GetOrientation().AsDegrees())
for p in d4.Pads():
    pos = p.GetPosition()
    print(f"Pad {p.GetNumber()}: net={p.GetNetname()}, pos=({pos.x/1e6:.3f}, {pos.y/1e6:.3f})")
jsd = b.FindFootprintByReference('J_SD')
print('Baseline J_SD pos:', jsd.GetPosition().x/1e6, jsd.GetPosition().y/1e6)
for p in jsd.Pads():
    pos = p.GetPosition()
    print(f"Pad {p.GetNumber()}: net={p.GetNetname()}, pos=({pos.x/1e6:.3f}, {pos.y/1e6:.3f})")
