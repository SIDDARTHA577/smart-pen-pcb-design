import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

s3, r3 = geom.is_segment_legal(59.500, 6.500, 59.500, 2.400, 'B.Cu', '/VSYS_RAW')
print(f"s3 reason: {r3}")

# Also test In2.Cu:
s_in2, r_in2 = geom.is_segment_legal(59.500, 6.500, 59.500, 2.400, 'In2.Cu', '/VSYS_RAW')
print(f"In2 reason: {r_in2}")

# Also test F.Cu:
s_fcu, r_fcu = geom.is_segment_legal(59.500, 6.500, 59.500, 2.400, 'F.Cu', '/VSYS_RAW')
print(f"F.Cu reason: {r_fcu}")
