import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')

# Update GPIO8_STRAP
for t in list(b.GetTracks()):
    if t.GetNetname() == '/GPIO8_STRAP':
        b.Delete(t)

net_strap = b.FindNet('/GPIO8_STRAP')
t1 = pcbnew.PCB_TRACK(b)
t1.SetStart(pcbnew.VECTOR2I(int(43.630*1e6), int(2.435*1e6)))
t1.SetEnd(pcbnew.VECTOR2I(int(43.630*1e6), int(1.000*1e6)))
t1.SetWidth(int(0.15*1e6))
t1.SetLayer(b.GetLayerID('F.Cu'))
t1.SetNet(net_strap)
b.Add(t1)

t2 = pcbnew.PCB_TRACK(b)
t2.SetStart(pcbnew.VECTOR2I(int(43.630*1e6), int(1.000*1e6)))
t2.SetEnd(pcbnew.VECTOR2I(int(42.975*1e6), int(1.000*1e6)))
t2.SetWidth(int(0.15*1e6))
t2.SetLayer(b.GetLayerID('F.Cu'))
t2.SetNet(net_strap)
b.Add(t2)

geom = BoardGeometry(b)

# Where can SD_SCK via be placed?
# Note: SD_CS via will be at (43.130, 1.750).
# Let's check any position (vx, vy) for SD_SCK where via is legal and segment from U1.12 is legal
for vx in [42.630, 42.500, 42.400, 42.700, 42.800]:
    for vy in [0.4, 0.5, 0.6, 0.7, 0.8, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0]:
        v_ok, rv = geom.is_via_legal(vx, vy, '/SD_SCK')
        if v_ok:
            # check distance to SD_CS via at (43.13, 1.75)
            import math
            d = math.hypot(vx - 43.130, vy - 1.750)
            if d >= 0.55:
                print(f"SD_SCK via legal at ({vx:.3f}, {vy:.3f}), dist to CS={d:.3f}")
