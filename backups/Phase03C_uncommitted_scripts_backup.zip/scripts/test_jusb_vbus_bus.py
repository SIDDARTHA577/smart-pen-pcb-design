import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Testing J_USB.2 and J_USB.11 reach from C10.1:")
# C10.1 is at (73.750, 1.500)
# Track 1: (73.750, 1.500) -> (73.750, 1.800) -> (80.800, 1.800)
# Branch to J_USB.2: (76.000, 1.800) -> (76.000, 3.100)
# Branch to J_USB.11: (80.800, 1.800) -> (80.800, 3.100)
for y_run in [1.50, 1.60, 1.70, 1.80]:
    s1, r1 = geom.is_segment_legal(73.750, 1.500, 80.800, y_run, 'F.Cu', '/USB_VBUS')
    s2, r2 = geom.is_segment_legal(76.000, y_run, 76.000, 3.100, 'F.Cu', '/USB_VBUS')
    s3, r3 = geom.is_segment_legal(80.800, y_run, 80.800, 3.100, 'F.Cu', '/USB_VBUS')
    print(f"y_run={y_run:.2f}: s1={s1}({r1}), s2={s2}({r2}), s3={s3}({r3})")
