import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
fcu = b.GetLayerID('F.Cu')
bcu = b.GetLayerID('B.Cu')
in2 = b.GetLayerID('In2.Cu')
net = b.FindNet('/USB_VBUS')

def add_via(x, y):
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(int(x*1e6), int(y*1e6)))
    v.SetWidth(int(0.500*1e6))
    v.SetDrill(int(0.300*1e6))
    v.SetNet(net)
    b.Add(v)

def add_track(x1, y1, x2, y2, layer_id, width=0.20):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(x1*1e6), int(y1*1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2*1e6), int(y2*1e6)))
    t.SetLayer(layer_id)
    t.SetWidth(int(width*1e6))
    t.SetNet(net)
    b.Add(t)

# 1. Q2.1, R26.1, D4.2 on F.Cu:
add_track(61.700, 5.350, 60.500, 4.875, fcu)
add_track(60.500, 4.875, 59.000, 5.600, fcu)

# 2. Q2.1 to U2.4 on B.Cu:
add_via(61.700, 5.350)
add_track(61.700, 5.350, 67.450, 5.350, bcu)
add_via(67.450, 5.350)
add_track(67.450, 5.350, 67.950, 5.370, fcu) # to U2.4

# 3. U2.4 to C11.1 on F.Cu:
add_track(67.450, 5.370, 67.450, 7.750, fcu)
add_track(67.450, 7.750, 67.250, 7.750, fcu) # to C11.1

# 4. Interconnect from U2.4 via (67.450, 5.350) to (73.750, 2.200):
add_track(67.450, 5.350, 71.775, 5.350, in2)
add_track(71.775, 5.350, 71.775, 4.400, in2)
add_via(71.775, 4.400)
add_track(71.775, 4.400, 71.775, 2.200, bcu)
add_track(71.775, 2.200, 73.750, 2.200, bcu)
add_via(73.750, 2.200)

# 5. C10.1 to J_USB.2 on F.Cu:
add_track(73.750, 1.500, 73.750, 2.200, fcu)
add_track(73.750, 2.200, 76.000, 2.200, fcu)
add_track(76.000, 2.200, 76.000, 3.100, fcu) # to J_USB.2

# 6. J_USB.2 to J_USB.11 bridge:
add_track(76.000, 3.100, 76.000, 4.000, fcu)
add_via(76.000, 4.000)
add_track(76.000, 4.000, 80.800, 4.000, bcu)
add_via(80.800, 4.000)
add_track(80.800, 4.000, 80.800, 3.100, fcu) # to J_USB.11

candidate_pcb = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb'
b.Save(candidate_pcb)
print("Saved complete USB_VBUS route to candidate PCB!")
