import json
from collections import defaultdict
from pathlib import Path

drc_path = Path("reports/RevG/Phase03C/raw/baseline/Main_SmartPen_drc.json")
with open(drc_path, "r", encoding="utf-8") as f:
    drc = json.load(f)

violations = drc.get("violations", [])
unconnected = drc.get("unconnected_items", [])

print(f"Total Violations: {len(violations)}")
print(f"Total Unconnected Items: {len(unconnected)}")

by_type = defaultdict(list)
for v in violations:
    by_type[v.get("type")].append(v)

for vtype, items in sorted(by_type.items()):
    print(f"\n--- Violation Type: {vtype} ({len(items)} items) ---")
    for i, item in enumerate(items[:5]):
        desc = item.get("description", "")
        items_involved = [it.get("item", "") for it in item.get("items", [])]
        print(f"  [{i+1}] {desc} | Items: {items_involved}")
    if len(items) > 5:
        print(f"  ... and {len(items)-5} more.")

print("\n--- Unconnected Items (sample of {len(unconnected)}) ---")
unconn_by_net = defaultdict(list)
for u in unconnected:
    net = "unknown"
    for item in u.get("items", []):
        if "net" in item:
            net = item["net"]
            break
        desc = item.get("description", "")
        if "Net" in desc:
            net = desc
    unconn_by_net[net].append(u)

for net, items in sorted(unconn_by_net.items(), key=lambda x: len(x[1]), reverse=True):
    print(f"Net '{net}': {len(items)} unconnected items")

