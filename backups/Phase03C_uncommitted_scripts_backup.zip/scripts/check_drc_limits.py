import pcbnew
b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
ds = b.GetDesignSettings()
print("Min track width:", ds.m_TrackMinWidth/1e6)
print("Min clearance:", ds.GetSmallestClearanceValue()/1e6)
print("Min via drill:", ds.m_ViasMinDrill/1e6)
print("Min via dia:", ds.m_ViasMinSize/1e6)
