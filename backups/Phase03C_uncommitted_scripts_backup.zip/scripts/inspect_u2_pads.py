import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
for f in b.GetFootprints():
    if f.GetReference() in ['U2', 'C12']:
        for p in f.Pads():
            pos = p.GetPosition()
            print(f"{f.GetReference()}.{p.GetName()} ({p.GetNetname()}) at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f}) size ({p.GetSize().x/1e6:.3f}, {p.GetSize().y/1e6:.3f})")
