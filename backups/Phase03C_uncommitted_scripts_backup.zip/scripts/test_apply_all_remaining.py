import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
fcu = b.GetLayerID('F.Cu')
bcu = b.GetLayerID('B.Cu')
in2 = b.GetLayerID('In2.Cu')

def add_via(x, y, net_name, width=0.500, drill=0.300):
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(int(x*1e6), int(y*1e6)))
    v.SetWidth(int(width*1e6))
    v.SetDrill(int(drill*1e6))
    v.SetNet(b.FindNet(net_name))
    b.Add(v)

def add_track(x1, y1, x2, y2, layer_id, net_name, width=0.20):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(x1*1e6), int(y1*1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2*1e6), int(y2*1e6)))
    t.SetLayer(layer_id)
    t.SetWidth(int(width*1e6))
    t.SetNet(b.FindNet(net_name))
    b.Add(t)

# ========================================================
# 1. /VSYS_RAW
# ========================================================
# SW3.1 (60.963, 6.824) to via (60.500, 6.500)
add_track(60.963, 6.824, 60.500, 6.500, fcu, '/VSYS_RAW')
add_via(60.500, 6.500, '/VSYS_RAW')
add_track(60.500, 6.500, 59.500, 6.500, bcu, '/VSYS_RAW')
add_track(59.500, 6.500, 59.500, 2.400, bcu, '/VSYS_RAW')
add_via(59.500, 2.400, '/VSYS_RAW')
add_track(59.500, 2.400, 59.000, 2.400, fcu, '/VSYS_RAW') # D4.1
# Tap to Q2.2 (61.700, 3.450):
add_track(59.500, 3.450, 61.700, 3.450, bcu, '/VSYS_RAW')
add_via(61.700, 3.450, '/VSYS_RAW')

# ========================================================
# 2. /VBAT
# ========================================================
# J_BAT.1 (62.300, 1.720) to via (62.300, 1.000)
add_track(62.300, 1.720, 62.300, 1.000, fcu, '/VBAT')
add_via(62.300, 1.000, '/VBAT')
# C12.1 (67.400, 1.400) & U2.3 (67.950, 2.770) to via (67.400, 1.000)
add_track(67.950, 2.770, 67.400, 2.770, fcu, '/VBAT')
add_track(67.400, 2.770, 67.400, 1.400, fcu, '/VBAT')
add_track(67.400, 1.400, 67.400, 1.000, fcu, '/VBAT')
add_via(67.400, 1.000, '/VBAT')
# B.Cu highway:
add_track(62.300, 1.000, 67.400, 1.000, bcu, '/VBAT')
# Tap to Q2.3 (63.900, 4.400):
add_track(63.900, 1.000, 63.900, 4.400, bcu, '/VBAT')
add_via(63.900, 4.400, '/VBAT')

# ========================================================
# 3. /USB_VBUS
# ========================================================
# Q2.1, R26.1, D4.2:
add_track(61.700, 5.350, 60.500, 4.875, fcu, '/USB_VBUS')
add_track(60.500, 4.875, 59.000, 5.600, fcu, '/USB_VBUS')
# Q2.1 to U2.4 on B.Cu:
add_via(61.700, 5.350, '/USB_VBUS')
add_track(61.700, 5.350, 67.450, 5.350, bcu, '/USB_VBUS')
add_via(67.450, 5.350, '/USB_VBUS')
# U2.4 to C11.1 on F.Cu:
add_track(67.950, 5.370, 67.450, 5.370, fcu, '/USB_VBUS')
add_track(67.450, 5.370, 67.450, 7.750, fcu, '/USB_VBUS')
add_track(67.450, 7.750, 67.250, 7.750, fcu, '/USB_VBUS')
# C10.1 to J_USB.2 on F.Cu:
add_track(73.750, 1.500, 73.750, 2.200, fcu, '/USB_VBUS')
add_track(73.750, 2.200, 76.000, 2.200, fcu, '/USB_VBUS')
add_track(76.000, 2.200, 76.000, 3.100, fcu, '/USB_VBUS')
# J_USB.2 to J_USB.11 bridge:
add_track(76.000, 3.100, 76.000, 4.000, fcu, '/USB_VBUS')
add_via(76.000, 4.000, '/USB_VBUS')
add_track(76.000, 4.000, 80.800, 4.000, bcu, '/USB_VBUS')
add_via(80.800, 4.000, '/USB_VBUS')
add_track(80.800, 4.000, 80.800, 3.100, fcu, '/USB_VBUS')

# ========================================================
# 4. MicroSD SPI Bus
# ========================================================
# SD_CS (U1.13 at 43.13, 2.435 -> J_SD.6 at 59.65, 4.20)
add_track(43.130, 2.435, 43.130, 0.850, fcu, '/SD_CS')
add_via(43.130, 0.850, '/SD_CS')
add_track(43.130, 0.850, 59.650, 0.850, bcu, '/SD_CS')
add_via(59.650, 0.850, '/SD_CS')
add_track(59.650, 0.850, 59.650, 4.200, fcu, '/SD_CS')
# R18.2 to SD_CS on F.Cu:
add_track(55.475, 2.350, 55.475, 0.850, fcu, '/SD_CS')
add_via(55.475, 0.850, '/SD_CS')

# SD_MOSI (U1.9 at 41.13, 2.435 -> J_SD.4 at 58.65, 4.20)
add_track(41.130, 2.435, 41.130, 0.550, fcu, '/SD_MOSI')
add_via(41.130, 0.550, '/SD_MOSI')
add_track(41.130, 0.550, 58.650, 0.550, bcu, '/SD_MOSI')
add_via(58.650, 0.550, '/SD_MOSI')
add_track(58.650, 0.550, 58.650, 4.200, fcu, '/SD_MOSI')

# SD_MISO (U1.10 at 41.63, 2.435 -> J_SD.5 at 59.15, 4.20)
add_track(41.630, 2.435, 41.630, 1.150, fcu, '/SD_MISO')
add_via(41.630, 1.150, '/SD_MISO')
add_track(41.630, 1.150, 59.150, 1.150, in2, '/SD_MISO')
add_via(59.150, 1.150, '/SD_MISO')
add_track(59.150, 1.150, 59.150, 4.200, fcu, '/SD_MISO')

# SD_SCK (U1.12 at 42.63, 2.435 -> J_SD.3 at 58.15, 4.20)
add_track(42.630, 2.435, 42.630, 1.750, fcu, '/SD_SCK')
add_via(42.630, 1.750, '/SD_SCK')
add_track(42.630, 1.750, 58.150, 1.750, in2, '/SD_SCK')
add_via(58.150, 1.750, '/SD_SCK')
add_track(58.150, 1.750, 58.150, 4.200, fcu, '/SD_SCK')

test_pcb = 'output/RevG/variants/FourLayer_Candidate/SmartPen_test_all.kicad_pcb'
b.Save(test_pcb)
print(f"Saved comprehensive test to {test_pcb}")
