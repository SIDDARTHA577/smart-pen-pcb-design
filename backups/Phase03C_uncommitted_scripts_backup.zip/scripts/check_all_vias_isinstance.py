import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")
for t in b.GetTracks():
    if isinstance(t, pcbnew.PCB_VIA):
        print(f"Via Net: {t.GetNetname()} Pos: ({t.GetPosition().x/1e6:.3f}, {t.GetPosition().y/1e6:.3f})")
