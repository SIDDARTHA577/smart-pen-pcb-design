import pcbnew
b = pcbnew.LoadBoard('output/RevG/SmartPen.kicad_pcb')
r27 = b.FindFootprintByReference('R27')
print('Baseline R27 pos:', r27.GetPosition().x/1e6, r27.GetPosition().y/1e6, 'rot:', r27.GetOrientation().AsDegrees())
for p in r27.Pads():
    print(f"Pad {p.GetNumber()} ({p.GetNetname()}): ({p.GetPosition().x/1e6:.3f}, {p.GetPosition().y/1e6:.3f})")
