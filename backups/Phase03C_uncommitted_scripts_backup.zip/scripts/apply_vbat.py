import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
fcu = b.GetLayerID('F.Cu')
bcu = b.GetLayerID('B.Cu')
in2 = b.GetLayerID('In2.Cu')
net = b.FindNet('/VBAT')

def add_via(x, y):
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(int(x*1e6), int(y*1e6)))
    v.SetWidth(int(0.500*1e6))
    v.SetDrill(int(0.300*1e6))
    v.SetNet(net)
    b.Add(v)

def add_track(x1, y1, x2, y2, layer_id, width=0.20):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(x1*1e6), int(y1*1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2*1e6), int(y2*1e6)))
    t.SetLayer(layer_id)
    t.SetWidth(int(width*1e6))
    t.SetNet(net)
    b.Add(t)

# 1. U2.3 to C12.1 on F.Cu:
add_track(67.950, 2.770, 67.950, 2.000, fcu)
add_track(67.950, 2.000, 67.400, 2.000, fcu)
add_track(67.400, 2.000, 67.400, 1.400, fcu)

# 2. C12.1 to via (67.400, 1.000):
add_track(67.400, 1.400, 67.400, 1.000, fcu)
add_via(67.400, 1.000)

# 3. Highway on B.Cu:
add_track(67.400, 1.000, 62.300, 1.000, bcu)

# 4. Via at (62.300, 1.000) to J_BAT.1:
add_via(62.300, 1.000)
add_track(62.300, 1.000, 62.300, 1.720, fcu)

# 5. Tap to Q2.3 via In2.Cu:
add_track(62.300, 1.000, 63.900, 3.500, in2)
add_via(63.900, 3.500)
add_track(63.900, 3.500, 63.900, 4.400, fcu) # Q2.3

candidate_pcb = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb'
b.Save(candidate_pcb)
print("Saved VBAT route to candidate PCB!")
