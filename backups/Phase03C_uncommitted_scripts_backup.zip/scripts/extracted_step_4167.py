& 'C:\Users\goran\AppData\Local\Programs\KiCad\10.0\bin\python.exe' -c "
import pcbnew, shutil

shutil.copy('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb', 'scratch_test_vip.kicad_pcb')
shutil.copy('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pro', 'scratch_test_vip.kicad_pro')
shutil.copy('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_prl', 'scratch_test_vip.kicad_prl')

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
net_dm_core = b.FindNet('/USB_DM_CORE')

# Move USB_DM_PORT to X=73.2 on In2.Cu
for t in list(b.GetTracks()):
    if t.GetNetname() == '/USB_DM_PORT':
        if t.GetClass() == 'PCB_VIA' and abs(t.GetPosition().x/1e6 - 72.5) < 0.1 and abs(t.GetPosition().y/1e6 - 8.5) < 0.1:
            t.SetPosition(pcbnew.VECTOR2I(int(73.2*1e6), int(8.5*1e6)))
        elif t.GetClass() == 'PCB_TRACK' and b.GetLayerName(t.GetLayer()) == 'In2.Cu':
            s = t.GetStart()
            e = t.GetEnd()
            if abs(s.x/1e6 - 72.5) < 0.1 and abs(e.x/1e6 - 72.5) < 0.1:
                t.SetStart(pcbnew.VECTOR2I(int(73.2*1e6), s.y))
                t.SetEnd(pcbnew.VECTOR2I(int(73.2*1e6), e.y))
            elif abs(e.x/1e6 - 72.5) < 0.1:
                t.SetEnd(pcbnew.VECTOR2I(int(73.2*1e6), e.y))
        elif t.GetClass() == 'PCB_TRACK' and b.GetLayerName(t.GetLayer()) == 'F.Cu':
            s = t.GetStart()
            e = t.GetEnd()
            if abs(s.x/1e6 - 72.5) < 0.1 and abs(s.y/1e6 - 8.5) < 0.1:
                t.SetStart(pcbnew.VECTOR2I(int(73.2*1e6), int(8.5*1e6)))
            elif abs(e.x/1e6 - 72.5) < 0.1 and abs(e.y/1e6 - 8.5) < 0.1:
                t.SetEnd(pcbnew.VECTOR2I(int(73.2*1e6), int(8.5*1e6)))

def add_trk(layer_name, sx, sy, ex, ey):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(sx*1e6), int(sy*1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(ex*1e6), int(ey*1e6)))
    t.SetWidth(int(0.15*1e6))
    t.SetLayer(b.GetLayerID(layer_name))
    t.SetNet(net_dm_core)
    b.Add(t)

def add_via(x, y):
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(int(x*1e6), int(y*1e6)))
    v.SetWidth(int(0.50*1e6))
    v.SetDrill(int(0.30*1e6))
    v.SetTopLayer(b.GetLayerID('F.Cu'))
    v.SetBottomLayer(b.GetLayerID('B.Cu'))
    v.SetNet(net_dm_core)
    b.Add(v)

# Route USB_DM_CORE:
add_trk('F.Cu', 44.63, 7.235, 44.63, 8.40)
add_trk('F.Cu', 44.63, 8.40, 52.00, 8.40)
add_trk('F.Cu', 52.00, 8.40, 52.00, 7.00)
add_via(52.00, 7.00)

add_trk('B.Cu', 52.00, 7.00, 52.00, 6.00)
add_trk('B.Cu', 52.00, 6.00, 69.20, 6.00)
add_via(69.20, 6.00)

# In2.Cu to (72.50, 6.00) -> (72.50, 7.025)
add_trk('In2.Cu', 69.20, 6.00, 72.50, 6.00)
add_trk('In2.Cu', 72.50, 6.00, 72.50, 7.025)
add_via(72.50, 7.025)

b.Save('scratch_test_vip.kicad_pcb')
print('Successfully saved scratch_test_vip.kicad_pcb')
"