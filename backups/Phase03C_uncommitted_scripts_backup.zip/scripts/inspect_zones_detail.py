with open('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb') as f:
    text = f.read()

import re
zones = re.findall(r'\(zone\s+.*?\n  \)', text, re.DOTALL)
print('Number of zones found:', len(zones))
for i, z in enumerate(zones):
    layer_m = re.search(r'\(layers\s+([^\)]+)\)', z)
    net_m = re.search(r'\(net\s+(\d+)\)\s+\(net_name\s+"([^"]+)"\)', z)
    uuid_m = re.search(r'\(uuid\s+"([^"]+)"\)', z)
    l_str = layer_m.group(1) if layer_m else "?"
    n_str = net_m.group(2) if net_m else "?"
    u_str = uuid_m.group(1) if uuid_m else "?"
    print(f'Zone {i}: layers={l_str}, net={n_str}, uuid={u_str}')

