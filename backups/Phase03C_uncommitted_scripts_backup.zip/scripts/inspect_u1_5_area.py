import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print("PADS near U1.5 (X: 36..41, Y: 3.5..5.5):")
for p in b.GetPads():
    pos = p.GetPosition()
    px, py = pos.x / 1e6, pos.y / 1e6
    if 36.0 <= px <= 41.0 and 3.5 <= py <= 5.5:
        fp = p.GetParentFootprint()
        ref = fp.GetReference() if fp else '?'
        print(f"  {ref}.{p.GetNumber()} [{p.GetNetname()}] at ({px:.3f}, {py:.3f})")

sys.exit(0)
