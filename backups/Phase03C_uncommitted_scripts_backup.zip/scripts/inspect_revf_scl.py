import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

b = pcbnew.LoadBoard('output/RevF_Working/SmartPen.kicad_pcb')
net = b.FindNet('/I2C_SCL')
print(f"=== NET /I2C_SCL in Rev F ===")
for t in b.TracksInNet(net.GetNetCode()):
    if isinstance(t, pcbnew.PCB_VIA):
        pos = t.GetPosition()
        print(f"  VIA at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})")
    else:
        s, e = t.GetStart(), t.GetEnd()
        print(f"  TRACK {t.GetLayerName()} ({s.x/1e6:.3f}, {s.y/1e6:.3f}) -> ({e.x/1e6:.3f}, {e.y/1e6:.3f})")

sys.exit(0)
