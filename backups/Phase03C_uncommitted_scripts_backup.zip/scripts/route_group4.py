import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

board_path = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb'
b = pcbnew.LoadBoard(board_path)

dm_net = b.FindNet('/USB_DM_CORE')
dp_net = b.FindNet('/USB_DP_CORE')
fcu = b.GetLayerID('F.Cu')
in2 = b.GetLayerID('In2.Cu')

def add_track(b, net, layer, x1, y1, x2, y2, w=0.18):
    t = pcbnew.PCB_TRACK(b)
    t.SetNet(net)
    t.SetLayer(layer)
    t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    t.SetWidth(int(w * 1e6))
    b.Add(t)

def add_via(b, net, x, y, dia=0.50, drill=0.30):
    v = pcbnew.PCB_VIA(b)
    v.SetNet(net)
    v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    v.SetWidth(int(dia * 1e6))
    v.SetDrill(int(drill * 1e6))
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    b.Add(v)

# 1. DP Routing
# F.Cu: U1.26 (44.130, 7.235) -> (44.130, 8.750) -> (54.000, 8.750) -> (54.000, 7.200)
add_track(b, dp_net, fcu, 44.130, 7.235, 44.130, 8.750)
add_track(b, dp_net, fcu, 44.130, 8.750, 54.000, 8.750)
add_track(b, dp_net, fcu, 54.000, 8.750, 54.000, 7.200)
# West Via DP
add_via(b, dp_net, 54.000, 7.200)
# In2.Cu: (54.000, 7.200) -> (70.500, 7.200) -> (70.500, 7.800)
add_track(b, dp_net, in2, 54.000, 7.200, 70.500, 7.200)
add_track(b, dp_net, in2, 70.500, 7.200, 70.500, 7.800)
# East Via DP
add_via(b, dp_net, 70.500, 7.800)
# F.Cu: (70.500, 7.800) -> (71.600, 7.025)
add_track(b, dp_net, fcu, 70.500, 7.800, 71.600, 7.025)

# 2. DM Routing
# F.Cu: U1.25 (44.630, 7.235) -> (44.630, 8.350) -> (52.000, 8.350) -> (52.000, 7.000)
add_track(b, dm_net, fcu, 44.630, 7.235, 44.630, 8.350)
add_track(b, dm_net, fcu, 44.630, 8.350, 52.000, 8.350)
add_track(b, dm_net, fcu, 52.000, 8.350, 52.000, 7.000)
# West Via DM
add_via(b, dm_net, 52.000, 7.000)
# In2.Cu: (52.000, 7.000) -> (52.000, 5.800) -> (73.000, 5.800) -> (73.000, 7.000)
add_track(b, dm_net, in2, 52.000, 7.000, 52.000, 5.800)
add_track(b, dm_net, in2, 52.000, 5.800, 73.000, 5.800)
add_track(b, dm_net, in2, 73.000, 5.800, 73.000, 7.000)
# East Via DM
add_via(b, dm_net, 73.000, 7.000)
# F.Cu: (73.000, 7.000) -> (72.500, 7.025)
add_track(b, dm_net, fcu, 73.000, 7.000, 72.500, 7.025)

b.Save(board_path)
print("Group 4 routes applied successfully!")
sys.exit(0)
