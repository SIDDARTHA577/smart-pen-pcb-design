import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

# Test Pad 4 route:
# (58.650, 4.200) -> (58.650, 3.250) -> (58.150, 3.250) -> (58.150, 1.200)
# But wait, what if Pad 3 (/SD_SCK) is at 58.150? If Pad 3 goes north, is (58.150, 3.250) clear?
# Pad 3 ends at Y=3.600. So at Y=3.250, (58.150, 3.250) is 0.350 mm south of Pad 3!
s1, r1 = geom.is_segment_legal(58.650, 4.200, 58.650, 3.250, 'F.Cu', '/SD_MOSI')
s2, r2 = geom.is_segment_legal(58.650, 3.250, 58.150, 3.250, 'F.Cu', '/SD_MOSI')
s3, r3 = geom.is_segment_legal(58.150, 3.250, 58.150, 1.200, 'F.Cu', '/SD_MOSI')
v, rv = geom.is_via_legal(58.150, 1.200, '/SD_MOSI')

print('Pad 4 MOSI test:')
print('  s1:', s1, r1)
print('  s2:', s2, r2)
print('  s3:', s3, r3)
print('  via:', v, rv)
