import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

s_in2, rs_in2 = geom.is_segment_legal(30.753, 4.400, 30.753, 7.200, 'In2.Cu', '/VBAT_SW')
print(f"s2 on In2.Cu: {s_in2} ({rs_in2})")

sys.exit(0)
