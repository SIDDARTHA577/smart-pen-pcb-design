import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

# Pad 3 is at (58.150, 4.200)
# Let's check segments going north from (58.150, 4.200)
for y in [4.8, 5.0, 5.2, 5.5, 5.8, 6.0]:
    s, r = geom.is_segment_legal(58.150, 4.200, 58.150, y, 'F.Cu', '/SD_SCK')
    print(f"Segment to (58.15, {y}): {s} ({r})")

# Let's check where a via can be placed around (57.0-58.5, 5.0-6.5)
for vx in [57.2, 57.5, 57.8, 58.15]:
    for vy in [5.2, 5.5, 5.8, 6.0, 6.2]:
        v, rv = geom.is_via_legal(vx, vy, '/SD_SCK')
        if v:
            print(f"Via legal at ({vx}, {vy})")
