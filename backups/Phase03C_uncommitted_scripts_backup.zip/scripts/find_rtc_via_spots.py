import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
# Delete current 3V3_RTC via and F.Cu track to U1.11
for t in list(b.GetTracks()):
    if t.GetNetname() == '/3V3_RTC':
        if t.GetClass() == 'PCB_VIA' and abs(t.GetPosition().x/1e6 - 42.13) < 0.1:
            b.Delete(t)
        elif t.GetClass() == 'PCB_TRACK' and abs(t.GetStart().x/1e6 - 42.13) < 0.1:
            b.Delete(t)

geom = BoardGeometry(b)
print("Searching legal via positions for 3V3_RTC connected to U1.11:")
for vx in [41.5, 41.8, 42.0, 42.13, 42.2]:
    for vy in [0.5, 0.7, 0.9, 1.1, 1.3, 1.5, 1.7, 1.8, 1.9]:
        v_ok, rv = geom.is_via_legal(vx, vy, '/3V3_RTC')
        if v_ok:
            # check segment from U1.11 to via
            s_ok, rs = geom.is_segment_legal(42.130, 2.435, vx, vy, 'F.Cu', '/3V3_RTC')
            if s_ok:
                print(f"  3V3_RTC via OK at ({vx}, {vy})")
