import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

for t in board.GetTracks():
    if t.GetNetname() in ['/USB_DP_PORT', '/USB_DM_PORT']:
        if isinstance(t, pcbnew.PCB_VIA):
            pos = t.GetPosition()
            print(f'VIA {t.GetNetname()} at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})')
        else:
            print(f'TRACK {t.GetNetname()} [{board.GetLayerName(t.GetLayer())}]: ({t.GetStart().x/1e6:.3f}, {t.GetStart().y/1e6:.3f}) -> ({t.GetEnd().x/1e6:.3f}, {t.GetEnd().y/1e6:.3f})')

