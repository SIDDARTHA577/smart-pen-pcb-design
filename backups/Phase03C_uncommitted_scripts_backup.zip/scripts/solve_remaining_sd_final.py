import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
import shutil

# Make a fresh test copy from scratch_test_vip.kicad_pcb
shutil.copy('scratch_test_vip.kicad_pcb', 'scratch_test_final_candidate.kicad_pcb')
shutil.copy('scratch_test_vip.kicad_pro', 'scratch_test_final_candidate.kicad_pro')

b = pcbnew.LoadBoard('scratch_test_final_candidate.kicad_pcb')

# 1. Delete the freestanding GND stitching via at (55.000, 1.200)
for t in list(b.GetTracks()):
    if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 55.00 and round(t.GetPosition().y/1e6, 2) == 1.20:
        b.Delete(t)

# 2. Delete existing via at (42.000, 0.500) for 3V3 (which blocked SD_SCK via)
for t in list(b.GetTracks()):
    if t.GetNetname() == '/3V3':
        if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 42.00 and round(t.GetPosition().y/1e6, 2) == 0.50:
            b.Delete(t)
        elif t.GetClass() != 'PCB_VIA':
            s, e = t.GetStart(), t.GetEnd()
            if (round(s.x/1e6, 2) == 42.00 and round(s.y/1e6, 2) == 0.50) or (round(e.x/1e6, 2) == 42.00 and round(e.y/1e6, 2) == 0.50):
                b.Delete(t)

# 3. Move R27 to (44.000, 1.000)
r27 = b.FindFootprintByReference('R27')
r27.SetPosition(pcbnew.VECTOR2I(int(44.000*1e6), int(1.000*1e6)))

# Re-route GPIO8_STRAP from U1.14 (43.630, 2.435) to R27.2 (44.475, 1.000)
for t in list(b.GetTracks()):
    if t.GetNetname() == '/GPIO8_STRAP':
        b.Delete(t)

net_strap = b.FindNet('/GPIO8_STRAP')
net_3v3 = b.FindNet('/3V3')
net_sck = b.FindNet('/SD_SCK')
net_mosi = b.FindNet('/SD_MOSI')
net_miso = b.FindNet('/SD_MISO')
net_cs = b.FindNet('/SD_CS')
net_vsys = b.FindNet('/VSYS_RAW')

def add_trk(layer, sx, sy, ex, ey, net, w=0.15):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(sx*1e6), int(sy*1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(ex*1e6), int(ey*1e6)))
    t.SetWidth(int(w*1e6))
    t.SetLayer(b.GetLayerID(layer))
    t.SetNet(net)
    b.Add(t)
    return t

def add_via(x, y, net, dia=0.50, drill=0.30):
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(int(x*1e6), int(y*1e6)))
    v.SetWidth(int(dia*1e6))
    v.SetDrill(int(drill*1e6))
    v.SetTopLayer(b.GetLayerID('F.Cu'))
    v.SetBottomLayer(b.GetLayerID('B.Cu'))
    v.SetNet(net)
    b.Add(v)
    return v

# Add 3V3 connection for R27.1 at (43.525, 1.000)
# Via at (43.525, 0.450)
add_via(43.525, 0.450, net_3v3)
add_trk('F.Cu', 43.525, 1.000, 43.525, 0.450, net_3v3)

# Add GPIO8_STRAP
add_trk('F.Cu', 43.630, 2.435, 43.630, 1.350, net_strap)
add_trk('F.Cu', 43.630, 1.350, 44.475, 1.350, net_strap)
add_trk('F.Cu', 44.475, 1.350, 44.475, 1.000, net_strap)

# Move VSYS_RAW via at (59.50, 2.40) to (59.00, 1.20)
for t in list(b.GetTracks()):
    if t.GetNetname() == '/VSYS_RAW':
        if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 59.50 and round(t.GetPosition().y/1e6, 2) == 2.40:
            t.SetPosition(pcbnew.VECTOR2I(int(59.000*1e6), int(1.200*1e6)))
        elif t.GetClass() != 'PCB_VIA':
            s, e = t.GetStart(), t.GetEnd()
            if round(s.x/1e6, 2) == 59.50 and round(s.y/1e6, 2) == 2.40:
                t.SetStart(pcbnew.VECTOR2I(int(59.000*1e6), int(1.200*1e6)))
            if round(e.x/1e6, 2) == 59.50 and round(e.y/1e6, 2) == 2.40:
                t.SetEnd(pcbnew.VECTOR2I(int(59.000*1e6), int(1.200*1e6)))

# Connect D4.1 (59.000, 2.400) to VSYS_RAW via at (59.000, 1.200) on F.Cu
add_trk('F.Cu', 59.000, 2.400, 59.000, 1.200, net_vsys)

# Clean out any old partial SD tracks
for net in [net_sck, net_mosi, net_miso, net_cs]:
    for t in list(b.GetTracks()):
        if t.GetNet() == net:
            b.Delete(t)

# --- 1. ROUTE SD_CS ---
# End A: U1.13 at (43.130, 2.435)
add_trk('F.Cu', 43.130, 2.435, 43.130, 1.750, net_cs)
add_via(43.130, 1.750, net_cs)
add_trk('In2.Cu', 43.130, 1.750, 43.130, 1.200, net_cs)
# Horizontal on In2.Cu to R18.2 at (56.975, 1.200)
add_trk('In2.Cu', 43.130, 1.200, 56.975, 1.200, net_cs)
# Via up to F.Cu at R18.2: R18.2 is at (56.975, 2.000)
add_via(56.975, 1.200, net_cs)
add_trk('F.Cu', 56.975, 1.200, 56.975, 2.000, net_cs)
# Continue on In2.Cu from (56.975, 1.200) to (59.300, 1.200) -> (59.300, 0.850)
add_trk('In2.Cu', 56.975, 1.200, 59.300, 1.200, net_cs)
add_trk('In2.Cu', 59.300, 1.200, 59.300, 0.850, net_cs)
add_via(59.300, 0.850, net_cs)
# F.Cu: (59.300, 0.850) -> (59.800, 0.850) -> (59.800, 3.600) -> (59.650, 4.200) (J_SD.6)
add_trk('F.Cu', 59.300, 0.850, 59.800, 0.850, net_cs)
add_trk('F.Cu', 59.800, 0.850, 59.800, 3.600, net_cs)
add_trk('F.Cu', 59.800, 3.600, 59.650, 4.200, net_cs)

# --- 2. ROUTE SD_SCK ---
# End A: U1.12 at (42.630, 2.435)
add_trk('F.Cu', 42.630, 2.435, 42.630, 0.500, net_sck)
add_via(42.630, 0.500, net_sck)
add_trk('In2.Cu', 42.630, 0.500, 42.630, 1.450, net_sck)
# Horizontal on In2.Cu to (57.500, 1.450)
add_trk('In2.Cu', 42.630, 1.450, 57.500, 1.450, net_sck)
# Via at (57.500, 1.450) to B.Cu
add_via(57.500, 1.450, net_sck)
# B.Cu from (57.500, 1.450) to (57.500, 5.500)
add_trk('B.Cu', 57.500, 1.450, 57.500, 5.500, net_sck)
# Via at (57.500, 5.500) to F.Cu
add_via(57.500, 5.500, net_sck)
# F.Cu to J_SD.3 at (58.150, 4.200)
add_trk('F.Cu', 57.500, 5.500, 58.150, 5.500, net_sck)
add_trk('F.Cu', 58.150, 5.500, 58.150, 4.200, net_sck)

# --- 3. ROUTE SD_MOSI ---
# End A: U1.9 at (41.130, 2.435)
add_trk('F.Cu', 41.130, 2.435, 39.680, 2.435, net_mosi)
add_via(39.680, 2.435, net_mosi)
add_trk('In2.Cu', 39.680, 2.435, 39.680, 1.700, net_mosi)
# Horizontal on In2.Cu to (57.400, 1.700) -> (57.400, 2.800)
add_trk('In2.Cu', 39.680, 1.700, 57.400, 1.700, net_mosi)
add_trk('In2.Cu', 57.400, 1.700, 57.400, 2.800, net_mosi)
add_via(57.400, 2.800, net_mosi)
# F.Cu: (57.400, 2.800) -> (57.400, 3.250) -> (58.650, 3.250) -> (58.650, 4.200) (J_SD.4)
add_trk('F.Cu', 57.400, 2.800, 57.400, 3.250, net_mosi)
add_trk('F.Cu', 57.400, 3.250, 58.650, 3.250, net_mosi)
add_trk('F.Cu', 58.650, 3.250, 58.650, 4.200, net_mosi)

# --- 4. ROUTE SD_MISO ---
# End A: U1.10 at (41.630, 2.435)
add_trk('F.Cu', 41.630, 2.435, 41.400, 1.600, net_miso)
add_via(41.400, 1.600, net_miso)
add_trk('In2.Cu', 41.400, 1.600, 41.400, 1.950, net_miso)
# Horizontal on In2.Cu to (59.650, 1.950) -> (59.650, 1.300)
add_trk('In2.Cu', 41.400, 1.950, 59.650, 1.950, net_miso)
add_trk('In2.Cu', 59.650, 1.950, 59.650, 1.300, net_miso)
add_via(59.650, 1.300, net_miso)
# F.Cu: (59.650, 1.300) -> (59.800, 1.300) -> (59.800, 3.250) -> (59.150, 3.250) -> (59.150, 4.200) (J_SD.5)
add_trk('F.Cu', 59.650, 1.300, 59.800, 1.300, net_miso)
add_trk('F.Cu', 59.800, 1.300, 59.800, 3.250, net_miso)
add_trk('F.Cu', 59.800, 3.250, 59.150, 3.250, net_miso)
add_trk('F.Cu', 59.150, 3.250, 59.150, 4.200, net_miso)

# Refill all zones
filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())

b.Save('scratch_test_final_candidate.kicad_pcb')
print("Successfully generated scratch_test_final_candidate.kicad_pcb!")
