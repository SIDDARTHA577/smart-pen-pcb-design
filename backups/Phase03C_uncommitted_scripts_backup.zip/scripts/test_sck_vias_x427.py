import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
# With R27 at (43.5, 1.0)
r27 = b.FindFootprintByReference('R27')
r27.SetPosition(pcbnew.VECTOR2I(int(43.5*1e6), int(1.0*1e6)))

geom = BoardGeometry(b)

for vx in [42.70, 42.75, 42.80]:
    for vy in [0.50, 0.60, 1.40, 1.50, 1.60]:
        v_ok, rv = geom.is_via_legal(vx, vy, '/SD_SCK')
        print(f"Via ({vx:.2f}, {vy:.2f}): {v_ok}, {rv}")
