import pcbnew, shutil, subprocess, json

for step_name in ['only_d4', 'd4_and_miso_ends']:
    shutil.copyfile('scratch_test_mosi_flawless.kicad_pcb', 'scratch_test_step.kicad_pcb')
    shutil.copyfile('scratch_test_mosi_flawless.kicad_pro', 'scratch_test_step.kicad_pro')
    b = pcbnew.LoadBoard('scratch_test_step.kicad_pcb')
    fcu = b.GetLayerID('F.Cu')
    in1 = b.GetLayerID('In1.Cu')

    d4 = b.FindFootprintByReference('D4')
    d4.SetPosition(pcbnew.VECTOR2I_MM(59.000, 4.050))
    p1 = d4.FindPadByNumber('1')
    p2 = d4.FindPadByNumber('2')
    p1.SetSize(pcbnew.VECTOR2I_MM(0.800, 0.900))
    p2.SetSize(pcbnew.VECTOR2I_MM(0.800, 0.900))
    for t in b.GetTracks():
        if isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/VSYS_RAW':
            pos = t.GetPosition()
            if abs(pcbnew.ToMM(pos.x) - 59.0) < 0.05 and abs(pcbnew.ToMM(pos.y) - 2.4) < 0.05:
                t.SetPosition(pcbnew.VECTOR2I_MM(59.000, 2.450))
        elif not isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/VSYS_RAW':
            p1_t, p2_t = t.GetStart(), t.GetEnd()
            x1, y1 = pcbnew.ToMM(p1_t.x), pcbnew.ToMM(p1_t.y)
            x2, y2 = pcbnew.ToMM(p2_t.x), pcbnew.ToMM(p2_t.y)
            if abs(y1 - 2.4) < 0.05 and abs(y2 - 2.4) < 0.05:
                t.SetStart(pcbnew.VECTOR2I_MM(59.500, 2.450))
                t.SetEnd(pcbnew.VECTOR2I_MM(59.000, 2.450))
            if abs(x1 - 59.5) < 0.05 and abs(x2 - 59.5) < 0.05 and abs(y2 - 2.4) < 0.05:
                t.SetEnd(pcbnew.VECTOR2I_MM(59.500, 2.450))
        elif not isinstance(t, pcbnew.PCB_VIA) and t.GetNetname() == '/USB_VBUS' and t.GetLayer() == fcu:
            p1_t, p2_t = t.GetStart(), t.GetEnd()
            x2, y2 = pcbnew.ToMM(p2_t.x), pcbnew.ToMM(p2_t.y)
            if abs(x2 - 59.0) < 0.05 and abs(y2 - 5.6) < 0.05:
                t.SetEnd(pcbnew.VECTOR2I_MM(59.000, 5.650))

    if step_name == 'd4_and_miso_ends':
        def add_tr(netname, lid, x1, y1, x2, y2, w=0.150):
            t = pcbnew.PCB_TRACK(b)
            t.SetStart(pcbnew.VECTOR2I_MM(x1, y1))
            t.SetEnd(pcbnew.VECTOR2I_MM(x2, y2))
            t.SetWidth(pcbnew.FromMM(w))
            t.SetLayer(lid)
            t.SetNet(b.FindNet(netname))
            b.Add(t)
        def add_via(netname, x, y):
            v = pcbnew.PCB_VIA(b)
            v.SetPosition(pcbnew.VECTOR2I_MM(x, y))
            v.SetDrill(pcbnew.FromMM(0.300))
            v.SetWidth(pcbnew.FromMM(0.500))
            v.SetNet(b.FindNet(netname))
            v.SetViaType(pcbnew.VIATYPE_THROUGH)
            b.Add(v)
        add_tr('/SD_MISO', fcu, 59.150, 4.200, 59.150, 5.025)
        add_tr('/SD_MISO', fcu, 59.150, 5.025, 57.300, 5.025)
        add_tr('/SD_MISO', fcu, 57.300, 5.025, 57.300, 5.500)
        add_via('/SD_MISO', 57.300, 5.500)
        add_tr('/SD_MISO', fcu, 41.630, 2.435, 41.630, 0.600)
        add_via('/SD_MISO', 41.630, 0.600)

    filler = pcbnew.ZONE_FILLER(b)
    filler.Fill(b.Zones())
    b.Save('scratch_test_step.kicad_pcb')
    cmd = [
        'C:/Users/goran/AppData/Local/Programs/KiCad/10.0/bin/kicad-cli.exe',
        'pcb', 'drc', '--severity-all', '--refill-zones', '--format', 'json',
        '-o', 'scratch_test_step_drc.json', 'scratch_test_step.kicad_pcb'
    ]
    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    with open('scratch_test_step_drc.json') as f:
        d = json.load(f)
    print('Step', step_name, 'violations:', len(d.get('violations', [])), 'unconnects:', len(d.get('unconnected_items', [])))
    for u in d.get('unconnected_items', []):
        print('  Unconnected:', [item.get('description') for item in u.get('items', [])])
