import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# Check pins 9, 10, 12, 13
# U1.9:  (41.130, 2.435)
# U1.10: (41.630, 2.435)
# U1.12: (42.630, 2.435)
# U1.13: (43.130, 2.435)

print("Checking straight north tracks from U1 pins:")
for px, net in [(41.130, '/SD_MOSI'), (41.630, '/SD_MISO'), (42.630, '/SD_SCK'), (43.130, '/SD_CS')]:
    for y in [2.0, 1.8, 1.6, 1.4, 1.2, 1.0, 0.8, 0.6]:
        leg, r = geom.is_segment_legal(px, 2.435, px, y, 'F.Cu', net)
        if leg:
            print(f"  {net} straight drop (X={px:.3f}) to Y={y:.1f}: legal")
            break

sys.exit(0)
