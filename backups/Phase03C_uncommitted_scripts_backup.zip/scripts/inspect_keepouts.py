from pathlib import Path
import re

pcb_text = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb").read_text(encoding="utf-8")
areas = re.findall(r'\(zone\s+.*?\(keepout\s+.*?\)\s+\(polygon.*?\)\)', pcb_text, re.DOTALL)
print("Keepout zones found:", len(areas))
for a in areas:
    print(a[:200])

