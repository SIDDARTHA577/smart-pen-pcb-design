import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Testing B.Cu and In2.Cu paths from (53.0, 7.5) to (73.0, 7.0):")

# Path: (53.0, 7.5) -> ... -> (73.0, 7.0)
# Let's inspect obstacles between X=53 and 73, Y=6.5 to 8.5 on B.Cu:
bcu_id = b.GetLayerID('B.Cu')
in2_id = b.GetLayerID('In2.Cu')

print("--- Obstacles on B.Cu between X=53 and 73, Y=6.5 to 8.5 ---")
for t in b.Tracks():
    if t.GetLayer() == bcu_id:
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if max(x1, x2) >= 53 and min(x1, x2) <= 73 and max(y1, y2) >= 6.5 and min(y1, y2) <= 8.5:
            print(f"Track B.Cu: {t.GetNetname()} ({x1:.3f},{y1:.3f}) -> ({x2:.3f},{y2:.3f})")

print("\n--- Obstacles on In2.Cu between X=53 and 73, Y=6.5 to 8.5 ---")
for t in b.Tracks():
    if t.GetLayer() == in2_id:
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if max(x1, x2) >= 53 and min(x1, x2) <= 73 and max(y1, y2) >= 6.5 and min(y1, y2) <= 8.5:
            print(f"Track In2.Cu: {t.GetNetname()} ({x1:.3f},{y1:.3f}) -> ({x2:.3f},{y2:.3f})")

print("\n--- Vias between X=53 and 73, Y=6.5 to 8.5 ---")
for t in b.Tracks():
    if isinstance(t, pcbnew.PCB_VIA):
        p = t.GetPosition()
        x, y = p.x/1e6, p.y/1e6
        if 53 <= x <= 73 and 6.5 <= y <= 8.5:
            print(f"Via: {t.GetNetname()} at ({x:.3f},{y:.3f})")
