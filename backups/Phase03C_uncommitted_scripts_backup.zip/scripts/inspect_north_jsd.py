import sys
sys.path.append('scripts')
import pcbnew

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
print('=== Footprints in X=[56, 62], Y=[4.5, 9.5] ===')
for fp in b.GetFootprints():
    pos = fp.GetPosition()
    px, py = pos.x/1e6, pos.y/1e6
    if 55.0 <= px <= 63.0 and 4.0 <= py <= 10.0:
        print(f"FP: {fp.GetReference()} at ({px:.3f}, {py:.3f}), layer={b.GetLayerName(fp.GetLayer())}")

print('=== Tracks in X=[56, 62], Y=[4.5, 9.5] ===')
for t in b.GetTracks():
    s = t.GetStart()
    e = t.GetEnd()
    sx, sy = s.x/1e6, s.y/1e6
    ex, ey = e.x/1e6, e.y/1e6
    if (56.0 <= sx <= 62.0 and 4.5 <= sy <= 9.5) or (56.0 <= ex <= 62.0 and 4.5 <= ey <= 9.5):
        print(f"Track/Via {t.GetClass()}: layer={b.GetLayerName(t.GetLayer())}, net={t.GetNetname()}, ({sx:.2f},{sy:.2f}) -> ({ex:.2f},{ey:.2f})")
