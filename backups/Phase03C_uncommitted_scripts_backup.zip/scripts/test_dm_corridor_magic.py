import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# 1. From (52.5, 7.3) jog to Y=6.6:
s1, r1 = geom.is_segment_legal(52.500, 7.300, 52.500, 6.600, 'B.Cu', '/USB_DM_CORE')
# 2. Run at Y=6.6 to pass under (54.00, 7.20) to X=56.0:
s2, r2 = geom.is_segment_legal(52.500, 6.600, 56.000, 6.600, 'B.Cu', '/USB_DM_CORE')
# 3. Jog up to Y=7.1 at X=56.0:
s3, r3 = geom.is_segment_legal(56.000, 6.600, 56.000, 7.100, 'B.Cu', '/USB_DM_CORE')
# 4. Run at Y=7.1 to pass over (60.50, 6.50) and under (60.15, 7.81) to X=68.0:
s4, r4 = geom.is_segment_legal(56.000, 7.100, 68.000, 7.100, 'B.Cu', '/USB_DM_CORE')

print(f"s1 (down to 6.6): {s1} ({r1})")
print(f"s2 (pass under 54.0 @ 6.6): {s2} ({r2})")
print(f"s3 (jog up to 7.1): {s3} ({r3})")
print(f"s4 (pass over 60.5 @ 7.1 to 68.0): {s4} ({r4})")
