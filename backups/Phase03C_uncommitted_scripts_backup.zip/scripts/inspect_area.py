import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- Tracks in X in [30, 42], Y in [1.0, 4.5] ---')
for t in board.GetTracks():
    s = t.GetStart()
    e = t.GetEnd()
    sx, sy = s.x/1e6, s.y/1e6
    ex, ey = e.x/1e6, e.y/1e6
    if (30 <= sx <= 42 or 30 <= ex <= 42) and (1.0 <= sy <= 4.5 or 1.0 <= ey <= 4.5):
        layer = board.GetLayerName(t.GetLayer())
        net = t.GetNetname()
        if isinstance(t, pcbnew.PCB_VIA):
            pos = t.GetPosition()
            print(f'VIA {net} at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f})')
        else:
            print(f'TRACK {net} [{layer}]: ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})')

