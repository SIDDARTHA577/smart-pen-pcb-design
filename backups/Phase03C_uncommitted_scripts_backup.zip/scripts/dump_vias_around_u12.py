import sys
sys.path.append('scripts')
import pcbnew

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
print("Footprints in X=[41.5, 43.5], Y=[0.0, 3.0]:")
for fp in b.GetFootprints():
    pos = fp.GetPosition()
    px, py = pos.x/1e6, pos.y/1e6
    if 41.5 <= px <= 43.5 and 0.0 <= py <= 3.0:
        print(f"  FP {fp.GetReference()} at ({px:.3f}, {py:.3f})")
        for p in fp.Pads():
            pp = p.GetPosition()
            print(f"    Pad {p.GetNumber()} ({p.GetNetname()}): ({pp.x/1e6:.3f}, {pp.y/1e6:.3f})")

print("Vias in X=[41.5, 43.5], Y=[0.0, 3.0]:")
for t in b.GetTracks():
    if t.GetClass() == 'PCB_VIA':
        pos = t.GetPosition()
        px, py = pos.x/1e6, pos.y/1e6
        if 41.5 <= px <= 43.5 and 0.0 <= py <= 3.0:
            print(f"  Via {t.GetNetname()} at ({px:.3f}, {py:.3f})")
