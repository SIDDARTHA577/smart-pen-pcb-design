import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew

b = pcbnew.LoadBoard('scratch_test_restore_vsys.kicad_pcb')
print("--- VIAS in [40.0, 45.0], [0.0, 3.0] ---")
for t in b.GetTracks():
    if t.GetClass() == 'PCB_VIA':
        pos = t.GetPosition()
        x, y = pos.x/1e6, pos.y/1e6
        if 40.0 <= x <= 45.0 and 0.0 <= y <= 3.0:
            print(f'VIA net={t.GetNetname()} pos=({x:.3f}, {y:.3f})')
    else:
        s, e = t.GetStart(), t.GetEnd()
        sx, sy, ex, ey = s.x/1e6, s.y/1e6, e.x/1e6, e.y/1e6
        if (40.0 <= sx <= 45.0 or 40.0 <= ex <= 45.0) and (0.0 <= sy <= 3.0 or 0.0 <= ey <= 3.0):
            print(f'TRK layer={t.GetLayerName()} net={t.GetNetname()} ({sx:.3f}, {sy:.3f})->({ex:.3f}, {ey:.3f})')
