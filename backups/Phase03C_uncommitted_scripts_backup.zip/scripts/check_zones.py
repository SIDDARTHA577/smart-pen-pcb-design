import os, pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")
for z in b.Zones():
    print(f"Zone Net: {z.GetNetname()}, Layer: {b.GetLayerName(z.GetLayer())}")
