import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

# Add In2.Cu 3V3 zone
zone = pcbnew.ZONE(board)
zone.SetLayer(board.GetLayerID('In2.Cu'))
net_3v3 = board.FindNet('/3V3')
zone.SetNet(net_3v3)

outline = zone.Outline()
outline.NewOutline()
outline.Append(int(0.40 * 1e6), int(0.40 * 1e6))
outline.Append(int(83.60 * 1e6), int(0.40 * 1e6))
outline.Append(int(83.60 * 1e6), int(8.80 * 1e6))
outline.Append(int(0.40 * 1e6), int(8.80 * 1e6))

# Set zone properties
zone.SetPadConnection(pcbnew.ZONE_CONNECTION_THERMAL)
zone.SetThermalReliefGap(int(0.15 * 1e6))
zone.SetThermalReliefSpokeWidth(int(0.20 * 1e6))

board.Add(zone)

# Also add 4 GND vias to Pad 33 of U1:
net_gnd = board.FindNet('/GND')
for vx, vy in [(42.2, 4.3), (42.2, 5.3), (43.5, 4.3), (43.5, 5.3)]:
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pcbnew.VECTOR2I(int(vx * 1e6), int(vy * 1e6)))
    v.SetWidth(int(0.50 * 1e6))
    v.SetDrill(int(0.30 * 1e6))
    v.SetNet(net_gnd)
    board.Add(v)

board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('Added In2.Cu 3V3 zone and U1.33 GND vias')

