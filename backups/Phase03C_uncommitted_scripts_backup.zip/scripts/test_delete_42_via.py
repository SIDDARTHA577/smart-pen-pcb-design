import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
r27 = b.FindFootprintByReference('R27')
r27.SetPosition(pcbnew.VECTOR2I(int(44.0*1e6), int(1.0*1e6)))

# Delete old GPIO8_STRAP and 3V3 via at (42.0, 0.5)
for t in list(b.GetTracks()):
    if t.GetNetname() == '/GPIO8_STRAP':
        b.Delete(t)
    elif t.GetNetname() == '/3V3' and (round(t.GetPosition().x/1e6, 1) == 42.0 or (t.GetClass() != 'PCB_VIA' and round(t.GetStart().x/1e6, 1) == 42.0)):
        b.Delete(t)

geom = BoardGeometry(b)
sck_via_ok, rsvia = geom.is_via_legal(42.630, 0.500, '/SD_SCK')
print(f"sck_via at (42.63, 0.50): {sck_via_ok} ({rsvia})")
