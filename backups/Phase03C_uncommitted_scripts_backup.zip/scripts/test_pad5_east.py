import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

print("--- Testing Pad 5 East at Y=3.250 ---")
for ex in [59.5, 59.8, 60.0, 60.2, 60.5]:
    s, r = geom.is_segment_legal(59.150, 3.250, ex, 3.250, 'F.Cu', '/SD_MISO')
    print(f"To X={ex}: {s} ({r})")
    if s:
        for vy in [3.250, 3.0, 2.8, 2.5, 2.0]:
            v, rv = geom.is_via_legal(ex, vy, '/SD_MISO')
            if v:
                print(f"  Via OK at ({ex}, {vy})")
