import pcbnew
import subprocess
import json

board = pcbnew.LoadBoard('scratch_test_mosi_flawless.kicad_pcb')

fcu = board.GetLayerID('F.Cu')
bcu = board.GetLayerID('B.Cu')
in1 = board.GetLayerID('In1.Cu')
in2 = board.GetLayerID('In2.Cu')

# Remove existing tracks and vias for SD_SCK, SD_MOSI, SD_MISO
# Keep SD_CS untouched! Keep CHG_STAT untouched! Keep VSYS_RAW untouched!
tracks_to_remove = []
for t in board.GetTracks():
    net = t.GetNetname()
    if net in ['/SD_SCK', '/SD_MOSI', '/SD_MISO']:
        tracks_to_remove.append(t)

print(f"Removing {len(tracks_to_remove)} old tracks/vias for SD_SCK, SD_MOSI, SD_MISO")
for t in tracks_to_remove:
    board.Remove(t)

def add_track(netname, layer, x1, y1, x2, y2, width=0.15):
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(pcbnew.VECTOR2I_MM(x1, y1))
    t.SetEnd(pcbnew.VECTOR2I_MM(x2, y2))
    t.SetWidth(pcbnew.FromMM(width))
    t.SetLayer(layer)
    t.SetNet(board.FindNet(netname))
    board.Add(t)
    return t

def add_via(netname, x, y, drill=0.3, width=0.5):
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pcbnew.VECTOR2I_MM(x, y))
    v.SetDrill(pcbnew.FromMM(drill))
    v.SetWidth(pcbnew.FromMM(width))
    v.SetNet(board.FindNet(netname))
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    board.Add(v)
    return v

# =========================================================================
# 1. SD_SCK: EXITS NORTH
# =========================================================================
# At U1.12 (42.630, 2.435):
add_track('/SD_SCK', fcu, 42.630, 2.435, 42.630, 1.150)
add_via('/SD_SCK', 42.630, 1.150)

# SCK at J_SD.3 (58.150, 4.200):
# Exits North to (58.000, 5.500)
add_track('/SD_SCK', fcu, 58.150, 4.200, 58.150, 5.500)
add_track('/SD_SCK', fcu, 58.150, 5.500, 58.000, 5.500)
add_via('/SD_SCK', 58.000, 5.500)

# SCK Transit on In1.Cu:
# From (42.630, 1.150) jog along X=44.200 to Y=5.500, then straight along Y=5.500 to 58.000
add_track('/SD_SCK', in1, 42.630, 1.150, 44.200, 1.150)
add_track('/SD_SCK', in1, 44.200, 1.150, 44.200, 5.500)
add_track('/SD_SCK', in1, 44.200, 5.500, 58.000, 5.500)

# =========================================================================
# 2. SD_MOSI: EXITS WEST
# =========================================================================
# At U1.9 (41.130, 2.435):
add_track('/SD_MOSI', fcu, 41.130, 2.435, 41.130, 1.650)
add_via('/SD_MOSI', 41.130, 1.650)

# At J_SD.4 (58.650, 4.200):
# Exits West along Y=3.350 to West Playground at (57.600, 3.100)
add_track('/SD_MOSI', fcu, 58.650, 4.200, 58.650, 3.350)
add_track('/SD_MOSI', fcu, 58.650, 3.350, 57.600, 3.350)
add_track('/SD_MOSI', fcu, 57.600, 3.350, 57.600, 3.100)
add_via('/SD_MOSI', 57.600, 3.100)

# MOSI Transit on In1.Cu at Y=1.400:
add_track('/SD_MOSI', in1, 41.130, 1.650, 41.450, 1.400)
add_track('/SD_MOSI', in1, 41.450, 1.400, 57.600, 1.400)
add_track('/SD_MOSI', in1, 57.600, 1.400, 57.600, 3.100)

# =========================================================================
# 3. SD_MISO: EXITS SOUTH
# =========================================================================
# At U1.10 (41.630, 2.435):
add_track('/SD_MISO', fcu, 41.630, 2.435, 41.630, 0.600)
add_via('/SD_MISO', 41.630, 0.600)

# At J_SD.5 (59.150, 4.200):
# Exits South straight into via at (59.150, 3.350)
add_track('/SD_MISO', fcu, 59.150, 4.200, 59.150, 3.350)
add_via('/SD_MISO', 59.150, 3.350)

# MISO Transit on In2.Cu (or In1.Cu at Y=2.000):
# Let's see: on In1.Cu at Y=2.000:
# From (41.630, 0.600) -> (43.500, 0.600) -> (44.500, 2.000) -> (58.500, 2.000) -> (59.150, 3.350)
add_track('/SD_MISO', in1, 41.630, 0.600, 43.500, 0.600)
add_track('/SD_MISO', in1, 43.500, 0.600, 44.500, 2.000)
add_track('/SD_MISO', in1, 44.500, 2.000, 58.500, 2.000)
add_track('/SD_MISO', in1, 58.500, 2.000, 59.150, 3.350)

out_pcb = 'scratch_test_cardinal.kicad_pcb'
board.Save(out_pcb)
print(f"Saved {out_pcb}")
