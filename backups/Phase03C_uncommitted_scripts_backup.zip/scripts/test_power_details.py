import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Checking jogged VBAT_SW run on B.Cu:")
# (28.090, 4.400) -> (41.0, 4.400) -> (41.0, 3.800) -> (44.0, 3.800) -> (44.0, 4.400) -> (62.963, 4.400)
j1, rj1 = geom.is_segment_legal(28.09, 4.4, 41.0, 4.4, 'B.Cu', '/VBAT_SW')
j2, rj2 = geom.is_segment_legal(41.0, 4.4, 41.0, 3.8, 'B.Cu', '/VBAT_SW')
j3, rj3 = geom.is_segment_legal(41.0, 3.8, 44.0, 3.8, 'B.Cu', '/VBAT_SW')
j4, rj4 = geom.is_segment_legal(44.0, 3.8, 44.0, 4.4, 'B.Cu', '/VBAT_SW')
j5, rj5 = geom.is_segment_legal(44.0, 4.4, 62.963, 4.4, 'B.Cu', '/VBAT_SW')
print(f"  VBAT_SW jog: j1={j1}, j2={j2}, j3={j3}, j4={j4}, j5={j5}")

print("\nChecking VSYS_RAW on B.Cu:")
# SW3.1 (60.963, 6.824) -> via at (60.0, 6.824) -> B.Cu (60.0, 6.824) -> (60.0, 3.0) -> via at (60.0, 3.0) -> F.Cu to Q2.2 (61.700, 3.450) and D4.1 (59.000, 2.400)
v_raw1, rr1 = geom.is_via_legal(60.0, 6.824, '/VSYS_RAW')
v_raw2, rr2 = geom.is_via_legal(60.0, 3.0, '/VSYS_RAW')
s_raw, rs_raw = geom.is_segment_legal(60.0, 6.824, 60.0, 3.0, 'B.Cu', '/VSYS_RAW')
print(f"  VSYS_RAW: v1={v_raw1}({rr1}), v2={v_raw2}({rr2}), s={s_raw}({rs_raw})")

sys.exit(0)
