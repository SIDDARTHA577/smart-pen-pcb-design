import json

with open("drc_current.json") as f:
    d = json.load(f)

for v in d.get('violations', []):
    if 'short' in v.get('type', '') or 'clearance' in v.get('type', ''):
        print(v.get('type'), v.get('description'))
        for it in v.get('items', []):
            print("  ", it.get('description'), it.get('pos'))
