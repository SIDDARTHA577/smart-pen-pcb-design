from pathlib import Path
import re

pcb_text = Path("output/RevG/SmartPen.kicad_pcb").read_text(encoding="utf-8")
for line in pcb_text.splitlines():
    if any(k in line for k in ["AE1", "J_RF", "antenna", "Antenna"]):
        print(line)

