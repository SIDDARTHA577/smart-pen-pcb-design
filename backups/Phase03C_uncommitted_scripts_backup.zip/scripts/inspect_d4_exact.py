import pcbnew
b = pcbnew.LoadBoard('output/RevG/SmartPen.kicad_pcb')
d4 = b.FindFootprintByReference('D4')
print('D4 layer:', b.GetLayerName(d4.GetLayer()))
for p in d4.Pads():
    print(f"Pad {p.GetNumber()}: layer={b.GetLayerName(p.GetLayer())}, pos=({p.GetPosition().x/1e6}, {p.GetPosition().y/1e6}), size=({p.GetSize().x/1e6}, {p.GetSize().y/1e6})")
