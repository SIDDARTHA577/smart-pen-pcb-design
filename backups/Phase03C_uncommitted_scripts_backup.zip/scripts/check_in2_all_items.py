import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")
in2 = b.GetLayerID('In2.Cu')

print("--- ALL In2.Cu TRACKS and VIAS X in [56, 61], Y in [0, 9] ---")
for t in b.GetTracks():
    if t.GetClass() == 'PCB_VIA':
        p = t.GetPosition()
        x, y = p.x/1e6, p.y/1e6
        if 56 <= x <= 61 and 0 <= y <= 9:
            print(f"VIA {t.GetNetname()}: ({x:.3f}, {y:.3f})")
    elif t.GetLayer() == in2:
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (56 <= x1 <= 61 or 56 <= x2 <= 61) and (0 <= y1 <= 9 or 0 <= y2 <= 9):
            print(f"In2 TRK {t.GetNetname()}: ({x1:.3f}, {y1:.3f}) -> ({x2:.3f}, {y2:.3f})")
