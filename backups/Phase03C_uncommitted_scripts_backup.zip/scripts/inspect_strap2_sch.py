with open('output/RevG/SmartPen.kicad_sch') as f:
    text = f.read()

pos = text.find('241.30 332.74')
if pos != -1:
    print(text[pos-200:pos+500])
