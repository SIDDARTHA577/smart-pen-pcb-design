import sys
sys.path.append('scripts')
import pcbnew

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
print("=== All items in X=[41.0, 44.0], Y=[0.0, 2.5] ===")
for t in b.GetTracks():
    s, e = t.GetStart(), t.GetEnd()
    sx, sy, ex, ey = s.x/1e6, s.y/1e6, e.x/1e6, e.y/1e6
    if (41.0 <= sx <= 44.0 or 41.0 <= ex <= 44.0) and (0.0 <= sy <= 2.5 or 0.0 <= ey <= 2.5):
        print(f"{t.GetClass()} net={t.GetNetname()} layer={b.GetLayerName(t.GetLayer())}: ({sx:.3f}, {sy:.3f}) -> ({ex:.3f}, {ey:.3f})")
