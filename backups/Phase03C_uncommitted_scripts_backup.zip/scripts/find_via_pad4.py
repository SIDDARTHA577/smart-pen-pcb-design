import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

for vy in [1.2, 1.5, 2.0, 2.5, 2.8, 3.0, 3.25]:
    for vx in [58.4, 58.65, 58.8]:
        v, rv = geom.is_via_legal(vx, vy, '/SD_MOSI')
        if v:
            print(f"Via OK at ({vx}, {vy})")
