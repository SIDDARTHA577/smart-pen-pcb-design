import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try: import wx; wx.DisableAsserts()
except: pass
import pcbnew, shutil

# Test In2.Cu track at Y=1.450 from 43.0 to 56.0
shutil.copy('scratch_test_restore_vsys.kicad_pcb', 'scratch_test_in2_fill.kicad_pcb')
shutil.copy('scratch_test_restore_vsys.kicad_pro', 'scratch_test_in2_fill.kicad_pro')
b = pcbnew.LoadBoard('scratch_test_in2_fill.kicad_pcb')

# Add track on In2.Cu
in2 = b.GetLayerID('In2.Cu')
net = b.FindNet('/SD_SCK')
t = pcbnew.PCB_TRACK(b)
t.SetStart(pcbnew.VECTOR2I(int(42.63*1e6), int(1.45*1e6)))
t.SetEnd(pcbnew.VECTOR2I(int(56.00*1e6), int(1.45*1e6)))
t.SetWidth(int(0.15*1e6))
t.SetLayer(in2)
t.SetNet(net)
b.Add(t)

filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
b.Save('scratch_test_in2_fill.kicad_pcb')
print("Filled zones with track on In2.Cu to 56.0")
