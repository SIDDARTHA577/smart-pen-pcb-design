import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

# Remove existing 3V3_RTC tracks and vias
to_del = []
for t in board.GetTracks():
    if t.GetNetname() == '/3V3_RTC':
        to_del.append(t)
for t in to_del:
    board.Remove(t)

def trk(board, netname, layer_name, x1, y1, x2, y2, w=0.18):
    net = board.FindNet(netname)
    layer = board.GetLayerID(layer_name)
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(pcbnew.VECTOR2I(int(x1 * 1e6), int(y1 * 1e6)))
    t.SetEnd(pcbnew.VECTOR2I(int(x2 * 1e6), int(y2 * 1e6)))
    t.SetWidth(int(w * 1e6))
    t.SetLayer(layer)
    t.SetNet(net)
    board.Add(t)
    return t

def via(board, netname, x, y, drill=0.30, dia=0.50):
    net = board.FindNet(netname)
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6)))
    v.SetWidth(int(dia * 1e6))
    v.SetDrill(int(drill * 1e6))
    v.SetNet(net)
    board.Add(v)
    return v

# Route 3V3_RTC with via at (41.400, 1.700)
# U1.11 is at (42.130, 2.435)
via(board, '/3V3_RTC', 41.400, 1.700)
trk(board, '/3V3_RTC', 'F.Cu', 42.130, 2.435, 41.400, 1.700)

via(board, '/3V3_RTC', 36.360, 1.000)
trk(board, '/3V3_RTC', 'B.Cu', 41.400, 1.700, 36.360, 1.700)
trk(board, '/3V3_RTC', 'B.Cu', 36.360, 1.700, 36.360, 1.000)
trk(board, '/3V3_RTC', 'F.Cu', 36.360, 1.000, 36.360, 1.640)

board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('Adjusted 3V3_RTC via position')

