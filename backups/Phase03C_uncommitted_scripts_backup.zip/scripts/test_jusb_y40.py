import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

s1, r1 = geom.is_segment_legal(76.000, 3.100, 76.000, 4.000, 'F.Cu', '/USB_VBUS')
s2, r2 = geom.is_segment_legal(76.000, 4.000, 80.800, 4.000, 'F.Cu', '/USB_VBUS')
s3, r3 = geom.is_segment_legal(80.800, 4.000, 80.800, 3.100, 'F.Cu', '/USB_VBUS')

print(f"s1 (up to 4.0): {s1} ({r1})")
print(f"s2 (horiz 76.0->80.8 @ 4.0): {s2} ({r2})")
print(f"s3 (down to J_USB.11): {s3} ({r3})")
