import json
from collections import defaultdict
from pathlib import Path

drc_path = Path("reports/RevG/Phase03C/raw/baseline/Main_SmartPen_drc.json")
with open(drc_path, "r", encoding="utf-8") as f:
    drc = json.load(f)

unconn = drc.get("unconnected_items", [])
print(f"Total unconnected items: {len(unconn)}")

items_by_net = defaultdict(list)
for i, u in enumerate(unconn):
    desc = u.get("description")
    subitems = u.get("items", [])
    nets = set()
    for sub in subitems:
        d = sub.get("description", "")
        # Look for [netname]
        if "[" in d and "]" in d:
            n = d.split("[")[1].split("]")[0]
            nets.add(n)
        elif "Pad" in d:
            nets.add(d)
    net_str = "/".join(sorted(nets)) if nets else "unknown"
    items_by_net[net_str].append((u, subitems))

for net, lst in sorted(items_by_net.items(), key=lambda x: len(x[1]), reverse=True):
    print(f"Net: {net} -> {len(lst)} items")
    for u, subitems in lst[:3]:
        p1 = subitems[0].get("pos", {}) if len(subitems) > 0 else {}
        p2 = subitems[1].get("pos", {}) if len(subitems) > 1 else {}
        print(f"   {subitems[0].get('description')} @ ({p1.get('x')}, {p1.get('y')}) <--> {subitems[1].get('description') if len(subitems)>1 else 'N/A'} @ ({p2.get('x')}, {p2.get('y')})")

