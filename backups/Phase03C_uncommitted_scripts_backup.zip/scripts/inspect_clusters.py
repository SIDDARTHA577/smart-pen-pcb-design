import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

# Let's inspect the surroundings of:
# Cluster 1: J_IMU.1 (1.7, 4.6) to R10.1 (5.725, 4.6)
# Cluster 2: R12.1 (14.025, 7.0) to R13.1 (20.025, 7.0)
# Cluster 3: R1.1 (37.975, 2.36) to U1.17 (45.28, 3.085)
# Cluster 4: U4.5 (68.114, 6.563) to J_UART.4 (59.76, 7.347)
print('Cluster inspection script ready.')

