import sys
sys.path.append('scripts')
import pcbnew

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
net = b.FindNet('/3V3_RTC')
print("Pads of 3V3_RTC:")
for fp in b.GetFootprints():
    for p in fp.Pads():
        if p.GetNetname() == '/3V3_RTC':
            print(f"  {fp.GetReference()}.{p.GetNumber()} at ({p.GetPosition().x/1e6:.3f}, {p.GetPosition().y/1e6:.3f}) layer={b.GetLayerName(p.GetLayer())}")
