import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")
for t in b.GetTracks():
    if not isinstance(t, pcbnew.PCB_VIA):
        p1, p2 = t.GetStart(), t.GetEnd()
        if 44.0 <= p1.x/1e6 <= 45.0 or 44.0 <= p2.x/1e6 <= 45.0:
            print(f"Track Net: {t.GetNetname()} Layer: {b.GetLayerName(t.GetLayer())} ({p1.x/1e6:.3f}, {p1.y/1e6:.3f}) -> ({p2.x/1e6:.3f}, {p2.y/1e6:.3f})")
