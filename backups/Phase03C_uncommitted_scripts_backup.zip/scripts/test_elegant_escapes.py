import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

print("=== Testing the Elegant 4-Pad Escape Strategy ===")

# 1. Pad 3 (SD_SCK at 58.150, 4.200):
s3_1, r3_1 = geom.is_segment_legal(58.150, 4.200, 58.150, 5.500, 'F.Cu', '/SD_SCK')
s3_2, r3_2 = geom.is_segment_legal(58.150, 5.500, 57.500, 5.500, 'F.Cu', '/SD_SCK')
v3, rv3 = geom.is_via_legal(57.500, 5.500, '/SD_SCK')
print(f"1. SD_SCK: s1={s3_1}, s2={s3_2}, via={v3} ({rv3})")

# 2. Pad 4 (SD_MOSI at 58.650, 4.200):
s4_1, r4_1 = geom.is_segment_legal(58.650, 4.200, 58.650, 3.250, 'F.Cu', '/SD_MOSI')
s4_2, r4_2 = geom.is_segment_legal(58.650, 3.250, 57.400, 3.250, 'F.Cu', '/SD_MOSI')
s4_3, r4_3 = geom.is_segment_legal(57.400, 3.250, 57.400, 2.800, 'F.Cu', '/SD_MOSI')
v4, rv4 = geom.is_via_legal(57.400, 2.800, '/SD_MOSI')
print(f"2. SD_MOSI: s1={s4_1}, s2={s4_2}, s3={s4_3}, via={v4} ({rv4})")

# 3. Pad 5 (SD_MISO at 59.150, 4.200):
s5_1, r5_1 = geom.is_segment_legal(59.150, 4.200, 59.150, 3.250, 'F.Cu', '/SD_MISO')
s5_2, r5_2 = geom.is_segment_legal(59.150, 3.250, 59.850, 3.250, 'F.Cu', '/SD_MISO')
s5_3, r5_3 = geom.is_segment_legal(59.850, 3.250, 59.850, 1.300, 'F.Cu', '/SD_MISO')
s5_4, r5_4 = geom.is_segment_legal(59.850, 1.300, 59.500, 1.300, 'F.Cu', '/SD_MISO')
v5, rv5 = geom.is_via_legal(59.500, 1.300, '/SD_MISO')
print(f"3. SD_MISO: s1={s5_1}, s2={s5_2}, s3={s5_3}, s4={s5_4}, via={v5} ({rv5})")

# 4. Pad 6 (SD_CS at 59.650, 4.200):
# Pad 6 goes directly south to via at (59.650, 0.850)
# But wait! D4.1 is at (59.000, 2.400).
# What if Pad 6 drops a via at (59.650, 3.250) or (59.650, 0.850)?
# Let's check via at (59.650, 0.850):
v6, rv6 = geom.is_via_legal(59.650, 0.850, '/SD_CS')
print(f"4. SD_CS via at (59.650, 0.850): via={v6} ({rv6})")
