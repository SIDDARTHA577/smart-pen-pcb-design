import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")

print("--- 3V3 tracks and vias in restore_vsys ---")
for t in b.GetTracks():
    if t.GetNetname() == '/3V3':
        p1 = t.GetStart()
        p2 = t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (55 <= x1 <= 65 or 55 <= x2 <= 65):
            if t.GetClass() == 'PCB_VIA':
                print(f"VIA at ({x1:.3f}, {y1:.3f})")
            else:
                print(f"TRK {b.GetLayerName(t.GetLayer())}: ({x1:.3f}, {y1:.3f}) -> ({x2:.3f}, {y2:.3f})")
