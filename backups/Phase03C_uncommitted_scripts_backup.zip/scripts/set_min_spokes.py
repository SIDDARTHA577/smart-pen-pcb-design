import json

pro_path = 'output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pro'
with open(pro_path, 'r') as f:
    d = json.load(f)

d['board']['design_settings']['rules']['min_resolved_spokes'] = 1

with open(pro_path, 'w') as f:
    json.dump(d, f, indent=2)

print('Set min_resolved_spokes to 1 in SmartPen.kicad_pro')

