import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Checking In2.Cu for SCL east run:")
for y in [6.5, 6.8, 7.0, 7.15]:
    leg, r = geom.is_segment_legal(24.25, y, 38.5, y, 'In2.Cu', '/I2C_SCL')
    print(f"  In2.Cu Y={y}: {leg} ({r})")

# Via at (38.5, 4.585)
v_ok, rv = geom.is_via_legal(38.5, 4.585, '/I2C_SCL')
print(f"Via at (38.5, 4.585): {v_ok} ({rv})")

sys.exit(0)
