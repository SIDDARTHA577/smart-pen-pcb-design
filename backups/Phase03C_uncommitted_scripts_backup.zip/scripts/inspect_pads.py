with open('output/RevG/variants/FourLayer_Candidate/SmartPen.pretty/U1.kicad_mod') as f:
    text = f.read()

import re
pads = re.findall(r'\(pad\s+"(\d+)".*?\(size\s+([-\d.]+)\s+([-\d.]+)\)', text)
for p in pads[:10]:
    print(f'Pad {p[0]}: size {p[1]} x {p[2]}')

