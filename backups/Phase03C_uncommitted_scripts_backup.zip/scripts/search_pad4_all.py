import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

print("=== Searching all possible escapes for Pad 4 (SD_MOSI at 58.650, 4.200) ===")

# Pad 4 is at (58.650, 4.200).
# Let's test all (x, y) points in a grid around Pad 4:
for dx in [-0.6, -0.5, -0.4, -0.3, -0.2, 0.0, 0.2, 0.3, 0.4, 0.5, 0.6]:
    for dy in [-1.5, -1.2, -1.0, -0.8, -0.6, -0.4, 0.4, 0.6, 0.8, 1.0, 1.2, 1.5]:
        tx = round(58.650 + dx, 3)
        ty = round(4.200 + dy, 3)
        s, r = geom.is_segment_legal(58.650, 4.200, tx, ty, 'F.Cu', '/SD_MOSI')
        if s:
            v, rv = geom.is_via_legal(tx, ty, '/SD_MOSI')
            if v:
                print(f"Direct route to via at ({tx}, {ty}): LEGAL!")
            else:
                # Can we place a via near tx, ty?
                pass
