import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# Check the two 3V3 track stubs:
for t in b.Tracks():
    if t.GetNetname() == '/3V3' and not isinstance(t, pcbnew.PCB_VIA):
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if abs(x1 - 57.15) < 0.1 or abs(x1 - 59.76) < 0.1:
            print(f"Stub: ({x1:.3f},{y1:.3f}) -> ({x2:.3f},{y2:.3f})")
            # Check via legality at (x2, y2)
            v_ok, rv = geom.is_via_legal(x2, y2, '/3V3')
            print(f"  Via at end ({x2:.3f},{y2:.3f}): {v_ok} ({rv})")
