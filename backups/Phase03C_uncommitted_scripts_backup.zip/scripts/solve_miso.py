import pcbnew
import numpy as np
from collections import deque
import json
import subprocess

board = pcbnew.LoadBoard('scratch_test_mosi_flawless.kicad_pcb')

# Let's see what layers we have
fcu = board.GetLayerID('F.Cu')
bcu = board.GetLayerID('B.Cu')
in1 = board.GetLayerID('In1.Cu')
in2 = board.GetLayerID('In2.Cu')

net_miso = board.FindNet('/SD_MISO')

# Start: Pad 10 of U1 (41.630, 2.435)
# End: Pad 5 of J_SD (59.150, 4.200)

print(f"Net MISO: {net_miso.GetNetname()}")

# Let's inspect obstacles around U1.10 and J_SD.5
# Can we escape U1.10?
# From U1.10 (41.630, 2.435):
# Track on F.Cu straight down to (41.630, 0.800)
# Let's check clearance of a track at X=41.630, Y from 2.435 down to 0.800
# And a via at (41.630, 0.800):
# Wait, let's test if a via at (41.630, 0.800) drill=0.3, width=0.5 passes DRC.
