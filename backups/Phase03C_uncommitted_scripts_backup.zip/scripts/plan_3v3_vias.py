import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

# 1. Add In2.Cu 3V3 zone
z_3v3 = pcbnew.ZONE(board)
z_3v3.SetLayer(board.GetLayerID('In2.Cu'))
z_3v3.SetNet(board.FindNet('/3V3'))
outline = z_3v3.Outline()
outline.NewOutline()
outline.Append(int(0.40 * 1e6), int(0.40 * 1e6))
outline.Append(int(83.60 * 1e6), int(0.40 * 1e6))
outline.Append(int(83.60 * 1e6), int(8.80 * 1e6))
outline.Append(int(0.40 * 1e6), int(8.80 * 1e6))
z_3v3.SetPadConnection(pcbnew.ZONE_CONNECTION_THERMAL)
z_3v3.SetThermalReliefGap(int(0.15 * 1e6))
z_3v3.SetThermalReliefSpokeWidth(int(0.20 * 1e6))
board.Add(z_3v3)

# 2. Inspect all 3V3 pads
pads_3v3 = []
for fp in board.Footprints():
    for p in fp.Pads():
        if p.GetNetname() == '/3V3':
            pos = p.GetPosition()
            pads_3v3.append((fp.GetReference(), p.GetNumber(), pos.x/1e6, pos.y/1e6))

print(f'Total 3V3 pads on board: {len(pads_3v3)}')
for ref, pnum, px, py in pads_3v3:
    print(f'  {ref}.{pnum} at ({px:.3f}, {py:.3f})')

