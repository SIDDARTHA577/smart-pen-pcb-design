import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Checking West SCL routing:")
# Can we route on B.Cu from (24.250, 7.150) to (7.500, 7.150)?
s1, r1 = geom.is_segment_legal(7.500, 7.150, 24.250, 7.150, 'B.Cu', '/I2C_SCL')
print(f"B.Cu (7.5, 7.15) -> (24.25, 7.15): {s1} ({r1})")

# Via at (7.500, 7.150):
v1, rv1 = geom.is_via_legal(7.500, 7.150, '/I2C_SCL')
print(f"Via at (7.5, 7.15): {v1} ({rv1})")

# F.Cu from via (7.5, 7.15) to R11.2 (6.675, 7.200):
s2, r2 = geom.is_segment_legal(7.500, 7.150, 6.675, 7.200, 'F.Cu', '/I2C_SCL')
print(f"F.Cu to R11.2: {s2} ({r2})")

# F.Cu or B.Cu from R11.2 to J_IMU.4 (4.700, 4.600):
# Can we run B.Cu from (7.5, 7.15) to (4.7, 7.15)?
s3, r3 = geom.is_segment_legal(4.700, 7.150, 7.500, 7.150, 'B.Cu', '/I2C_SCL')
print(f"B.Cu (4.7, 7.15) -> (7.5, 7.15): {s3} ({r3})")

v2, rv2 = geom.is_via_legal(4.700, 7.150, '/I2C_SCL')
print(f"Via at (4.7, 7.15): {v2} ({rv2})")

s4, r4 = geom.is_segment_legal(4.700, 7.150, 4.700, 4.600, 'F.Cu', '/I2C_SCL')
print(f"F.Cu to J_IMU.4: {s4} ({r4})")
