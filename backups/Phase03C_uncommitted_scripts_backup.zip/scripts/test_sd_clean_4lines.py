import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Checking MicroSD SPI 4-line routing:")

# 1. SD_MOSI at Y=0.450 on B.Cu:
v_mosi_w, r_mw = geom.is_via_legal(41.130, 0.450, '/SD_MOSI')
v_mosi_e, r_me = geom.is_via_legal(58.650, 0.450, '/SD_MOSI')
s_mosi_bcu, r_mb = geom.is_segment_legal(41.130, 0.450, 58.650, 0.450, 'B.Cu', '/SD_MOSI')
s_mosi_f1, r_mf1 = geom.is_segment_legal(41.130, 2.435, 41.130, 0.450, 'F.Cu', '/SD_MOSI')
s_mosi_f2, r_mf2 = geom.is_segment_legal(58.650, 0.450, 58.650, 4.200, 'F.Cu', '/SD_MOSI')
print(f"MOSI: v_w={v_mosi_w}, v_e={v_mosi_e}, bcu={s_mosi_bcu}({r_mb}), f1={s_mosi_f1}, f2={s_mosi_f2}")

# 2. SD_MISO at Y=1.550 on In2.Cu:
v_miso_w, r_iw = geom.is_via_legal(41.630, 1.550, '/SD_MISO')
v_miso_e, r_ie = geom.is_via_legal(59.150, 1.550, '/SD_MISO')
s_miso_in2, r_ib = geom.is_segment_legal(41.630, 1.550, 59.150, 1.550, 'In2.Cu', '/SD_MISO')
s_miso_f1, r_if1 = geom.is_segment_legal(41.630, 2.435, 41.630, 1.550, 'F.Cu', '/SD_MISO')
s_miso_f2, r_if2 = geom.is_segment_legal(59.150, 1.550, 59.150, 4.200, 'F.Cu', '/SD_MISO')
print(f"MISO: v_w={v_miso_w}, v_e={v_miso_e}, in2={s_miso_in2}({r_ib}), f1={s_miso_f1}, f2={s_miso_f2}")

# 3. SD_SCK at Y=1.950 on In2.Cu:
v_sck_w, r_sw = geom.is_via_legal(42.630, 1.950, '/SD_SCK')
v_sck_e, r_se = geom.is_via_legal(58.150, 1.950, '/SD_SCK')
s_sck_in2, r_sb = geom.is_segment_legal(42.630, 1.950, 58.150, 1.950, 'In2.Cu', '/SD_SCK')
s_sck_f1, r_sf1 = geom.is_segment_legal(42.630, 2.435, 42.630, 1.950, 'F.Cu', '/SD_SCK')
s_sck_f2, r_sf2 = geom.is_segment_legal(58.150, 1.950, 58.150, 4.200, 'F.Cu', '/SD_SCK')
print(f"SCK: v_w={v_sck_w}, v_e={v_sck_e}, in2={s_sck_in2}({r_sb}), f1={s_sck_f1}, f2={s_sck_f2}")

# 4. SD_CS at Y=0.850 on In2.Cu:
v_cs_w, r_cw = geom.is_via_legal(43.130, 0.850, '/SD_CS')
v_cs_e, r_ce = geom.is_via_legal(59.650, 0.850, '/SD_CS')
s_cs_in2, r_cb = geom.is_segment_legal(43.130, 0.850, 59.650, 0.850, 'In2.Cu', '/SD_CS')
s_cs_f1, r_cf1 = geom.is_segment_legal(43.130, 2.435, 43.130, 0.850, 'F.Cu', '/SD_CS')
s_cs_f2, r_cf2 = geom.is_segment_legal(59.650, 0.850, 59.650, 4.200, 'F.Cu', '/SD_CS')
print(f"CS: v_w={v_cs_w}, v_e={v_cs_e}, in2={s_cs_in2}({r_cb}), f1={s_cs_f1}, f2={s_cs_f2}")
