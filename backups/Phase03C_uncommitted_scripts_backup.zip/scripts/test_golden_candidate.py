import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
import shutil

src_pcb = 'scratch_test_restore_vsys.kicad_pcb'
dst_pcb = 'scratch_golden_verified.kicad_pcb'
shutil.copy(src_pcb, dst_pcb)
shutil.copy(src_pcb.replace('.kicad_pcb', '.kicad_pro'), dst_pcb.replace('.kicad_pcb', '.kicad_pro'))

b = pcbnew.LoadBoard(dst_pcb)

# 1. Delete freestanding stitching via at (55.00, 1.20)
for t in list(b.GetTracks()):
    if t.GetClass() == 'PCB_VIA' and round(t.GetPosition().x/1e6, 2) == 55.00 and round(t.GetPosition().y/1e6, 2) == 1.20:
        b.Delete(t)

# 2. Fix R27 silkscreen reference position (move text away from copper)
r27 = b.FindFootprintByReference('R27')
if r27:
    r27.Reference().SetPosition(pcbnew.VECTOR2I(int(44.0 * 1e6), int(0.0 * 1e6)))

# 3. Update CHG_STAT clean jog on B.Cu
for t in list(b.GetTracks()):
    if t.GetNetname() == '/CHG_STAT' and t.GetLayer() == b.GetLayerID('B.Cu'):
        b.Delete(t)

bcu = b.GetLayerID('B.Cu')
fcu = b.GetLayerID('F.Cu')
in2 = b.GetLayerID('In2.Cu')

def add_trk(netname, layer_id, x1, y1, x2, y2, w=0.15):
    net = b.FindNet(netname)
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(int(round(x1 * 1e6)), int(round(y1 * 1e6))))
    t.SetEnd(pcbnew.VECTOR2I(int(round(x2 * 1e6)), int(round(y2 * 1e6))))
    t.SetWidth(int(round(w * 1e6)))
    t.SetLayer(layer_id)
    t.SetNet(net)
    b.Add(t)
    return t

def add_via(netname, x, y, drill=0.30, dia=0.50):
    net = b.FindNet(netname)
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(int(round(x * 1e6)), int(round(y * 1e6))))
    v.SetWidth(int(round(dia * 1e6)))
    v.SetDrill(int(round(drill * 1e6)))
    v.SetNet(net)
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    b.Add(v)
    return v

# Apply CHG_STAT clean jog
add_trk('/CHG_STAT', bcu, 24.25, 1.00, 39.00, 1.00, 0.18)
add_trk('/CHG_STAT', bcu, 39.00, 1.00, 39.00, 2.30, 0.18)
add_trk('/CHG_STAT', bcu, 39.00, 2.30, 44.00, 2.30, 0.18)
add_trk('/CHG_STAT', bcu, 44.00, 2.30, 44.00, 1.80, 0.18)
add_trk('/CHG_STAT', bcu, 44.00, 1.80, 66.05, 1.80, 0.18)

# 4. Clear existing SD tracks
for netname in ['/SD_SCK', '/SD_MOSI', '/SD_MISO', '/SD_CS']:
    net = b.FindNet(netname)
    for t in list(b.GetTracks()):
        if t.GetNet() == net:
            b.Delete(t)

# --- ROUTE NET 1: /SD_MOSI (on B.Cu) ---
# U1.9 (41.130, 2.435) -> (41.130, 1.600) via
add_trk('/SD_MOSI', fcu, 41.130, 2.435, 41.130, 1.600)
add_via('/SD_MOSI', 41.130, 1.600)
# B.Cu: (41.130, 1.600) -> (41.130, 1.150) -> (57.400, 1.150) -> (57.400, 2.800) via
add_trk('/SD_MOSI', bcu, 41.130, 1.600, 41.130, 1.150)
add_trk('/SD_MOSI', bcu, 41.130, 1.150, 57.400, 1.150)
add_trk('/SD_MOSI', bcu, 57.400, 1.150, 57.400, 2.800)
add_via('/SD_MOSI', 57.400, 2.800)
# F.Cu: (57.400, 2.800) -> (57.400, 3.250) -> (58.650, 3.250) -> (58.650, 4.200) (J_SD.4)
add_trk('/SD_MOSI', fcu, 57.400, 2.800, 57.400, 3.250)
add_trk('/SD_MOSI', fcu, 57.400, 3.250, 58.650, 3.250)
add_trk('/SD_MOSI', fcu, 58.650, 3.250, 58.650, 4.200)

# --- ROUTE NET 2: /SD_SCK (on In2.Cu at Y=1.450) ---
# U1.12 (42.630, 2.435) -> (42.630, 0.500) via
add_trk('/SD_SCK', fcu, 42.630, 2.435, 42.630, 0.500)
add_via('/SD_SCK', 42.630, 0.500)
# In2.Cu: (42.630, 0.500) -> (42.630, 1.450) -> (58.000, 1.450) -> (58.000, 5.500) via
add_trk('/SD_SCK', in2, 42.630, 0.500, 42.630, 1.450)
add_trk('/SD_SCK', in2, 42.630, 1.450, 58.000, 1.450)
add_trk('/SD_SCK', in2, 58.000, 1.450, 58.000, 5.500)
add_via('/SD_SCK', 58.000, 5.500)
# F.Cu: (58.000, 5.500) -> (58.150, 5.500) -> (58.150, 4.200) (J_SD.3)
add_trk('/SD_SCK', fcu, 58.000, 5.500, 58.150, 5.500)
add_trk('/SD_SCK', fcu, 58.150, 5.500, 58.150, 4.200)

# --- ROUTE NET 3: /SD_CS (on In2.Cu at Y=1.150) ---
# U1.13 (43.130, 2.435) -> (43.130, 1.950) -> (43.000, 1.820) -> (43.000, 1.600) via
add_trk('/SD_CS', fcu, 43.130, 2.435, 43.130, 1.950)
add_trk('/SD_CS', fcu, 43.130, 1.950, 43.000, 1.820)
add_trk('/SD_CS', fcu, 43.000, 1.820, 43.000, 1.600)
add_via('/SD_CS', 43.000, 1.600)
# In2.Cu: (43.000, 1.600) -> (43.000, 1.150) -> (56.975, 1.150)
add_trk('/SD_CS', in2, 43.000, 1.600, 43.000, 1.150)
add_trk('/SD_CS', in2, 43.000, 1.150, 56.975, 1.150)
# Tap to R18.2 at (56.975, 2.000)
add_via('/SD_CS', 56.975, 1.150)
add_trk('/SD_CS', fcu, 56.975, 1.150, 56.975, 2.000)
# In2.Cu: (56.975, 1.150) -> (59.300, 1.150) -> (59.300, 0.700) via
add_trk('/SD_CS', in2, 56.975, 1.150, 59.300, 1.150)
add_trk('/SD_CS', in2, 59.300, 1.150, 59.300, 0.700)
add_via('/SD_CS', 59.300, 0.700)
# F.Cu: (59.300, 0.700) -> (59.800, 0.700) -> (59.800, 3.600) -> (59.650, 3.600) -> (59.650, 4.200) (J_SD.6)
add_trk('/SD_CS', fcu, 59.300, 0.700, 59.800, 0.700)
add_trk('/SD_CS', fcu, 59.800, 0.700, 59.800, 3.600)
add_trk('/SD_CS', fcu, 59.800, 3.600, 59.650, 3.600)
add_trk('/SD_CS', fcu, 59.650, 3.600, 59.650, 4.200)

# --- ROUTE NET 4: /SD_MISO (on In2.Cu at Y=2.050) ---
# U1.10 (41.630, 2.435) -> (41.630, 2.050) -> (41.400, 1.820) -> (41.400, 1.600) via
add_trk('/SD_MISO', fcu, 41.630, 2.435, 41.630, 2.050)
add_trk('/SD_MISO', fcu, 41.630, 2.050, 41.400, 1.820)
add_trk('/SD_MISO', fcu, 41.400, 1.820, 41.400, 1.600)
add_via('/SD_MISO', 41.400, 1.600)
# In2.Cu: (41.400, 1.600) -> (41.400, 2.320) -> (42.700, 2.320) -> (42.700, 2.050) -> (57.500, 2.050) -> (57.500, 1.000) via
add_trk('/SD_MISO', in2, 41.400, 1.600, 41.400, 2.320)
add_trk('/SD_MISO', in2, 41.400, 2.320, 42.700, 2.320)
add_trk('/SD_MISO', in2, 42.700, 2.320, 42.700, 2.050)
add_trk('/SD_MISO', in2, 42.700, 2.050, 57.500, 2.050)
add_trk('/SD_MISO', in2, 57.500, 2.050, 57.500, 1.000)
add_via('/SD_MISO', 57.500, 1.000)
# F.Cu: (57.500, 1.000) -> (57.800, 1.000) -> (57.800, 3.150) -> (59.150, 3.150) -> (59.150, 4.200) (J_SD.5)
add_trk('/SD_MISO', fcu, 57.500, 1.000, 57.800, 1.000)
add_trk('/SD_MISO', fcu, 57.800, 1.000, 57.800, 3.150)
add_trk('/SD_MISO', fcu, 57.800, 3.150, 59.150, 3.150)
add_trk('/SD_MISO', fcu, 59.150, 3.150, 59.150, 4.200)

# Refill all zones
print("Refilling zones...")
filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
print("Fill complete.")

b.Save(dst_pcb)
print(f"Successfully generated {dst_pcb}")
