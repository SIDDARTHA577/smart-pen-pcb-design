import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

dm_net = b.FindNet('/USB_DM_CORE')
dp_net = b.FindNet('/USB_DP_CORE')
fcu = b.GetLayerID('F.Cu')
in2 = b.GetLayerID('In2.Cu')

# Test DM path:
# U1.25 (44.630, 7.235) -> F.Cu (44.630, 8.350) -> F.Cu (52.000, 8.350) -> F.Cu (52.000, 5.800)
# Via DM at (52.000, 5.800)
# In2.Cu (52.000, 5.800) -> In2.Cu (73.000, 5.800)
# Via DM at (73.000, 5.800)
# F.Cu (73.000, 5.800) -> F.Cu (73.000, 7.025) -> F.Cu (72.500, 7.025)

print("Checking DM segments & vias:")
v_dm_w, r1 = geom.is_via_legal(52.0, 5.8, '/USB_DM_CORE')
v_dm_e, r2 = geom.is_via_legal(73.0, 5.8, '/USB_DM_CORE')
print(f"DM via west (52.0, 5.8): {v_dm_w} ({r1})")
print(f"DM via east (73.0, 5.8): {v_dm_e} ({r2})")

s_dm1, rs1 = geom.is_segment_legal(44.63, 7.235, 44.63, 8.35, 'F.Cu', '/USB_DM_CORE')
s_dm2, rs2 = geom.is_segment_legal(44.63, 8.35, 52.0, 8.35, 'F.Cu', '/USB_DM_CORE')
s_dm3, rs3 = geom.is_segment_legal(52.0, 8.35, 52.0, 5.8, 'F.Cu', '/USB_DM_CORE')
s_dm4, rs4 = geom.is_segment_legal(52.0, 5.8, 73.0, 5.8, 'In2.Cu', '/USB_DM_CORE')
s_dm5, rs5 = geom.is_segment_legal(73.0, 5.8, 73.0, 7.025, 'F.Cu', '/USB_DM_CORE')
s_dm6, rs6 = geom.is_segment_legal(73.0, 7.025, 72.5, 7.025, 'F.Cu', '/USB_DM_CORE')
print(f"DM segs: s1={s_dm1}, s2={s_dm2}, s3={s_dm3}, s4={s_dm4}, s5={s_dm5}, s6={s_dm6}")

sys.exit(0)
