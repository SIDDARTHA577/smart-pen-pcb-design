import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')

# Restore R27 to baseline position (43.5, 1.0)
r27 = b.FindFootprintByReference('R27')
r27.SetPosition(pcbnew.VECTOR2I(int(43.5*1e6), int(1.0*1e6)))

# Remove old GPIO8_STRAP and 3V3 tracks for R27
for t in list(b.GetTracks()):
    if t.GetNetname() == '/GPIO8_STRAP':
        b.Delete(t)
    elif t.GetNetname() == '/3V3' and (round(t.GetPosition().x/1e6, 1) == 42.0 or (t.GetClass() != 'PCB_VIA' and round(t.GetStart().x/1e6, 1) == 42.0)):
        b.Delete(t)

# Route GPIO8_STRAP: U1.14 (43.630, 2.435) -> (43.630, 1.000) -> R27.2 (43.975, 1.000)
net_strap = b.FindNet('/GPIO8_STRAP')
t1 = pcbnew.PCB_TRACK(b)
t1.SetStart(pcbnew.VECTOR2I(int(43.630*1e6), int(2.435*1e6)))
t1.SetEnd(pcbnew.VECTOR2I(int(43.630*1e6), int(1.000*1e6)))
t1.SetWidth(int(0.15*1e6))
t1.SetLayer(b.GetLayerID('F.Cu'))
t1.SetNet(net_strap)
b.Add(t1)

t2 = pcbnew.PCB_TRACK(b)
t2.SetStart(pcbnew.VECTOR2I(int(43.630*1e6), int(1.000*1e6)))
t2.SetEnd(pcbnew.VECTOR2I(int(43.975*1e6), int(1.000*1e6)))
t2.SetWidth(int(0.15*1e6))
t2.SetLayer(b.GetLayerID('F.Cu'))
t2.SetNet(net_strap)
b.Add(t2)

# Where does R27.1 (/3V3 at 43.025, 1.000) connect to 3V3?
# In2.Cu is 3V3 plane! So a via directly near R27.1
# Let's check where a via for 3V3 can be placed near R27.1

geom = BoardGeometry(b)
print("Testing SD_SCK segment from U1.12 (42.630, 2.435) south:")
for vy in [0.5, 0.6, 0.7, 0.8, 1.0, 1.2, 1.4]:
    s_ok, rs = geom.is_segment_legal(42.630, 2.435, 42.630, vy, 'F.Cu', '/SD_SCK')
    v_ok, rv = geom.is_via_legal(42.630, vy, '/SD_SCK')
    print(f"vy={vy:.2f}: seg={s_ok} ({rs}), via={v_ok} ({rv})")
