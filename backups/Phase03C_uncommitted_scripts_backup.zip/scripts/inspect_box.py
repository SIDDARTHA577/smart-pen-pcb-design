import pcbnew

board = pcbnew.LoadBoard('scratch_test_mosi_flawless.kicad_pcb')

print("=== PADS in X in [56, 62], Y in [0, 7] ===")
for foot in board.GetFootprints():
    for pad in foot.Pads():
        pos = pad.GetPosition()
        x = pcbnew.ToMM(pos.x)
        y = pcbnew.ToMM(pos.y)
        if 56.0 <= x <= 62.0 and 0.0 <= y <= 7.0:
            print(f"Pad {foot.GetReference()}.{pad.GetNumber()} [{pad.GetNetname()}] at ({x:.3f}, {y:.3f}) size=({pcbnew.ToMM(pad.GetSizeX()):.3f}, {pcbnew.ToMM(pad.GetSizeY()):.3f}) shape={pad.GetShape()}")

print("\n=== VIAS in X in [56, 62], Y in [0, 7] ===")
for t in board.GetTracks():
    if isinstance(t, pcbnew.PCB_VIA):
        pos = t.GetPosition()
        x = pcbnew.ToMM(pos.x)
        y = pcbnew.ToMM(pos.y)
        if 56.0 <= x <= 62.0 and 0.0 <= y <= 7.0:
            print(f"Via [{t.GetNetname()}] at ({x:.3f}, {y:.3f}) d={pcbnew.ToMM(t.GetDrill()):.3f} w={pcbnew.ToMM(t.GetWidth(pcbnew.F_Cu)):.3f}")

print("\n=== TRACKS in X in [56, 62], Y in [0, 7] ===")
for t in board.GetTracks():
    if not isinstance(t, pcbnew.PCB_VIA):
        p1 = t.GetStart()
        p2 = t.GetEnd()
        x1, y1 = pcbnew.ToMM(p1.x), pcbnew.ToMM(p1.y)
        x2, y2 = pcbnew.ToMM(p2.x), pcbnew.ToMM(p2.y)
        if (56.0 <= x1 <= 62.0 and 0.0 <= y1 <= 7.0) or (56.0 <= x2 <= 62.0 and 0.0 <= y2 <= 7.0):
            print(f"Track [{t.GetLayerName()}] {t.GetNetname()}: ({x1:.3f}, {y1:.3f}) -> ({x2:.3f}, {y2:.3f}) w={pcbnew.ToMM(t.GetWidth()):.3f}")
