import pcbnew

b = pcbnew.LoadBoard("scratch_test_clean_step10.kicad_pcb")
bcu = b.GetLayerID('B.Cu')

print("--- Objects on B.Cu between X=56 and 61, Y in [3.5, 8.0] ---")
for t in b.GetTracks():
    if t.GetClass() == 'PCB_VIA':
        p = t.GetPosition()
        x, y = p.x/1e6, p.y/1e6
        if 56 <= x <= 61 and 3.5 <= y <= 8.0:
            print(f"VIA {t.GetNetname()}: ({x:.3f}, {y:.3f})")
    elif t.GetLayer() == bcu:
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (56 <= x1 <= 61 or 56 <= x2 <= 61) and (3.5 <= y1 <= 8.0 or 3.5 <= y2 <= 8.0):
            print(f"TRK {t.GetNetname()}: ({x1:.3f}, {y1:.3f}) -> ({x2:.3f}, {y2:.3f})")
