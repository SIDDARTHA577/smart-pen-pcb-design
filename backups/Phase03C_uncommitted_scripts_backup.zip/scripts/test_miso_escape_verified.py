import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

s1, r1 = geom.is_segment_legal(59.150, 4.200, 59.150, 3.250, 'F.Cu', '/SD_MISO')
s2, r2 = geom.is_segment_legal(59.150, 3.250, 57.400, 3.250, 'F.Cu', '/SD_MISO')
s3, r3 = geom.is_segment_legal(57.400, 3.250, 57.400, 2.800, 'F.Cu', '/SD_MISO')
v, rv = geom.is_via_legal(57.400, 2.800, '/SD_MISO')

print("MISO Escape:")
print("  s1:", s1, r1)
print("  s2:", s2, r2)
print("  s3:", s3, r3)
print("  via:", v, rv)
