import json

d = json.load(open('reports/RevG/Phase03C/raw/candidate_scl_drc.json'))
u1 = d.get('unconnected_items', [])[0]
u2 = d.get('unconnected_items', [])[1]
print("GND Island 1:", u1.get('items')[0].get('pos'), u1.get('items')[1].get('pos'))
print("GND Island 2:", u2.get('items')[0].get('pos'), u2.get('items')[1].get('pos'))
