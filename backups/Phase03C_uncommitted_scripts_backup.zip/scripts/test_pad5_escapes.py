import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

print("--- Testing Pad 5 (SD_MISO at 59.150, 4.200) escapes ---")

# Option 1: NORTH
for y in [4.8, 5.0, 5.2, 5.5]:
    for x in [59.150, 59.5, 60.0, 60.5]:
        s, r = geom.is_segment_legal(59.150, 4.200, x, y, 'F.Cu', '/SD_MISO')
        if s:
            v, rv = geom.is_via_legal(x, y, '/SD_MISO')
            if v:
                print(f"Pad 5 North OK to ({x}, {y})")

# Option 2: EAST
# Pad 6 ends at Y=3.6. Above Y=4.8 or below Y=3.6?
for y in [3.250, 3.400, 3.500]:
    s, r = geom.is_segment_legal(59.150, 4.200, 59.150, y, 'F.Cu', '/SD_MISO')
    print(f"Pad 5 south to Y={y}: {s} ({r})")
