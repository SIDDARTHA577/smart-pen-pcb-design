import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")
fcu = b.GetLayerID('F.Cu')

print("--- Objects on F.Cu between X=43 and 57 in Y=[0.0, 3.0] ---")
for t in b.GetTracks():
    if t.GetLayer() == fcu and not isinstance(t, pcbnew.PCB_VIA):
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (43.0 <= x1 <= 57.0 or 43.0 <= x2 <= 57.0) and (0.0 <= y1 <= 3.0 or 0.0 <= y2 <= 3.0):
            print(f"TRK Net: {t.GetNetname()} ({x1:.3f}, {y1:.3f}) -> ({x2:.3f}, {y2:.3f})")

for fp in b.GetFootprints():
    for p in fp.Pads():
        pos = p.GetPosition()
        x, y = pos.x/1e6, pos.y/1e6
        if 43.0 <= x <= 57.0 and 0.0 <= y <= 3.0:
            print(f"FP: {fp.GetReference()} Pad: {p.GetNumber()} Net: {p.GetNetname()} at ({x:.3f}, {y:.3f})")
