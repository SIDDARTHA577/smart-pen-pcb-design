import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

print("Checking via locations for Q2.3:")
for x in [63.0, 63.5, 63.9, 64.5]:
    for y in [3.0, 3.2, 3.4, 3.5, 3.6, 5.0, 5.2]:
        v_ok, rv = geom.is_via_legal(x, y, '/VBAT')
        if v_ok:
            s_fcu, rf = geom.is_segment_legal(x, y, 63.900, 4.400, 'F.Cu', '/VBAT')
            if s_fcu:
                print(f"Legal via at ({x},{y}) with F.Cu reach to Q2.3!")
