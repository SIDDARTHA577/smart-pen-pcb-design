import pcbnew
import math

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

def is_point_legal_for_via(board, x, y, netname, dia=0.50, drill=0.30, min_clr=0.16, edge_clr=0.30):
    # Board boundary check (84.0 x 9.2 mm)
    r_via = dia / 2.0
    if x - r_via < edge_clr or x + r_via > (84.0 - edge_clr):
        return False
    if y - r_via < edge_clr or y + r_via > (9.2 - edge_clr):
        return False

    net = board.FindNet(netname)
    v_pos = pcbnew.VECTOR2I(int(x * 1e6), int(y * 1e6))

    # Check existing vias on all layers
    for t in board.GetTracks():
        if isinstance(t, pcbnew.PCB_VIA):
            pos = t.GetPosition()
            dx = (pos.x - v_pos.x) / 1e6
            dy = (pos.y - v_pos.y) / 1e6
            dist = math.hypot(dx, dy)
            # Hole-to-hole clearance: min 0.50 mm
            if dist < 0.50:
                return False
            # Copper clearance if different net
            if t.GetNetname() != netname and dist < (dia/2.0 + t.GetWidth(pcbnew.F_Cu)/2e6 + min_clr):
                return False

    # Check pads on F.Cu and B.Cu
    for fp in board.Footprints():
        for p in fp.Pads():
            if p.GetNetname() != netname:
                p_pos = p.GetPosition()
                dx = (p_pos.x - v_pos.x) / 1e6
                dy = (p_pos.y - v_pos.y) / 1e6
                dist = math.hypot(dx, dy)
                # bounding radius of pad
                p_r = math.hypot(p.GetSize().x/2e6, p.GetSize().y/2e6)
                if dist < (r_via + p_r + min_clr):
                    return False
    return True

# Test finding a legal via spot for each 3V3 pad
pads_3v3 = []
for fp in board.Footprints():
    for p in fp.Pads():
        if p.GetNetname() == '/3V3':
            pos = p.GetPosition()
            pads_3v3.append((fp.GetReference(), p.GetNumber(), p, pos.x/1e6, pos.y/1e6))

print(f'Total 3V3 pads: {len(pads_3v3)}')

found_count = 0
for ref, pnum, pad, px, py in pads_3v3:
    found = False
    # Try 8 cardinal directions at distances 0.7 to 1.2 mm
    for dist in [0.70, 0.85, 1.00, 1.20]:
        for angle_deg in [0, 90, 180, 270, 45, 135, 225, 315]:
            rad = math.radians(angle_deg)
            vx = px + dist * math.cos(rad)
            vy = py + dist * math.sin(rad)
            if is_point_legal_for_via(board, vx, vy, '/3V3'):
                print(f'  {ref}.{pnum} -> Legal via at ({vx:.3f}, {vy:.3f}), dist={dist:.2f}, angle={angle_deg}')
                found = True
                found_count += 1
                break
        if found:
            break
    if not found:
        print(f'  FAILED to find legal via for {ref}.{pnum} at ({px:.3f}, {py:.3f})')

print(f'Successfully found legal via positions for {found_count} / {len(pads_3v3)} pads!')

