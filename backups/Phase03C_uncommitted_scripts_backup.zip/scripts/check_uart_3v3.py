import pcbnew

b = pcbnew.LoadBoard("scratch_test_clean_step10.kicad_pcb")
for fp in b.GetFootprints():
    if fp.GetReference() == 'J_UART':
        for p in fp.Pads():
            if p.GetNetname() == '/3V3':
                print(f"J_UART 3V3 pad {p.GetNumber()} at ({p.GetPosition().x/1e6:.3f}, {p.GetPosition().y/1e6:.3f})")

for t in b.GetTracks():
    if t.GetNetname() == '/3V3':
        p1, p2 = t.GetStart(), t.GetEnd()
        if (59 <= p1.x/1e6 <= 61 or 59 <= p2.x/1e6 <= 61) and (6.5 <= p1.y/1e6 <= 8.5 or 6.5 <= p2.y/1e6 <= 8.5):
            print(f"TRK/VIA near J_UART: {b.GetLayerName(t.GetLayer())} ({p1.x/1e6:.3f}, {p1.y/1e6:.3f}) -> ({p2.x/1e6:.3f}, {p2.y/1e6:.3f})")
