import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
try:
    import wx
    wx.DisableAsserts()
except Exception:
    pass
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

for test_x in [26.5, 27.0, 27.5, 28.5, 29.0]:
    v_ok, v_r = geom.is_via_legal(test_x, 5.600, '/I2C_SCL')
    print(f"Via at ({test_x:.1f}, 5.600): {v_ok} ({v_r})")
