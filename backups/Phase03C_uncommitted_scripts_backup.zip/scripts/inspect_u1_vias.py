import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print("VIAS under U1 (X: 41..45, Y: 3.0..6.5):")
for t in b.GetTracks():
    if isinstance(t, pcbnew.PCB_VIA):
        pos = t.GetPosition()
        px, py = pos.x / 1e6, pos.y / 1e6
        if 41.0 <= px <= 45.0 and 3.0 <= py <= 6.5:
            print(f"  VIA [{t.GetNetname()}] at ({px:.3f}, {py:.3f})")

sys.exit(0)
