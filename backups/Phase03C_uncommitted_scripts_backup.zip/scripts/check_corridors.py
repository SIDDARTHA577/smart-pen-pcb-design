import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

import pcbnew
import math
from astar_miso import track_clear, via_clear, in1, in2, bcu, fcu

board = pcbnew.LoadBoard('scratch_test_mosi_flawless.kicad_pcb')

print("Searching for In1.Cu transit corridors:")
for yi in range(5, 35):
    y = yi * 0.1
    c = track_clear(in1, 42.5, y, 57.0, y)
    if c:
        print(f"  In1.Cu clear at Y={y:.2f}")

print("\nSearching for In2.Cu transit corridors:")
for yi in range(5, 35):
    y = yi * 0.1
    c = track_clear(in2, 43.5, y, 56.0, y)
    if c:
        print(f"  In2.Cu clear at Y={y:.2f}")

print("\nSearching for B.Cu transit corridors:")
for yi in range(5, 35):
    y = yi * 0.1
    c = track_clear(bcu, 42.5, y, 57.0, y)
    if c:
        print(f"  B.Cu clear at Y={y:.2f}")
