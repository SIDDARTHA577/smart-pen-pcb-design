import pcbnew
import heapq
import math

board = pcbnew.LoadBoard('scratch_test_mosi_flawless.kicad_pcb')

fcu = board.GetLayerID('F.Cu')
in1 = board.GetLayerID('In1.Cu')
in2 = board.GetLayerID('In2.Cu')
bcu = board.GetLayerID('B.Cu')

net_name = '/SD_MISO'
target_net = board.FindNet(net_name)

# Start and end
start_pt = (41.630, 2.435) # U1.10
end_pt = (59.150, 4.200)   # J_SD.5

# Let's collect all existing items (pads, tracks, vias)
# grouped by layer
items_by_layer = {fcu: [], in1: [], in2: [], bcu: []}
all_vias = []

for f in board.GetFootprints():
    for p in f.Pads():
        if p.GetNetname() == net_name:
            continue
        pos = p.GetPosition()
        x, y = pcbnew.ToMM(pos.x), pcbnew.ToMM(pos.y)
        sx, sy = pcbnew.ToMM(p.GetSizeX()), pcbnew.ToMM(p.GetSizeY())
        # which layers?
        for lid in [fcu, in1, in2, bcu]:
            if p.IsOnLayer(lid):
                items_by_layer[lid].append({
                    'type': 'pad',
                    'ref': f'{f.GetReference()}.{p.GetNumber()}',
                    'x': x, 'y': y, 'sx': sx, 'sy': sy
                })

for t in board.GetTracks():
    if t.GetNetname() == net_name:
        continue
    if isinstance(t, pcbnew.PCB_VIA):
        pos = t.GetPosition()
        x, y = pcbnew.ToMM(pos.x), pcbnew.ToMM(pos.y)
        d = pcbnew.ToMM(t.GetDrill())
        w = pcbnew.ToMM(t.GetWidth(pcbnew.F_Cu))
        v_data = {'type': 'via', 'net': t.GetNetname(), 'x': x, 'y': y, 'drill': d, 'width': w}
        all_vias.append(v_data)
        for lid in [fcu, in1, in2, bcu]:
            items_by_layer[lid].append(v_data)
    else:
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = pcbnew.ToMM(p1.x), pcbnew.ToMM(p1.y)
        x2, y2 = pcbnew.ToMM(p2.x), pcbnew.ToMM(p2.y)
        w = pcbnew.ToMM(t.GetWidth())
        lid = t.GetLayer()
        if lid in items_by_layer:
            items_by_layer[lid].append({
                'type': 'track',
                'net': t.GetNetname(),
                'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2, 'w': w
            })

print(f"Collected obstacles: vias={len(all_vias)}")
for lid in [fcu, in1, in2, bcu]:
    print(f"  Layer {board.GetLayerName(lid)}: {len(items_by_layer[lid])} obstacles")

# Clearance check function for a track segment
def track_clear(lid, x1, y1, x2, y2, w=0.15, req_clear=0.15):
    # check board edge
    if min(y1, y2) - w/2.0 < 0.25 or max(y1, y2) + w/2.0 > 8.95:
        return False
    # check all obstacles on layer
    for ob in items_by_layer[lid]:
        if ob['type'] == 'pad':
            # pad distance to line segment
            dx = max(0.0, abs((x1+x2)/2.0 - ob['x']) - ob['sx']/2.0)
            dy = max(0.0, abs((y1+y2)/2.0 - ob['y']) - ob['sy']/2.0)
            dist = math.hypot(dx, dy)
            if dist - w/2.0 < req_clear:
                return False
        elif ob['type'] == 'via':
            # distance from circle to segment
            vx, vy = ob['x'], ob['y']
            dx, dy = x2 - x1, y2 - y1
            l2 = dx*dx + dy*dy
            if l2 == 0:
                d = math.hypot(vx - x1, vy - y1)
            else:
                tp = max(0.0, min(1.0, ((vx - x1)*dx + (vy - y1)*dy) / l2))
                px = x1 + tp * dx
                py = y1 + tp * dy
                d = math.hypot(vx - px, vy - py)
            if d - ob['width']/2.0 - w/2.0 < req_clear:
                return False
        elif ob['type'] == 'track':
            # approximate distance between segments
            # check endpoints and midpoint
            for mx, my in [(x1, y1), (x2, y2), ((x1+x2)/2.0, (y1+y2)/2.0)]:
                tx1, ty1, tx2, ty2 = ob['x1'], ob['y1'], ob['x2'], ob['y2']
                tdx, tdy = tx2 - tx1, ty2 - ty1
                tl2 = tdx*tdx + tdy*tdy
                if tl2 == 0:
                    d = math.hypot(mx - tx1, my - ty1)
                else:
                    tp = max(0.0, min(1.0, ((mx - tx1)*tdx + (my - ty1)*tdy) / tl2))
                    d = math.hypot(mx - (tx1 + tp*tdx), my - (ty1 + tp*tdy))
                if d - ob['w']/2.0 - w/2.0 < req_clear:
                    return False
    return True

# Clearance check for through-via
def via_clear(x, y, via_w=0.5, drill=0.3, req_clear=0.15, req_hole_clear=0.25):
    # board edge
    if y - via_w/2.0 < 0.25 or y + via_w/2.0 > 8.95:
        return False
    for ob in all_vias:
        d = math.hypot(x - ob['x'], y - ob['y'])
        if d - via_w/2.0 - ob['width']/2.0 < req_clear:
            return False
        if d - drill/2.0 - ob['drill']/2.0 < req_hole_clear:
            return False
    # check against pads and tracks on all 4 layers
    for lid in [fcu, in1, in2, bcu]:
        for ob in items_by_layer[lid]:
            if ob['type'] == 'pad':
                dx = max(0.0, abs(x - ob['x']) - ob['sx']/2.0)
                dy = max(0.0, abs(y - ob['y']) - ob['sy']/2.0)
                d = math.hypot(dx, dy)
                if d - via_w/2.0 < req_clear:
                    return False
            elif ob['type'] == 'track':
                x1, y1, x2, y2 = ob['x1'], ob['y1'], ob['x2'], ob['y2']
                dx, dy = x2 - x1, y2 - y1
                l2 = dx*dx + dy*dy
                if l2 == 0:
                    d = math.hypot(x - x1, y - y1)
                else:
                    tp = max(0.0, min(1.0, ((x - x1)*dx + (y - y1)*dy) / l2))
                    d = math.hypot(x - (x1 + tp*dx), y - (y1 + tp*dy))
                if d - via_w/2.0 - ob['w']/2.0 < req_clear:
                    return False
    return True

print("Checking test points...")
print("Via (57.6, 2.7):", via_clear(57.6, 2.7))
print("Via (57.6, 3.1):", via_clear(57.6, 3.1))
print("Via (41.63, 0.6):", via_clear(41.63, 0.6))
print("Via (41.63, 0.8):", via_clear(41.63, 0.8))
