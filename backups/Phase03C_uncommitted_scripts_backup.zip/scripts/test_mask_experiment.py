import pcbnew
import subprocess
import json
from pathlib import Path

candidate_pcb = Path("output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb")
board = pcbnew.LoadBoard(str(candidate_pcb))
ds = board.GetDesignSettings()
ds.m_SolderMaskExpansion = int(0.025 * 1e6) # 0.025 mm

# Also set U1 pad 33 solder mask margin to 0
u1 = board.FindFootprintByReference("U1")
pad33 = u1.FindPadByNumber("33")
pad33.SetLocalSolderMaskMargin(int(-0.025 * 1e6)) # cancel the 0.025 expansion so pad 33 has 0 expansion

test_file = Path("scratch_mask_test.kicad_pcb")
board.Save(str(test_file))

res = subprocess.run([
    r"C:\Users\goran\AppData\Local\Programs\KiCad\10.0\bin\kicad-cli.exe",
    "pcb", "drc", "--severity-all", "--format", "json", "-o", "scratch_mask_drc.json", str(test_file)
], capture_output=True, text=True)

with open("scratch_mask_drc.json", "r", encoding="utf-8") as f:
    d = json.load(f)

v = d.get("violations", [])
sm_bridges = [item for item in v if item.get("type") == "solder_mask_bridge"]
print(f"Total violations: {len(v)}")
print(f"Solder mask bridges remaining: {len(sm_bridges)}")
for b in sm_bridges:
    print(" ", b.get("description"), [it.get("description") for it in b.get("items", [])])

test_file.unlink(missing_ok=True)
Path("scratch_mask_drc.json").unlink(missing_ok=True)

