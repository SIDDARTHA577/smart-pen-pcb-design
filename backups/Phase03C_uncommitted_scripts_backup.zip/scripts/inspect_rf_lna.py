import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

for t in board.GetTracks():
    if t.GetNetname() == '/RF_LNA':
        s, e = t.GetStart(), t.GetEnd()
        print(f'RF_LNA track: ({s.x/1e6:.3f}, {s.y/1e6:.3f}) -> ({e.x/1e6:.3f}, {e.y/1e6:.3f}), len={t.GetLength()/1e6:.3f}')

