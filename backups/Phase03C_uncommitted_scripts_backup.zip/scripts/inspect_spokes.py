import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

for comp_pad in [('U3', '17'), ('C7', '2'), ('C6', '2'), ('U2', '2')]:
    fp = board.FindFootprintByReference(comp_pad[0])
    pad = fp.FindPadByNumber(comp_pad[1])
    pos = pad.GetPosition()
    print(f'{comp_pad[0]}.{comp_pad[1]} at ({pos.x/1e6:.3f}, {pos.y/1e6:.3f}), size ({pad.GetSize().x/1e6:.3f}, {pad.GetSize().y/1e6:.3f})')

