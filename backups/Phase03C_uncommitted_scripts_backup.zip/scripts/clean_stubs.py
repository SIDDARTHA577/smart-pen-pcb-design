import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

to_remove = []

for t in board.GetTracks():
    net = t.GetNetname()
    if isinstance(t, pcbnew.PCB_VIA):
        pos = t.GetPosition()
        px, py = round(pos.x/1e6, 3), round(pos.y/1e6, 3)
        # Dangling RF_LNA via
        if net == '/RF_LNA' and px == 51.5 and py == 6.25:
            to_remove.append(t)
        # Dangling 3V3_RF via
        elif net == '/3V3_RF' and px == 38.5 and py == 5.8:
            to_remove.append(t)
        # Dangling USB_DP_CORE via colliding with UART_RX
        elif net == '/USB_DP_CORE' and px == 54.5 and py == 7.6:
            to_remove.append(t)
        # Dangling VBAT via
        elif net == '/VBAT' and px == 67.4 and py == 1.0:
            to_remove.append(t)
    else:
        s = t.GetStart()
        e = t.GetEnd()
        sx, sy = round(s.x/1e6, 3), round(s.y/1e6, 3)
        ex, ey = round(e.x/1e6, 3), round(e.y/1e6, 3)
        l = round(t.GetLength()/1e6, 3)
        
        # Dangling RF_LNA stub
        if net == '/RF_LNA' and sx == 39.5 and ex == 39.5 and sy == 6.59 and ey == 6.25:
            to_remove.append(t)
        # Dangling 3V3_RF stub
        elif net == '/3V3_RF' and sx == 46.705 and ex == 46.705 and sy == 7.55 and ey == 5.8:
            to_remove.append(t)
        # Dangling 3V3_RF stub to 38.5
        elif net == '/3V3_RF' and sx == 40.48 and ex == 38.5:
            to_remove.append(t)
        # Dangling SD_CS stub colliding with D4
        elif net == '/SD_CS' and sx == 59.65 and ex == 59.65 and sy == 4.2 and ey == 0.85:
            to_remove.append(t)
        # Dangling CHG_PROG stub
        elif net == '/CHG_PROG' and sx == 66.3 and ex == 66.3 and sy == 5.373 and ey == 6.225:
            to_remove.append(t)
        # Dangling LED_RED_SINK stub
        elif net == '/LED_RED_SINK' and sx == 23.25 and ex == 23.25 and sy == 2.75 and ey == 1.15:
            to_remove.append(t)
        # Dangling VBAT stub to 67.4, 1.0
        elif net == '/VBAT' and sx == 67.4 and ex == 67.4 and sy == 1.0 and ey == 1.4:
            to_remove.append(t)
        # Dangling USB_DP_PORT stub to 8.65 colliding with R5
        elif net == '/USB_DP_PORT' and sx == 78.15 and ex == 78.15 and sy == 3.1 and ey == 8.65:
            to_remove.append(t)
        # Dangling USB_DM_PORT stub to 8.05 colliding with R6
        elif net == '/USB_DM_PORT' and sx == 78.65 and ex == 78.65 and sy == 3.1 and ey == 8.05:
            to_remove.append(t)
        # USB_DP_CORE stub to 54.5, 7.6
        elif net == '/USB_DP_CORE' and sx == 54.5 and ex == 54.5 and sy == 8.65 and ey == 7.6:
            to_remove.append(t)
        # USB_DM_CORE stub (72.95, 7.025 to 73.0, 7.025)
        elif net == '/USB_DM_CORE' and sx == 72.95 and ex == 73.0 and sy == 7.025 and ey == 7.025:
            to_remove.append(t)

print(f'Removing {len(to_remove)} dangling items')
for t in to_remove:
    board.Remove(t)

# Fix TOUCH_OUT via: move from (39.7, 2.75) to (39.7, 3.35)
for t in board.GetTracks():
    if t.GetNetname() == '/TOUCH_OUT':
        if isinstance(t, pcbnew.PCB_VIA):
            pos = t.GetPosition()
            px, py = round(pos.x/1e6, 2), round(pos.y/1e6, 2)
            if px == 39.7 and py == 2.75:
                t.SetPosition(pcbnew.VECTOR2I(int(39.7*1e6), int(3.35*1e6)))
                print('Moved TOUCH_OUT via to (39.7, 3.35)')
        else:
            # adjust connected tracks
            s = t.GetStart()
            e = t.GetEnd()
            sx, sy = round(s.x/1e6, 2), round(s.y/1e6, 2)
            ex, ey = round(e.x/1e6, 2), round(e.y/1e6, 2)
            if sx == 39.7 and sy == 2.75:
                t.SetStart(pcbnew.VECTOR2I(int(39.7*1e6), int(3.35*1e6)))
            if ex == 39.7 and ey == 2.75:
                t.SetEnd(pcbnew.VECTOR2I(int(39.7*1e6), int(3.35*1e6)))

board.Save('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
print('Saved updated candidate board')

