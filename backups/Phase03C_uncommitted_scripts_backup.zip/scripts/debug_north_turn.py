import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

s1, r1 = geom.is_segment_legal(58.650, 4.200, 58.650, 4.850, 'F.Cu', '/SD_MOSI')
s2, r2 = geom.is_segment_legal(58.650, 4.850, 58.200, 4.850, 'F.Cu', '/SD_MOSI')
print("s1:", s1, r1)
print("s2:", s2, r2)
