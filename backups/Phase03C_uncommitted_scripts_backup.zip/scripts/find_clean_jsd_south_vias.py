import pcbnew, math

b = pcbnew.LoadBoard("scratch_test_fcu_cs_clean.kicad_pcb")

nearby_pads = []
for fp in b.GetFootprints():
    for p in fp.Pads():
        pos = p.GetPosition()
        x, y = pos.x/1e6, pos.y/1e6
        if 55.0 <= x <= 61.0 and 0.0 <= y <= 7.0:
            nearby_pads.append((fp.GetReference(), p.GetNumber(), p.GetNetname(), x, y, p.GetSize().x/1e6, p.GetSize().y/1e6))

def check_via_legal(netname, vx, vy, v_dia=0.50):
    for ref, pnum, pnet, px, py, sx, sy in nearby_pads:
        if pnet == netname:
            continue
        dx = max(0, abs(vx - px) - sx/2)
        dy = max(0, abs(vy - py) - sy/2)
        dist = math.hypot(dx, dy)
        if dist < (v_dia/2 + 0.150):
            return False, f"Collision with {ref}.{pnum} ({pnet}) dist={dist:.3f}"
    return True, "OK"

for net, x in [('/SD_SCK', 58.150), ('/SD_MOSI', 58.650), ('/SD_MISO', 59.150)]:
    legal_ys = []
    for y_int in range(48, 65):
        y = y_int / 10.0
        ok, reason = check_via_legal(net, x, y)
        if ok:
            legal_ys.append(y)
    print(f"Net {net} at X={x:.3f} legal Ys in [4.8, 6.4]: {legal_ys}")
