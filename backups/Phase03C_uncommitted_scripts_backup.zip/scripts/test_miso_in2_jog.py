import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

s, r = geom.is_segment_legal(41.400, 1.600, 41.400, 2.050, 'In2.Cu', '/SD_MISO')
print("SD_MISO In2.Cu vertical (41.40, 1.60 -> 2.05):", s, r)
s_h, r_h = geom.is_segment_legal(41.400, 2.050, 43.000, 2.050, 'In2.Cu', '/SD_MISO')
print("SD_MISO In2.Cu horizontal to 43.0:", s_h, r_h)
