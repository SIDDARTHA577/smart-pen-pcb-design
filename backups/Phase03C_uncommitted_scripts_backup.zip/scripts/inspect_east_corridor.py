import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

print('--- COMPONENTS/PADS in X: 45..52, Y: 3.8..7.2 ---')
for p in board.GetPads():
    pos = p.GetPosition()
    x, y = pos.x / 1e6, pos.y / 1e6
    if 45.0 <= x <= 52.0 and 3.8 <= y <= 7.2:
        fp = p.GetParentFootprint()
        ref = fp.GetReference() if fp else '?'
        if ref != 'U1':
            print(f'{ref}.{p.GetNumber()} [{p.GetNetname()}] at ({x:.3f}, {y:.3f}) layer {p.GetLayerName()}')

