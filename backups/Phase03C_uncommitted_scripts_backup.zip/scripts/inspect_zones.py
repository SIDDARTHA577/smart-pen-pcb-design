import pcbnew

board = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')

for i, z in enumerate(board.Zones()):
    layers = [board.GetLayerName(l) for l in z.GetLayerSet().Seq()]
    print(f'Zone {i}: layers {layers}, net {z.GetNetname()}, pad connection: {z.GetPadConnection()}')
