import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")
bcu = b.GetLayerID('B.Cu')

print("--- Objects on B.Cu between X=52.5 and 66.0, Y in [0.0, 1.5] ---")
for t in b.GetTracks():
    if t.GetClass() == 'PCB_VIA':
        p = t.GetPosition()
        x, y = p.x/1e6, p.y/1e6
        if 52.5 <= x <= 66.0 and 0.0 <= y <= 1.5:
            print(f"VIA Net: {t.GetNetname()} at ({x:.3f}, {y:.3f})")
    elif t.GetLayer() == bcu:
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (52.5 <= x1 <= 66.0 or 52.5 <= x2 <= 66.0) and (0.0 <= y1 <= 1.5 or 0.0 <= y2 <= 1.5):
            print(f"TRK Net: {t.GetNetname()} ({x1:.3f}, {y1:.3f}) -> ({x2:.3f}, {y2:.3f})")
