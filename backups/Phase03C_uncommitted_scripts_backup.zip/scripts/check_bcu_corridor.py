import pcbnew

b = pcbnew.LoadBoard("scratch_test_restore_vsys.kicad_pcb")
bcu = b.GetLayerID('B.Cu')

print("--- ALL B.Cu TRACKS between X=40 and 60 ---")
for t in b.GetTracks():
    if t.GetLayer() == bcu and not isinstance(t, pcbnew.PCB_VIA):
        p1, p2 = t.GetStart(), t.GetEnd()
        x1, y1 = p1.x/1e6, p1.y/1e6
        x2, y2 = p2.x/1e6, p2.y/1e6
        if (40 <= x1 <= 60 or 40 <= x2 <= 60):
            print(f"TRK Net: {t.GetNetname()} ({x1:.3f}, {y1:.3f}) -> ({x2:.3f}, {y2:.3f}) W: {t.GetWidth()/1e6:.3f}")

print("\n--- ALL VIAS between X=40 and 60 ---")
for t in b.GetTracks():
    if isinstance(t, pcbnew.PCB_VIA):
        p = t.GetPosition()
        x, y = p.x/1e6, p.y/1e6
        if 40 <= x <= 60 and 0 <= y <= 3.5:
            print(f"VIA Net: {t.GetNetname()} Pos: ({x:.3f}, {y:.3f})")
