import os, sys
os.environ["WXSUPPRESS_SIZER_FLAGS_CHECK"] = "1"
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('output/RevG/variants/FourLayer_Candidate/SmartPen.kicad_pcb')
geom = BoardGeometry(b)

# 1. /VSYS_RAW:
# SW3.1 is at (60.963, 6.824)
# Q2.2 is at (61.700, 3.450)
# D4.1 is at (59.000, 2.400)
# Let's test on B.Cu:
# Via near SW3.1: (60.000, 6.824) -> B.Cu (60.000, 6.824) -> (60.000, 2.400)
# Via near D4.1: (60.000, 2.400) -> F.Cu to D4.1 (59.000, 2.400)
# And tap to Q2.2 (61.700, 3.450)
print("Checking VSYS_RAW:")
for x in [59.5, 60.0, 60.5]:
    for y in [6.5, 6.8, 7.0]:
        v_ok, r = geom.is_via_legal(x, y, '/VSYS_RAW')
        if v_ok:
            print(f"  Legal via near SW3.1 at ({x},{y})")

for x in [59.5, 60.0, 60.5]:
    for y in [2.2, 2.4, 2.6, 2.8]:
        v_ok, r = geom.is_via_legal(x, y, '/VSYS_RAW')
        if v_ok:
            print(f"  Legal via near D4.1 at ({x},{y})")

# 2. /VBAT:
# J_BAT.1 is at (62.300, 1.720)
# C12.1 is at (67.400, 1.400)
# U2.3 is at (67.950, 2.770)
# Q2.3 is at (63.900, 4.400)
print("\nChecking VBAT:")
v1_ok, r1 = geom.is_via_legal(62.300, 1.000, '/VBAT')
v2_ok, r2 = geom.is_via_legal(67.400, 1.000, '/VBAT')
print(f"  Via at (62.3, 1.0): {v1_ok}, Via at (67.4, 1.0): {v2_ok}")
# On B.Cu from (62.3, 1.0) to (67.4, 1.0)
s_bat, rb = geom.is_segment_legal(62.300, 1.000, 67.400, 1.000, 'B.Cu', '/VBAT')
print(f"  B.Cu run: {s_bat} ({rb})")

sys.exit(0)
