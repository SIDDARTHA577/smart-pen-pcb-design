import sys
sys.path.append('scripts')
import pcbnew
from strict_clearance_checker import BoardGeometry

b = pcbnew.LoadBoard('scratch_test_vip.kicad_pcb')
geom = BoardGeometry(b)

print("Checking vias for SD_MISO in X in [59.2, 60.0], Y in [0.5, 3.0]:")
for vx in [59.2, 59.3, 59.4, 59.5, 59.6, 59.7, 59.8, 59.9, 60.0]:
    for vy in [0.5, 0.7, 0.9, 1.1, 1.3, 1.5, 1.7, 1.9, 2.1, 2.3, 2.5, 2.7, 2.9]:
        v, rv = geom.is_via_legal(vx, vy, '/SD_MISO')
        if v:
            print(f"  Via OK at ({vx:.2f}, {vy:.2f})")
